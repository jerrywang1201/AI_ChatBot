from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import

from radarclient import compat
import subprocess
import plistlib
import re
import os
import webbrowser
from .utilities import logger


class RadarGUI(object):
    """
    Collection of utilities for interacting with the Radar 8 application on macOS.
    """

    @classmethod
    def attachment_download_cache_parent_directory_path(cls):
        """
        Return the path to the parent directory into which the Radar app
        downloads attachments when the user double-clicks them or uses the
        "Show in Finder" menu command. The Radar app creates a sub-directory
        per Radar ID in this parent directory, and indivdual attachments
        get download into that per-ID directory.
        
        :return: path to parent directory
        """
        result = None
        cmd = ['defaults', 'read', 'com.apple.radar.gm', 'PreferredAttachmentDownloadCachePath']
        try:
            result = subprocess.check_output(cmd, stderr=subprocess.PIPE).decode('utf-8').strip()
        except subprocess.CalledProcessError:
            result = '~/Library/Application Support/Radar'

        if not result:
            raise Exception('Unable to get attachment download cache parent directory path using "{}"'.format(' '.join(cmd)))

        return os.path.expanduser(result + '/Downloads/Problem')

    @classmethod
    def attachment_save_to_downloads_folder_path(cls):
        """
        Return the path to the parent directory into which the Radar app
        downloads attachments when the user uses the "Save to Downloads Folder"
        menu command.
                
        :return: path to parent directory
        """
        result = None
        cmd = ['defaults', 'read', 'com.apple.radar.gm', 'ELIBPreferredDownloadPath']
        try:
            result = subprocess.check_output(cmd, stderr=subprocess.PIPE).decode('utf-8').strip()
        except subprocess.CalledProcessError:
            result = '~/Library/Application Support/Radar/Downloads'

        if not result:
            raise Exception('Unable to get attachment download parent directory path for option --downloads-folder because no such folder is configured in the Radar app. Try using --downloads instead or configure it in Radar\'s settings.')

        return os.path.expanduser(result)

    @classmethod
    def front_window_selected_radar_ids(cls):
        """
        Return a list of Radar IDs selected in the front window.
        If the front window is some kind of problem list, returns the items selected in that list.
        If the front window is a problem detail window, this returns an empty list unless items
        are selected in the Related Problems tab.

        :return: List of Radar IDs integers, can be empty
        """
        result_data = cls.radar_app_ui_state_information()
        if not (result_data and 'front_window_selection' in result_data):
            return []
        front_window_selection = result_data['front_window_selection']

        if cls.looks_like_list_of_integer_strings(front_window_selection):
            return [int(x) for x in front_window_selection]
        return []

    @classmethod
    def front_window_radar_id(cls):
        """
        Return the Radar ID for the front window.
        If the front window is some kind of problem list, returns None.
        If the front window is a problem detail window, returns its Radar ID.

        :return: Radar ID or None
        """
        result_data = cls.radar_app_ui_state_information()
        if not (result_data and 'front_window_radar_id' in result_data):
            return []
        front_window_radar_id = result_data['front_window_radar_id']
        if cls.looks_like_integer_string(front_window_radar_id):
            return int(front_window_radar_id)
        
        return None

    @classmethod
    def front_window_radar_id_or_selected_radar_ids(cls):
        """
        Return a list with either the front window Radar ID, if there is one,
        or the Radar IDs selected in the front window.

        This is intended as a convenience wrapper method for getting whatever
        Radar ID(s) the user probably intended to work with.

        :return: List of Radar ID integers
        """
        radar_id = cls.front_window_radar_id()
        if radar_id:
            return [radar_id]
        return cls.front_window_selected_radar_ids()

    @classmethod
    def radar_app_ui_state_information(cls):
        cmd = ['osascript', '-']
        try:
            result = subprocess.run(cmd, capture_output=True, input=cls.selected_radar_ids_applescript_query().encode('utf-8'))
            if result.returncode:
                logger.error('Unable to get Radar app UI state: {}'.format(result.stderr))
                return None
            return plistlib.loads(result.stdout)
        except:
            return None

    @staticmethod
    def selected_radar_ids_applescript_query():
        return '''\
            use AppleScript version "2.4"

            set my_selection to []
            set front_window_radar_id to ""

            set radarApplication to application id "com.apple.radar.gm"
            if radarApplication is running then
                tell radarApplication
                    if (count of windows) > 0 then
                        set front_window to window 1
                        set my_selection to selection of front_window
                        set front_window_radar_id to getProblemID of front_window
                    end if
                end tell
            end if

            tell application "System Events"
                set result_data to {front_window_selection:my_selection, front_window_radar_id:front_window_radar_id}
                set root_plist_item to make new property list item with properties {kind:record, value:result_data}
            end tell

            return text of root_plist_item
        '''

    @classmethod
    def looks_like_list_of_integer_strings(cls, items):
        if type(items) != list:
            return False
        for item in items:
            if cls.looks_like_integer_string(item):
                continue
            return False
        return True
        
    @staticmethod
    def looks_like_integer_string(item):
        number_re = re.compile(r'^\d+$')
        if isinstance(item, compat.string_types):
            if number_re.match(item):
                return True
        return False

    @staticmethod
    def _open_items_in_radar(ids, path=''):
        """
        Open a list of int IDs in radar

        :param ids: list of IDs
        :param path: the short string that is part of the path in the URL like "ts" for test suites

        :return: None
        """
        str_id_gen = (str(item_id) for item_id in ids)
        if path != '':
            path = '{}/'.format(path)

        url = 'rdar8://{}{}'.format(path, '&'.join(str_id_gen))
        webbrowser.open(url)

    @staticmethod
    def open_radar_ids_in_radar(radar_ids):
        """
        Opens all radars for ``radar_ids`` in Radar

        :param iter radar_ids: IDs of radars to be opened

        :return: None
        """
        RadarGUI._open_items_in_radar(radar_ids)

    @staticmethod
    def open_radar_id_in_radar(radar_id):
        """
        Open a single radar ID in Radar

        :param int radar_id: radar ID to open

        :return: None
        """
        RadarGUI.open_radar_ids_in_radar([radar_id])

    @staticmethod
    def open_radars_in_radar(radars):
        """
        Opens :py:class:`~radarclient.model.Radar` objects in Radar

        :param list radars: List of :py:class:`~radarclient.client.Radar` objects to open in Radar

        :return: None
        """
        RadarGUI.open_radar_ids_in_radar((radar.id for radar in radars))

    @staticmethod
    def open_radar_in_radar(radar):
        """
        Opens a single :py:class:`~radarclient.model.Radar` object in Radar

        :param Radar radar: :py:class:`~radarclient.model.Radar` to open in Radar

        :return: None
        """
        RadarGUI.open_radar_ids_in_radar([radar.id])

    @staticmethod
    def open_test_suite_ids_in_radar(test_suite_ids):
        """
        Open multiple test suites in Radar using their IDs

        :param iter[int] test_suite_ids: iterator of test suite IDs to open

        :return: None
        """
        RadarGUI._open_items_in_radar(test_suite_ids, path='ts')

    @staticmethod
    def open_test_suite_id_in_radar(test_suite_id):
        """
        Open a test suite using its ID in Radar

        :param int test_suite_id: Test suite ID to open in radar

        :return: None
        """
        RadarGUI.open_test_suite_ids_in_radar([test_suite_id])

    @staticmethod
    def open_test_suites_in_radar(test_suites):
        """
        Open multiple test suites in Radar using TestSuites

        :param list[TestSuite] test_suites: List of :py:class:`~radarclient.model.TestSuite` objects to open in Radar

        :return: None
        """
        RadarGUI.open_test_suite_ids_in_radar((suite.database_id_attribute_value() for suite in test_suites))

    @staticmethod
    def open_test_suite_in_radar(test_suite):
        """
        Open a test suite in Radar using a TestSuite

        :param TestSuite test_suite: :py:class:`~radarclient.model.TestSuite` object to open in Radar

        :return: None
        """
        RadarGUI.open_test_suites_in_radar([test_suite])

    @staticmethod
    def open_test_case_ids_in_radar(test_case_ids):
        """
        Open multiple test cases in Radar using their IDs

        :param iter[int] test_case_ids: iterator of test case IDs to use

        :return: None
        """
        RadarGUI._open_items_in_radar(test_case_ids, path='tsc')

    @staticmethod
    def open_test_case_id_in_radar(test_case_id):
        """
        Open a test case in Radar using its ID

        :param int test_case_id: ID of test case to open

        :return: None
        """
        RadarGUI.open_test_case_ids_in_radar([test_case_id])

    @staticmethod
    def open_test_cases_in_radar(test_cases):
        """
        Open multiple test cases in Radar using TestCase objects

        :param list[TestCase] test_cases: List of TestCase objects to open

        :return: None
        """
        RadarGUI.open_test_case_ids_in_radar((test_case.database_id_attribute_value() for test_case in test_cases))

    @staticmethod
    def open_test_case_in_radar(test_case):
        """
        Open a test case in Radar using a TestCase object

        :param TestCase test_case: TestCase object to open in Radar

        :return: None
        """
        RadarGUI.open_test_case_ids_in_radar([test_case.database_id_attribute_value()])

    @staticmethod
    def open_scheduled_test_ids_in_radar(test_ids):
        """
        Open multiple scheduled tests in Radar using their IDs

        :param iter[int] test_ids: iterator of IDs to open

        :return: None
        """
        RadarGUI._open_items_in_radar(test_ids, path='st')

    @staticmethod
    def open_scheduled_test_id_in_radar(test_id):
        """
        Open a scheduled test in Radar using its ID

        :param int test_id: ID of scheduled test to open

        :return: None
        """
        RadarGUI.open_scheduled_test_ids_in_radar([test_id])

    @staticmethod
    def open_scheduled_tests_in_radar(scheduled_tests):
        """
        Open multiple scheduled tests in Radar using ScheduledTest objects

        :param list[ScheduledTest] scheduled_tests: list of ScheduledTest objects to open

        :return: None
        """
        RadarGUI.open_scheduled_test_ids_in_radar((scheduled_test.database_id_attribute_value() for scheduled_test in
                                                   scheduled_tests))

    @staticmethod
    def open_scheduled_test_in_radar(scheduled_test):
        """
        Open a scheduled test in Radar using a ScheduledTest object

        :param ScheduledTest scheduled_test: ScheduledTest to open in Radar

        :return: None
        """
        RadarGUI.open_scheduled_test_ids_in_radar([scheduled_test.database_id_attribute_value()])

    @staticmethod
    def open_scheduled_test_case_ids_in_radar(case_ids):
        """
        Open multiple scheduled test cases in Radar using their IDs

        :param iter[int] case_ids: iterator of test case IDs to open

        :return: None
        """
        RadarGUI._open_items_in_radar(case_ids, path='stc')

    @staticmethod
    def open_scheduled_test_case_id_in_radar(case_id):
        """
        Open a scheduled test case in Radar using its ID

        :param int case_id: ID of scheduled test case to open

        :return: None
        """
        RadarGUI.open_scheduled_test_case_ids_in_radar([case_id])

    @staticmethod
    def open_scheduled_test_cases_in_radar(test_cases):
        """
        Open scheduled test cases in Radar using ScheduledTestCase objects

        :param list[ScheduledTestCase] test_cases: List of ScheduledTestCases to open

        :return: None
        """
        RadarGUI.open_scheduled_test_case_ids_in_radar((test_case.database_id_attribute_value() for test_case in
                                                        test_cases))

    @staticmethod
    def open_scheduled_test_case_in_radar(test_case):
        """
        Open a scheduled test case in Radar using a ScheduledTestCase

        :param ScheduledTestCase test_case: a ScheduledTestCase object to open in Radar

        :return: None
        """
        RadarGUI.open_scheduled_test_case_ids_in_radar([test_case.database_id_attribute_value()])
