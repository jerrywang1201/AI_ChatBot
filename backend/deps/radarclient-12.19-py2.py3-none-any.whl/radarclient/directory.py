#!/usr/bin/env python

# autopep8 -i --ignore E501 githelper.py

from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import base64
import collections
import json
import re
import subprocess
from functools import reduce
from .utilities import logger
from .environment import RadarEnvironment

LoggedInAppleConnectAccount = collections.namedtuple('LoggedInAppleConnectAccount', 'username full_username expired'.split())
"""
Named tuple to hold information about a logged in AppleConnect account.

Properties:

- ``username`` (without the ``@APPLECONNECT.APPLE.COM`` suffix)
- ``full_username`` (with the ``@APPLECONNECT.APPLE.COM`` suffix)
- ``expired`` (``True`` if expired)

"""

class AppleDirectoryUserEntry(object):
    """
    Represents an AppleDirectory user.
    """

    def __init__(self, ldif):
        # This currently doesn't handle multiline attribute values
        self.attributes = collections.defaultdict(list)
        for line in ldif.splitlines():
            pair = re.findall(r'^(\S+): (.*)', line)
            if not pair:
                continue
            attribute, value = pair[0]
            self.attributes[attribute].append(value)

    def attribute_values(self, key):
        return self.attributes[key]

    def attribute_value(self, key):
        if key in self.attributes:
            return self.attributes[key][0]
        return None

    def dsid(self):
        """
        Returns the user's DSID.

        """
        return int(self.attribute_value('internationaliSDNNumber'))

    def first_name(self):
        """
        Returns the user's first name.

        """
        return self.attribute_value('givenName')

    def last_name(self):
        """
        Returns the user's last name.

        """
        return self.attribute_value('sn')

    def email(self):
        """
        Returns the user's email.

        """
        return self.attribute_value('mail')

    def manager_dsid(self):
        """
        Find the DSID of the manager of the person represented by the receiver.

        :rtype: int
        :return: DSID of the manager

        Example::

            manager_dsid = user.manager_dsid()
            manager_user = radarclient.AppleDirectoryQuery.user_entry_for_dsid(manager_dsid)
            print(manager_user.email())

        """
        return AppleDirectoryQuery.manager_dsid_for_dsid(self.dsid())

    def __repr__(self):
        return '<AppleDirectoryUserEntry dsid={} {} {}>'.format(self.dsid(), self.first_name(), self.last_name())


class KerberosKlistOutputParser(object):

    def __init__(self, klist_tool_wrapper, radar_environment):
        self.klist_tool_wrapper = klist_tool_wrapper
        self.radar_environment = radar_environment

    def logged_in_appleconnect_accounts(self):
        json_cache_list = self.klist_tool_wrapper.cache_list_json_output()
        if json_cache_list is not None:
            return self.logged_in_appleconnect_accounts_from_json_cache_list(json_cache_list)
        else:
            return self.logged_in_appleconnect_accounts_from_parsing_klist_output()

    def logged_in_appleconnect_accounts_from_json_cache_list(self, cache_info_list):
        logger.debug('Getting logged in AppleConnect accounts from klist JSON output')
        accounts = []
        for cache_info in cache_info_list:
            name = cache_info['Name']
            components = name.split('@')
            if len(components) != 2:
                logger.info('Ignoring cache entry with unexpected name format: {}'.format(name))
                continue
            expired = cache_info['Expired'] == 'yes'
            account = self.parse_principal(components, expired)
            logger.debug('Logged in AppleConnect account: {} components={} expired={}'.format(account, components, expired))
            if account:
                if cache_info['Default Cache'] == 'yes':
                    logger.debug('Default account')
                    accounts.insert(0, account)
                else:
                    logger.debug('Not default account')
                    accounts.append(account)
        return accounts

    def logged_in_appleconnect_accounts_from_parsing_klist_output(self):
        logger.debug('Getting logged in AppleConnect accounts from klist plain text output')
        accounts = []
        cache_list_output = self.klist_tool_wrapper.cache_list_output().splitlines()
        state = 'waiting_for_header'
        while cache_list_output:
            output_line = cache_list_output.pop(0)
            if re.match(r'^(-|\s)*$', output_line):
                continue
            logger.debug('klist -l output line: {}'.format(output_line))

            if state == 'waiting_for_header':
                if 'Cache name' not in output_line:
                    continue
                if 'Principal name' in output_line:
                    state = 'linux_parse_entry'
                else:
                    state = 'macos_parse_entry'
            elif state == 'linux_parse_entry':
                account = self.linux_parse_entry(output_line)
                if account:
                    accounts.append(account)
            elif state == 'macos_parse_entry':
                account = self.macos_parse_entry(output_line)
                if account:
                    if output_line.startswith('* '):
                        accounts.insert(0, account)
                    else:
                        accounts.append(account)

        return accounts

    def linux_parse_entry(self, output_line):
        result = re.match(r'^(\S+)\s+(\S+)', output_line)
        if not result:
            logger.warning('Unexpected line in klist -l output: {}'.format(output_line))
            return None
        cache_id = result.group(2)
        # Linux klist -l truncates the principals in the list so we have
        # to additionally run klist -c with the cache ID to get the full
        # principal name
        klist_cache_info = self.klist_tool_wrapper.output_for_cache_id(cache_id)
        principal = self.principal_in_linux_cache_file_content(klist_cache_info)
        if principal:
            return self.parse_principal(principal, 'Expired' in output_line)
        return None

    def macos_parse_entry(self, output_line):
        result = re.match(r'^[\* ]*(\S+)@(\S+)', output_line)
        if not result:
            logger.warning('Unexpected line in klist -l output: {}'.format(output_line))
            return None
        # macOS klist does not truncate so we can use the entries directly from the list
        principal = result.group(1), result.group(2)
        return self.parse_principal(principal, 'Expired' in output_line)

    def parse_principal(self, principal, expired):
        username, realm = principal
        expected_realm = self.radar_environment.configuration_value('kerberos_realm')
        if realm == expected_realm:
            return LoggedInAppleConnectAccount(username=username, full_username='{}@{}'.format(username, realm), expired=expired)
        logger.info('Ignoring principal {}, not expected realm {}'.format(principal, expected_realm))
        return None

    def principal_in_linux_cache_file_content(self, klist_cache_info):
        result = re.search(r'principal: (\S+)@(\S+)$', klist_cache_info, flags=re.MULTILINE|re.IGNORECASE)
        if result:
            return result.group(1), result.group(2)
        logger.warning('Unable to find principal in klist -c output: {}'.format(klist_cache_info))
        return None


class AppleDirectoryQuery(object):
    """
    Utility class to query AppleDirectory.

    This class provides some helpers to get AppleConnect status and query AppleDirectory
    via LDAP. This can be useful for group membership tests.
    """

    LDAP_URL_NOD = 'ldap://nod.apple.com'
    LDAP_URL_LOOKUP = 'ldap://lookup.apple.com'

    @classmethod
    def logged_in_appleconnect_accounts(cls, radar_environment=RadarEnvironment.default_environment(), _unit_test_support_klist_output=None):
        """
        Return the list of logged in AppleConnect accounts on the system.

        :param radarclient.RadarEnvironment radar_environment: Optional RadarEnvironment instance, in case you need to target a different environment than production.
        :rtype: list[LoggedInAppleConnectAccount]

        Example::

            accounts = AppleDirectoryQuery.logged_in_appleconnect_accounts()
            # first one is the default account
            for account in accounts:
                print('AppleConnect account {}/{}, expired = {}'.format(account.full_username, account.username, account.expired))

        """

        klist_tool_wrapper = KerberosKlistToolWrapper()
        if _unit_test_support_klist_output:
            klist_tool_wrapper = KerberosKlistToolWrapperUnitTestDummy(_unit_test_support_klist_output.decode('utf-8'), {})

        klist_parser = KerberosKlistOutputParser(klist_tool_wrapper, radar_environment)
        return klist_parser.logged_in_appleconnect_accounts()

    @classmethod
    def user_entry_for_appleconnect_username(cls, username):
        """
        Return an :py:class:`AppleDirectoryUserEntry` instance for the given AppleDirectory username.

        :param str username: User's AppleConnect username
        :rtype: AppleDirectoryUserEntry

        Example::

            adUser = AppleDirectoryQuery.user_entry_for_appleconnect_username('foobar')
            print('AppleDirectory user {} {} ()'.format(adUser.first_name, adUser.last_name, adUser.email))

        """
        username += '@appleconnect.apple.com'
        return cls.user_entry_for_attribute_value('uid', username)

    @classmethod
    def user_entry_for_dsid(cls, dsid):
        """
        Like :py:meth:`AppleDirectoryQuery.user_entry_for_appleconnect_username`, but takes a DSID.

        :param int dsid: User's DSID
        :rtype: AppleDirectoryUserEntry
        """
        return cls.user_entry_for_attribute_value('internationaliSDNNumber', dsid)

    @classmethod
    def user_entries_for_dsids(cls, dsids):
        """
        Like :py:meth:`AppleDirectoryQuery.user_entry_for_dsid`, but takes a list of DSIDs.

        :param list[int] dsids: List of DSIDs
        :rtype: list[tuple[int, AppleDirectoryUserEntry or None]]

        The return value is a list of two-element tuples. The first tuple element is the DSID
        as passed in and the second element is the :py:class:`AppleDirectoryUserEntry` item,
        or `None` if the DSID could not be resolved. The tuples appear in the order of the
        input DSID list so you can map back 1:1.

        You can also construct a DSID-to-user-object mapping by passing the result list to the
        :py:class:`dict` constructor.

        Example::

            dsids = [1234, 5678, 91011]
            user_pairs = AppleDirectoryQuery.user_entries_for_dsids(dsids)
            user_map = dict(user_pairs)

            some_user = user_map[some_dsid]

        """
        return cls.user_entries_for_attribute_values('internationaliSDNNumber', dsids)

    @classmethod
    def user_entry_for_attribute_value(cls, name, value):
        attribute_value_user_pairs = cls.user_entries_for_attribute_values(name, [value])
        if not attribute_value_user_pairs:
            logger.error(u'Unable to find user for {} {}'.format(name, value))
            return None
        _, user = attribute_value_user_pairs[0]
        return user

    @staticmethod
    def reformat_ldif(text):
        def process_value(attribute, value, is_base64):
            if is_base64:
                if ';binary' not in attribute:
                    value = base64.b64decode(value).decode('utf-8')
                    if '\n' in value:
                        value = value.replace('\n', r'\n')
                else:
                    return '{}:: {}'.format(attribute, value)
            return '{}: {}'.format(attribute, value)

        attribute = None
        value = None
        is_base64 = False
        for line in text.splitlines():
            match = re.match(r'[\t ](.*)', line)
            if match:
                assert value
                value += match.group(1)
                continue

            if value:
                yield process_value(attribute, value, is_base64)
                attribute = None
                value = None

            match = re.match(r'([a-z0-9;-]+):(:|<)? (.*)', line, flags=re.IGNORECASE)
            if not match:
                yield line
                continue
            attribute = match.group(1)
            extra_separator = match.group(2)
            value = match.group(3)
            is_base64 = extra_separator == ':'

        if value:
            yield process_value(attribute, value, is_base64)


    @classmethod
    def user_entries_for_attribute_values(cls, name, values):
        query = '(|' + ''.join(['({}={})'.format(name, value) for value in values]) + ')'

        cmd = ['ldapsearch', '-LLL', '-x', '-H', cls.LDAP_URL_NOD, '-b', 'cn=users,dc=apple,dc=com', query]
        logger.debug('LDAP search command: {}'.format(cmd))
        output = subprocess.check_output(cmd)
        logger.debug('LDAP search output: {}'.format(output))

        reformatted = reduce(lambda a, b: a + b + '\n', cls.reformat_ldif(output.decode('utf-8')), '')

        entries = re.findall(r'(^dn: .*?\n\n)', reformatted, flags=re.MULTILINE|re.DOTALL)
        logger.debug('LDAP search {} results'.format(len(entries)))
        users = [AppleDirectoryUserEntry(entry) for entry in entries]
        mapping = {str(value).lower(): e for e in users for value in e.attribute_values(name)}
        return [(value, mapping.get(str(value).lower())) for value in values]

    @classmethod
    def member_dsid_list_for_group_name(cls, group_name):
        """
        Return the list of member DSIDs for a given AppleDirectory group name.

        :param str group_name: AppleDirectory group name
        :rtype: list[int]

        Example::

            team_member_ids = AppleDirectoryQuery.member_dsid_list_for_group_name('some team group name')
            radars = radar_client.radars_for_ids(list_of_radar_ids)
            radars_assigned_to_team = [radar for radar in radars if radar.assignee.dsid in team_member_ids]

        """
        cmd = ['ldapsearch', '-LLL', '-x', '-H', cls.LDAP_URL_NOD, '-b', 'cn=groups,dc=apple,dc=com', 'cn={}'.format(group_name), 'memberUid']
        output = [line.decode('utf-8') for line in subprocess.check_output(cmd).splitlines()]
        member_uids = [line[len('memberUid: '):] for line in output if 'memberUid: ' in line]

        dsid_list = []
        max_batch_size = 100
        for i in range(0, len(member_uids), max_batch_size):
            batch_member_uids = member_uids[i:i + max_batch_size]
            uid_query_items = ''.join(['(uid={})'.format(uid) for uid in batch_member_uids])
            cmd = 'ldapsearch -LLL -x -H {} -b cn=users,dc=apple,dc=com "(|{})" internationaliSDNNumber'.format(cls.LDAP_URL_NOD, uid_query_items)
            output = [line.decode('utf-8') for line in subprocess.check_output(cmd, shell=True).splitlines()]
            batch_member_uid_dsids = [int(line[len('internationaliSDNNumber: '):]) for line in output if 'internationaliSDNNumber: ' in line]
            dsid_list.extend(batch_member_uid_dsids)
        return dsid_list

    @classmethod
    def manager_dsid_for_dsid(cls, dsid):
        pairs = cls.manager_dsids_for_dsids([dsid])
        if not pairs:
            return None
        return pairs[0][1]

    @classmethod
    def manager_dsids_for_dsids(cls, dsids):
        """
        Given a list of DSIDs of some users, return the DSIDs of their managers.

        :param list[int] dsids: List of DSIDs
        :rtype: list[tuple[int, int or None]]

        The return value is a list of two-element tuples. The first tuple element is the DSID
        of a person as passed in and the second element is the DSID of that person's manager,
        or `None` if the manager DSID could not be determined. The tuples appear in the order of the
        input DSID list so you can map back 1:1.

        You can also construct a DSID-to-user-object mapping by passing the result list to the
        :py:class:`dict` constructor.

        Example::

            dsids = [1234, 5678, 91011]
            user_manager_pairs = AppleDirectoryQuery.manager_dsids_for_dsids(dsids)
            user_manager_map = dict(user_pairs)

            manager_dsid = user_manager_map[some_dsid]

        """
        query = '(|' + ''.join(['(appleDSID={})'.format(dsid) for dsid in dsids]) + ')'
        cmd = ['ldapsearch', '-LLL', '-x', '-H', cls.LDAP_URL_LOOKUP, '-b', 'ou=People,o=Apple', query, 'manager']
        output = [line.decode('utf-8') for line in subprocess.check_output(cmd).splitlines()]
        if len(output) < 2:
            return []

        dsid_re = re.compile(r'appledsid=(\d+)', flags=re.IGNORECASE)
        def find_dsid_in_line(line):
            match = dsid_re.search(line)
            if match:
                return int(match.group(1))

        mapping = {}
        while output:
            line = output.pop(0)
            if not line.startswith('dn:'):
                continue
            dsid = find_dsid_in_line(line)
            manager_line = output.pop(0)
            manager_dsid = find_dsid_in_line(manager_line)
            mapping[str(dsid)] = manager_dsid
        return [(dsid, mapping.get(str(dsid))) for dsid in dsids]


class KerberosKlistToolWrapper(object):

    kerberos_klist_path = '/usr/bin/klist'
    kerberos_klist_list_caches_command = [kerberos_klist_path, '-l']

    def __init__(self, _unittest_support_suppress_json=False):
        self._unittest_support_suppress_json = _unittest_support_suppress_json

    def cache_list_output(self):
        return subprocess.check_output(self.kerberos_klist_list_caches_command, stderr=subprocess.STDOUT).decode('utf-8')

    def cache_list_json_output(self):
        if self._unittest_support_suppress_json:
            return None

        cmd = self.kerberos_klist_list_caches_command + ['--json']
        try:
            json_data = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
            if b'Usage: ' in json_data:
                # FreeBSD doesn't understand --json but also doesn't signal the failure with a non-zero exit code.
                # Peek at stderr and look for the usage message instead.
                # Details in rdar://105203808
                logger.info('Invalid JSON output for cmd "{}": {}'.format(cmd, json_data))
                return None
            return json.loads(json_data)
        except subprocess.CalledProcessError:
            return None

    def output_for_cache_id(self, cache_id):
        cmd = [self.kerberos_klist_path, '-c', cache_id]
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT).decode('utf-8')


class KerberosKlistToolWrapperUnitTestDummy(object):

    def __init__(self, klist_dash_l_output, klist_dash_c_map, klist_dash_l_json_output=None):
        self.klist_dash_l_output = klist_dash_l_output
        self.klist_dash_c_map = klist_dash_c_map
        self.klist_dash_l_json_output = klist_dash_l_json_output

    def cache_list_output(self):
        return self.klist_dash_l_output

    def cache_list_json_output(self):
        return self.klist_dash_l_json_output

    def output_for_cache_id(self, cache_id):
        return self.klist_dash_c_map[cache_id]

__all__ = [
    "AppleDirectoryUserEntry",
    "AppleDirectoryQuery",
    "LoggedInAppleConnectAccount",
]