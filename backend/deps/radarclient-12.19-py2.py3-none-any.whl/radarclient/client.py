#!/usr/bin/env python

# Some naming conventions:
# - method names should refer to "radars", not "problems",
#   for consistency with what's already there
# - methods that take or return IDs should include "id/ids" in their name,
#   e.g. "radars_for_ids" (taking ids, returning instances) or "radar_ids" (returning ids)
# - methods that take or return Radar object instances should include
#   "radar/radars" in their name, e.g. "radars_for_query" (returning radars)
# - methods that execute a query and take a dict with the query data structure should have
#   "find" in their name and again also express if they return object instances or IDs.
#   No other method names should use "find". Examples: "find_scheduled_test_data", "find_radar_ids"

# autopep8 -i --ignore E501 githelper.py

from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import contextlib
import json
import os
import platform
import pprint
import re
import socket
import warnings
from copy import deepcopy, copy
from functools import partial
from logging import DEBUG as LOGGING_LEVEL_DEBUG
from multiprocessing import Queue as mpQueue
from ssl import SSLError
from threading import Thread, local as thread_local

from . import http_request_utilities
from .environment import *
from .directory import *
from .model import *
from .exceptions import (
    ClosedComponentNoFollowOnException, ComponentNotFoundException, CorruptedResponseException,
    IncompatibleFieldsRequestException, NetworkErrorMaximumAttemptsExceededException,
    MaximumSendAttemptsExceededException, NoActiveAppleConnectException, ObjectNotFoundException,
    RadarAccessDeniedResponseException, AppleConnectUnavailableException, UnsuccessfulResponseException,
        BulkTestSuiteSchedulingException, APIJobErrorException, APIJobTimeoutException
)
from radarclient import compat, utilities, response_code_is_success, Relationship
from .utilities import RadarProtocolVersion, logger
from .retrypolicy import RetryPolicy, RetryScheme
from .ratelimitpolicy import RateLimitPolicy
from .decorators import deprecated, deprecated_in_place, deprecated_and_removed

# These symbols are imported here only for backwards compatibility
# with clients that incorrectly import them from "radarclient.client"
from .authenticationstrategy import (AuthenticationStrategySPNego, AuthenticationStrategyOIDC,
                                     AuthenticationStrategyWebCookie, AuthenticationStrategyCachedRadarAccessToken,
                                     AuthenticationStrategyAppToApp, ClientSystemIdentifier, AuthenticationStrategyAppleConnect)
from .http_request_utilities import AuthenticatedRequestUrllib2

from .version import __version__ as library_version
__version__ = library_version


class DebuggingRelationshipTraversalDelegate(object):
    """
    Example implementation of :py:meth:`Radar.all_relationships` delegate.

    """
    def should_follow_relationship(self, relationship):
        print(u'DebuggingRelationshipTraversalDelegate should_follow_relationship: {}'.format(relationship))
        return True

    def traversal_progress(self, processed_radar_count, total_radar_count):
        print(u'DebuggingRelationshipTraversalDelegate traversal_progress: {}/{}'.format(processed_radar_count, total_radar_count))


class RadarAPIJob(object):

    def __init__(self, client, request_body, creation_url_components, job_url_components=('jobs',)):
        self.creation_url_components = creation_url_components
        self.client = client
        _, data = self.client.build_and_send_json_request(self.creation_url_components, request_data=request_body,
                                                          method='POST')
        self.JobId = data['jobId']
        self.job_url_components = job_url_components + (self.JobId,)

        self.fetch_job_info()

        self.start_time = time.time()
        self.status_key = 'jobStatus'

    def fetch_job_info(self):
        """
        Refreshes information about the job through the Radar API

        :return: None
        """
        logger.debug('Fetching data for job {}'.format(self.JobId))
        _, data = self.client.build_and_send_request(self.job_url_components)
        for k, v in data.items():
            setattr(self, k, v)

    def percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        raise NotImplementedError('Must be implemented on the child classes')

    @deprecated(percent_complete, 12.0)
    def get_percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        raise NotImplementedError('Must be implemented on the child classes')

    def cancel(self):
        """
        Cancels the job through the API

        :returns: None
        """
        _, _ = self.client.build_and_send_request(self.job_url_components, method="DELETE")
        self.fetch_job_info()

    def wait_until_done(self, polling_delay=.6, timeout=None, status_callback=None):
        """
        Wait until the job has finished, polling every `polling_delay` seconds. Each time it polls it also
        calls `status_method` to provide an update on the progress of the job

        :param float polling_delay: Delay between each call to check status of job in seconds
        :param int timeout: Number of seconds after which the job will be canceled
        :param func status_callback: Function that takes in the job ID, job status, and percent complete as arguments
            to be used as the user sees fit

        :returns: None
        """
        def default_callback(job_id, status, percent_complete):
            logger.debug('Job {} is {} and is {}% complete'.format(job_id, status, percent_complete))

        if status_callback is None:
            status_callback = default_callback

        while timeout is None or time.time() - self.start_time < timeout:
            self.fetch_job_info()

            status_callback(self.JobId, getattr(self, self.status_key), self.percent_complete())

            if getattr(self, self.status_key) == "COMPLETED":
                return
            elif getattr(self, self.status_key) == 'ERROR':
                raise APIJobErrorException('Job {} failed to complete with error(s) "{}"'.format(
                    self.JobId, pprint.pformat(self.errors)),
                    self.errors
                )
            else:
                time.sleep(polling_delay)
        self.cancel()
        raise APIJobTimeoutException('Timed out waiting for job {} to complete. It has been canceled'.format(
            self.JobId))

    @deprecated_in_place(wait_until_done, 12.0)
    def wait_until_complete(self, polling_delay=.6, time_out=None, status_method=logger.debug):
        """
        Wait until the job has finished, polling every `polling_delay` seconds. Each time it polls it also
        calls `status_method` to provide an update on the progress of the job

        :param float polling_delay: Delay between each call to check status of job in seconds
        :param int time_out: Number of seconds after which the job will be canceled
        :param func status_method: Function that takes a string as an argument for the purposes
            of showing status

        :returns: None
        """
        while time_out is None or time.time() - self.start_time < time_out:
            self.fetch_job_info()

            log_string = 'Job {} is {} and is {}% complete'.format(self.JobId, self.jobStatus,
                                                                   self.get_percent_complete())
            status_method(log_string)

            if self.jobStatus == "COMPLETED":
                return
            else:
                time.sleep(polling_delay)
        logger.warning('Timed out waiting for job {} to complete'.format(self.JobId))
        self.cancel()


class ScheduleTestSuitesInBulkJob(RadarAPIJob):
    """
    Creates a job to schedule test suites. In general, users should not be calling this directly and should instead use
    :py:meth:`RadarClient.schedule_tests_for_test_suite_ids` or one of the other test suite scheduling methods

    :param RadarClient client: An instance of RadarClient to use
    :param dict request_body: A dictionary to be used as a request body per `Bulk Suite Scheduling Docs`_
    """
    def __init__(self, client, request_body):
        super(ScheduleTestSuitesInBulkJob, self).__init__(
            client, request_body, ('tests', 'scheduledtests', 'bulk')
        )
        self.status_key = 'status'

    def percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        # Work around issue where values are sometimes None when returned from API
        if self.completedCount is None or self.totalCount is None:
            percent_complete = 0
        else:
            percent_complete = round(self.completedCount / self.totalCount * 100)

        # Works around issue where the job is listed as PROCESSING but the numbers indicate it is done
        if percent_complete == 100 and getattr(self, self.status_key) != 'COMPLETED':
            percent_complete = 99
        return percent_complete

    def scheduled_suite_ids(self):
        """
        Returns a generator of all the scheduled test IDs

        :return: generator of scheduled test IDs
        """
        return (test['id'] for test in self.jobAttribute['scheduleTests'])


class ModifyRadarsJob(RadarAPIJob):
    """
    This class creates a job to modify radars per the `Radar API Docs (Modify Problems)`_

    :param RadarClient client: An instance of RadarClient to use
    :param dict request_body: A dictionary to be used as a request body per `Radar API Docs (Modify Problems)`_

    This job contains the following attributes as returned from the radar API:
     - JobId
     - queuedProblemCounts
     - processingProblemCounts
     - finishedProblemCounts
     - errorProblemCounts
     - canceledProblemCounts
     - totalProblemCounts
     - jobStatus
     - statusCode
     - problemResponseDetails

    `problemResponseDetails` is particularly useful as it is a list of dictionaries outlining if something
    went wrong while updating a radar

    Example::

        request_dict = {
            problemIDs: [93065929, 93064778, 93064532, 93062549],
            diagnosis: 'Adding this diagnosis right now'
        }
        mod_job = ModifyRadarsJob(radar_client, request_dict)
        mod_job.wait_until_complete()

        if mod_job.errorProblemCounts > 0:
            print('There were errors, {}'.format(mod_job.problemResponseDetails))

    """
    def __init__(self, client, request_body):
        super(ModifyRadarsJob, self).__init__(client, request_body, ('problems', 'modify'),
                                              job_url_components=('problems', 'modify'))

    def percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        percent_complete = round(self.finishedProblemCounts / self.totalProblemCounts * 100)

        # Works around issue where the job is listed as PROCESSING but the numbers indicate it is done
        if percent_complete == 100 and self.jobStatus != 'COMPLETED':
            percent_complete = 99
        return percent_complete

    @deprecated(percent_complete, 12.0)
    def get_percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        percent_complete = round(self.finishedProblemCounts / self.totalProblemCounts * 100)

        # Works around issue where the job is listed as PROCESSING but the numbers indicate it is done
        if percent_complete == 100 and self.jobStatus != 'COMPLETED':
            percent_complete = 99
        return percent_complete


class ModifyRadarTestObjectJob(RadarAPIJob):
    """
    Parent class for modify jobs on Radar Test object types.

    :param RadarClient client: An instance of RadarClient to use
    :param dict request_body: A dictionary to be used per the modify API docs

    This object contains the following attributes as returned from the radar API
     - jobId
     - queuedTestCounts
     - finishedTestCounts
     - errorTestCounts
     - cancelledTestCounts
     - totalTestCounts
     - jobStatus
     - statusCode
     - testResponseDetails

    `testResponseDetails` is particularly useful as it is a list of dictionaries outlining if something
    went wrong while updating an item

    Example::

        request_dict = {
            ids: [93065929, 93064778, 93064532, 93062549],
            title: 'These will all have the same title now'
        }

        # In this case we are modifying test cases and so use ModifyTestCasesJob, a child class of this class
        mod_job = ModifyTestCasesJob(radar_client, request_dict)
        mod_job.wait_until_complete()

        if mod_job.errorTestCounts > 0:
            print('There were errors, {}'.format(mod_job.testResponseDetails))
    """

    def __init__(self, client, request_body, creation_url_components):
        super(ModifyRadarTestObjectJob, self).__init__(
            client, request_body, creation_url_components, job_url_components=('tests', 'modify'))

    def percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        percent_complete = round(self.finishedTestCounts / self.totalTestCounts * 100)

        # Works around issue where the job is listed as PROCESSING but the numbers indicate it is done
        if percent_complete == 100 and self.jobStatus != 'COMPLETED':
            percent_complete = 99
        return percent_complete

    @deprecated(percent_complete, 12.0)
    def get_percent_complete(self):
        """
        Returns the progress of the job in percentage terms as an int between 0 and 100.

        :rtype: int
        :return: Percentage job is complete between 0 and 100
        """
        percent_complete = round(self.finishedTestCounts / self.totalTestCounts * 100)

        # Works around issue where the job is listed as PROCESSING but the numbers indicate it is done
        if percent_complete == 100 and self.jobStatus != 'COMPLETED':
            percent_complete = 99
        return percent_complete


class ModifyTestCasesJob(ModifyRadarTestObjectJob):
    """
    Creates a job to modify multiple test cases. An example of usage can be seen in documentation for
    :py:class:`~radarclient.client.ModifyRadarTestObjectJob`
    """

    def __init__(self, client, request_body):
        super(ModifyTestCasesJob, self).__init__(client, request_body, ('tests', 'cases', 'modify'))


class ModifyTestSuitesJob(ModifyRadarTestObjectJob):
    """
    Creates a job to modify multiple test suites. An example of usage can be seen in documentation for
    :py:class:`~radarclient.client.ModifyRadarTestObjectJob`
    """

    def __init__(self, client, request_body):
        super(ModifyTestSuitesJob, self).__init__(client, request_body, ('tests', 'suites', 'modify'))


class ModifyScheduledTestsJob(ModifyRadarTestObjectJob):
    """
    Creates a job to modify multiple scheduled test suites. An example of usage can be seen in documentation for
    :py:class:`~radarclient.client.ModifyRadarTestObjectJob`
    """

    def __init__(self, client, request_body):
        super(ModifyScheduledTestsJob, self).__init__(client, request_body, ('tests', 'scheduledtests', 'modify'))


class ModifyScheduledTestCasesJob(ModifyRadarTestObjectJob):
    """
    Creates a job to modify multiple scheduled test cases. An example of usage can be seen in documentation for
    :py:class:`~radarclient.client.ModifyRadarTestObjectJob`
    """

    def __init__(self, client, request_body):
        super(ModifyScheduledTestCasesJob, self).__init__(client, request_body, ('tests', 'scheduledcases', 'modify'))


class RadarClient(object):
    """
    This class represents the connection to the Radar Web API server.

    :param AuthenticationStrategy authentication_strategy: The authentication strategy to use.
    :param ClientSystemIdentifier client_system_identifier: An identifier for the client system.
    :param str protocol_version: Optional Radar server API version. Only use this if you want to override the default in order to test upcoming features.
    :param RetryPolicy retry_policy: Optional opt-in automatic retry behavior for send requests.
    :param RateLimitPolicy rate_limit_policy: Optional opt-in rate-limit behavior for send requests.

    Example::

        authentication_strategy = AuthenticationStrategyAppleConnect()
        system_identifier = ClientSystemIdentifier('MyApp', '1.0')
        radar_client = RadarClient(authentication_strategy, system_identifier, retry_policy=RetryPolicy(), rate_limit_policy=RateLimitPolicy())

        radar = radar_client.radar_for_id(1234)

    If you need to target a different environment, you can pass an additional RadarEnvironment instance
    to the authentication strategy, in this example the UAT environment::

        authentication_strategy = AuthenticationStrategyAppleConnect(radar_environment=RadarEnvironment('uat'))

    See :py:class:`ClientSystemIdentifier` for details about what you should provide
    for the ``client_system_identifier`` parameter.

    If you use multithreading in your code, note that instances of this class must not
    be shared across threads. You should create a separate instance for each thread that needs one.

    For more information about using the automatic retry behavior available, see :py:class:`~radarclient.retrypolicy.RetryPolicy`.

    For more information about using the rate-limiting behavior available, see :py:class:`~radarclient.ratelimitpolicy.RateLimitPolicy`.

    """
    # This has moved to the Radar class but is kept here for legacy support
    problem_default_fields = list(Radar.PROBLEM_DEFAULT_FIELDS)

    RESPONSE_FORMAT_STANDARD = 'STANDARD'
    RESPONSE_FORMAT_COMPACT = 'COMPACT'
    VALID_RESPONSE_FORMATS = {RESPONSE_FORMAT_COMPACT, RESPONSE_FORMAT_STANDARD}

    # TODO: remove, temporary workaround for <rdar://problem/15487961>
    problem_fields_unavailable_for_find_query = [
        'configurationSummary',
        'hasReleaseNotes',
        'hasSourceChanges',
        'hasWorkaround',
        'isExternallyViewable',
        'keywordsCount',
        'picturesCount',
        'securityListCount',
        'thirdPartyProductsCount'
    ]

    # TODO: remove, temporary workaround for <rdar://problem/18113501>
    # Not strictly needed anymore but left in for compatibility for any users requesting these fields manually.
    problem_count_fields_unavailable_for_find_query = [
        'counts.attachments'
        'counts.cc',
        'counts.keywords',
        'counts.otherRelatedItems',
        'counts.pictures',
        'counts.relatedProblems',
        'counts.securityList',
        'counts.thirdPartyProducts',
    ]

    problem_fields_unavailable_for_execute_query = [
        'configurationSummary',
        'counts.keywords',
        'counts.otherRelatedItems',
        'counts.securityList',
        'counts.thirdPartyProducts',
        'hasReleaseNotes',
        'hasSourceChanges',
        'hasWorkaround',
        'isExternallyViewable',
    ]

    max_radar_batch_size = 15

    def __init__(self, authentication_strategy, client_system_identifier=None, protocol_version=None, retry_policy=None, rate_limit_policy=None):
        if (protocol_version and RadarProtocolVersion(protocol_version) < RadarProtocolVersion(RadarProtocolVersion.current_minimum_string)
            or not protocol_version):
            protocol_version = RadarProtocolVersion(RadarProtocolVersion.current_default_string)
        self.authentication_strategy = authentication_strategy
        self.radar_cache = weakref.WeakValueDictionary()
        self.client_system_identifier = client_system_identifier
        self.protocol_version = RadarProtocolVersion.from_string_or_instance(protocol_version)
        self.retry_policy = retry_policy
        self.rate_limit_policy = rate_limit_policy
        self.current_user_person = None
        self.sent_request_count = 0
        if not client_system_identifier:
            logger.warning('Please provide a client system identifier constructor argument to RadarClient(). See http://liyanage.apple.com/software/radarclient-python/#radarclient for details')
        authentication_strategy.client_system_identifier_accessor = lambda : client_system_identifier

        # Tracking fields for various Radar Test attributes that require updating by ID
        self._scheduled_test_statuses = None
        self._scheduled_test_case_statuses = None
        self._test_statuses = None
        self._test_categories = None
        self._track_names = None
        self._test_complexities = None
        self._business_processes = None
        self._application_names = None
        self._test_cycles = None
        self._test_geographies = None

    def __repr__(self):
        return '<RadarClient protocolVersion={} clientSystemIdentifier={} auth={}>'.format(self.protocol_version, self.client_system_identifier.user_agent_string(), type(self.authentication_strategy).__name__)

    def __getstate__(self):
        state = {
            'version': __version__,
            'authentication_strategy': self.authentication_strategy,
            'client_system_identifier': self.client_system_identifier,
            'protocol_version': str(self.protocol_version),
            'retry_policy': self.retry_policy,
            'rate_limit_policy': self.rate_limit_policy
        }
        return state

    def __setstate__(self, state):
        authentication_strategy = state['authentication_strategy']
        client_system_identifier = state['client_system_identifier']
        if not (authentication_strategy and client_system_identifier):
            raise Exception('Unable to deserialize from invalid state')
        protocol_version_string = state.get('protocol_version')
        retry_policy = state['retry_policy']
        rate_limit_policy = state['rate_limit_policy']
        self.__init__(authentication_strategy, client_system_identifier, protocol_version_string, retry_policy, rate_limit_policy)

    # RadarClient can be deepcopy()-ed in the same process, but some fields must be shared (and are thread-safe)
    def __deepcopy__(self, memo):

        # start out with a shallow copy, where most fields are shared
        new_self = copy(self)

        new_self.authentication_strategy = deepcopy(self.authentication_strategy, memo)
        new_self.authentication_strategy.client_system_identifier_accessor = self.authentication_strategy.client_system_identifier_accessor
        new_self.radar_cache = weakref.WeakValueDictionary() # not shared between threads
        new_self.current_user_person = deepcopy(self.current_user_person, memo)
        new_self.sent_request_count = 0

        # fields not explicitly deepcopied above share references, like rate_limit_policy

        return new_self

    @staticmethod
    def radarclient_for_current_appleconnect_session(system_identifier, protocol_version='2.2', retry_policy=None, rate_limit_policy=None):
        """
        Gets an instance of radarclient authenticated using the already logged in AppleConnect
        account

        :param ClientSystemIdentifier system_identifier: system identifier to use for radarclient
        :param str protocol_version: The protocol version to be used. Default is ``2.2``
        :param retry_policy: A retry policy to use with this instance of RadarClient. Default is ``None``. See more at
            :py:class:`~radarclient.retrypolicy.RetryPolicy`.
        :param rate_limit_policy: A rate-limit policy to use with this instance of RadarClient. Default is ``None``. See more at
            :py:class:`~radarclient.ratelimitpolicy.RateLimitPolicy`.

        :return: :py:class:`RadarClient`
        :raises: :py:class:`radarclient.exceptions.AppleConnectUnavailableException`
        """
        if not AuthenticationStrategyAppleConnect.available():
            logger.debug('AppleConnect unavailable')
            print('Unable to authenticate using AppleConnect as it is unavailable on this system')
            raise AppleConnectUnavailableException()

        return RadarClient(
            AuthenticationStrategyAppleConnect(),
            system_identifier,
            protocol_version=protocol_version,
            retry_policy=retry_policy,
            rate_limit_policy=rate_limit_policy
        )

    @classmethod
    @contextlib.contextmanager
    def log_duration(cls, message, level=LOGGING_LEVEL_DEBUG):
        if not logger.isEnabledFor(level):
            yield
            return

        t1 = datetime.datetime.now()
        yield
        t2 = datetime.datetime.now()
        logger.log(level, 'Request duration {:0.3f}s {}'.format((t2 - t1).total_seconds(), message))

    @classmethod
    def create_requested_fields_header(cls, fields):
        """
        Builds a proper header tuple for requested fields

        :param list[str] fields: list of fields to include

        :return: (<requested fields header>, <fields>)

        :meta private:
        """
        return ('X-Fields-Requested', ','.join(set(fields)))

    @classmethod
    def create_additional_fields_header(cls, item_class, additional_fields):
        requested_fields = item_class.property_names
        if additional_fields:
            requested_fields = requested_fields + additional_fields
        return cls.create_requested_fields_header(requested_fields)

    @classmethod
    def create_additional_fields_header_for_find(cls, item_class, additional_fields):
        if len(item_class.EXCLUDE_FROM_FIND) == 0:
            return cls.create_additional_fields_header(item_class, additional_fields)
        else:
            requested_fields = set(item_class.property_names) - item_class.EXCLUDE_FROM_FIND
            if additional_fields is not None:
                requested_fields.update(additional_fields)
            return cls.create_requested_fields_header(requested_fields)

    @classmethod
    def create_response_format_header(cls, response_format):
        upper_cased_format = response_format.upper()
        if upper_cased_format not in cls.VALID_RESPONSE_FORMATS:
            raise ValueError('{} is not a valid response format'.format(response_format))
        else:
            return 'X-Response-Format', upper_cased_format

    @classmethod
    def configure_request_for_requested_fields(cls, request, fields):
        request.add_header(*cls.create_requested_fields_header(fields))

    @classmethod
    def configure_request_for_additional_fields(cls, request, item_class, additional_fields):
        request.add_header(*cls.create_additional_fields_header(item_class, additional_fields))

    @classmethod
    def configure_find_request_for_additional_fields(cls, request, item_class, additional_fields):
        request_header = cls.create_additional_fields_header_for_find(item_class, additional_fields)
        request.add_header(*request_header)

    @classmethod
    def create_limit_header(cls, limit):
        """
        Create a proper header value tuple for limit

        :param int limit: limit to use

        :return: (<limit header>, <limit>)

        :meta private:
        """
        return 'X-rowlimit', limit

    @classmethod
    def configure_request_with_limit(cls, request, limit):
        request.add_header(*cls.create_limit_header(limit))

    def assemble_radar_requested_fields(self, fields, additional_fields, for_find=False):
        if fields is None:
            fields = []
        if additional_fields is None:
            additional_fields = []
        if fields and additional_fields:
            raise IncompatibleFieldsRequestException('Usage of both "fields" and "additional_fields" is not allowed.')
        if fields:
            requested_fields = set(fields)
            if 'id' not in fields:
                requested_fields.add('id')
        else:
            requested_fields = set(Radar.PROBLEM_DEFAULT_FIELDS)
            if for_find:
                requested_fields = requested_fields - set(self.problem_fields_unavailable_for_find_query +
                                                          self.problem_count_fields_unavailable_for_find_query)
            if additional_fields:
                requested_fields |= set(additional_fields)
        if 'builds' in requested_fields:
            requested_fields.remove('builds')
            requested_fields.update(Radar.build_attrs.keys())
        return sorted(list(requested_fields))   # Sorting here to make debugging simpler, but not necessary for API

    def username(self):
        return self.authentication_strategy.username()

    # data must be of type bytes, not string
    # json_string must be of type string, not bytes
    # data is ignored if json_string is passed
    def request_for_json_url(self, url, data=None, json_string=None, method=None):
        """
        Get an API request object pre-configured for raw JSON requests/responses.

        :param str json_string: A unicode string with the JSON request data, if needed.
        :param str method: Optional HTTP method. The default is GET when no request payload is
                           specified and POST when it is. This can be useful to force PUT over POST
                           when a request payload is present, or DELETE over GET when it isn't.

        Returns a request object that you can send using the :py:meth:`RadarClient.send_request` method.

        This method, together with :py:meth:`RadarClient.send_request` and
        :py:meth:`RadarClient.webservice_url_for_path_components`, is intended as an "escape hatch" to be
        used in exceptional situations when you want to access a feature of the Radar API that this
        library's API does not currently support directly.

        There are also 2 higher level escape hatch methods that are preferable to this one,
        :py:meth:`build_and_send_json_request` and
        :py:meth:`build_and_send_request` which take care of
        building the URL, adding headers, sending the request, and checking the result. See those methods
        for examples.

        Example::

            radar_id = 1234
            problem_history_url = radar_client.webservice_url_for_path_components('problems', radar_id, 'history')
            request = radar_client.request_for_json_url(problem_history_url)
            response_status, response_data = radar_client.send_request(request)
            if radarclient.response_code_is_success(response_status):
                for history_item in response_data:
                    print('Changed at {}: changed by: {}'.format(history_item['changedAt'], history_item['changedBy']['email']))

        Example with a request payload::

            request_data = {
                'problemIDs': [1234],
                'priority': 2
            }
            request_json = json.dumps(request_data)
            modify_url = radar_client.webservice_url_for_path_components('problems', 'modify')
            request = radar_client.request_for_json_url(modify_url, json_string=request_json)
            response_status, response_data = radar_client.send_request(request)
            if not radarclient.response_code_is_success(response_status):
                # handle error

        """
        if json_string:
            data = json_string.encode('utf-8')
        request = self.request_for_url(url, data, method)
        http_request_utilities.configure_request_for_json(request)
        return request

    # data must be of type bytes, not string
    def request_for_url(self, url, data=None, method=None):
        if not method:
            method = None
        request = self.authentication_strategy.authenticated_request(url, data, method)
        # The new Radar Test API endpoint require API version to be passed in to function properly
        request.add_header('X-API-Version', self.protocol_version)
        return request

    def _send_request_with_retries(self, request, check_response_code):
        attempt_count = 0
        max_send_attempts = self.retry_policy.max_send_attempts
        response = None
        exception = None

        while attempt_count < max_send_attempts:
            if self.rate_limit_policy:
                self.rate_limit_policy._wait_if_needed(request)
            attempt_count += 1
            try:
                logger.log(LOGGING_LEVEL_DEBUG, 'Sending request for {} {}'.format(request.method, request.url()))
                response = request.send(check_response_code=check_response_code)
                break
            # Most API-side errors end up as type UnsuccessfulResponseException
            except UnsuccessfulResponseException as ure:
                exception = ure
                method = request.method
                endpoint = self.retry_policy._strip_endpoint(request.url())
                status_code = ure.code
                retry_scheme = self.retry_policy._get_retry_scheme(method, endpoint, status_code)
                if retry_scheme == RetryScheme():
                    # The retry scheme we got represents one that performs no retries for the given request
                    break
                _max_send_attempts = min(retry_scheme.max_send_attempts, self.retry_policy.max_send_attempts)
                if attempt_count >= _max_send_attempts:
                    exception = MaximumSendAttemptsExceededException(status_code, ure.message)
                    break
                delay = self.retry_policy._get_delay(retry_scheme.delay_type, attempt_count)
                if self.retry_policy.logging_callback is not None:
                    self.retry_policy.logging_callback(request, ure, retry_scheme, delay)
                logger.log(LOGGING_LEVEL_DEBUG,
                           'RetryPolicy: {} {}, attempt #{}, response code {}, delaying for {}s ({})'.format(
                               method, request.get_path(), attempt_count, status_code, delay, retry_scheme.delay_type
                           ))
                time.sleep(delay)
            # Transient networking errors somewhere between host and Radar API, usually temporary
            except (
                compat.builtins_ConnectionError, compat.builtins_ConnectionResetError, compat.builtins_BrokenPipeError,
                compat.builtins_ConnectionAbortedError, compat.builtins_ConnectionRefusedError,
                compat.builtins_TimeoutError, compat.http_IncompleteRead, compat.http_RemoteDisconnected,
                socket.gaierror, socket.timeout, SSLError, compat.urllib_URLError
            ) as tne:
                exception = tne
                if not self.retry_policy.retry_transient_networking_errors:
                    break
                method = request.method
                logger.log(LOGGING_LEVEL_DEBUG,
                           'RetryPolicy: Network Error sending {} {} (attempt #{}): {}'.format(
                               method, request.get_path(), attempt_count, tne
                           ))
                if attempt_count >= max_send_attempts:
                    exception = NetworkErrorMaximumAttemptsExceededException(tne)
                    break
                if self.retry_policy.logging_callback is not None:
                    endpoint = self.retry_policy._strip_endpoint(request.url())
                    retry_scheme = RetryScheme(method=method, endpoint=endpoint, status_code=None,
                                               delay_type=self.retry_policy.DELAY_TYPE_NONE,
                                               max_send_attempts=self.retry_policy.max_send_attempts)
                    delay = self.retry_policy._get_delay(retry_scheme.delay_type, attempt_count)
                    self.retry_policy.logging_callback(request, tne, retry_scheme, delay)
           # Fallback for other error types
            except Exception as e:
                exception = e
                break
        return response, exception, attempt_count

    def send_request(self, request, check_response_code=True, protocol_version=None):
        self.configure_request_user_agent_string(request)
        if protocol_version:
            protocol_version = RadarProtocolVersion.from_string_or_instance(protocol_version)
        else:
            protocol_version = self.protocol_version
        self.configure_request_protocol_version(request, protocol_version)
        with self.log_duration('{} {}'.format(request.effective_method_for_logging(), request.url())):
            if self.retry_policy:
                response, exception, attempt_count = self._send_request_with_retries(
                    request,
                    check_response_code=check_response_code
                )
                self.sent_request_count += attempt_count
                if not response:
                    assert exception, "There should be an exception if there was no response!"
                    raise exception
            else:
                if self.rate_limit_policy:
                    self.rate_limit_policy._wait_if_needed(request)
                logger.log(LOGGING_LEVEL_DEBUG, 'Sending request for {} {}'.format(request.method, request.url()))
                response = request.send(check_response_code=check_response_code)
                self.sent_request_count += 1
        return (response.status(), response.data())

    def configure_request_protocol_version(self, request, version):
        request.add_header('X-API-Version', str(version))

    def configure_request_user_agent_string(self, request):
        http_request_utilities.configure_request_user_agent_string_with_client_system_identifier(request, client_system_identifier=self.client_system_identifier, authentication_strategy=self.authentication_strategy)

    def webservice_base_url(self):
        webservice_url = self.authentication_strategy.radar_environment.configuration_value('webservice_url')
        return webservice_url

    def webservice_url_for_path_components(self, *components):
        """
        Builds a request URL for the given components

        :param tuple components: tuple of the components of the URL

        :return: A URL to use for a request to the radar API with the components added

        Example::

            components = ('problems', 'find')
            url = radar_client.webservice_url_for_path_components(components)
            # url will be <base URL>/problems/find

        """
        components = [component for component in components if component is not None]

        # Convert all components to unicode strings (this includes numbers, etc)
        unicode_components = list(map(compat.unicode_string_type, components))
        # Encode all components under utf-8.  This will convert unicode characters to an ascii safe representation
        encoded_components = [component.encode('utf-8') for component in unicode_components]
        # urllib.quote converts strings into a url safe representation
        quoted_components = list(map(compat.urllib_url_quote, encoded_components))

        return '/'.join([self.webservice_base_url()] + quoted_components)

    def webservice_url_for_radar_ids(self, ids):
        return self.webservice_url_for_path_components('problems', ','.join(str(i) for i in ids))

    def webservice_url_for_keyword_ids(self, ids):
        return self.webservice_url_for_path_components('keywords', ','.join(str(i) for i in ids))

    def webservice_url_for_labels(self):
        return self.webservice_url_for_path_components('label-sets')

    def webservice_url_for_other_related_item_systems(self):
        return self.webservice_url_for_path_components('other-related-items/systems')

    def build_and_send_json_request(self, url_components, request_data, additional_headers=None, method=None,
                                    check_result=True, protocol_version=None):
        """
        This method acts as a higher level escape hatch to :py:meth:`request_for_json_url`. It will build
        the URL, convert the request data to JSON, add the specified headers, and send the request.

        :param tuple url_components: tuple of all URL components matching what would be passed to
            :py:meth:`webservice_url_for_path_components`
        :param dict request_data: request data to be converted to JSON
        :param list[tuple] additional_headers: list of additional headers to be added. Each tuple should be
            (<header>, <value>)
        :param str method: request method. POST is used if nothing passed in
        :param bool check_result: If True, checks the return status for error codes
        :param str protocol_version: Optional Radar server API version. Only use this if you want to override the default in order to test upcoming features.

        :return: tuple with (<status code>, <returned data>)

        Example::

            # Matches example from docs for request_for_json_url() with request payload
            request_data = {
                'problemIDs': [1234],
                'priority': 2
            }
            status, info = radar_client.build_and_send_json_request(('problems', 'modify'), request_data)

        """
        if protocol_version is None:
            protocol_version = self.protocol_version

        if additional_headers is None:
            additional_headers = []

        url = self.webservice_url_for_path_components(*url_components)
        request_json = None
        if request_data is not None:
            request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method=method)

        for header in additional_headers:
            request.add_header(*header)

        req_status, req_data = self.send_request(request, check_response_code=check_result, protocol_version=protocol_version)
        if check_result and not response_code_is_success(req_status):
            req_data = utilities._convert_response_list_to_dict(req_data)   # API v2.2 (rdar://97676446)
            raise self.exception_for_non_success_response(req_status, req_data)

        return req_status, req_data

    def build_and_send_request(self, url_components, request_data=None, additional_headers=None, method=None,
                               check_result=True, protocol_version=None):
        """
        This method acts as a higher level escape hatch to :py:meth:`request_for_json_url`. It will build
        the URL, add the specified headers, and send the request

        :param tuple url_components: tuple of all URL components matching what would be passed to
            :py:meth:`~radarclient.client.RadarClient.webservice_url_for_path_components`
        :param bytes request_data: data to send with request
        :param list[tuple] additional_headers: list of additional headers to be added. Each tuple should be
            (<header>, <value>)
        :param str method: method used for request. Default will be GET
        :param bool check_result: If True, checks the return status for error codes
        :param str protocol_version: Optional Radar server API version. Only use this if you want to override the default in order to test upcoming features.

        :return: tuple with (<status code>, <returned data>)

        Example::

            # Matches example without payload from docs for request_for_json_url()
            status, data = radar_client.build_and_send_request(('problems', 1234, 'history'))

        """
        if protocol_version is None:
            protocol_version = self.protocol_version

        if additional_headers is None:
            additional_headers = []

        url = self.webservice_url_for_path_components(*url_components)
        request = self.request_for_url(url, request_data, method)

        for header in additional_headers:
            request.add_header(*header)

        req_status, req_data = self.send_request(request, check_response_code=check_result, protocol_version=protocol_version)
        if check_result and not response_code_is_success(req_status):
            req_data = utilities._convert_response_list_to_dict(req_data)   # API v2.2 (rdar://97676446)
            raise self.exception_for_non_success_response(req_status, req_data)

        return req_status, req_data

    def _strip_id_from_component_dict(self, _dict):
        """
        For APIs/endpoints that don't take a 'component' dictionary with the 'id' key-value pair, this removes it.

        :meta private:
        """
        if 'component' in _dict and 'id' in _dict['component']:
            del _dict['component']['id']
        return _dict

    def other_related_item_systems(self):
        """
        Get other related item systems

        Returns a list of :py:class:`~radarclient.model.OtherRelatedItemSystem` instances. See that class for an example.

        """
        url = self.webservice_url_for_other_related_item_systems()
        request = self.request_for_json_url(url)
        status, data = self.send_request(request)
        if not response_code_is_success(status):
            raise self.exception_for_non_success_response(status, data)
        return [OtherRelatedItemSystem(item_data) for item_data in data]

    def keyword_for_id(self, keyword_id, additional_fields=None):
        """
        Get a Keyword for a given ID

        :param int keyword_id: ID of keyword
        :param list[str] additional_fields: A list of additional fields to load from the Radar Web API
            per the `Get Keywords by ID API Docs`_

        :rtype: :py:class:`~radarclient.model.Keyword`
        :raises (API v2.1) ObjectNotFoundException: if no keyword with the ID is found
        :raises (API v2.2) RadarAccessDeniedResponseException: if no keyword with the ID is found
        """
        return Keyword._get_by_id(keyword_id, self, additional_fields=additional_fields)

    def keywords_for_ids(self, keyword_ids, additional_fields=None):
        """
        Get keywords given their IDs.

        :param list keyword_ids: A list of integer keyword IDs.
        :param list[str] additional_fields: A list of additional fields to load from the Radar Web API
            per the `Get Keywords by ID API Docs`_

        Returns a list of :py:class:`~radarclient.model.Keyword` instances, or an empty list if none found. See that class for an
        example.
        """
        return Keyword._get_by_ids(keyword_ids, self, additional_fields=additional_fields, batch_size=Keyword.MAX_BATCH_SIZE)

    def keywords_for_name(self, keyword_name, additional_fields=None):
        """
        Find keywords by name. A convenience wrapper for :py:meth:`find_keywords()`.

        :param str keyword_name: A keyword name
        :param list additional_fields: A list of additional fields to load from the Radar Web API for the returned
            :py:class:`~radarclient.model.Keyword` instance. Reference `Find Keywords API Docs`_ for more information.

        Returns a list of :py:class:`~radarclient.model.Keyword` instances for keywords with the given name.

        """
        return self.find_keywords({'name': keyword_name}, additional_fields)

    def find_keywords(self, request_data, additional_fields=None):
        """
        Find keywords for requested attributes.

        :param dict request_data: request attributes
        :param list additional_fields: (optional) additional fields to return for each result. Reference
            `Find Keywords API Docs`_ for info

        Returns a list of :py:class:`~radarclient.model.Keyword` instances matching the search criteria.

        """
        return Keyword._find(request_data, self, additional_fields=additional_fields,
                             return_results_directly=True)

    def labels_by_name(self):
        """
        Get the labels for the currently signed in user.

        :returns: dict that maps label names to :py:class:`~radarclient.model.Label` instances.
        """
        def processor(results):
            return {data['name']: Label(data) for data in results[0]['labels']}

        return Label._get_by_ids([''], self, processing_callable=processor, additional_headers=[('X-Filter-Labelset', 'active')])

    def labels_by_id(self):
        """
        Get the labels for the currently signed in user.

        :returns: dict that maps label IDs to :py:class:`~radarclient.model.Label` instances.
        """
        def processor(results):
            return {data['id']: Label(data) for data in results[0]['labels']}

        return Label._get_by_ids([''], self, processing_callable=processor, additional_headers=[('X-Filter-Labelset', 'active')])

    def get_active_label_set(self):
        """
        Get the current active label set for the logged in user

        :rtype: ~radarclient.model.LabelSet
        """
        _, label_set = self.build_and_send_request((LabelSet.BASE_URL,), additional_headers=[('X-Filter-Labelset', 'active')])
        return LabelSet(label_set[0])

    def set_active_label_set_by_id(self, _id):
        """
        Set the active label set by its ``id``

        :param str id: ``id`` of the active label set to make active

        :return: None
        """
        self.build_and_send_request((LabelSet.BASE_URL, _id, 'active'), method='POST')

    def set_active_label_set_by_name(self, name):
        """
        Set the active label set with just the name

        :param str name: name of the active label set to make active

        :return: None

        Setting the active Label Set by name is no longer natively supported by Radar API v2.2+. This method will attempt
        to workaround that, and throw an error unless exactly one subscribed Label Set is found matching the provided name.
        Users may wish to switch to :py:meth:`set_active_label_set_by_id()`.
        """
        active_label_sets = self.get_subscribed_label_sets()
        matching_label_sets = [label_set for label_set in active_label_sets if label_set.name == name]
        assert len(matching_label_sets) == 1, '{} Label Sets were found matching the provided name, and there can be only one'.format(len(matching_label_sets))
        self.build_and_send_request((LabelSet.BASE_URL, matching_label_sets[0].id, 'active'), method='POST')

    def set_active_label_set(self, label_set):
        """
        Set the active label set with a :py:class:`~radarclient.model.LabelSet` object

        :param LabelSet label_set: LabelSet to set as active

        :return: None
        """
        self.set_active_label_set_by_id(label_set.id)

    def get_subscribed_label_sets(self):
        """
        Get a list of all LabelSets the logged in user is subscribed to

        :rtype: list[LabelSet]
        """
        _, label_sets = self.build_and_send_request((LabelSet.BASE_URL,), additional_headers=[('X-Filter-Labelset', 'subscribe')])
        return LabelSet._instantiate_list_of_items(label_sets)

    def find_label_sets(self, query_data, limit=None):
        """
        Find label sets

        :param dict query_data: query data as documented in `Find Label Sets Docs`_
        :param int limit: maximum number of items to return

        :return: list of :py:class:`~radarclient.model.LabelSet` objects
        """
        return LabelSet._find(query_data, self, return_results_directly=True, limit=limit)

    def subscribe_to_label_set_by_id(self, _id):
        """
        Subscribe active user to a label set by id

        :param str id: ``id`` of label set to subscribe to

        :return: None
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if set with ``id`` does not
            exist
        """
        try:
            self.build_and_send_request((LabelSet.BASE_URL, _id, LabelSet.SUBSCRIBE_ENDPOINT), method='POST')
        except UnsuccessfulResponseException as ure:
            if ure.code != 409:
                raise

    def subscribe_to_label_set_by_name(self, name):
        """
        Subscribe active user to a label set by name

        :param str name: name of label set to subscribe to

        :return: None
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if set with name does not
            exist

        Subscribing to a Label Set by name is no longer natively supported by Radar API v2.2+. This method will attempt
        to workaround that, and throw an error unless exactly one Label Set is found matching the provided name.
        Users may wish to switch to :py:meth:`subscribe_to_label_set_by_id()`.
        """
        matching_label_sets = self.find_label_sets({'name': name})
        assert len(matching_label_sets) == 1, '{} Label Sets were found matching the provided name "{}", and there must be exactly 1'.format(len(matching_label_sets), name)
        label_set_identifier = matching_label_sets[0].id
        try:
            self.build_and_send_request((LabelSet.BASE_URL, label_set_identifier, LabelSet.SUBSCRIBE_ENDPOINT), method='POST')
        except UnsuccessfulResponseException as ure:
            if ure.code != 409:
                raise

    def subscribe_to_label_set(self, label_set):
        """
        Subscribe active user to label set using a :py:class:`~radarclient.model.LabelSet` object

        :param LabelSet label_set: LabelSet to subscribe to

        :return: None
        """
        self.subscribe_to_label_set_by_id(label_set.id)

    def unsubscribe_from_label_set_by_id(self, _id):
        """
        Unsubscribe active user from label set by name

        :param str name: Name of label set to unsubscribe from

        :return: None
        """
        try:
            self.build_and_send_request(
                (LabelSet.BASE_URL, _id, LabelSet.SUBSCRIBE_ENDPOINT), method='DELETE'
            )
        except UnsuccessfulResponseException as ure:
            if ure.code != 400 or not ure.reason.__contains__('is not subscribed'):
                raise

    def unsubscribe_from_label_set_by_name(self, name):
        """
        Unsubscribe active user from label set by name

        :param str name: Name of label set to unsubscribe from

        :return: None

        Unsubscribing from a Label Set by name is no longer natively supported by by Radar API v2.2+. This method
        will attempt to workaround that, and throw an error unless exactly one Label Set is found matching the provided name.
        Users may wish to switch to :py:meth:`unsubscribe_from_label_set_by_id()`.
        """
        active_label_sets = self.get_subscribed_label_sets()
        if not active_label_sets:
            return
        matching_label_sets = [label_set for label_set in active_label_sets if label_set.name == name]
        if len(matching_label_sets) == 0:
            return
        assert len(matching_label_sets) == 1, 'Unable to unsubscribe from label set by name because the name "{}" is ambiguous, found {} matches'.format(name, len(matching_label_sets))
        label_set_identifier = matching_label_sets[0].id
        try:
            self.build_and_send_request(
                (LabelSet.BASE_URL, label_set_identifier, LabelSet.SUBSCRIBE_ENDPOINT), method='DELETE'
            )
        except UnsuccessfulResponseException as ure:
            if ure.code != 400 or not ure.reason.__contains__('is not subscribed'):
                raise

    def unsubscribe_from_label_set(self, label_set):
        """
        Unsubscribe active user from label set using :py:class:`~radarclient.model.LabelSet` object

        :param LabelSet label_set: LabelSet to unsubscribe from

        :return: None
        """
        self.unsubscribe_from_label_set_by_id(label_set.id)

    def create_radar(self, request_data, additional_fields=None):
        """
        Create a new :py:class:`~radarclient.model.Radar` (Problem) in the Radar database.

        :param dict request_data: A dictionary with the initial properties of the Radar. See the code example below, or
            consult the `Create Problem API Docs`_.
        :return: The resulting :py:class:`~radarclient.model.Radar` instance returned by the API. See more below.

        If ``additional_fields`` was included with the request, the created Radar object will be `reloaded` from the
        API with those attributes requested.

        If the new Radar was created in a dropbox component to which the current account doesn't have access, then the
        method returns an instance of :py:class:`~radarclient.model.RadarPlaceholder` instead.

        This method can raise the following exceptions if the Radar could not be created:

        - ``ComponentNotFoundException`` if the component can't be found (this could be a permission issue or a bad component name/version)
        - ``ClosedComponentNoFollowOnException`` if the component is closed with no follow on component configured
        - ``UnsuccessfulResponseException`` in all other unsuccessful response conditions

        Example::

            request_data = {
                'title': u'create_radar test bug',
                'component': {'name': 'Foo Bar Component', 'version': '1.0'},
                'description': u'test bug description',
                'classification': 'Other Bug',
                'reproducible': 'Not Applicable',
            }

            # Create the new radar
            radar = radar_client.create_radar(request_data)
            # Move the new radar to Verify
            radar.state = 'Verify'
            radar.resolution = 'Not Applicable'
            radar.commit_changes()
            # Close the new radar
            radar.state = 'Closed'
            radar.commit_changes()

        """
        if 'component' in request_data and 'id' in request_data['component']:
            request_data['componentID'] = request_data['component']['id']
            del request_data['component']
        url = self.webservice_url_for_path_components('problems')
        query_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=query_json)
        try:
            status, problem_data = self.send_request(request)
            if status == 201:
                # Success scenarios
                payload_id = problem_data.get('id')
                assert payload_id, 'Unexpected missing Radar ID for 201 response: {}'.format(problem_data)
                payload_code = None
                payload_status = problem_data.get('status')
                if payload_status:
                    payload_code, _ = re.findall(r'^(\d+) (.+)', payload_status)[0]
                if additional_fields or 'title' not in problem_data:
                    return self.radar_for_id(payload_id, additional_fields=additional_fields)
                if payload_code and int(payload_code) == 403:
                    # The Radar was created successfully, but it was filed into a dropbox component
                    # to which the current user doesn't have access.
                    return RadarPlaceholder({'id': payload_id})
                assert problem_data, 'Unexpected missing problem data in Radar creation response'
                radar_data = Radar.parse_webservice_data(problem_data, self, set(list(problem_data.keys())))
                assert len(radar_data) > 0, 'Parsed radar data is empty'
                return radar_data[0]
            else:
                raise Exception("Unexpected success status code! ({})".format(status))
        except UnsuccessfulResponseException as exc_ure:
            # Failure scenarios
            err_status = exc_ure.code
            err_reason = exc_ure.reason
            err_message = exc_ure.message
            if err_status == 400:
                if 'Closed component with no follow on' in err_reason:
                    raise ClosedComponentNoFollowOnException(err_status, err_reason, err_message)
                elif 'Component does not exist' in err_reason:
                    raise ComponentNotFoundException(err_status, err_reason, err_message)
                raise UnsuccessfulResponseException(err_status, err_reason, err_message)
            elif err_status == 403:
                raise RadarAccessDeniedResponseException(err_status, err_reason, err_message)
            else:
                raise exc_ure
        except Exception as exc:
            # If the results aren't one of the above:
            raise Exception("Unknown Radar creation failure: {}".format(exc))

    def clone_radar(self, original_radar_id, reason_text, component, current_user_is_originator=True, title=None,
                    description=None, diagnosis=None, classification=None, milestone=None):
        """
        Clone an existing Radar given its ID.

        :param int original_radar_id: The ID of the original Radar.
        :param str reason_text: The reason for cloning the Radar.
        :param ~radarclient.model.Component component: A :py:class:`~radarclient.model.Component` object `OR` a dictionary with the
            ``name`` and ``version`` of the component for the cloned Radar.
        :param bool current_user_is_originator: [optional] If ``True`` (the default), the current user will be set as the cloned
            Radar's originator. If ``False``, the original Radar's originator is reused as the clone's originator.
        :param str title: [optional] The title to be used for the cloned Radar. If not provided, the original's title will be
            reused automatically.
        :param str description: [optional] The initial Description text for the cloned Radar. If not provided, the original's
            Description entries will be compressed into a single entry on the cloned Radar.
        :param str diagnosis: [optional] The initial Diagnosis/Discussion text for the cloned Radar. If not provided, the original's
            Description entries will be compressed into a single entry on the cloned Radar.
        :param str classification: [optional] The cloned Radar's classification value.
        :param ~radarclient.model.Milestone milestone: [optional] The :py:class:`~radarclient.model.Milestone` to be used for the cloned Radar.

        Returns a :py:class:`~radarclient.model.Radar` instance for the clone.

        Example::

            clone_component = {'name': 'Foo Bar Component', 'version': '1.0'},
            cloned_radar = radar_client.clone_radar(1234, 'A good reason for the clone', clone_component)
            print('Radar {} cloned to {}'.format(1234, cloned_radar.id))

        """
        if isinstance(component, dict):
            if 'id' in component and component['id'] is not None:
                component_key, component_value = 'componentID', component['id']
            else:
                component_key = 'component'
                component_value = {'name': component['name'], 'version': component['version']}  # Removes None ids
        if isinstance(component, Component):
            component_key, component_value = 'componentID', component.id
        request_data = {
            component_key: component_value,
            'reason': reason_text,
            'originatorOfClone': current_user_is_originator
        }
        if title is not None:
            request_data['title'] = title
        if description is not None:
            request_data['description'] = description
        if diagnosis is not None:
            request_data['diagnosis'] = diagnosis
        if classification is not None:
            request_data['classification'] = classification
        if milestone is not None:
            request_data['milestone'] = milestone

        url = self.webservice_url_for_radar_ids([original_radar_id])
        url += '/clone'

        query_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=query_json)
        status, problem_data = self.send_request(request)

        radar = Radar.parse_webservice_data(problem_data, self, set(problem_data.keys()))
        return radar[0]

    def radar_for_id(self, problem_id, additional_fields=None, error_callback=None, verbose=False, fetch_person_info_from_ds=False, fields=None):
        """
        Convenience variant of :py:meth:`RadarClient.radars_for_ids` that takes just a single
        ID and returns a single :py:class:`~radarclient.model.Radar` instance.

        For more information about the available fields that can be requested via ``additional_fields``, please see the
        official `Get Problem API Docs`_.

        """
        result = self.radars_for_ids([problem_id], additional_fields=additional_fields, error_callback=error_callback, fields=fields)
        if result:
            return result[0]
        return None

    def radars_for_ids(self, problem_ids, additional_fields=None, batch_size=15, progress_callback=None, error_callback=None, verbose=False, fetch_person_info_from_ds=False, fields=None):
        """
        Loads Radars given their IDs.

        :param list problem_ids: A list of integer IDs of the bugs to load
        :param list additional_fields: A list of additional fields to load from the Radar API for the returned
            :py:class:`~radarclient.model.Radar` instances. For more information about the available fields that can be
            requested, please see the official `Get Problem API Docs`_.
        :param int batch_size: The number of Radars that should be loaded in one request to the Radar API. Defaults to 15, the maximum is 15.
        :param callable progress_callback: An optional callable that takes three arguments, a float value between 0 and 1 to represent the progress,
                                           an integer representing the number of radars already loaded, and an integer representing the number of
                                           radars that will be loaded in total. This can be useful when loading a large number of Radars with batching.
        :param callable error_callback:    An optional callable that gets called when there is an error accessing a Radar. Currently the only cases that
                                           are handled are permission denied and radar not found errors. The callable is called once per failed Radar ID
                                           with two arguments, the Radar ID that encountered the response and an exception of type :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
                                           (or a subclass thereof), which has a code and a reason property. Note that the Radar ID parameter can be None in some cases
                                           so your callback needs to be able to handle that.
        :param list fields: (optional) A specific list of attributes ("fields") to use for the "X-Fields-Requested"
            header, as a way to override the default fields. NOTE: ``id`` will always be requested, for compatibility.

        Returns a list of :py:class:`~radarclient.model.Radar` instances.

        The receiver maintains a cache of Radars so that repeated requests for the same ID
        (with the same set of ``additional_fields``) don't result in repeated Radar API requests.
        This cache is useful to prevent duplicate requests when traversing relationship graphs.
        If the cache causes problems, you can clear it with :py:meth:`RadarClient.clear_radar_cache`.

        Example::

            print_progress = lambda progress, loaded, total: print('Loading data: {} of {}, {:.0%} complete'.format(loaded, total, progress), file=sys.stderr)
            radars = radar_client.radars_for_ids([12179571, 11725080], progress_callback=print_progress)

        """
        assert None not in problem_ids, 'None value passed for Radar ID'
        problem_ids = [int(id) for id in problem_ids]

        requested_fields = self.assemble_radar_requested_fields(fields, additional_fields)
        requested_key_map = self.cache_key_map_for_radar_ids(problem_ids, requested_fields)
        requested_keys = set(requested_key_map.keys())
        cached_radar_keys = self.cached_radar_keys()

        requested_uncached_radar_keys = requested_keys - cached_radar_keys
        requested_uncached_radar_ids = [requested_key_map[i] for i in requested_uncached_radar_keys]
        requested_cached_radar_keys = requested_keys & cached_radar_keys
        requested_cached_radar_ids = [requested_key_map[i] for i in requested_cached_radar_keys]

        cached_radars = [self.cached_radar_for_key(i) for i in requested_cached_radar_keys]
        loaded_radars = []
        total_loading_count = len(requested_uncached_radar_ids)

        if progress_callback:
            progress_callback(0.0, 0, total_loading_count)

        if batch_size > self.max_radar_batch_size:
            logger.warning(u'Requested batch size {} is too big, limiting to {}'.format(batch_size, self.max_radar_batch_size))
            batch_size = self.max_radar_batch_size

        if requested_uncached_radar_ids:
            seen = set(requested_cached_radar_ids)
            ordered_unique_requested_uncached_radar_ids = [i for i in problem_ids if not (i in seen or seen.add(i))]
            assert total_loading_count == len(ordered_unique_requested_uncached_radar_ids), 'total_loading_count {} != {}'.format(total_loading_count, len(ordered_unique_requested_uncached_radar_ids))
            for i in range(0, total_loading_count, batch_size):
                batch_radar_ids = ordered_unique_requested_uncached_radar_ids[i:i + batch_size]
                logger.debug(u'Loading data for {} radars...'.format(len(batch_radar_ids)))
                url = self.webservice_url_for_radar_ids(batch_radar_ids)
                request = self.request_for_json_url(url)
                self.configure_request_for_requested_fields(request, requested_fields)
                try:
                    status, problem_or_error_data = self.send_request(request)
                except UnsuccessfulResponseException as ure:
                    if error_callback and ure.code in (compat.http_NOT_FOUND, compat.http_FORBIDDEN):
                        self._process_unsuccessful_response_exception_for_batch(batch_radar_ids, ure, error_callback)
                        continue
                    else:
                        raise
                if isinstance(problem_or_error_data, dict):
                    problem_or_error_data = [problem_or_error_data]

                response_toplevel_data_type_is_list = isinstance(problem_or_error_data, list)
                logger.debug('Response for Radar IDs {}: {} (is list: {})'.format(batch_radar_ids, status, response_toplevel_data_type_is_list))
                if not response_toplevel_data_type_is_list:
                    self._process_radars_for_ids_corrupted_response_for_batch(batch_radar_ids, status, problem_or_error_data, error_callback)
                    continue

                problem_data = self._process_radars_for_ids_items_for_batch(batch_radar_ids, problem_or_error_data, error_callback)

                batch_loaded_radars = Radar.parse_webservice_data(problem_data, self, requested_fields)
                for radar in batch_loaded_radars:
                    self.cache_radar(radar, requested_fields)
                loaded_radars.extend(batch_loaded_radars)

                if progress_callback:
                    loaded_count = len(loaded_radars)
                    progress_callback(loaded_count / total_loading_count, loaded_count, total_loading_count)

        if progress_callback:
            progress_callback(1.0, total_loading_count, total_loading_count)

        id_to_radar_map = {r.id: r for r in cached_radars + loaded_radars}
        ordered_radars = [id_to_radar_map[id] for id in problem_ids if id in id_to_radar_map]
        return ordered_radars

    def _process_radars_for_ids_items_for_batch(self, batch_radar_ids, problem_or_error_data, error_callback):
        problem_data = []
        for item_data in problem_or_error_data:
            if 'status' not in item_data:
                problem_data.append(item_data)
                continue
            if 'id' in item_data:
                id = int(item_data['id'])
            elif len(batch_radar_ids) == 1:
                id = batch_radar_ids[0]
            else:
                id = None
            status = int(item_data['status'].split()[0])
            self.create_and_process_exception_for_non_success_response(status, item_data, error_callback, id)
        return problem_data

    def _process_radars_for_ids_corrupted_response_for_batch(self, batch_radar_ids, status, problem_or_error_data, error_callback):
        error = None
        message = problem_or_error_data
        response_is_success = response_code_is_success(status)

        if response_is_success:
            logger.error('Response for Radar IDs {} is not a list: {}'.format(batch_radar_ids, problem_or_error_data))
            error = CorruptedResponseException(status, message, u'Response for Radar IDs {} is not a list: {}'.format(batch_radar_ids, problem_or_error_data))
        else:
            error_cls = http_request_utilities.exception_class_for_unsuccessful_http_response_code(status)
            error = error_cls(status, message, u'Non-200 response code {} for Radar ID batch {}: {}'.format(status, batch_radar_ids, message))

        logger.error('Response for Radar IDs {} error: {}'.format(batch_radar_ids, error))

        for failed_radar_id in batch_radar_ids:
            if error_callback:
                error_callback(failed_radar_id, error)
            else:
                logger.error(compat.unicode_string_type(error).encode('utf-8'))

    def _process_unsuccessful_response_exception_for_batch(self, batch_radar_ids, unsuccessful_response_exception, error_callback):
        assert error_callback
        logger.error('Response for Radar IDs {} error: {}'.format(batch_radar_ids, unsuccessful_response_exception))

        for failed_radar_id in batch_radar_ids:
            error_callback(failed_radar_id, unsuccessful_response_exception)

    def radars_for_ids_multithreaded(self, problem_ids, additional_fields=None, batch_size=15, progress_callback=None,
                                     error_callback=None, verbose=False, fetch_person_info_from_ds=None,
                                     max_pull_thread_count=4, return_result_queue=False, fields=None):
        """
        Loads Radars given their IDs using the :py:class:`~radarclient.client.SimpleThreadManager` class.

        It uses the same parameters as :py:meth:`radars_for_ids` with two additional parameters:

        :param int max_pull_thread_count: The maximum number of parallel threads to open. This defaults to ``4``.
        :param bool return_result_queue: Pass in ``True`` to return a tuple containing
            ``(result_queue, exception_queue, thread_set)``. You can use the queue as input for a multiprocessed
            system. All 3 items in the tuple can be used with
            :py:class:`~radarclient.utilities.wait_for_multithreaded_completion_helper` to wait for all threads to
            complete and add appropriate sentinel values to the ``result_queue`` to stop your spawned processes. This
            should only be used when you need to access the ``Queue`` of radar results directly.
        :return: A Generator for the :py:class:`~radarclient.model.Radar` objects matching the provided IDs or, if
            ``return_result_queue=True``, a tuple containing ```(result_queue, exception_queue, thread_set)``
        :rtype: :py:meth:`~radarclient.utilities.multithreaded_results_gen`, tuple
        :raises: If an error is raised in a child thread, that error will be raised in the main thread. If
            multiple threads raise an error, only the first error is raised.

        """
        assert None not in problem_ids, "None value passed in 'problem_ids'"

        chunked_ids = [problem_ids[i:i + batch_size] for i in range(0, len(problem_ids), batch_size)]

        self.authentication_strategy.ensure_valid_authentication_credentials()  # Ensures /signon for accessToken first
        manager = SimpleThreadManager(chunked_ids, chunked_kwarg='problem_ids', max_thread_count=max_pull_thread_count)
        return manager.get_threaded_results(
            self,
            'radars_for_ids',
            problem_ids=None,
            additional_fields=additional_fields,
            batch_size=batch_size,
            progress_callback=progress_callback,
            error_callback=error_callback,
            return_result_queue=return_result_queue,
            fields=fields
        )

    @classmethod
    def exception_for_non_success_response(cls, status, item_data):
        if not status and isinstance(item_data, dict):
            status = int(item_data['status'].split()[0])

        assert status and not response_code_is_success(status)
        error_cls = http_request_utilities.exception_class_for_unsuccessful_http_response_code(status)
        if isinstance(item_data, dict):
            message = item_data.get('message', '(No error message available)')
        else:
            message = '(No error message available, response payload = {})'.format(item_data)
        return error_cls(status, message, u'Non-200 response code {}: {}'.format(status, message))

    def create_and_process_exception_for_non_success_response(self, status, item_data, error_callback=None, error_callback_argument=None):
        error = self.exception_for_non_success_response(status, item_data)
        if error_callback:
            error_callback(error_callback_argument, error)
        else:
            # TODO: test unicode 2 and 3
            logger.error(compat.string_representation_for_exception(error))

    def cache_radar(self, radar, fields):
        key = self.cache_key_for_radar_id(radar.id, fields)
        self.radar_cache[key] = radar

    def clear_radar_cache(self):
        """
        Clears the receiver's Radar instance cache. See :py:meth:`RadarClient.radars_for_ids`
        for more information.

        """
        self.radar_cache.clear()

    def cached_radar_for_key(self, key):
        radar = self.radar_cache.get(key, None)
        if radar:
            radar.clear_change_records()
        return radar

    def cache_key_for_radar_id(self, radar_id, fields):
        return str(radar_id) + str(hash(''.join(sorted(fields))))

    def cache_key_map_for_radar_ids(self, radar_ids, fields):
        fields_hash = hash(''.join(sorted(fields)))
        return {str(i) + str(fields_hash): i for i in radar_ids}

    def cached_radar_keys(self):
        return set(self.radar_cache.keys())

    def find_people(self, includeExternal=False, **kwargs):
        """
        Finds Radar users and returns a list of :py:class:`~radarclient.model.Person` objects.

        The available parameters (``**kwargs``) are:

        :param str firstName: first name
        :param str lastName: last name
        :param str company: the name of the company where the person works
        :param str department: the name of the department where the person works
        :param int dsid: Directory Services ID / user ID
        :param list[int] dsids: Like ``dsid`` but allows to query for a list of DSIDs, not just a single one
        :param str email: email address
        :param bool includeInactive: If True, include inactive users in the response
        :param str phone: phone number
        :param str type: ``Internal``, ``External``, or ``All`` (the default)
        :return: list of :py:class:`~radarclient.model.Person` objects or an empty list if none found

        .. note::
            You **must** include at least **one** of the following parameters: ``firstName``, ``lastName``, ``dsid``,
            ``department``, ``email``, or ``phone``.

        Examples::

            people_query = radar_client.find_people(lastName='Smith')
            for person in people_query:
                print(person)

        """
        available_params = ['firstName', 'lastName', 'company', 'department',
                            'dsid', 'email', 'includeInactive', 'phone', 'type', 'dsids']
        for param in kwargs.keys():
            assert param in available_params, "{} is not a supported parameter! The available parameters are {}".format(
                param,
                available_params
            )
        request_data = {k: v for k, v in list(kwargs.items()) if v}
        if includeExternal and 'type' not in request_data:
            request_data['type'] = 'All'

        return Person._find(request_data, self, return_results_directly=True)

    def current_user(self, ignore_cache=False):
        """
        Returns a :py:class:`~radarclient.model.Person` instance for the currently logged in user,
        corresponding to the credentials encoded in the :py:class:`AuthenticationStrategy`
        that was used to create the receiver.

        The receiver will query the server once for the first call to this method
        and cache the result. All subsequent calls on the same receiver instance
        return the cached value.

        Example::

            person = radar_client.current_user()
            print('Logged in as {} {} ({})'.format(person.firstName, person.lastName, person.email))

        """
        if not self.current_user_person or ignore_cache:
            _, person_data = self.build_and_send_request(('people', 'find', 'current-user'))
            self.current_user_person = Person(person_data)

        return self.current_user_person

    def person_for_dsid(self, dsid):
        """
        Get a :py:class:`~radarclient.model.Person` object from its DSID. A convenience wrapper for
        :py:meth:`~find_people`.

        :param int dsid: The DSID of the Person to retrieve.
        :return: The :py:class:`~radarclient.model.Person` object, or ``None``.
        """
        people = self.find_people(includeExternal=True, dsid=dsid)
        if people and len(people) == 1:
            return people[0]
        return None

    def create_component(self, request_data, additional_fields=None):
        """
        Create a new Radar component. The ability to create a new Component is restricted to users who have taken and
        passed the Component Creator class on the Radar website, and not available to all users by default.

        :param dict request_data: A dictionary with the initial properties of the component, see the code example below
            or consult the `Create Component API Docs`_.
        :param list additional_fields: Optional list of additional fields to request.

        Returns a :py:class:`~radarclient.model.Component` instance for the new component. At that time, the component
        has been committed to the Radar database and is visible to other users. The returned instance has a default set
        of attributes populated. Additional attributes can be requested via the ``additional_fields`` parameter.

        This method can raise an :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if the component
        could not be created.

        Example::

            user_dsid = self.client.current_user().dsid
            component_name = 'New Component'
            component_version = '1.0'
            work_group_id = 123456 # Work Group must be specified by ID

            request_data = {
                'description': 'create_component test',
                'isOpenToExternals': False,
                'isRestricted': True,
                'isRootLevel': True,
                'name': component_name,
                'ownerId': user_dsid,
                'version': component_version,
                'workGroup': work_group_id,
            }

            component = radar_client.create_component(request_data)

        When creating a subcomponent (``'isRootLevel': False``), the following attributes are required:

        - doesInheritBuildsAndMilestones (:py:class:`bool`)
        - doesInheritAccessGroups (:py:class:`bool`)
        - doesInheritDescriptionTemplates (:py:class:`bool`)
        - doesInheritTentpole (:py:class:`bool`)
        - doesInheritCategory (:py:class:`bool`)
        - doesInheritSysDiagnostics (:py:class:`bool`)
        - parent (dictionary that specifies parent component, see note below)

        .. note::
            The value for ``parent`` is a dictionary that specifies the parent by ``id`` **OR** by ``name`` and ``version``.
        """
        url = self.webservice_url_for_path_components('components')
        query_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=query_json)
        _, component_data = self.send_request(request)
        if additional_fields:
            return self.component_for_id(component_data['id'], additional_fields=additional_fields)
        return Component(component_data)

    def components_for_name(self, name, version=None, additional_fields=None):
        """
        Find components by name and optionally version. It uses the Get Component API from the `Component API Docs`_.

        :param str name: Name of the component(s).
        :param str version: Optional component version.
        :param list additional_fields: Optional list of additional fields to request. See note below.
        :return: A :py:class:`list` of components found, or an empty list if none found.

        .. note::
            As of Radar API v2.2, when providing both ``name`` and ``version`` the API returns a `single` component
            matching both strings exactly, with all possible attributes included (i.e. ``additional_fields`` is
            irrelevant). However, if only ``name`` is provided, because ``GET /components/{name}`` without
            ``/{version}`` is not supported, it will instead call :py:meth:`~find_components` using an exact (``eq``)
            match for ``name``, and ``additional_fields`` will still be applicable.

        For compatibility, this method will always return the :py:class:`~radarclient.model.Component` object[s] in a
        :py:class:`list`.

        The available ``additional_fields`` values are documented in the `Component API Docs`_. Some useful ones are
        ``screener``, ``owner`` and ``subcomponents``.
        """
        if version is not None:
            item = '{}/{}'.format(name, version)
            # With name and version provided, this endpoint returns a single value, but behaves like a multi-object
            # endpoint and therefore uses the get_by_ids function
            return Component._get_by_ids([item], self, additional_fields=additional_fields)
        else:
            request_data = {'name': {'eq': name}}
            return self.find_components(request_data, additional_fields=additional_fields)

    def component_for_name_and_version(self, name, version, additional_fields=None):
        """
        Find a component by name `and` version. This is a convenience wrapper for :py:meth:`~components_for_name` that
        will return a single :py:class:`~radarclient.model.Component` object. It uses the Get Component API from the
        `Component API Docs`_.

        :param str name: Component name.
        :param str version: Component version.
        :param list additional_fields: Optional list of additional fields to request. See note below.
        :return: A :py:class:`~radarclient.model.Component` object,

        .. note::
            As of Radar API v2.2, the Component object returned will automatically include all possible attributes, so
            ``additional_fields`` is irrelevant. We will retain support for it in case this changes in the future.

        """
        components = self.components_for_name(name, version, additional_fields=additional_fields)
        assert len(components) != 0, "No components found"
        assert len(components) == 1, "More than one Component was found"
        return components[0]

    def find_components(self, request_data, additional_fields=None, limit=None):
        """
        Find components by search criteria other than name and version.

        :param dict request_data: request attributes
        :param list additional_fields: Optional list of additional fields to request. See warning below.
        :param int limit: the maximum number of items to return.
        :return: A list of matching :py:class:`~radarclient.model.Component` objects, or an empty list if none found.

        .. warning::
            Restricted components (i.e. ``isRestricted=True``) cannot be loaded via this method `specifically with`
            ``additional_fields`` and will result in a ``403 Forbidden`` error.

        The available ``request_data`` query fields and ``additional_fields`` parameter
        values are documented in the `Component API Docs`_.

        Example::

            request_data = {
                'description': 'foo bar'
            }
            components = radar_client.find_components(request_data)
            for component in components:
                print(component.id)

        """
        return Component._find(request_data, self, limit=limit, additional_fields=additional_fields,
                               return_results_directly=True)

    def component_for_id(self, component_id, additional_fields=None):
        """
        Find component by id. It uses the Get Component API from the `Component API Docs`_.

        :param int component_id: id of the component
        :param list additional_fields: Optional list of additional fields to request
        :return: A :py:class:`~radarclient.model.Component` object, or
            :py:class:`~radarclient.exceptions.ObjectNotFoundException` if not found.

        .. note::
            As of Radar API v2.2, the Component object returned will automatically include all possible attributes, so
            ``additional_fields`` is irrelevant. We will retain support for it in case this changes in the future.

        The available ``additional_fields`` values are documented in the `Component API Docs`_.
        """
        return Component._get_by_id(component_id, self, additional_fields=additional_fields)

    def components_for_ids(self, component_ids, additional_fields=None, batch_size=1000):
        """
        Find multiple components by their IDs. This is a convenience wrapper for :py:meth:`~find_components()` using the
        ``componentIds`` request attribute.

        Due to API limitations, the Component objects returned by this method include fewer attributes by default than
        the responses to :py:meth:`component_for_id`, and are limited to ``id``, ``name``, ``version``, ``description``,
        ``isClosed``, and ``isRestricted``.

        :param list component_ids: The list of component IDs (:py:class:`int`)
        :param list additional_fields: Optional list of additional fields to request. See warning below.
        :param int batch_size: The number of Components that should be loaded in one request to the Radar API. Defaults to 1000, the maximum is 1000.
        :return: A :py:class:`~radarclient.model.Component` object, or an empty list if none found.

        .. warning::
            Restricted components (i.e. ``isRestricted=True``) cannot be loaded via this method `specifically with`
            ``additional_fields`` and will result in a ``403 Forbidden`` error.

        The available ``additional_fields`` values are documented in the `Component API Docs`_.
        """
        if batch_size > 1000:
            logger.warning(u'Requested batch size {} is too big, limiting to {}'.format(batch_size, 1000))
            batch_size = 1000

        loaded_components = []
        for i in range(0, len(component_ids), batch_size):
            batch_component_ids = component_ids[i:i + batch_size]
            batch_loaded_components = self.find_components({'componentIds': batch_component_ids}, additional_fields=additional_fields)
            loaded_components.extend(batch_loaded_components)

        return loaded_components

    def component_ancestors_for_component_id(self, component_id, additional_fields=None):
        """
        Get a list of all ancestors of a component given its ID.

        :param int component_id: component ID
        :param list additional_fields: Optional list of additional fields to request

        Returns a list of ancestor components as instances of :py:class:`~radarclient.model.Component`,
        ordered from closest (parent) to most distant ancestor. If any parent component in the ancestry is inaccessible,
        the final component in the list will be a :py:class:`~radarclient.model.ComponentInaccessible`.

        The available ``additional_fields`` parameter values are documented in the
        `Component API Docs`_.

        Example::

            components = client.find_components({'name': {'eq': 'Accounts'}, 'version': 'iOS'})
            ancestors = client.component_ancestors_for_component_id(components[0].id)
            for component in ancestors:
                print(component.id, component.name, component.version)

        """
        ancestors = []
        component = self.component_for_id(component_id, additional_fields=additional_fields)
        while True:
            parent = component.parent
            if parent:
                try:
                    component = self.component_for_id(parent.id, additional_fields=additional_fields)
                    ancestors.append(component)
                except UnsuccessfulResponseException as ure:
                    if ure.code == 403:
                        ancestors.append(ComponentInaccessible({'id': parent.id}))
                        break
                    raise ure
            else:
                break
        return ancestors

    def component_tree_for_component(self, component, flattened_by=None, include_closed=True, max_tree_height=None):
        """
        Fetch the component hierarchy for a given parent component.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param str flattened_by: [Optional] Flatten the component hierarchy into a :py:class:`list`, ordered either
            ``breadth_first`` or ``depth_first``.
        :param bool include_closed: [Optional] Whether or not to include closed Components in the response. Defaults to
            ``True`` to match the API behavior.
        :param int max_tree_height: [Optional] How deep to limit the hierarchy in the response.
        :return: A :py:class:`~radarclient.model.Component` with nested Components in its ``subcomponents`` property, or
            if ``flattened_by`` was specified, a :py:class:`list` of Component objects, ordered by ``breadth_first`` or
            ``depth_first``. Inaccessible components are represented by
            :py:class:`~radarclient.model.ComponentInaccessible`.

        .. rubric:: Known Caveats

        - **Radar API v2.2** includes closed components by default and the ``includeClosedLeafNodes`` header will only\
        cause the API to filter out closed **leaf nodes** (i.e. closed components `without` subcomponents). In other\
        words, closed components that have open subcomponents will `always` be included.

        """
        component = self._get_component_object(component)
        assert component.id, "Component object is missing an 'id' property"
        url = ('components', component.id, 'componentTree')
        additional_headers = [('includeClosedLeafNodes', include_closed)]
        if max_tree_height:
            assert isinstance(max_tree_height, int), "max_tree_height must be an integer"
            additional_headers.append(('maxTreeHeight', max_tree_height))
        status, response = self.build_and_send_request(url, additional_headers=additional_headers)

        if not response_code_is_success(status):
            raise self.exception_for_non_success_response(status, response)

        root_component = Component(response)
        if not flattened_by:
            return root_component

        assert flattened_by in ['breadth_first', 'depth_first'], "Unknown value for 'flattened_by': {}".format(flattened_by)
        component_list = []
        to_process = [root_component]
        while to_process:
            parent = to_process.pop(0)
            if flattened_by == 'breadth_first':
                to_process = to_process + parent.subcomponents
            elif flattened_by == 'depth_first':
                to_process = parent.subcomponents + to_process
            component_list.append(parent)

        return component_list

    def _convert_to_components(self, component_like_objects):
        """
        Converts a list/set of Component-like objects (Components, ComponentBundleMember, ComponentBundleItem, etc.) and
        returns a list of Component or ComponentInaccessible objects.

        :meta private:
        """
        all_components = []
        for component_object in component_like_objects:
            if isinstance(component_object, Component):
                all_components.append(component_object)
            else:
                all_components.append(ComponentValueConverter.decode_radar_value(component_object.dictionary_representation_data))
        return all_components

    def components_for_bundle(self, bundle):
        """
        Retrieve all the Components included in a :py:class:`~radarclient.model.ComponentBundle`.

        Per the Radar API, all components in the bundle are returned, even if they're closed (``isClosed==True``).
        Specifically on **Radar API v2.2+**, the response also includes `inaccessible` components.

        :param ComponentBundle bundle: The :py:class:`~radarclient.model.ComponentBundle`, or the Component Bundle's
            ``id`` as an :py:class:`int`.
        :return: A :py:class:`list` of :py:class:`~radarclient.model.Component` and
            :py:class:`~radarclient.model.ComponentInaccessible` objects.
        """
        if isinstance(bundle, int):
            bundle = self.component_bundle_for_id(bundle, include_component_children=True)
        else:
            needs_reload = False
            for member in bundle.components:
                if member.isComponentTreeIncluded and not hasattr(member, 'subcomponents') or member.subcomponents is None:
                    needs_reload = True
                    break
            if needs_reload:
                bundle = self.component_bundle_for_id(bundle.id, include_component_children=True)

        all_component_objects = set()
        for member in bundle.components:
            if member.isComponentTreeIncluded:
                to_process = [member]
                while to_process:
                    parent = to_process.pop(0)
                    to_process = to_process + parent.subcomponents
                    all_component_objects.add(parent)
            else:
                all_component_objects.add(member)

        return self._convert_to_components(all_component_objects)

    def components_for_bundle_group(self, bundle_group):
        """
        Retrieve all the Components included in a :py:class:`~radarclient.model.ComponentBundleGroup`.

        Per the Radar API, all components in the bundle group are returned, even if they're closed (``isClosed==True``).
        Specifically on **Radar API v2.2+**, the response also includes `inaccessible` components.

        :param ComponentBundleGroup bundle_group: The :py:class:`~radarclient.model.ComponentBundleGroup`, or the
            Component Bundle Group's ``id`` as an :py:class:`int`.
        :return: A :py:class:`list` of :py:class:`~radarclient.model.Component` and
            :py:class:`~radarclient.model.ComponentInaccessible` objects.
        """
        if isinstance(bundle_group, int):
            bundle_group = self.component_bundle_group_for_id(bundle_group)

        all_component_objects = set()
        for bundle in bundle_group.memberBundles:
            all_component_objects.update(self.components_for_bundle(bundle.id))
        for bundle_group in bundle_group.memberGroups:
            all_component_objects.update(self.components_for_bundle_group(bundle_group.id))

        return self._convert_to_components(all_component_objects)

    def _get_component_object(self, component_arg):
        """
        Ensures that a component argument is an instance of the Component class, not just an int or dict.

        :meta private:
        """
        if isinstance(component_arg, int):
            return self.component_for_id(component_arg)
        elif isinstance(component_arg, dict):
            return Component(component_arg)
        elif isinstance(component_arg, Component):
            return component_arg
        raise Exception("The 'component' argument must be a Component object, Component dict, or ID integer")

    def _program_management_property_items_for_component(self, component, property_class, path_component,
                                                         include_closed, load_expanded_objects=False):
        component = self._get_component_object(component)

        assert component.id, "Component object is missing an 'id' property"
        url = self.webservice_url_for_path_components('components', component.id, path_component)

        request = self.request_for_json_url(url)
        if not include_closed:
            request.add_header('X-Fetch-Open', 'true')

        status, response_data = self.send_request(request)
        if status == 404:
            return None
        elif not response_code_is_success(status):
            raise self.exception_for_non_success_response(status, response_data)

        component_property_items = [property_class(item_data, component=component) for item_data in response_data]

        if not load_expanded_objects:
            return component_property_items
        else:
            # For accessing the "Get Component Event/Category/Tentpole by ID" APIs, only available in v2.2+
            expanded_property_items = []
            for component_property_item in component_property_items:
                url = ('components', component_property_item.definedComponentId, path_component, component_property_item.id)
                status, response_data = self.build_and_send_request(url)
                if response_code_is_success(status):
                    response_data['definedComponentId'] = component_property_item.definedComponentId
                    if path_component == 'milestones':
                        response_data['inheritanceType'] = component_property_item.inheritanceType
                    else:
                        response_data['inherited'] = component_property_item.inherited
                    expanded_property_items.append(property_class(response_data, component=component))
            return expanded_property_items

    def events_for_component(self, component, include_associations=False, include_closed=False):
        """
        Find the Events associated with the specified ``component``.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param bool include_associations: Will retrieve the expanded :py:class:`~radarclient.model.Event` objects that
            include the associated :py:class:`~radarclient.model.Milestone` objects. **Only available on API v2.2+.**
        :param bool include_closed: Whether or not to include closed Events.
        :return: A list of :py:class:`~radarclient.model.Event` objects, or an empty list if none found.

        Example::

            request_data = {
                'id': 1234
            }
            component, = radar_client.find_components(request_data)
            events = radar_client.events_for_component(component)
            for event in events:
                print(event.name)

        """
        return self._program_management_property_items_for_component(component, Event, 'events',
                                                                     include_closed=include_closed,
                                                                     load_expanded_objects=include_associations)

    def categories_for_component(self, component, include_associations=False, include_closed=False):
        """
        Find the Categories associated with the specified ``component``.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param bool include_associations: Will retrieve the expanded :py:class:`~radarclient.model.Category` objects
            that also include the associated :py:class:`~radarclient.model.Milestone` objects. **Only available on API
            v2.2+.**
        :param bool include_closed: Whether or not to include closed Categories.
        :return: A list of :py:class:`~radarclient.model.Category` objects, or an empty list if none found.
        """
        return self._program_management_property_items_for_component(component, Category, 'categories',
                                                                     include_closed=include_closed,
                                                                     load_expanded_objects=include_associations)

    def tentpoles_for_component(self, component, include_associations=False, include_closed=False):
        """
        Find the Tentpoles associated with the specified ``component``.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param bool include_associations: Will retrieve the expanded
            :py:class:`~radarclient.model.Tentpole` objects that also include the associated
            :py:class:`~radarclient.model.Milestone`, :py:class:`~radarclient.model.Category`, and
            :py:class:`~radarclient.model.Event` objects. **Only available on API v2.2+.**
        :param bool include_closed: Whether or not to include closed Tentpoles.
        :return: A list of :py:class:`~radarclient.model.Tentpole` objects, or an empty list if none found.
        """
        return self._program_management_property_items_for_component(component, Tentpole, 'tentpoles',
                                                                     include_closed=include_closed,
                                                                     load_expanded_objects=include_associations)

    def milestones_for_component(self, component, include_access_groups=False, include_closed=False):
        """
        Find the Milestones associated with the specified ``component``.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param bool include_access_groups: Will retrieve the expanded Milestone objects with the lists of
            :py:class:`~radarclient.model.AccessGroup` objects for their ``restrictedAccessGroups`` and
            ``protectedAccessGroups`` attributes.
        :param bool include_closed: Whether or not to include closed Milestones.
        :return: A list of :py:class:`~radarclient.model.Milestone` objects.

        For more information, see the `Get Component Milestones API Docs`_.
        """
        return self._program_management_property_items_for_component(component, Milestone, 'milestones',
                                                                     include_closed=include_closed,
                                                                     load_expanded_objects=include_access_groups)

    def builds_for_component(self, component, include_closed=False):
        """
        Find the Builds associated with the specified ``component``.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param bool include_closed: Whether or not to include closed Builds.
        :return: A list of :py:class:`~radarclient.model.Build` instances.
        """
        return self._program_management_property_items_for_component(component, Build, 'builds',
                                                                     include_closed=include_closed)

    def keywords_for_component(self, component, additional_fields=None, include_inherited=True, include_closed=False):
        """
        Find the Keywords associated with the specified ``component``.

        :param ~radarclient.model.Component component: The target component object. Will also accept an ``id``
            :py:class:`int`.
        :param list additional_fields: A list of optional properties to include in the response. Currently this
            only supports ``component``, which will reference the `defining` component for each keyword, inherited or
            not.
        :param bool include_inherited: Whether or not to include inherited keywords. Defaults to ``True``.
        :param bool include_closed: Whether or not to include closed Keywords. Defaults to ``False``.
        :return: A list of :py:class:`~radarclient.model.Keyword` instances.
        """
        # Keywords have separate logic from the Program Management properties, so handle this retrieval separately
        component = self._get_component_object(component)
        assert component.id, "Component object is missing an 'id' property"

        if additional_fields is None:
            additional_fields = []

        url = self.webservice_url_for_path_components('components', component.id, 'keywords')
        request = self.request_for_json_url(url)
        status, response_data = self.send_request(request)
        if status == 404:
            return None
        elif not response_code_is_success(status):
            raise self.exception_for_non_success_response(status, response_data)

        all_kw_dicts = [item_data for item_data in response_data]

        if not include_closed:
            all_kw_dicts = [kw_dict for kw_dict in all_kw_dicts if not kw_dict['keyword']['closed']]
        if not include_inherited:
            all_kw_dicts = [kw_dict for kw_dict in all_kw_dicts if not kw_dict['inherited']]

        if 'component' in additional_fields:
            defining_component_ids = set([kw_dict['keyword']['definedComponentId'] for kw_dict in all_kw_dicts])
            defining_components = self.components_for_ids(list(defining_component_ids))
            defining_component_map = {component.id: component for component in defining_components}
            all_keywords = [Keyword(kw_dict, component=defining_component_map[kw_dict['keyword']['definedComponentId']]) for kw_dict in all_kw_dicts]
        else:
            all_keywords = [Keyword(kw_dict) for kw_dict in all_kw_dicts]

        return all_keywords

    def milestone_associations_for_component_id(self, component_id, milestone_id=None, category_id=None, event_id=None, tentpole_id=None, include_closed=False):
        """
        Returns the associated/available :py:class:`~radarclient.model.Event`, :py:class:`~radarclient.model.Category`, and :py:class:`~radarclient.model.Tentpole`
        objects for a given Component's ID, in the form of a :py:class:`~radarclient.model.MilestoneAssociations` object.

        :param int component_id: The target Component's ID
        :param int milestone_id: Optional Milestone ID to filter the results
        :param int category_id: Optional Category ID to filter the results. If provided, the ``categories`` property
            for the resulting :py:class:`~radarclient.model.MilestoneAssociations` object will be empty
        :param int event_id: Optional Event ID to filter the results. If provided, the ``events`` property
            for the resulting :py:class:`~radarclient.model.MilestoneAssociations` object will be empty
        :param int tentpole_id: Optional Tentpole ID to filter the results. If provided, the ``tentpoles`` property
            for the resulting :py:class:`~radarclient.model.MilestoneAssociations` object will be empty
        :param bool include_closed: Whether or not to include closed entities in the results

        For more information, see the `Fetch Component Milestone's Association API Docs`_.
        """
        url = ('components', component_id, 'fetchMilestoneAssociations')
        request_data = {'includeClosed': include_closed}
        if milestone_id is not None:
            request_data['milestoneId'] = milestone_id
        if category_id is not None:
            request_data['categoryId'] = category_id
        if event_id is not None:
            request_data['eventId'] = event_id
        if tentpole_id is not None:
            request_data['tentpoleId'] = tentpole_id

        status, response = self.build_and_send_json_request(url, request_data=request_data, method='POST')
        if response_code_is_success(status):
            return MilestoneAssociations(response, component_id=component_id)

        raise self.exception_for_non_success_response(status, response)

    def access_groups_for_component_id(self, component_id):
        """
        Find the Access Groups defined for a provided Component's id.

        :param int component_id: The target Component's ID
        :return: A list of :py:class:`~radarclient.model.AccessGroup` instances.
        """
        url = ('components', component_id, 'accessgroups')
        status, response_data = self.build_and_send_request(url)
        if status == 404:
            return None
        elif not response_code_is_success(status):
            raise self.exception_for_non_success_response(status, response_data)

        access_groups = [AccessGroup(group_data) for group_data in response_data]
        # 'roles' isn't a property of the response from GET /components/{component-id}/accessgroups
        for access_group in access_groups:
            del access_group.roles
        return access_groups

    def work_group_for_component_id(self, component_id):
        """
        Find the Work Group defined for a provided Component's ID. A convenience wrapper for
        :py:meth:`~RadarClient.component_for_id` that returns the ``workGroupObject`` property of the corresponding
        :py:class:`~radarclient.model.Component`.

        :param int component_id: The target Component's ID
        :return: A :py:class:`~radarclient.model.WorkGroup`.
        """
        return self.component_for_id(component_id).workGroupObject

    def _create_program_management_property_item_for_component(self, request_data, component, property_name):
        component = self._get_component_object(component)

        assert component.id, "Component object is missing an 'id' property"
        url = self.webservice_url_for_path_components('components', component.id, property_name)

        query_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=query_json)

        status, object_data = self.send_request(request)
        if status != 201:
            return None
        return object_data

    def create_event_for_component(self, request_data, component):
        """
        Create a new :py:class:`~radarclient.model.Event` for a component.

        :param dict request_data: A dictionary with the initial properties of the Event, see the code example below.
        :param `~radarclient.model.Component` component: The component the new event is associated with. Will also
            accept an ``id`` :py:class:`int`.
        :return: An :py:class:`~radarclient.model.Event` instance for the newly created event.

        Example::

            # Using API v2.1
            request_data = {
                'name': u'NewMilestone',
                'beginsAt': '2022-07-01T00:00:00-0000',
                'endsAt': '2022-08-01T00:00:00-0000',
                'isTentpoleRequired': false,
            }

            # Using API v2.2
            request_data = {
                'name': u'NewMilestone',
                'startDate': '2022-07-01T00:00:00-0000',
                'endDate': '2022-08-01T00:00:00-0000',
                'tentpoleRequired': false,
            }

            component = radar_client.component_for_id(514369)
            event = radar_client.create_event_for_component(request_data, component)

        """
        event_data = self._create_program_management_property_item_for_component(request_data, component, 'events')
        events = Event.parse_webservice_data(event_data, component, self)
        return events[0]

    def create_milestone_for_component(self, request_data, component):
        """
        Create a new :py:class:`~radarclient.model.Milestone` for a component, and returns the newly-created Milestone
        instance.

        Behaves like :py:meth:`~RadarClient.create_event_for_component`; see that method for more details.

        See :py:class:`~radarclient.model.Milestone` for more details about the required parameters.
        """
        milestone_data = self._create_program_management_property_item_for_component(request_data, component,
                                                                                     'milestones')
        milestones = Milestone.parse_webservice_data(milestone_data, component, self)
        return milestones[0]

    def create_build_for_component(self, request_data, component):
        """
        Create a new :py:class:`~radarclient.model.Build` for a component, and returns the newly-created Build instance.

        Behaves like :py:meth:`~RadarClient.create_event_for_component`; see that method for more details.

        See :py:class:`~radarclient.model.Build` for more details about the required parameters.
        """
        build_data = self._create_program_management_property_item_for_component(request_data, component, 'builds')
        builds = Build.parse_webservice_data(build_data, component, self)
        return builds[0]

    def create_category_for_component(self, request_data, component):
        """
        Create a new :py:class:`~radarclient.model.Category` for a component, and returns the newly-created Category
        instance.

        Behaves like :py:meth:`~RadarClient.create_event_for_component`; see that method for more details.

        See :py:class:`~radarclient.model.Category` for more details about the required parameters.
        """
        category_data = self._create_program_management_property_item_for_component(request_data, component,
                                                                                    'categories')
        categories = Category.parse_webservice_data(category_data, component, self)
        return categories[0]

    def create_tentpole_for_component(self, request_data, component):
        """
        Create a new :py:class:`~radarclient.model.Tentpole` for a component, and returns the newly-created Tentpole
        instance.

        Behaves like :py:meth:`~RadarClient.create_event_for_component`; see that method for more details.

        See :py:class:`~radarclient.model.Tentpole` for more details about the required parameters.
        """
        tentpole_data = self._create_program_management_property_item_for_component(request_data, component,
                                                                                    'tentpoles')
        tentpoles = Tentpole.parse_webservice_data(tentpole_data, component, self)
        return tentpoles[0]

    def create_keyword_for_component(self, request_data, component):
        """
        Create a new :py:class:`~radarclient.model.Keyword` for a component, and returns the newly-created Keyword
        instance.

        Behaves like :py:meth:`~RadarClient.create_event_for_component`; see that method for more details.

        See :py:class:`~radarclient.model.Keyword` for more details about the required parameters.
        """
        keyword_data = self._create_program_management_property_item_for_component(request_data, component, 'keywords')
        keywords = Keyword.parse_webservice_data(keyword_data, component, self)
        return keywords[0]

    def _delete_program_management_property_items_from_component(self, items_to_delete, component, property_name):
        component = self._get_component_object(component)
        assert component.id, "Component object is missing an 'id' property"
        url = ('components', component.id, property_name, ','.join(str(item.id) for item in items_to_delete))
        status, _ = self.build_and_send_request(url, method='DELETE')
        return response_code_is_success(status)

    def delete_component_events(self, events, component):
        """
        Removes :py:class:`~radarclient.model.Event` objects from a Component.

        :param list events: A list of the Event objects to be removed.
        :param `~radarclient.model.Component` component: The Component that the Events are defined on. Will also accept
            an ``id`` :py:class:`int`.
        :return: :py:class:`bool`, True if successful, False if not.

        Event objects can be retrieved via :py:meth:`events_for_component` or the ``event`` property of a Radar object.
        """
        return self._delete_program_management_property_items_from_component(events, component, 'events')

    def delete_component_milestones(self, milestones, component):
        """
        Removes :py:class:`~radarclient.model.Milestone` objects from a Component.

        Behaves like :py:meth:`~RadarClient.delete_component_events`; see that method for more details.

        Milestone objects can be retrieved via :py:meth:`milestones_for_component` or the ``milestone`` property of a
        Radar object.
        """
        return self._delete_program_management_property_items_from_component(milestones, component, 'milestones')

    def delete_component_builds(self, builds, component):
        """
        Removes :py:class:`~radarclient.model.Build` objects from a Component.

        Behaves like :py:meth:`~RadarClient.delete_component_events`; see that method for more details.

        Build objects can be retrieved via :py:meth:`builds_for_component` or the ``build`` property of a Radar object.
        """
        return self._delete_program_management_property_items_from_component(builds, component, 'builds')

    def delete_component_categories(self, categories, component):
        """
        Removes :py:class:`~radarclient.model.Category` objects from a Component.

        Behaves like :py:meth:`~RadarClient.delete_component_events`; see that method for more details.

        Category objects can be retrieved via :py:meth:`categories_for_component` or the ``event`` property of a Radar
        object.
        """
        return self._delete_program_management_property_items_from_component(categories, component, 'categories')

    def delete_component_tentpoles(self, tentpoles, component):
        """
        Removes :py:class:`~radarclient.model.Tentpole` objects from a Component.

        Behaves like :py:meth:`~RadarClient.delete_component_events`; see that method for more details.

        Tentpole objects can be retrieved via :py:meth:`tentpoles_for_component` or the ``tentpole`` property of a Radar
        object.
        """
        return self._delete_program_management_property_items_from_component(tentpoles, component, 'tentpoles')

    def delete_component_keywords(self, keywords, component):
        """
        Removes :py:class:`~radarclient.model.Keyword` objects from a Component.

        Behaves like :py:meth:`~RadarClient.delete_component_events`; see that method for more details.

        Keyword objects can be retrieved via :py:meth:`keywords_for_component` or the ``keywords()`` property of a Radar
        object.
        """
        return self._delete_program_management_property_items_from_component(keywords, component, 'keywords')

    def component_bundle_for_id(self, bundle_id, include_component_children=False):
        """
        Find component bundle by id

        :param int bundle_id: id of the component bundle
        :param bool include_component_children: If true, the components returned in the bundle
            include their child components.
        :return: :py:class:`~radarclient.model.ComponentBundle` object, or
            :py:class:`~radarclient.exceptions.ObjectNotFoundException` if not found.

        """
        if include_component_children:
            headers = [('X-Component-Children', True)]
        else:
            headers = None
        return ComponentBundle._get_by_id(bundle_id, self, additional_headers=headers)

    def component_bundles_for_ids(self, bundle_ids, include_component_children=False):
        """
        Get component bundles for a list of IDs.

        :param list[int] bundle_ids: list of IDs
        :param bool include_component_children: If True, the components returned in the bundle
            include their child components

        :return: list of :py:class:`~radarclient.model.ComponentBundle` objects or an empty list if none found.
        """
        if include_component_children:
            headers = [('X-Component-Children', True)]
        else:
            headers = None

        return ComponentBundle._pseudo_get_by_ids(bundle_ids, self, additional_headers=headers)

    def component_bundles_for_name(self, name, include_component_children=False):
        """
        Get :py:class:`~radarclient.model.ComponentBundle` objects using a name string search. Specifically searches for
        bundles with names that `include` the provided value for ``name``. Essentially a wrapper \
        for :py:meth:`find_component_bundles`.

        :param str name: :py:class:`~radarclient.model.ComponentBundle` name (partial match allowed)
        :param bool include_component_children: If true, the components returned in the bundle
            include their child components

        :return: A list of :py:class:`~radarclient.model.ComponentBundle` objects, or an empty list if none found.
        """
        request_data = {
            'name': '%{}%'.format(name)
        }
        bundles = self.find_component_bundles(
            request_data,
            include_component_children=include_component_children,
            return_results_directly=True
        )
        return bundles

    def find_component_bundles(self, query_data, include_component_children=False, limit=None,
                               return_results_directly=False):
        """
        Find component bundles. Previously took name as an argument. This functionality has been
        moved to :py:meth:`component_bundles_for_name`. The find API endpoint only returns
        information about the component bundle, not of the components. If that is all that is
        needed, time can be saved by using return_results_directly. Otherwise it will get the IDs
        of matching component bundles and then get by ID for those.

        :param dict query_data: query dictionary per `Find Component Bundle Docs`_
        :param bool include_component_children: If true, the components returned in the bundle
            include their child components. This cannot be used if return_results_directly is True
        :param int limit: maximum number of items to return
        :param bool return_results_directly: If True, will return just the results of the find

        :return: a :py:class:`list` of :py:class:`~radarclient.model.ComponentBundle` instances, or an empty list if none found.

        """
        if isinstance(query_data, compat.unicode_string_type):
            warnings.warn('Searching by string name is deprecated for this method. Please switch '
                          'to using component_bundle_for_name()')
            return self.component_bundles_for_name(
                query_data, include_component_children=include_component_children
            )

        exclusive_fields = None
        headers = None
        if not return_results_directly:
            exclusive_fields = ['id']
            if include_component_children:
                headers = [('X-Component-Children', True)]

        partial_get_by_ids = partial(self.component_bundles_for_ids,
                                     include_component_children=include_component_children)

        # Radar API does not generally raise an error if there are no results. This endpoint
        # does. Adding in a catch to handle that. See <rdar://problem/68867421> Find Component
        # Bundles Returns Error if Not Matches Found
        try:
            to_return = ComponentBundle._find(
                query_data, self, return_results_directly=return_results_directly, limit=limit,
                exclusive_fields_for_first_search=exclusive_fields, additional_headers=headers,
                get_ids_method=partial_get_by_ids
            )
        except UnsuccessfulResponseException as ure:
            if ure.code == 404:
                to_return = []
            else:
                raise
        return to_return

    def find_component_bundle_names(self, name):
        """
        Find all :py:class:`~radarclient.model.ComponentBundle` objects by name string search. Specifically searches for
        bundles with names that `include` the provided value for ``name``. Essentially a wrapper \
        for :py:meth:`component_bundles_for_name`.

        :param str name: :py:class:`~radarclient.model.ComponentBundle` name (partial match allowed)
        :return: a :py:class:`list` of strings representing the component bundle names that matched the name prefix
        """
        bundles = self.component_bundles_for_name(name)
        bundle_names = [bundle.name for bundle in bundles]
        return bundle_names

    def component_bundle_group_for_id(self, bundle_group_id):
        """
        Loads a component bundle group by its ``id``.

        :param int bundle_group_id: id of the component bundle group
        :return: an instance of :py:class:`~radarclient.model.ComponentBundleGroup`, or
            :py:class:`~radarclient.exceptions.ObjectNotFoundException` if not found.
        """
        return ComponentBundleGroup._get_by_id(bundle_group_id, self)

    def component_bundle_groups_for_ids(self, bundle_group_ids):
        """
        Get component bundle groups for a list of IDs.

        :param list[int] bundle_group_ids: list of IDs
        :return: A list of :py:class:`~radarclient.model.ComponentBundleGroup` objects or an empty list if none found.
        """
        return ComponentBundleGroup._pseudo_get_by_ids(bundle_group_ids, self)

    def find_component_bundle_groups(self, request_data):
        """
        Find component bundle groups for the requested attributes.

        :param dict request_data: The query dictionary that defines the component bundle groups to search for.
        :return: A list of :py:class:`~radarclient.model.ComponentBundleGroup` objects or an empty list if none found.
        """
        return ComponentBundleGroup._find(request_data, self, return_results_directly=True)

    def find_radar_count(self, request_data):
        """
        Execute a Radar search and return the count.

        :param dict request_data: request attributes

        See also :py:meth:`RadarClient.find_radar_ids` and :py:meth:`RadarClient.find_radars`.

        .. note::
            As of Radar API v2.2, this API can return an unlimited number of Radars, bound only by
            the :py:class:`~radarclient.client.AuthenticationStrategy`'s ``request_timeout``. Care
            should be taken to size the request query (using either date ranges or other
            filters) to complete in a reasonable amount of time.

        For examples on constructing ``request_data``, see :py:meth:`RadarClient.find_radar_ids`.

        """

        url = self.webservice_url_for_path_components('problems/find')
        query_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=query_json)
        request.add_header('countsOnly', 'true')
        status, info = self.send_request(request)

        return info["totalCount"]

    def find_radar_ids(self, request_data, limit=None):
        """
        Find radars matching the requested attributes and return the list of IDs.

        :param dict request_data: request attributes
        :param int limit: The maximum number of Radar IDs to return. See note below.

        Returns a list of integers representing radar IDs, suitable for passing to :py:meth:`RadarClient.radars_for_ids`.
        If you need a count only, use :py:meth:`RadarClient.find_radar_count`.

        Examples for request_data (API v2.1)::

            { "state": "Analyze" }
            { "state": [ "Analyze", "Verify" ] }
            { "keyword": [ "Snakes on a Radar", "OSX-Perf Reviewed" ] }
            { "component": { "name": "python-radarclient", "version": "1.0" }, "state": "Analyze" }
            { "id": [8000000, 9000000] }

        Examples for request_data (API v2.2+)::

            { "state": { "eq" : "Analyze" } }
            { "state" : { "any" : [ "Analyze", "Verify" ] } }
            { "any" : [ { "keyword" : { "like" : "Snakes on a Radar" } }, { "keyword" : { "like" : "OSX-Perf Reviewed" } } ] }
            { "any" : [ { "keywordId" : { "eq" : 52846 } }, { "keywordId" : { "eq" : 47597 } } ] }
            { "all" : [ { "component" : { "eq" : { "id" : 514369, "includeSubcomponents" : false } } }, { "state" : { "eq" : "Analyze" } } ] }
            { "id" : { "any" : [8000000, 9000000] } }

        .. note::
            Specifically in API v2.2+ the value of ``limit`` will be honored for any number up to and including ``7500``. Any value larger
            will actually set the ``X-RowLimit`` header to ``-1``, thereby raising the cap to the absolute maximum of 250,000.

        """
        limit = limit or 7500
        if limit > 7500:
            limit = -1

        url = self.webservice_url_for_path_components('problems/find')
        query_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=query_json)
        request.add_header('idsOnly', 'true')                   # API v2.2 (don't remove)
        if limit:
            self.configure_request_with_limit(request, limit)
        status, id_list = self.send_request(request)
        if not id_list:
            return []
        else:
            return id_list

    @deprecated(replacement=find_radar_ids, version=1.17)
    def find_problem_ids():
        pass

    def find_radar_ids_multithreaded(self, request_data, chunk_hours, chunking_key='createdAt',
                                     return_result_queue=False, limit=None, max_thread_count=9):
        """
        Find the ID numbers of Radars matching the requested attributes, using multithreaded processing via the
        :py:class:`SimpleThreadManager` class.

        :param dict request_data: request attributes
        :param float chunk_hours: size of chunks in hours. If 3 is passed in, ``request_data`` will be
            divided in to ``n`` chunks, most of which will span 3 hours.
        :param str chunking_key: Key in the query with a datetime value to use for dividing the query.
        :param bool return_result_queue: Pass in ``True`` to return a tuple containing
            ``(result_queue, exception_queue, thread_set)``. You can use the queue as input for a multiprocessed
            system. All 3 items in the tuple can be used with
            :py:class:`~radarclient.utilities.wait_for_multithreaded_completion_helper` to wait for all threads to
            complete and add appropriate sentinel values to the ``result_queue`` to stop your spawned processes. This
            should only be used when you need to access the ``Queue`` of radar results directly.
        :param int limit: The maximum number of Radar IDs to return `per thread/chunk`. Defaults to 7500, maximum allowed is 250000.
        :param int max_thread_count: [optional] How many parallel threads to open to the Radar API. Default is 9.
        :return: A generator for the Radar IDs found or if ``return_result_queue=True``, a :py:class:`tuple` containing
            ``(result_queue, exception_queue, thread_set)``.
        :rtype: :py:meth:`~radarclient.utilities.multithreaded_results_gen` or :py:class:`tuple`
        :raises: If an error is raised in a child thread, that error will be raised in the main thread. If
            multiple threads raise an error, only the first error is raised.

        .. note::
            As of July 5th, 2023, the API Rate Limit for Find Problems has changed to a transactions per `second` model, with
            a base limit of **9** tps. (Previously, the limit was 2000 per `hour`.) The default value for ``max_thread_count``
            is **9** and cannot exceed **26** (which is the maximum tps for users who have had their profile
            specifically updated to support the ``max`` rate limit.) Find Problems is now also included in the default
            schemes for :py:class:`~radarclient.retrypolicy.RetryPolicy` with an exponential backoff.

        For more information about how to utilize ``chunk_hours`` and ``chunking_key``, see
        :py:meth:`find_radars_multithreaded`, which uses the same mechanisms.
        """
        _MAX_FIND_THREAD_COUNT = 26

        chunked_queries = utilities.ChunkQueryDictGenerator(request_data, chunk_hours, chunking_value=chunking_key)

        find_thread_count = min(len(chunked_queries), min(max_thread_count, _MAX_FIND_THREAD_COUNT))

        self.authentication_strategy.ensure_valid_authentication_credentials()  # Ensures /signon for accessToken first
        manager = SimpleThreadManager(chunked_queries, chunked_kwarg='request_data', max_thread_count=find_thread_count)
        return manager.get_threaded_results(
            self,
            'find_radar_ids',
            request_data=None,
            return_result_queue=return_result_queue,
            limit=limit
        )

    def find_radars(self, request_data, additional_fields=None, limit=None, batch_size=15, progress_callback=None, return_find_results_directly=False, error_callback=None, fetch_person_info_from_ds=False, fields=None):
        """
        Find radars for requested attributes.

        :param dict request_data: The query dictionary that defines which Radars you want to find. Since
                                  the Python client passes this through to the server unchanged, the contents
                                  of this dictionary are not documented here. See the server-side API documentation
                                  for details instead: `Find Problems documentation`_
        :param list additional_fields: (optional) additional fields to return for each result
        :param int limit: (optional) the maximum number of Radars to return
        :param int batch_size: (optional) see description at :py:meth:`RadarClient.radars_for_ids`
        :param callable progress_callback: (optional) see description at :py:meth:`RadarClient.radars_for_ids`
        :param bool return_find_results_directly: (optional) Use find API directly. See discussion below.
        :param callable error_callback: (optional) see description at :py:meth:`RadarClient.radars_for_ids`.
                                        This is ignored if you use the return_find_results_directly option.
        :param list fields: (optional) A specific list of attributes ("fields") to use for the "X-Fields-Requested"
            header, as a way to override the default fields. NOTE: ``id`` will always be requested, for compatibility.

        Like :py:meth:`RadarClient.find_radar_ids`, but returns :py:class:`~radarclient.model.Radar` instances
        instead of their IDs. If you need IDs only, use :py:meth:`RadarClient.find_radar_ids`.
        If you need counts only, use :py:meth:`RadarClient.find_radar_count`.

        Examples for additional_fields::

            ['targetStartDate']
            ['targetStartDate', 'effortCurrentTotalEstimate']

        Because of a Radar API limitation, this method by default produces the result with a two-step lookup:

        1. It finds just the IDs of Radars matching the search criteria with :py:meth:`RadarClient.find_radar_ids`, which queries the Radar API's ``/problems/find`` search endpoint
        2. Then it loads the full details for the resulting ID list with :py:meth:`RadarClient.radars_for_ids`, which queries the Radar API's ``/problems/<id>,<id>,...`` endpoint

        The reason for this indirection, which comes with a performance hit, is that the Radar
        API is unable to return the full set of fields from the ``/probems/find`` endpoint, only the
        ``/problems/<id>...`` endpoint provides full access to all information. See these
        Radars for more information about this limitation:

        * <rdar://problem/15487961> Unify Problem Object data structure across endpoints
        * <rdar://problem/12293502> Can't request some fields with POST /problems/find

        Since callers of this method can ask for arbitrary Radar fields with the ``additional_fields``
        parameter, the implementation has to perform the find operation using this two-step process
        to fulfill its contract.

        If you are willing to accept a limited set of fields in exchange for better performance,
        then you can disable the two-step lookup by setting the ``return_find_results_directly``
        parameter to true. You'll get an exception if you ask for a field that is not supported
        in that mode.

        Some notes about how that option interacts with others:

        * Using the ``orderBy`` clause in the search criteria implies ``return_find_results_directly`` because ``orderBy`` is mutually exclusive with ``idsOnly``.
        * The ``progress_callback`` and ``batch_size`` options don't apply when using ``return_find_results_directly`` because they are options of the :py:meth:`RadarClient.radars_for_ids` method, which isn't involved in that case.

        Examples::

            radar_query = {'assignee': 299156498, 'state': 'Verify', 'orderBy': [{'field': 'title', 'order': 'ascending'}]}
            radars = radar_client.find_radars(radar_query)
            for radar in radars:
                print(radar.id, radar.title)

        .. _`Find Problems documentation`: https://radar.apple.com/developer/api/documentation/latest/problem-apis#find-problems

        """
        request_data = request_data.copy()

        def run_find_request(requested_fields):
            url = self.webservice_url_for_path_components('problems/find')
            query_json = json.dumps(request_data)
            request = self.request_for_json_url(url, json_string=query_json)
            self.configure_request_for_requested_fields(request, requested_fields)

            if limit:
                self.configure_request_with_limit(request, limit)

            status, problem_data = self.send_request(request)
            if status == 404:
                return []

            return Radar.parse_webservice_data(problem_data, self, requested_fields)

        problem_ids_to_load = []

        if 'orderBy' in request_data and not return_find_results_directly:
            # As described in the docstring above, by default this method
            # does an id-only find followed by a load of the Radars by ID,
            # in order to satisfy the additional_fields list. However,
            # according to the Radar team, idsOnly and orderBy are mutally
            # exclusive, so if the user uses orderBy, we cannot use the
            # idsOnly query, we have to use a regular query here.
            ids_only_find_request_requested_fields = ['id']
            radars_for_ids_only = run_find_request(ids_only_find_request_requested_fields)
            if radars_for_ids_only:
                problem_ids_to_load = [r.id for r in radars_for_ids_only]
        elif return_find_results_directly:
            # If the user explicitly asks us not to use the two-step lookup,
            # then they have to ensure that they don't:
            # - use orderBy in the query
            # - request any attributes in fields or additional_fields that are not available through the find endpoint.
            requested_fields = self.assemble_radar_requested_fields(fields, additional_fields, for_find=True)
            radars = run_find_request(requested_fields)
            for radar in radars:
                # TODO: Remove, temporary workaround for rdar://109528682
                for attr in ['classification', 'milestone', 'originator', 'component']:
                    if attr not in requested_fields and hasattr(radar, attr):
                        delattr(radar, attr)
                self.cache_radar(radar, requested_fields)
            return radars
        else:
            try:
                del request_data["countsOnly"]
                del request_data["idsOnly"]
            except KeyError:
                pass

            problem_ids_to_load = self.find_radar_ids(request_data, limit=limit)

        requested_fields = self.assemble_radar_requested_fields(fields, additional_fields)
        return self.radars_for_ids(problem_ids_to_load, batch_size=batch_size, progress_callback=progress_callback, error_callback=error_callback, fields=requested_fields)

    def find_radars_multithreaded(self, request_data, chunk_hours, additional_fields=None,
                                  return_find_results_directly=False, error_callback=None,
                                  chunking_key='createdAt', return_result_queue=False, max_thread_count=9, fields=None):
        """
        Searches for radars with multiple threads by chopping up a query based on the value of
        ``chunking_key`` in the ``request_data`` query dict. The query must contain a value for
        ``<chunking_key>['gt']`` or ``<chunking_key>['gte']``. If no value is provided for
        ``<chunking_key>['lt']`` or ``<chunking_key>['lte']``, it sets it to now. This method will
        be able to perform larger searches that would otherwise require writing a separate method to
        loop over a query that has been divided up. The division is performed using :py:class:`~radarclient.utilities.ChunkQueryDictGenerator`.
        See that documentation for information on date and time formats.

        .. note::
            As of July 5th, 2023, the API Rate Limit for Find Problems has changed to a transactions per `second` model, with
            a base limit of **9** tps. (Previously, the limit was 2000 per `hour`.) The default value for ``max_thread_count``
            is **9** and cannot exceed **26** (which is the maximum tps for users who have had their profile
            specifically updated to support the ``max`` rate limit.) Find Problems is now also included in the default
            schemes for :py:class:`~radarclient.retrypolicy.RetryPolicy` with an exponential backoff.

        :param dict request_data: request attributes
        :param float chunk_hours: size of chunks in hours. If 3 is passed in, ``request_data`` will be
            divided in to ``n`` chunks, most of which will span 3 hours
        :param list additional_fields: additional fields to return for each result
        :param bool return_find_results_directly: See information in :py:meth:`find_radars`
        :param callable error_callback: See information in :py:meth:`find_radars`
        :param str chunking_key: The key in ``request_data`` to use for dividing the query into chunks. It can be either
            an ISO8601-formatted date/time string or a tz-aware :py:class:`datetime.datetime` object. While users are still
            limited to a `single` attribute dictionary matching the ``chunking_key``, it can be at any depth in the query.
        :param bool return_result_queue: Pass in ``True`` to return a tuple containing
            ``(result_queue, exception_queue, thread_set)``. You can use the queue as input for a multiprocessed
            system. All 3 items in the tuple can be used with
            :py:class:`~radarclient.utilities.wait_for_multithreaded_completion_helper` to wait for all threads to
            complete and add appropriate sentinel values to the ``result_queue`` to stop your spawned processes. This
            should only be used when you need to access the ``Queue`` of radar results directly.
        :param int max_thread_count: [optional] How many parallel threads to open to the Radar API. Default is 9.
        :param list fields: (optional) A specific list of attributes ("fields") to use for the "X-Fields-Requested"
            header, as a way to override the default fields. NOTE: ``id`` will always be requested, for compatibility.

        :return: Generator that generates :py:class:`~radarclient.model.Radar` objects or, if
            ``return_result_queue=True``, a tuple containing ``(result_queue, exception_queue, thread_set)``
        :rtype: :py:meth:`~radarclient.utilities.multithreaded_results_gen`, tuple
        :raises: If an error is raised in a child thread, that error will be raised in the main thread. If
            multiple threads raise an error, only the first error is raised.

        .. note::
            Any ISO8601-formatted datetime strings in ``request_data`` must be adjusted to the UTC timezone
            specifically for ``find_radars_multithreaded()``.

        Example::

            # This example will break up the query into 7-day chunks (i.e. 168 hours == 1 week).
            request_data = {
                "all": [
                    {
                        "priority": {
                            "eq": 1
                        }
                    },
                    {
                        "any": [
                            {
                                "keyword": {
                                    "eq": "Program Top Issue"
                                }
                            },
                            {
                                "keyword": {
                                    "eq": "Seed Blocker"
                                }
                            }
                        ]
                    },
                    {
                        "originatedOrModifiedBy": {
                            "eq": {
                                "date": {
                                    "gte": "2021-07-01T00:00:00-0000",
                                    "lt": "2021-07-08T00:00:00-0000"
                                }
                            }
                        }
                    }
                ]
            }
            radars = set(radar_client.find_radars_multithreaded(request_data, 168, chunking_key='originatedOrModifiedBy'))

        If you want to get access to the results queue directly, see the below example

        Example::

            def do_a_thing(result_q):
                item = result_q.get()
                while result_q != 'STOP':
                    print(item)
                    item = result_q.get()

            result_q, exception_q, thread_set = client.find_radars_multithreaded(query, return_result_queue=True)
            num_processes = 4
            sentinel = 'STOP'
            p_list = []

            for _ in range(num_processes):
                p = Process(do_a_thing, args=(result_q,), daemon=True)
                p_list.append(p)
                p.start()

            wait_for_multithreaded_completion_helper(
                result_queue, exception_queue, thread_set, num_processes, sentinel=sentinel
            )
            for p in p_list:
                p.join()

        """
        _MAX_FIND_THREAD_COUNT = 26
        _BY_ID_THREAD_COUNT = 4
        if return_result_queue:
            result_queue = mpQueue()
        else:
            result_queue = compat.queue_module.Queue()
        exception_queue = compat.queue_module.Queue(1)
        if not return_find_results_directly:
            radar_for_id_queue = compat.queue_module.Queue()

        query_queue = compat.queue_module.Queue()

        self.authentication_strategy.ensure_valid_authentication_credentials()  # Ensures /signon for accessToken first

        def by_id_thread_worker():
            local_data = thread_local()
            local_data.thread_client = deepcopy(self)

            while (not query_queue.empty() or not radar_for_id_queue.empty()) and not exception_queue.full():
                try:
                    pull_count = 0
                    result_batch = []

                    while len(result_batch) < 15 and \
                            pull_count < 100 and \
                            (not query_queue.empty() or not radar_for_id_queue.empty()):
                        pull_count += 1
                        try:
                            pulled_item = radar_for_id_queue.get(timeout=.1)

                            if pulled_item is None or exception_queue.full():
                                break
                            else:
                                # This relies on the find workers fetching only IDs
                                result_batch.append(pulled_item)
                        except compat.queue_module.Empty:
                            pass

                    if exception_queue.full():
                        break

                    if len(result_batch) > 0:
                        radars = local_data.thread_client.radars_for_ids(
                            result_batch,
                            additional_fields=additional_fields,
                            error_callback=error_callback,
                            fields=fields
                        )

                        for radar in radars:
                            result_queue.put(radar, 120)
                except Exception as ex:
                    try:
                        exception_queue.put_nowait(ex)
                        compat.log_exception(logger, ex)
                    except compat.queue_module.Full:
                        pass

        def find_thread_worker():
            local_data = thread_local()
            local_data.thread_client = deepcopy(self)

            if return_find_results_directly:
                placement_queue = result_queue
            else:
                placement_queue = radar_for_id_queue

            while True:
                # Include a timeout to prevent possible hang prior to python 3.0
                query = query_queue.get(timeout=10)
                # If None retrieved or there was an exception, break
                if query is None or exception_queue.full():
                    break

                attempts = 0
                success = False

                while attempts < 3 and not success:
                    try:
                        attempts += 1
                        if return_find_results_directly:
                            radars = local_data.thread_client.find_radars(
                                query,
                                additional_fields=additional_fields,
                                return_find_results_directly=return_find_results_directly,
                                error_callback=error_callback,
                                fields=fields
                            )
                        else:
                            radars = local_data.thread_client.find_radar_ids(query)

                        for r in radars:
                            placement_queue.put(r, timeout=120)
                        success = True
                        query_queue.task_done()
                    except Exception as ex:
                        if isinstance(ex, UnsuccessfulResponseException):
                            # Don't retry on an error with a 4xx status code
                            if 400 <= ex.code <= 499:
                                attempts = 3

                        # If the request has been tried 3 times and failed, put the exception on the
                        # exception queue. Only the first exception from all threads is raised
                        if attempts == 3:
                            query_queue.task_done()
                            try:
                                exception_queue.put_nowait(ex)
                                compat.log_exception(logger, ex)
                            except compat.queue_module.Full:
                                pass

        chunked_queries = utilities.ChunkQueryDictGenerator(
            request_data, chunk_hours, chunking_value=chunking_key
        )

        for query_chunk in chunked_queries:
            query_queue.put(query_chunk)

        find_thread_count = min(len(chunked_queries), min(max_thread_count, _MAX_FIND_THREAD_COUNT))
        logger.debug('find_thread_count was {}'.format(find_thread_count))

        tracking_thread_set = set()
        for _ in range(find_thread_count):
            query_queue.put(None)
            t = Thread(target=find_thread_worker)
            t.daemon = True
            t.start()
            tracking_thread_set.add(t)

        if not return_find_results_directly:
            for _ in range(_BY_ID_THREAD_COUNT):
                t = Thread(target=by_id_thread_worker)
                t.daemon = True
                t.start()
                tracking_thread_set.add(t)
        if return_result_queue:
            return result_queue, exception_queue, tracking_thread_set
        else:
            return utilities.multithreaded_results_gen(result_queue, exception_queue, tracking_thread_set)

    @deprecated(replacement=find_radars, version=1.17)
    def find_problems():
        pass

    def combined_history_multithreaded(self, radars, max_thread_count=25, skip_diagnosis_history=False,
                                       additional_snapshot_attributes=None, include_data_changes=False,
                                       return_result_queue=False, skip_snapshots=False):
        """
        A multithreaded version of :py:meth:`~radarclient.model.Radar.combined_history` to speed up turnaround
        times. This is primarily useful with ``skip_diagnosis_history=False`` or when Radar objects were not pre-loaded
        with their Problem History via ``additional_fields=['history']``. Uses the :py:class:`SimpleThreadManager`
        class.

        :param list[Radar] radars: The :py:class:`~radarclient.model.Radar` objects to get the combined history for.
        :param int max_thread_count: [optional] How many parallel threads to open to the Radar API. Default is 25.
        :param bool skip_diagnosis_history: aka "Express Mode". Setting to ``True`` will skip the Diagnosis History
            (ChangedField object) and use only the Problem History object. Allows for pre-loading and bulk-loading but
            the history is limited to 11 specific attributes.
        :param bool skip_snapshots: Will skip assembling the ``RadarHistorySnapshot`` objects. This can save processing
            time and memory for bugs that have very long histories, lots of related problems, diagnosis comments, etc.
        :param list[str] additional_snapshot_attributes: Similar to ``additional_fields`` for a Radar request, a list of
            extra attributes and/or actions to include in the :py:class:`RadarHistorySnapshot` objects. Does not apply
            in Express Mode.
        :param bool include_data_changes: By default change events with the ``data`` change_type are omitted. Set to
            ``True`` to include. Does not apply in Express Mode.
        :param bool return_result_queue: Pass in ``True`` to return a tuple containing
            ``(result_queue, exception_queue, thread_set)``. You can use the queue as input for a multiprocessed
            system. All 3 items in the tuple can be used with
            :py:class:`~radarclient.utilities.wait_for_multithreaded_completion_helper` to wait for all threads to
            complete and add appropriate sentinel values to the ``result_queue`` to stop your spawned processes. This
            should only be used when you need to access the ``Queue`` of radar results directly.
        :return: A Generator for the :py:class:`~radarclient.model.Radar` objects matching the provided IDs or, if
            ``return_result_queue=True``, a tuple containing ``(result_queue, exception_queue, thread_set)``

        Example::

            radars = radar_client.radars_for_query(query_id=123456)
            radars_with_history = radar_client.combined_history_multithreaded(radars)
            for radar in radars_with_history:
                for modification_event in radar.combined_history():
                    print(modification_event)
                    print(modification_event.radar_history_snapshot)

        """
        if additional_snapshot_attributes is None:
            additional_snapshot_attributes = []
        assert None not in radars, "None value passed in 'radars'"

        manager = SimpleThreadManager(radars, max_thread_count=max_thread_count, client=self)
        return manager.get_threaded_results(
            radars,
            'combined_history',
            skip_diagnosis_history=skip_diagnosis_history,
            skip_snapshots=skip_snapshots,
            additional_snapshot_attributes=additional_snapshot_attributes,
            include_data_changes=include_data_changes,
            return_result_queue=return_result_queue
        )

    def find_radar_groups(self, query_data, limit=None):
        """
        Finds :py:class:`~radarclient.model.WorkGroup` and
        :py:class:`~radarclient.model.AccessGroup` objects

        :param dict query_data: query as outlined in the `Find Group API Docs`_
        :param int limit: maximum number of results to return

        :return: dictionary with keys ``Access Groups`` and ``Work Groups``. Each key point to a list of
            :py:class:`~radarclient.model.AccessGroup` and :py:class:`~radarclient.model.WorkGroup`
            objects respectively, that were found
        :rtype: dict

        Example::

            groups = radar_client.find_radar_groups({'hasExternalUsers': True}, limit=20)
            for group in groups['Access Groups']:
                print(group.name)
            for group in groups['Work Groups']:
                print(group.name)

        """
        def processor(results, *args):
            to_return = {
                'Access Groups': [],
                'Work Groups': []
            }
            for result in results:
                if result['type'] == 'Access Group':
                    to_return['Access Groups'].append(AccessGroup(result))
                elif result['type'] == 'Work Group':
                    to_return['Work Groups'].append(WorkGroup(result))
                else:
                    raise ValueError('Unknown group type returned')
            return to_return

        return RadarGroup._find(query_data, self, limit=limit, processing_callable=processor,
                                return_results_directly=True)

    def work_group_for_id(self, group_id, additional_fields=None):
        """
        Get a work group for specified ID

        :param int group_id: ID of group
        :param list[str] additional_fields: additional fields to return for results per the
            `Get Work Group API Docs`_

        :rtype: :py:class:`~radarclient.model.WorkGroup`
        """
        additional_fields = additional_fields or []
        if 'id' not in additional_fields:
            additional_fields.append('id')
        return WorkGroup._get_by_id(group_id, self, additional_fields=additional_fields)

    def work_group_for_name(self, name, additional_fields=None):
        """
        Get a work group for the specified name

        :param str name: name of work group
        :param list[str] additional_fields: additional fields to return for results per the
            `Get Work Group API Docs`_

        :rtype: :py:class:`~radarclient.model.WorkGroup`
        """
        additional_fields = additional_fields or []
        if 'id' not in additional_fields:
            additional_fields.append('id')
        return self.work_group_for_id(name, additional_fields=additional_fields)

    def access_group_for_id(self, group_id, additional_fields=None):
        """
        Get an access group for specified ID

        :param int group_id: ID of access group
        :param list[str] additional_fields: additional fields to return for results per the
            `Get Access Group API Docs`_

        :rtype: :py:class:`~radarclient.model.AccessGroup`
        """
        additional_fields = additional_fields or []
        if 'id' not in additional_fields:
            additional_fields.append('id')
        return AccessGroup._get_by_id(group_id, self, additional_fields=additional_fields)

    def access_group_for_name(self, name, additional_fields=None):
        """
        Get an access group for a specified name

        :param str name: name of access group
        :param list[str] additional_fields: additional fields to return for results per the
            `Get Access Group API Docs`_

        :rtype: :py:class:`~radarclient.model.AccessGroup`
        """
        additional_fields = additional_fields or []
        if 'id' not in additional_fields:
            additional_fields.append('id')
        return self.access_group_for_id(name, additional_fields=additional_fields)

    def find_scheduled_tests(self, query_data, additional_fields=None, limit=None, return_results_directly=False):
        """
        Finds scheduled tests and returns a list of :py:class:`~radarclient.model.ScheduledTest`
        objects.

        :param dict query_data: dictionary with the query data structure as documented in `Find Scheduled Test Docs`_
        :param list additional_fields: (optional) additional fields to return for each result as documented in the
            `Find Scheduled Test Docs`_
        :param int limit: the maximum number of items to return
        :param bool return_results_directly: If ``True``, will return just the results of the find. If ``False``,
            will fetch items from the get by ID endpoint. This is useful if you want to request additional fields
            that are only available from that endpoint

        :return: list of :py:class:`~radarclient.model.ScheduledTest` or empty list if nothing found
        """
        get_ids_method = partial(self.scheduled_tests_for_ids, additional_fields=additional_fields)
        # Work around mismatched ID names
        # rdar://115851863 (Finding Scheduled Tests and Getting by ID Return the ID with Different Names)
        if additional_fields is not None:
            actual_additional_fields = ['scheduledTestId'] + additional_fields
        else:
            actual_additional_fields = None

        return ScheduledTest._find(query_data, self, limit=limit, additional_fields=actual_additional_fields,
                                   return_results_directly=return_results_directly,
                                   processing_callable=ScheduledTest._find_processor_for_compact_format,
                                   additional_headers=[self.create_response_format_header(self.RESPONSE_FORMAT_COMPACT)],
                                   get_ids_method=get_ids_method)


    def scheduled_test_for_id(self, scheduled_test_id, additional_fields=None, fields=None):
        """
        Gets scheduled test by ID and returns a :py:class:`~radarclient.model.ScheduledTest` object.

        :param int scheduled_test_id: Scheduled test ID
        :param list additional_fields: (optional) additional fields to retrieve per `Get Scheduled Test Docs`_
        :param list fields: List of exclusive fields to fetch

        :rtype: :py:class:`~radarclient.model.ScheduledTest`
        :raises: IncompatibleFieldsRequestException if both ``fields`` and ``additional_fields`` are requested
        """
        return ScheduledTest._get_by_id(scheduled_test_id, self, additional_fields=additional_fields, fields=fields)

    def scheduled_tests_for_ids(self, scheduled_test_ids, additional_fields=None, fields=None):
        """
        Retrieves multiple scheduled tests by ID. If an error is raised for a single ID, no error
        will be raised. It is possible to get an empty list from this function.

        :param list[int] scheduled_test_ids: list of scheduled test suite IDs
        :param list[str] additional_fields: list of additional fields to retrieve per `Get Scheduled Test Docs`_
        :param list fields: List of exclusive fields to fetch. If passed in ``additional_fields`` will be ignored

        :return: List of :py:class:`~radarclient.model.ScheduledTest` objects

        Example::

            # attributes returned by endpoints in new API are in flux and additional fields may not be accurate
            query = {'component: 'Test Component'}
            found_tests = self.client.find_scheduled_tests(
                query, additional_fields=['blockedCasePercent'], limit=10
            )
            ids = [test.scheduledID for test in found_tests]
            by_id_tests = self.client.scheduled_tests_for_ids(ids, additional_fields=['cases'])
            fully_merged_bool = ScheduledTest.merge_lists(by_id_tests, found_tests)

            # by_id_tests now contains a list of ScheduledTest objects with all the keys

        """
        return ScheduledTest._get_by_ids(scheduled_test_ids, self, additional_fields=additional_fields, fields=fields)

    def schedule_tests_for_test_suite_ids(self, test_suite_ids, additional_request_data=None, fetch_full_object=True,
                                          additional_fields=None):
        """
        Schedules multiple tests suites using only the suite IDs of the test suites

        :param list[int] test_suite_ids: list of suite IDs to schedule
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: list[:py:class:`~radarclient.model.ScheduledTest`] list of the scheduled tests
        """
        to_return = []

        request_data = {}
        if additional_request_data:
            request_data = additional_request_data

        request_data['suiteIds'] = list(test_suite_ids)

        scheduling_job = ScheduleTestSuitesInBulkJob(self, request_data)
        scheduling_job.wait_until_done()

        if len(scheduling_job.errors) > 0:
            raise BulkTestSuiteSchedulingException(scheduling_job.errors)

        scheduled_ids = scheduling_job.scheduled_suite_ids()

        for suite_id in scheduled_ids:
            if additional_fields is not None or fetch_full_object:
                to_return.append(
                    self.scheduled_test_for_id(suite_id, additional_fields=additional_fields)
                )
            else:
                to_return.append(ScheduledTest({ScheduledTest.identifier_attrs[0]: suite_id}))

        return to_return

    def schedule_test_for_test_suite_id(self, test_suite_id, additional_request_data=None, fetch_full_object=True,
                                        additional_fields=None):
        """
        Schedules a single test suite by ID

        :param int test_suite_id: ID of the suite to schedule
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: :py:class:`~radarclient.model.ScheduledTest`
        """
        suites = self.schedule_tests_for_test_suite_ids(
            [test_suite_id], additional_request_data=additional_request_data, fetch_full_object=fetch_full_object,
            additional_fields=additional_fields
        )
        return suites[0]

    def schedule_test_for_test_suite(self, test_suite, additional_request_data=None,
                                     fetch_full_object=True, additional_fields=None):
        """
        Create a new scheduled test for specified test suite

        :param TestSuite test_suite: :py:class:`~radarclient.model.TestSuite` to schedule
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more
            detailed object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: :py:class:`~radarclient.model.ScheduledTest` representing the created scheduled test

        Example::

            test_suite = radar_client.test_suite_for_id(123)
            scheduled_test = radar_client.schedule_test_for_test_suite(test_suite)

        """
        return self.schedule_test_for_test_suite_id(test_suite.database_id_attribute_value(),
                                                    additional_request_data=additional_request_data,
                                                    fetch_full_object=fetch_full_object,
                                                    additional_fields=additional_fields)

    def schedule_tests_for_test_suites(self, test_suites, additional_request_data=None,
                                       fetch_full_object=True, additional_fields=None):
        """
        Schedule multiple tests using a list of :py:class:`~radarclient.model.TestSuite` objects

        :param list[TestSuite] test_suites: list of :py:class:`~radarclient.model.TestSuite` objects to schedule
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: list[:py:class:`~radarclient.model.ScheduledTest`]
        """
        return self.schedule_tests_for_test_suite_ids(
            (test_suite.database_id_attribute_value() for test_suite in test_suites),
            additional_request_data=additional_request_data,
            fetch_full_object=fetch_full_object,
            additional_fields=additional_fields
        )

    def schedule_tests_for_test_suite_ids_with_cases_for_priority(
            self, test_suite_ids, priorities_to_schedule, additional_request_data=None, fetch_full_object=True,
            additional_fields=None):
        """
        Schedule multiple test suites using their IDs with only the cases of the specified priorities

        :param list test_suite_ids: list of test suite IDs to schedule
        :param list priorities_to_schedule: list of integer priorities of cases to be scheduled
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: list[:py:class:`~radarclient.model.ScheduledTest`]
        """
        if additional_request_data is None:
            additional_request_data = {}

        case_filter = {'any': []}
        for priority in priorities_to_schedule:
            case_filter['any'].append({'priority': {'eq': priority}})

        additional_request_data['casesFilterCriteria'] = [case_filter]

        return self.schedule_tests_for_test_suite_ids(
            test_suite_ids,
            additional_request_data=additional_request_data,
            fetch_full_object=fetch_full_object,
            additional_fields=additional_fields
        )

    def schedule_test_for_test_suite_id_with_cases_for_priority(
            self, test_suite_id, priorities_to_schedule, additional_request_data=None, fetch_full_object=True,
            additional_fields=None):
        """
        Schedule a single test suite using its ID with only the cases of the specified priorities

        :param int test_suite_id: single test suite ID
        :param list priorities_to_schedule: list of integer priorities of cases to be scheduled
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: :py:class:`~radarclient.model.ScheduledTest` representing the created scheduled test
        """

        return self.schedule_tests_for_test_suite_ids_with_cases_for_priority(
            [test_suite_id],
            additional_request_data=additional_request_data,
            fetch_full_object=fetch_full_object,
            additional_fields=additional_fields,
            priorities_to_schedule=priorities_to_schedule
        )[0]

    def schedule_test_for_test_suite_with_cases_for_priority(
            self, test_suite, priorities_to_schedule, additional_request_data=None, fetch_full_object=True,
            additional_fields=None):
        """
        Schedule a single test using a TestSuite object with only the cases of the specified priorities

        :param TestSuite test_suite: suite to be scheduled
        :param list priorities_to_schedule: list of integer priorities of cases to be scheduled
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: :py:class:`~radarclient.model.ScheduledTest` representing the created scheduled test
        """
        suite_ids = [test_suite.database_id_attribute_value()]

        return self.schedule_tests_for_test_suite_ids_with_cases_for_priority(
            suite_ids,
            priorities_to_schedule,
            additional_request_data=additional_request_data,
            fetch_full_object=fetch_full_object,
            additional_fields=additional_fields
        )[0]

    def schedule_tests_for_test_suites_with_cases_for_priority(
            self, test_suites, priorities_to_schedule, additional_request_data=None, fetch_full_object=True,
            additional_fields=None):
        """
        Schedule multiple tests using multiple TestSuite objects with only the cases of the specified priorities

        :param list[TestSuite] test_suites: list of test suite to be scheduled
        :param list priorities_to_schedule: list of integer priorities of cases to be scheduled
        :param dict additional_request_data: optional dictionary with additional request data per
            `Bulk Suite Scheduling Docs`_. suiteId is included by default
        :param bool fetch_full_object: By default, the API returns only the Scheduled Test ID. When this argument is
            ``True``, or ``additional_fields`` is not ``None``, a second request will be made to get the more detailed
            object from the server
        :param list additional_fields: optional additional fields to request per `Create Scheduled Test Docs`_

        :return: list[:py:class:`~radarclient.model.ScheduledTest`]
        """
        suite_ids = (suite.database_id_attribute_value() for suite in test_suites)

        return self.schedule_tests_for_test_suite_ids_with_cases_for_priority(
            suite_ids,
            priorities_to_schedule,
            additional_request_data=additional_request_data,
            fetch_full_object=fetch_full_object,
            additional_fields=additional_fields
        )

    @deprecated_in_place('schedule_test_for_test_suite_id', 3.107)
    def schedule_new_test_for_test_suite(self, test_suite_id, additional_request_data=None, additional_fields=None):
        """
        Schedules a new test and returns a :py:class:`~radarclient.model.ScheduledTest` object.

        :param int test_suite_id: ID of test suite
        :param dict additional_request_data: optional dictionary with additional request data per
            `Scheduled Test API Documentation`_. suiteId is included by default
        :param list additional_fields: optional additional fields to request per
            `Scheduled Test API Documentation`_

        """
        if additional_fields is None:
            additional_fields = []

        url = self.webservice_url_for_path_components('scheduled-tests')
        request_data = {}
        if additional_request_data:
            request_data = additional_request_data
        request_data['suiteID'] = test_suite_id
        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='POST')
        self.configure_request_for_additional_fields(request, ScheduledTest, additional_fields)
        status, test_data = self.send_request(request)

        return ScheduledTest(test_data)

    def delete_scheduled_test_suite_by_id(self, scheduled_test_id):
        """
        Delete a scheduled test using the ID. This cannot be reversed

        :param int scheduled_test_id: ID of scheduled test to delete

        :return: None
        """
        self.build_and_send_request((ScheduledTest.BASE_URL, scheduled_test_id), method='DELETE')

    def delete_scheduled_test_suite(self, scheduled_test):
        """
        Delete a scheduled test suite. This cannot be reversed

        :param :py:class:`~radarclient.model.ScheduledTest` scheduled_test: scheduled test to delete

        :return: None
        """
        self.delete_scheduled_test_suite_by_id(scheduled_test.database_id_attribute_value())

    @deprecated_in_place('delete_scheduled_test_suite', 3.107)
    def delete_scheduled_test(self, scheduled_test_id):
        """
        Deletes a scheduled test.

        :param int scheduled_test_id: ID of scheduled test

        """

        url = self.webservice_url_for_path_components('scheduled-tests', scheduled_test_id)
        request = self.request_for_json_url(url, method='DELETE')
        status, _ = self.send_request(request)

        return status

    def find_scheduled_test_cases(self, query_data, additional_fields=None, limit=None, return_results_directly=False):
        """
        Find scheduled test cases that match query_data

        :param dict query_data: Query with attributes as defined in the `Find Scheduled Test Case Docs`_
        :param list[str] additional_fields: List of additional fields to get as documented in the
            `Find Scheduled Test Case Docs`_
        :param int limit: the maximum number of items to return
        :param bool return_results_directly: If ``True``, will return just the results of the find. If ``False``,
            will fetch items from the get by ID endpoint

        :return: list of :py:class:`~radarclient.model.ScheduledTestCase` objects
        """
        get_ids_method = partial(self.scheduled_test_cases_for_ids, additional_fields=additional_fields)

        # Work around mismatched ID names
        # rdar://116066084 (Finding Scheduled Test Case and Getting by ID Return Differently Named Attributes for ID)
        if additional_fields is not None:
            actual_additional_fields = ['scheduledCaseId'] + additional_fields
        else:
            actual_additional_fields = None

        return ScheduledTestCase._find(query_data, self, additional_fields=actual_additional_fields,
                                       limit=limit, return_results_directly=return_results_directly,
                                       additional_headers=[self.create_response_format_header(self.RESPONSE_FORMAT_COMPACT)],
                                       processing_callable=ScheduledTestCase._find_processor_for_compact_format,
                                       get_ids_method=get_ids_method)

    def scheduled_test_cases_for_ids(self, id_list, additional_fields=None, fields=None):
        """
        Get a list of scheduled test cases by ID

        :param list[int] id_list: list of IDs
        :param list[str] additional_fields: list of additional fields to fetch as defined in the
            `Get Scheduled Test Case Docs`_
        :param list[str] fields: List of exclusive fields to fetch. If passed in ``additional_fields`` will be ignored

        :return: list of :py:class:`~radarclient.model.ScheduledTestCase`
        """
        return ScheduledTestCase._get_by_ids(id_list, self, additional_fields=additional_fields, fields=fields)

    def scheduled_test_case_for_id(self, case_id, additional_fields=None, fields=None):
        """
        Get a scheduled test case by ID

        :param int case_id: ID of the scheduled test case to get
        :param list[str] additional_fields: list of additional fields to fetch as defined in the
            `Get Scheduled Test Case Docs`_
        :param list[str] fields: List of exclusive fields to fetch

        :return: :py:class:`~radarclient.model.ScheduledTestCase` object
        :raises: IncompatibleFieldsRequestException if both ``fields`` and ``additional_fields`` are requested
        """
        return ScheduledTestCase._get_by_id(case_id, self, additional_fields=additional_fields, fields=fields)

    def delete_scheduled_test_case_by_id(self, scheduled_test_case_id):
        """
        Delete a scheduled test case by ID. This cannot be reversed.

        :param int scheduled_test_case_id: ID of scheduled test case to delete

        :return: None
        """
        self.build_and_send_request((ScheduledTestCase.BASE_URL, scheduled_test_case_id), method='DELETE')

    def delete_scheduled_test_case(self, scheduled_test_case):
        """
        Delete a scheduled test case using a :py:class:`~radarclient.model.ScheduledTestCase` object. This cannot be
        reversed

        :param ScheduledTestCase scheduled_test_case: ScheduledTestCase to be deleted

        :return: None
        """
        self.delete_scheduled_test_case_by_id(scheduled_test_case.database_id_attribute_value())

    @deprecated_in_place('~radarclient.model.ScheduledTestCase.commit_changes', 3.98)
    def set_scheduled_test_case_data_for_case_number(self, scheduled_test_id, scheduled_test_case_number, request_data, additional_fields=None):
        """
        Sets scheduled test case data for a sequence case number and returns the response status code (201 if the request was successful).

        :param int scheduled_test_id: ID of scheduled test
        :param int scheduled_test_case_number: sequence number of case in the scheduled test
        :param dict request_data: dictionary with the change request data structure as documented
            per the `Scheduled Test Case Docs`

        :return: request status
        """

        # additional_fields is unused but allowed for backwards compatibility for now
        if additional_fields is not None:
            warnings.warn('The additional_fields parameter is deprecated, please remove it from your call. It will be eliminated in a future version', stacklevel=1)

        url = self.webservice_url_for_path_components('scheduled-tests', scheduled_test_id, 'cases', scheduled_test_case_number)
        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='PUT')
        status, _ = self.send_request(request)

        return status

    @deprecated_in_place('~radarclient.model.ScheduledTest.modify_multiple_associated_scheduled_cases',
                         3.98)
    def modify_multiple_scheduled_test_cases_for_scheduled_test_id(self, scheduled_test_id, scheduled_test_case_ids, request_data=None):
        """
        Modifies scheduled test case data for a scheduled test case id or group of ids and returns the response status code (200 if the request was successful).

        :param int scheduled_test_id: ID of scheduled test
        :param int scheduled_test_case_ids: a list of scheduled test case ids in the scheduled test
        :param dict request_data: dictionary with the change request data structure as documented in the API docs. A ``caseIDs`` key/value pair is automatically added based on the ``scheduled_test_case_ids`` parameter value.

        Example::

            request_data = {
                "status": "Pass",
                "priority": 3
            }
            status = self.client.modify_multiple_scheduled_test_cases_for_scheduled_test_id(3120131, [35880767, 35880768], request_data)

        """
        url = self.webservice_url_for_path_components('scheduled-tests', scheduled_test_id, 'cases/modify')
        if (not scheduled_test_case_ids) or (request_data is None):
            return None

        request_data['caseIDs'] = scheduled_test_case_ids
        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='POST')
        status, _ = self.send_request(request)

        return status

    @deprecated_in_place('~radarclient.model.ScheduledTest.commit_changes', 3.96)
    def set_scheduled_test_data_for_test_id(self, scheduled_test_id, request_data):
        """
        Sets scheduled test case data for scheduled test ID and returns the response
        status code (201 if the request was successful).

        :param int scheduled_test_id: ID of scheduled test
        :param dict request_data: dictionary with the change request data structure as documented in the API docs

        """

        url = self.webservice_url_for_path_components('scheduled-tests', scheduled_test_id)
        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='PUT')
        status, _ = self.send_request(request)

        return status

    @deprecated_in_place('scheduled_test_for_id', 3.96)
    def scheduled_test_data_for_test_id(self, scheduled_test_id, additional_fields=None):
        """
        Finds data for a scheduled test and returns a :py:class:`ScheduledTestData`
        instance.

        :param str scheduled_test_id: scheduled test ID
        :param list additional_fields: optional additional fields to request, valid values are documented in the Radar web API documentation.

        """
        url = self.webservice_url_for_path_components('scheduled-tests', scheduled_test_id)
        request = self.request_for_json_url(url)
        self.configure_request_for_additional_fields(request, ScheduledTestData, additional_fields)
        status, test_data = self.send_request(request)

        if response_code_is_success(status):
            return ScheduledTestData(test_data)

        raise self.exception_for_non_success_response(status, test_data)

    @deprecated(replacement=scheduled_test_data_for_test_id, version=1.17)
    def find_scheduled_test_data():
        pass

    def find_test_suites(self, query_data, additional_fields=None, limit=None, return_results_directly=False):
        """
        Finds test suites that match the query. Due to limitations in the radar API,
        this actually gets test suite IDs first, and then fetches the test suites themselves. The
        find API is not able to return as many fields as the get by ID API. If you only need values
        as returned by the Find API, you can avoid the performance hit by using
        ``return_results_directly``. If you request an unsupported field, it will raise an error

        :param dict query_data: dictionary with the query data structure as documented in the
            `Find Test Suite API Docs`_
        :param list additional_fields: optional additional fields to request, valid values are
            documented in the `Test Suite API Documentation`_. If using ``return_results_directly``,
            only fields for the find end point are valid
        :param int limit: the maximum number of items to return
        :param bool return_results_directly: If ``True``, will return just the results of the find. If ``False``,
            will fetch items from the get by ID endpoint

        :return: list of :py:class:`~radarclient.model.TestSuite` objects. Empty list if nothing found
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if unsupported field
            is passed in
        """
        get_ids_method = partial(self.test_suites_for_ids, additional_fields=additional_fields)

        return TestSuite._find(query_data, self, limit=limit, additional_fields=additional_fields,
                               return_results_directly=return_results_directly,
                               get_ids_method=get_ids_method,
                               additional_headers=[self.create_response_format_header(self.RESPONSE_FORMAT_COMPACT)],
                               processing_callable=TestSuite._find_processor_for_compact_format)

    def test_suite_for_id(self, suite_id, additional_fields=None, fields=None):
        """
        Gets test suite by id. If you are looking to find multiple and not have an exception raised
        when the suite does not exist or permissions are missing, use :py:meth:`test_suites_for_ids`

        :param int suite_id: test suite ID
        :param list additional_fields: optional list of additional fields to return as specified
            in the `Get Test Suite API Docs`_
        :param list fields: List of exclusive fields to fetch

        :returns: :py:class:`~radarclient.model.TestSuite`
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if there is a server error, the user
            does not have permissions, or the ID does not exist
        :raises: IncompatibleFieldsRequestException if both ``fields`` and ``additional_fields`` are requested

        Example::

            test_suite = radar_client.test_suite_for_id(123, additional_fields=['associatedTests'])
            for case in test_suite.cases:
                print('test suite {} / test case {}'.format(test_suite.suiteID, case.database_id_attribute_value()));

        """
        return TestSuite._get_by_id(suite_id, self, additional_fields=additional_fields, fields=fields)

    def test_suites_for_ids(self, id_list, additional_fields=None, fields=None):
        """
        Get multiple test suites by ID. Since the current Radar API does not support this
        functionality, this emulates the behavior on the client side. If there is an
        issue with one of the IDs, it will simply not be returned and error info will be printed.

        :param list[int] id_list: list of test suite IDs
        :param list[str] additional_fields: optional list of additional fields to return as specified
            in the `Get Test Suite API Docs`_
        :param list fields: List of exclusive fields to fetch. If passed in ``additional_fields`` will be ignored

        :return: list of :py:class:`~radarclient.model.TestSuite` objects. List may be empty
        """
        return TestSuite._get_by_ids(id_list, self, additional_fields=additional_fields, fields=fields)

    def create_test_suite(self, request_data, fetch_full_object=True, additional_fields=None):
        """
        Creates a test suite.

        :param dict request_data: Dictionary with values as specified in the `Create Test Suite API Docs`_
        :param bool fetch_full_object: If ``True`` or ``additional_fields`` is not ``None``, fetches the full
            :py:class:`~radarclient.model.TestSuite` with the returned ID, otherwise it returns
            a TestSuite with only an ID.
        :param list additional_fields: optional list with additional request data structure as documented in the
            `Create Test Suite API Docs`_

        :return: :py:class:`~radarclient.model.TestSuite`
        """
        _, data = self.build_and_send_json_request((TestSuite.BASE_URL,), request_data, method='POST')
        suite_id = data['suiteId']

        if additional_fields is not None or fetch_full_object:
            return self.test_suite_for_id(suite_id, additional_fields=additional_fields)
        else:
            return TestSuite(data)

    def create_test_suite_case(self, request_data, fetch_full_object=True, additional_fields=None):
        """
        Creates a test suite case per the `Create Test Suite Case Docs`_.

        :param dict request_data: dictionary of request data
        :param bool fetch_full_object: If ``True`` or ``additional_fields`` is not ``None``, fetches the full
            :py:class:`~radarclient.model.TestCase` with the returned ID, otherwise it returns
            a ``TestCase`` with only an ID.
        :param list[str] additional_fields: Additional fields to fetch

        :return: :py:class:`~radarclient.model.TestCase`
        """
        actual_request = {}
        for key in request_data:
            if request_data[key] is None:
                logger.debug('Removing None value for {} due to unexpected Radar '
                              'behavior'.format(key))
            else:
                actual_request[key] = request_data[key]

        _, data = self.build_and_send_json_request(
            (TestCase.BASE_URL,), actual_request, method='POST'
        )

        if additional_fields is not None or fetch_full_object:
            return self.test_suite_case_for_id(data['caseId'])
        else:
            return TestCase(data)

    def create_scheduled_test_case(self, scheduled_suite_id, request_data, fetch_full_object=True,
                                   additional_fields=None):
        """
        Creates a scheduled test case as part of a scheduled test suite

        :param int scheduled_suite_id: ID of the scheduled test suite the case will be a part of
        :param dict request_data: Creation request data per `Add Scheduled Case Docs`_
        :param bool fetch_full_object: If ``True`` or ``additional_fields`` is not ``None``, fetches the full
            :py:class:`~radarclient.model.ScheduledTestCase` with the returned ID, otherwise it returns
            ScheduledTestCase with only an ID.
        :param additional_fields: Additional fields to fetch

        :return: :py:class:`~radarclient.model.ScheduledTestCase`
        """
        _, data = self.build_and_send_json_request(
            (ScheduledTestCase.BASE_URL, scheduled_suite_id), request_data, method='POST'
        )

        if additional_fields is not None or fetch_full_object:
            return self.test_suite_case_for_id(data['caseId'])
        else:
            return TestCase(data)

    def create_scheduled_test_case(self, scheduled_suite_id, request_data, fetch_full_object=True,
                                   additional_fields=None):
        """
        Creates a scheduled test case as part of a scheduled test suite

        :param int scheduled_suite_id: ID of the scheduled test suite the case will be a part of
        :param dict request_data: Creation request data per `Add Scheduled Case Docs`_
        :param bool fetch_full_object: If ``True`` or ``additional_fields`` is not ``None``, fetches the full
            :py:class:`~radarclient.model.ScheduledTestCase` with the returned ID, otherwise it returns a
            ``ScheduledTestCase`` with only an ID.
        :param additional_fields: Additional fields to fetch

        :return: :py:class:`~radarclient.model.ScheduledTestCase`
        """
        _, data = self.build_and_send_json_request(
            (ScheduledTestCase.BASE_URL, scheduled_suite_id), request_data, method='POST'
        )

        if additional_fields is not None or fetch_full_object:
            return self.scheduled_test_case_for_id(data['id'])
        else:
            return ScheduledTestCase(data)

    @deprecated_in_place('create_test_suite_case', 3.96)
    def add_test_suite_case(self, request_data):
        """
        Adds a test case to a test suite. Note that the test suite ID must be included as a value
        for suiteID in request_data

        :param dict request_data: dictionary for the request, following the structure for Add Test Suite Case in the Radar API docs.

        :return: status 201 on success and the created ID for the Test Case
        """
        url = self.webservice_url_for_path_components('test-suites', 'cases')
        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='POST')
        status, test_case_id = self.send_request(request)

        return status, test_case_id['caseID']

    @deprecated_in_place('~radarclient.model.TestSuite.add_existing_test_case', 3.98)
    def associate_test_suite_case_by_id(self, suite_id, test_case_id):
        """
        Convenience function for adding a single test case to the end of a test suite

        :param int suite_id: The ID of the suite to be added to
        :param int test_case_id: The ID of the test case to add

        :return: None
        """
        self.associate_test_suite_cases_by_ids(suite_id, [test_case_id])

    @deprecated_in_place('~radarclient.model.TestSuite.add_existing_test_cases', 3.98)
    def associate_test_suite_cases_by_ids(self, suite_id, test_case_ids):
        """
        Takes a suite_id and a list of case_ids and appends the test cases to the test suite in
        list order using the Add Bulk Test Suite Case endpoint
        https://radar.apple.com/developer/api/documentation/latest/tstt-apis#test

        :param int suite_id: The ID of the suite to add to
        :param list test_case_ids: List of caseID ints to associate with the suite

        :return: None

        Example::

            # Working with TestSuite and TestCase objects
            test_suite = radar_client.test_suite_for_id(123)
            test_cases = [radar_client.test_suite_case_for_id(45678)]
            cases_to_add = TestCaseListValueConverter.encode_radar_value(test_cases)
            suite_id = test_suite.suiteID
            radar_client.associate_test_suite_cases_by_id(suite_id, cases_to_add)

            # Working with just IDs
            suite_id = 12345
            test_case_ids = [123, 456, 789]
            radar_client.associate_test_suite_cases_by_id(suite_id, test_case_ids

        """
        url = self.webservice_url_for_path_components('test-suites', 'testcases')

        request_data = {'suiteID': suite_id, 'testCaseIDs': test_case_ids}
        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='POST')
        self.send_request(request)

        # This weird update works around <rdar://problem/66362208> Bulk Add Test Cases Does Not
        # Do So In Order
        updated_suite = self.test_suite_for_id(suite_id, additional_fields=['cases'])
        num_cases = len(updated_suite.cases)
        for case_id in test_case_ids:
            self._reorder_test_suite_case_by_id(suite_id, case_id, num_cases)

    @deprecated_in_place('~radarclient.model.TestSuite.reorder_associated_test_case', 3.98)
    def reorder_test_suite_case_by_id(self, suite_id, test_case_id, case_number):
        """
        Updates a test case to appear in a specific spot in a test suite. The test case must
        already be part of the test suite or an error will be thrown

        :param int suite_id: suiteID of suite to be updated
        :param int test_case_id: caseID of the case to be updated
        :param int case_number: where the test case should be in the suite

        :return: None

        Example::

            # Move test case 3456 to position 5 of suite 12345
            radar_client.reorder_test_suite_case_by_id(12345, 3456, 5)
        """
        self._reorder_test_suite_case_by_id(suite_id, test_case_id, case_number)

    @deprecated_in_place('~radarclient.model.TestSuite.remove_associated_test_case', 3.98)
    def remove_test_suite_case(self, suite_id, case_number):
        """
        Removes a test suite case from a test suite by case number. This follows the functionality
        as implemented in the API. To remove test case using the caseID,
        use remove_test_suite_case_by_id

        :param int suite_id: test suite ID
        :param int case_number: caseNumber for case in the suite

        :return: status 201 on success
        """

        url = self.webservice_url_for_path_components('test-suites', suite_id, 'cases', case_number)
        request = self.request_for_url(url, method='DELETE')
        status, _ = self.send_request(request)

        return status

    @deprecated_in_place('~radarclient.model.TestSuite.remove_associated_test_case', 3.98)
    def remove_test_suite_case_by_id(self, suite_id, case_id):
        """
        Removes a test case from a test suite using the caseID. If that ID is not found,
        the suite will not have any changes made.

        Note: This iterates through the cases of the test suite until a matching
        test case is found.

        :param int suite_id: test suite ID
        :param int case_id: test case ID
        """

        suite = self.test_suite_for_id(suite_id, additional_fields=['cases'])
        for case in suite.cases:
            if case.caseID == case_id:
                self.remove_test_suite_case(suite_id, case.caseNumber)
                break

    def find_test_suite_case_ids(self, query_data, limit=None):
        """
        Gets caseIds for all test cases found by a query

        :param dict query_data: dictionary with the query data structure as documented in the
            `Find Test Suite Case Docs`_. Conditional items can be used in the same way as radar.
        :param int limit: the maximum number of items to return

        :return: list of caseIDs, empty list if nothing is found
        """
        additional_headers = [self.create_response_format_header(self.RESPONSE_FORMAT_COMPACT)]
        return TestCase._find_ids(query_data, self, TestCase.identifier_attrs[0], limit=limit,
                                  additional_headers=additional_headers,
                                  processing_callable=TestCase._find_processor_for_compact_format)

    def find_test_suite_cases(self, query_data, additional_fields=None, limit=None, return_results_directly=False):
        """
        Finds test cases that match the query. Due to limitations in the radar API, this actually
        gets test case IDs first, and then fetches the test cases themselves. The find API for
        test cases is not able to return as many of the keys that the API can return when
        looking by ID. If you only need values as returned by the Find API, you can avoid the
        performance hit by using ``return_results_directly``. If you request an unsupported field,
        it will raise an error

        :param dict query_data: dictionary with the query data structure as documented in the
            `Find Test Suite Case Docs`_. Conditional items can be used in the same way for radar
        :param list additional_fields: additional fields to be requested
        :param int limit: the maximum number of items to return
        :param bool return_results_directly: If ``True``, will return just the results of the find. If ``False``,
            will fetch items from the get by ID endpoint

        :return: list of :py:class:`~radarclient.model.TestCase` objects. Empty list if nothing is found
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if unsupported field is
            passed in

        Example::

            # Find all test cases in test component | 1.0 with "test title" in the title and a
            # priority of 3 or 4 and only get data from find end point
            query = {
                'title': {'like': '%test title%'},
                'priority': [3, 4],
                'component': {'name': 'test component', 'version': '1.0'}
            }
            results = radar_client.find_test_suite_cases(query, return_results_directly=True)

        """
        query_data = utilities._strip_id_from_component_dict(query_data)
        exclusive_fields = ['caseId'] if not return_results_directly else None
        get_ids_method = partial(self.test_suite_cases_for_ids, additional_fields=additional_fields)

        return TestCase._find(
            query_data, self, limit=limit, additional_fields=additional_fields,
            exclusive_fields_for_first_search=exclusive_fields,
            return_results_directly=return_results_directly,
            get_ids_method=get_ids_method,
            additional_headers=[self.create_response_format_header(self.RESPONSE_FORMAT_COMPACT)],
            processing_callable=TestCase._find_processor_for_compact_format
        )

    def test_suite_cases_for_ids(self, case_ids, additional_fields=None, fields=None):
        """
        Finds multiple test cases by ID. If ID does not exist or user does not have permissions,
        an error is printed but not raised

        :param list[int] case_ids: list of integer caseId values to get
        :param list[str] additional_fields: optional list with additional fields
            as documented in the `Get Test Suite Case Docs`_
        :param list[str] fields: List of exclusive fields to fetch. If passed in ``additional_fields`` will be ignored

        :return: list of :py:class:`~radarclient.model.TestCase` objects or empty list if no items found
        """
        return TestCase._get_by_ids(case_ids, self, additional_fields=additional_fields, fields=fields)

    def test_suite_case_for_id(self, case_id, additional_fields=None, fields=None):
        """
        Finds a single test case with ID

        :param int case_id: caseId of test case to get
        :param list[str] additional_fields: optional list with additional request data structure
            as documented in the `Get Test Suite Case Docs`_
        :param list[str] fields: List of exclusive fields to fetch

        :rtype: :py:class:`~radarclient.model.TestCase`
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` if there is a server error,
            the user does not have permissions, or the ID does not exist
        :raises: IncompatibleFieldsRequestException if both ``fields`` and ``additional_fields`` are requested
        """
        return TestCase._get_by_id(case_id, self, additional_fields=additional_fields, fields=fields)

    def delete_test_suite_case_by_id(self, test_suite_case_id):
        """
        Deletes a test case completely by ID, cannot be undone

        :param int test_suite_case_id: ID of test case to be deleted

        :return: None
        """
        self.build_and_send_request((TestCase.BASE_URL, test_suite_case_id), method='DELETE')

    def delete_test_suite_case(self, test_suite_case):
        """
        Deletes a test case completely using :py:class:`~radarclient.model.TestCase`

        :param TestCase test_suite_case: TestCase object to delete

        :return: None
        """
        self.delete_test_suite_case_by_id(test_suite_case.database_id_attribute_value())

    @deprecated_in_place('~radarclient.model.TestCase.relate_radar', 3.98)
    def add_related_radar_to_test_case(self, suite_id, case_number, radar_id, relationship_type=Relationship.TYPE_RELATED_TO):
        """
        Relate radar to test case and returns the response status code (201 if the request was successful).

        :param int suite_id: Test Suite ID to which to relate the radar
        :param int case_number: Test Case Number inside the given test suite to which to relate the radar
        :param int radar_id: Radar ID to relate to the given test case
        :param int relationship_type: Optional, type of the relationship, defaults to "related to". See :py:class:`Relationship` for valid values.

        Example::

            radar_client.add_related_radar_to_test_case(suite_id=953271, case_number=1, radar_id=25691112)

        """
        url = self.webservice_url_for_path_components('test-suites', suite_id, 'cases', case_number)

        relationship = {
            "id": radar_id,
            "relationType": relationship_type
        }
        request_data = {
            'relatedProblems': [relationship]
        }

        request_json = json.dumps(request_data)
        request = self.request_for_json_url(url, json_string=request_json, method='PUT')
        status, _ = self.send_request(request, check_response_code=False)

        return status

    @classmethod
    def extract_radar_ids_from_text(cls, text):
        """
        Extracts substrings that look like Radar IDs from a string.

        :param str text: the input text

        Returns a list of Radar IDs found in the text in the order in which they appear in the input string.
        Duplicates are eliminated.

        """
        all_ids = re.findall(r'\b\d{7,9}\b', text)
        seen = set()
        return [x for x in all_ids if not (x in seen or seen.add(x))]

    def create_workflow(self, conditions, actions, notifications, name=None, status=None, tags=None, query_id=None,
                        workflow_condition_type=None, filter_events=None):
        """
        Create a :py:class:`~radarclient.model.Workflow` to get notifications from Radar about changes to problems based on a
        query.

        :param dict conditions: A dictionary containing the criteria which are used to match events within the Radar
            ecosystem.
        :param dict actions: A dictionary defining the changes that will be made to applicable Radars on behalf of the
            user, if any.
        :param list notifications: A list of notification types.
        :param str name: [optional] The name string for the Workflow.
        :param str status: [optional] ``ACTIVE`` or ``INACTIVE``.
        :param list tags: [optional] A :py:class:`list` of ``tag`` strings.
        :param int query_id: [optional] The query ID
        :param str workflow_condition_type: [optional] ``ASSIGNED``, ``DRI``, ``PROXY``, ``CC``, ``WATCHLIST``, or ``OTHER``.
        :param dict filter_events: [optional] A dictionary containing the filter criteria.
        :return: The created :py:class:`~radarclient.model.Workflow` object.

        For more information, see the full documentation for `Radar API Docs (Workflow APIs)`_.
        """
        request_data = {
            'actions': actions,
            'conditions': conditions,
            'notifications': notifications
        }

        if name is not None:
            request_data['name'] = name
        if status is not None:
            assert status in ['ACTIVE', 'INACTIVE']
            request_data['status'] = status
        if tags is not None:
            request_data['tags'] = tags
        if query_id is not None:
            request_data['queryId'] = query_id
        if workflow_condition_type is not None:
            assert workflow_condition_type in ['ASSIGNED', 'DRI', 'PROXY', 'CC', 'WATCHLIST', 'OTHER']
            request_data['workflowConditionType'] = workflow_condition_type
        if filter_events is not None:
            request_data['filterEvents'] = filter_events

        status, response = self.build_and_send_json_request((Workflow.BASE_URL,), request_data, method='POST')
        if response_code_is_success(status):
            return Workflow(response)

    def find_workflows(self, request_data):
        """
        Find Workflows using the provided search criteria.

        .. note::
            Workflows are user-specific. The Find Workflows API can only search through Workflows created by the \
            current authenticated user.

        :param dict request_data: The search criteria for the Find Workflows operation.

        Returns a list of matching :py:class:`~radarclient.model.Workflow` objects, or an empty list if none found.

        The available ``request_data`` attributes are documented in the `Find Workflow API Docs`_.
        """
        return Workflow._find(request_data, self)

    def workflow_for_id(self, workflow_id):
        """
        Get a :py:class:`~radarclient.model.Workflow` for a given ID.

        :param str workflow_id: The ``workflowId`` of the desired Workflow (UUID string)

        :rtype: :py:class:`~radarclient.model.Workflow`
        :raises ObjectNotFoundException: if no Workflow with the ID is found
        """
        return Workflow._get_by_id(workflow_id, self)

    def workflows_for_ids(self, workflow_ids):
        """
        Get a list of :py:class:`~radarclient.model.Workflow` objects given their IDs.

        :param list workflow_ids: A list of ``workflowId`` UUID strings.

        Returns a list of :py:class:`~radarclient.model.Keyword` instances. See that class for an
        example.
        """
        return Workflow._get_by_ids(workflow_ids, self)

    def workflows_for_current_user(self):
        """
        Get a list of Workflows available to the authenticated user.

        .. note::
            Workflows are user-specific. This method will only return Workflows created by the current authenticated \
            user.

        :return: list of :py:class:`~radarclient.model.Workflow` objects
        """
        # TO-DO: This still needs an accurate/updated Pagination mechanism.
        next_page = None
        workflows = []
        while True:
            query_params = ''
            if next_page:
                query_params = '?page_to_fetch={}'.format(next_page)

            status, data = self.build_and_send_request(('{}{}'.format(Workflow.BASE_URL, query_params),))
            next_page = data['nextPage']
            data = data['workflows']

            for sub in data:
                workflows.append(Workflow(sub))

            if not next_page:
                break

        return workflows

    def update_workflow(self, workflow, conditions=None, actions=None, notifications=None, name=None, status=None,
                        tags=None):
        """
        Update an existing :py:class:`~radarclient.model.Workflow`. Workflow objects can be obtained via
        :py:class:`~radarclient.client.RadarClient.workflows_for_current_user`,
        :py:class:`~radarclient.client.RadarClient.workflow_for_id`, or
        :py:class:`~radarclient.client.RadarClient.workflows_for_ids`.

        :param ~radarclient.model.Workflow workflow: The :py:class:`~radarclient.model.Workflow` to update.
        :param dict conditions: [optional] A dictionary containing the criteria which are used to match events within the Radar
            ecosystem.
        :param dict actions: [optional] A dictionary defining the changes that will be made to applicable Radars on behalf of the
            user, if any.
        :param list notifications: [optional] A list of notification types.
        :param str name: [optional] The name string for the Workflow.
        :param str status: [optional] ``ACTIVE`` or ``INACTIVE``.
        :param list tags: [optional] A :py:class:`list` of ``tag`` strings.
        :return: The updated :py:class:`~radarclient.model.Workflow` object.

        For more information, see the full documentation for `Radar API Docs (Workflow APIs)`_.
        """
        workflow_data = workflow.dictionary_representation_data
        if actions is not None:
            workflow_data['actions'] = actions
        if conditions is not None:
            workflow_data['conditions'] = conditions
        if notifications is not None:
            workflow_data['notifications'] = notifications
        if name is not None:
            workflow_data['name'] = name
        if status is not None:
            assert status in ['ACTIVE', 'INACTIVE']
            workflow_data['status'] = status
        if tags is not None:
            workflow_data['tags'] = tags

        status, response = self.build_and_send_json_request((Workflow.BASE_URL, workflow.workflowId), workflow_data, method='PUT')
        if response_code_is_success(status):
            return Workflow(response)

    def delete_workflow(self, workflow):
        """
        Delete a workflow.

        Update an existing :py:class:`~radarclient.model.Workflow`. Workflow objects can be obtained via
        :py:class:`~radarclient.client.RadarClient.workflows_for_current_user`,
        :py:class:`~radarclient.client.RadarClient.workflow_for_id`, or
        :py:class:`~radarclient.client.RadarClient.workflows_for_ids`.

        :param ~radarclient.model.Workflow workflow: The :py:class:`~radarclient.model.Workflow` object to delete
        :return: :py:class:`bool`, True if successful
        """
        status, _ = self.build_and_send_request((Workflow.BASE_URL, workflow.workflowId), method='DELETE', check_result=False)
        return response_code_is_success(status)

    def create_query(self, name, search_attrs, description=None, is_public=False, query_type='Problem-Query'):
        """
        Creates a saved :py:class:`~radarclient.model.Query` for the search parameters in search_attrs

        :param str name: Name to be given to the new query. Max is 1024 chars.
        :param dict search_attrs: The search criteria to use for the query.
        :param str description: [optional] Description of created query. Max is 4000 chars.
        :param bool is_public: [optional] Specifies whether the query is public.
        :param str query_type: [optional] Specifies the type of query. Defaults to "Problem-Query". See more below.
        :return: The :py:class:`~radarclient.model.Query` object created.

        The valid ``query_type`` values are listed at
        https://radar.apple.com/developer/api/documentation/latest/enumerated-types#query-types.

        Example::

            name = 'my new query'
            description = 'testing radar query creation'
            search_attrs = {
                "all": [
                    { "component": { "eq": { "name": "python-radarclient", "version": "1.0" } } },
                    { "state": { "eq": "Analyze" } }
                ]
            }
            new_query = radar_client.create_query(name, search_attrs, description=description, is_public=True)

        """
        request_data = {
            'name': name,
            'searchAttributes': search_attrs,
            'description': description,
            'type': query_type,
        }
        _, query_data = self.build_and_send_json_request((Query.BASE_URL,), request_data, method='POST')
        if is_public:
            # Do an Update Query on behalf of the user for feature parity. Workaround for rdar://101348857
            new_query = Query(query_data)
            status, updated_query_data = self.build_and_send_json_request((Query.BASE_URL, new_query.id),
                                                                          {'everyoneAccess': 'Read Only'},
                                                                          method='POST')
            if response_code_is_success(status):
                query_data = updated_query_data
        return Query(query_data)

    def delete_query(self, query):
        """
        Delete a saved query

        :param Query query: query to delete
        :return: :py:class:`bool` True if successful, Exception for failure.

        Example::

            query = radar_client.query_for_id(1234)
            radar_client.delete_query(query)

        """
        status, _ = self.build_and_send_request((Query.BASE_URL, query.id), method='DELETE')
        return response_code_is_success(status)

    def find_queries(self, request_data):
        """
        Find saved Queries using the provided search criteria.

        :param dict request_data: The search criteria for the Find Query operation.
        :return: A :py:class:`list` of matching Queries, or an empty list if none found.

        The available ``request_data`` attributes are documented in the `Find Query API Docs`_.

        """
        return Query._find(request_data, self, return_results_directly=True)

    def query_for_id(self, query_id):
        """
        Load a saved query by its ID.

        :param int query_id: ID of the query to retrieve
        :return: A :py:class:`~radarclient.model.Query` object, or
            :py:class:`~radarclient.exceptions.ObjectNotFoundException` if not found.

        Example::

            query = self.client.query_for_id(125909)
            print(query)

        """
        return Query._get_by_id(query_id, self)

    def subscribed_queries(self, subscribed_user=None):
        """
        Fetches and returns a list of all queries to which the specified user is subscribed. Defaults to the current
        authenticated user.

        :param Person subscribed_user: (optional) The :py:class:`~radarclient.model.Person` whose subscribed queries are
            to be retrieved. If not specified, it will be the current authenticated user.
        :return: A list of :py:class:`~radarclient.model.Query` objects, or an empty list if none found.

        .. note::
            ``subscribed_user`` is only supported in API v2.2+.

        Example::

            queries = radar_client.subscribed_queries()
            for query in queries:
                print(query)

        """
        user = subscribed_user or self.current_user()
        request_data = { "ALL": { "subscribedByPersonId": user.dsid } }
        _, query_data = self.build_and_send_json_request(Query.URL_COMPONENTS_FOR_FIND, request_data, method='POST')
        return Query._instantiate_list_of_items(query_data)

    def radar_ids_for_query(self, query_id, limit=None):
        """
        Executes a query and returns a :py:class:`list` of Radar IDs.

        :param str query_id: ID of the query to execute
        :param int limit: The maximum number of Radar IDs to return. See note below.
        :return: A list of :py:class:`int` Radar IDs, or an empty list if none found.

        .. note::
            Specifically in API v2.2+ the value of ``limit`` will be honored for any number up to and including \
            ``7500``. Any value larger will actually set the ``X-RowLimit`` header to ``-1``, thereby raising the cap \
            to the absolute maximum of 250,000.

        Example::

            radar_ids = self.client.radar_ids_for_query(125909)
            for radar_id in radar_ids:
                print(radar_id)

        """
        query_id = compat.unicode_string_type(query_id)
        assert re.match(r'\d+$', query_id)

        limit = limit or 7500
        if limit > 7500:
            limit = -1

        # New queries (and legacy queries edited by Radar 8 and thus 'converted') return a list of ID integers, but
        # payload headers are required to get a successful response. (rdar://98887169)
        url = self.webservice_url_for_path_components('query/{}/execute'.format(query_id))
        request = self.request_for_json_url(url)

        request.add_header('idsOnly', 'true')
        if limit:
            self.configure_request_with_limit(request, limit)

        status, radar_data = self.send_request(request)

        if response_code_is_success(status):
            # Legacy queries from Radar 7 return idsOnly response as a string of comma-separated IDs. (rdar://72396216)
            if isinstance(radar_data, list) and len(radar_data) == 1:
                value = radar_data[0]
                if isinstance(value, dict) and 'id' in value:
                    value = value['id']
                    radar_data = [int(i) for i in value.split(',')]
        return radar_data

    def radars_for_query(self, query_id, additional_fields=None, limit=None, fields=None):
        """
        Executes a query and returns an array of :py:class:`~radarclient.model.Radar` objects.

        :param int query_id: ID of the query to execute
        :param list additional_fields: (optional) additional fields to return for each result
        :param int limit: the maximum number of items to return, up to 7,500 (in API v2.2). The default is 2000.
        :param list fields: (optional) A specific list of attributes ("fields") to use for the "X-Fields-Requested"
            header, as a way to override the default fields. NOTE: ``id`` will always be requested, for compatibility.
        :return: A list of :py:class:`~radarclient.model.Radar` objects, or an empty list if none found.

        Example::

            radars = self.client.radars_for_query(125909)
            for radar in radars:
                print(radar.id)

        """
        query_id = compat.unicode_string_type(query_id)
        assert re.match(r'\d+$', query_id)

        # New queries (and legacy queries edited by Radar 8 and thus 'converted') require payload/body headers to get a
        # successful response, so route through request_for_json_url() even without a payload/body. (rdar://98887169)
        url = self.webservice_url_for_path_components('query/{}/execute'.format(query_id))
        request = self.request_for_json_url(url)

        requested_fields = self.assemble_radar_requested_fields(fields, additional_fields)
        excluded_fields = []
        # Remove unsupported fields. Temporary(?) workaround for <rdar://problem/15487961>
        excluded_fields.extend(self.problem_fields_unavailable_for_execute_query)
        requested_fields = [x for x in requested_fields if x not in excluded_fields]
        self.configure_request_for_requested_fields(request, requested_fields)
        if limit:
            self.configure_request_with_limit(request, limit)

        status, radar_data = self.send_request(request)
        if not response_code_is_success(status):
            raise self.exception_for_non_success_response(status, radar_data)

        # TODO: Remove, temporary workaround for rdar://109530965
        for radar_dict in radar_data:
            for attr in ['classification', 'milestone', 'originator', 'component']:
                if attr not in requested_fields and attr in radar_dict:
                    del radar_dict[attr]

        return Radar.parse_webservice_data(radar_data, self, requested_fields)

    def radar_count_for_query(self, query_id):
        """
        Returns the count of Radars for the Query matching the provided ID.

        :param int query_id: ID of the query to execute
        :return: An :py:class:`int` of the number of Radars found.

        .. note::
            As of Radar API v2.2, the maximum count in the response has been raised to to 250,000.

        Example::

            radar_count = self.client.radar_count_for_query(125909)
            print(radar_count)

        """
        query_id = compat.unicode_string_type(query_id)
        assert re.match(r'\d+$', query_id)

        url = ('query', query_id, 'execute')
        headers = [('countsOnly', True)]
        status, response = self.build_and_send_request(url, additional_headers=headers)
        if response_code_is_success(status):
            return response['totalCount']
        return None

    def _run_test_suite_query(self, query_id, additional_fields=None):
        """
        Actually makes the request for a query

        :param int query_id: ID of the query to run
        :param list additional_fields: list of additional fields to fetch

        :return: list of TestSuites from query
        """
        if additional_fields is not None:
            headers = [self.create_additional_fields_header_for_find(TestSuite, additional_fields)]
        else:
            headers = []

        _, info = self.build_and_send_request(
            (Query.BASE_URL, query_id, 'execute'), additional_headers=headers
        )
        return info

    def _run_test_suite_query_work_around_missing_execute(self, query_id, additional_fields=None, ids_only=False):
        """
        Runs a query but uses the execute endpoint for TSTT queries and the find endpoint for Radar 8 created
        queries. Eventually, execute should work for both and we can remove this

        :param query_id: the ID of the query
        :param additional_fields: additional fields to grab
        :param ids_only: If True, only the IDs are returned

        :return: list of dicts or TestSuite objects
        """
        search_attributes_key = 'searchAttributes'
        query = self.query_for_id(query_id)
        if getattr(query, search_attributes_key, None) is None:
            logger.debug('No {}. Assuming a TSTT built query'.format(search_attributes_key))
            to_return = self._run_test_suite_query(query_id, additional_fields=additional_fields)
        else:
            if ids_only:
                to_return = self.find_test_suites(getattr(query, search_attributes_key), return_results_directly=True)
            else:
                to_return = self.find_test_suites(getattr(query, search_attributes_key),
                                                  additional_fields=additional_fields)

        return to_return

    def test_suite_ids_for_query(self, query_id):
        """
        Get just the IDs for a saved test suite query

        :param int query_id: ID of the query

        :return: list of test suite IDs
        """
        item_info = self._run_test_suite_query_work_around_missing_execute(query_id, ids_only=True)
        # May be `suiteID` due to rdar://116878945 (When Running a Query for Test Suites, the Suites are Returned with
        # the ID `suiteID` instead of `suiteId)
        if len(item_info) > 0 and isinstance(item_info[0], dict):
            to_return = [item['suiteID'] for item in item_info]
        else:
            to_return = [getattr(item, 'suiteId') for item in item_info]
        return to_return

    def test_suites_for_query(self, query_id, additional_fields=None):
        """
        Get all test suites from a query

        :param int query_id: ID of query
        :param list additional_fields: additional fields to grab for the test suite as documented
            in the `Find Test Suite API Docs`_

        :return: list of all the :py:class:`~radarclient.model.TestSuite` objects found by the query
        """
        query_results = self._run_test_suite_query_work_around_missing_execute(query_id,
                                                                               additional_fields=additional_fields)
        if len(query_results) > 0 and isinstance(query_results[0], dict):
            to_return = TestSuite._instantiate_list_of_items(query_results)
        else:
            to_return = query_results

        return to_return

    def delete_test_suite(self, test_suite):
        """
        Delete a test suite using a :py:class:`~radarclient.model.TestSuite` object. This cannot be reversed

        :param TestSuite test_suite: TestSuite to delete completely

        :return: None
        """
        self.delete_test_suite_by_id(getattr(test_suite, TestSuite.identifier_attrs[0]))

    def delete_test_suite_by_id(self, test_suite_id):
        """
        Delete a test suite using the ID of the test suite. This cannot be reversed

        :param int test_suite_id: ID of test suite to delete

        :return: None
        """
        self.build_and_send_request((TestSuite.BASE_URL, test_suite_id), method='DELETE')

    def _update_query_subscriber_permissions(self, query, subscriber_objects, operator, permission=None):
        subscriber_dicts = []
        for subscriber_obj in subscriber_objects:
            if isinstance(subscriber_obj, Person):
                subscriber_data = {
                    'id': subscriber_obj.dsid,
                    'type': 'person'
                }
            # Group objects don't load with 'id' but can be added using only 'name'. Workaround for rdar://97922871
            elif isinstance(subscriber_obj, AccessGroup):
                subscriber_data = {
                    'name': subscriber_obj.name,
                    'type': 'access-group'
                }
            elif isinstance(subscriber_obj, WorkGroup):
                subscriber_data = {
                    'name': subscriber_obj.name,
                    'type': 'work-group'
                }
            if permission:
                subscriber_data['permission'] = permission
            subscriber_dicts.append(subscriber_data)

        request_data = {
            'subscriber': {
                operator: subscriber_dicts
            }
        }
        status, response = self.build_and_send_json_request((Query.BASE_URL, query.id), request_data, method='POST')
        if response_code_is_success(status):
            return Query(response)

    def set_subscriber_permissions_for_query(self, query, subscriber_objects, permission):
        """
        Changes the permissions for Persons, Access Groups, or Work Groups subscribed to a Query.

        A :py:class:`~radarclient.model.Query` object can be obtained from :py:meth:`~radarclient.client.query_for_id`,
        :py:meth:`~radarclient.client.queries_for_ids`, :py:meth:`~radarclient.client.create_query`,
        :py:meth:`~radarclient.client.find_queries`, or :py:meth:`~radarclient.client.subscribed_queries`.

        :param Query query: The Query object to modify
        :param list subscriber_objects: the list of Persons, Access Groups, or Work Groups to modify permissions for
        :param str permission: type of permission to grant. The valid type values are listed in the
            `Query Permissions Docs`_ but is typically one of: ``Read Only``, ``Read & Write``, ``Owner (Read & Write)``
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure

        Example::

            query = radar_client.query_for_id(123456)
            person = radar_client.find_people(email='test_email@apple.com')[0]
            acc_group = radar_client.access_group_for_id(654321)
            permission = Query.READ_ONLY_PERMISSION
            query = radar_client.set_subscriber_permissions_for_query(query, [person, acc_group], permission)

        """
        return self._update_query_subscriber_permissions(query, subscriber_objects, 'upsert', permission)

    def set_everyone_permissions_for_query(self, query, permission):
        """
        Changes the permissions for the 'Everyone' entry of the 'subscribers' property of a :`~radarclient.model.Query`.

        :param Query query: The Query object to modify.
        :param str permission: type of permission to grant. The valid type values are listed in the
            `Query Permissions Docs`_ but is typically one of: ``Read Only``, ``Read & Write``, ``Owner (Read & Write)``
            , or ``No Access``.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure
        """
        request_data = {'everyoneAccess': permission}
        status, response = self.build_and_send_json_request((Query.BASE_URL, query.id), request_data, method='POST')
        if response_code_is_success(status):
            return Query(response)

    def add_person_to_query(self, query, person, permission):
        """
        A convenience method that calls :py:meth:`~add_persons_to_query` for a single Person.

        :param Query query: The Query object to update.
        :param Person person: The :py:class:`~radarclient.model.Person` object to add.
        :param str permission: type of permission to grant. The valid type values are listed in the
            `Query Permissions Docs`_ but is typically ``Read Only``, ``Read & Write``, or ``Owner (Read & Write)``.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure
        """
        return self.add_persons_to_query(query, [person], permission)

    def add_persons_to_query(self, query, persons, permission):
        """
        Add 1 or more Persons as subscribers to the specified Query with the specified permissions.

        A :py:class:`~radarclient.model.Query` object can be obtained from :py:meth:`~query_for_id`,
        :py:meth:`~create_query`, :py:meth:`~find_queries`, or :py:meth:`~subscribed_queries`.

        A :py:class:`~radarclient.model.Person` object can be obtained from :py:meth:`~find_people` or
        :py:meth:`~person_for_dsid`, and also from various properties of objects like ``radar.Assignee`` or
        ``component.screener``.

        :param Query query: The Query object to update.
        :param list persons: the list of :py:class:`~radarclient.model.Person` objects to add.
        :param str permission: type of permission to grant. The valid type values are listed in the
            `Query Permissions Docs`_ but is typically ``Read Only``, ``Read & Write``, or ``Owner (Read & Write)``.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure

        Example::

            query = radar_client.query_for_id(123456)
            someone = radar_client.person_for_dsid(123456789)
            someone_else = radar_client.find_people(email='test_email@apple.com')[0]
            permission = Query.READ_AND_WRITE_PERMISSION
            query = radar_client.add_persons_to_query(query, [someone, someone_else], permission)

        """
        return self._update_query_subscriber_permissions(query, persons, 'upsert', permission)

    def remove_person_from_query(self, query, person):
        """
        A convenience method that calls :py:meth:`~remove_persons_from_query` for a single Person.

        :param Query query: The Query object to update.
        :param Person person: The :py:class:`~radarclient.model.Person` object to add.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure
        """
        return self.remove_persons_from_query(query, [person])

    def remove_persons_from_query(self, query, persons):
        """
        Unsubscribe 1 or more Persons from a Query.

        A :py:class:`~radarclient.model.Query` object can be obtained from :py:meth:`~query_for_id`,
        :py:meth:`~create_query`, :py:meth:`~find_queries`, or :py:meth:`~subscribed_queries`.

        A :py:class:`~radarclient.model.Person` object can be obtained from :py:meth:`~find_people` or
        :py:meth:`~person_for_dsid`, and also from various properties of objects like ``radar.Assignee`` or
        ``component.screener``.

        :param Query query: The Query object to update.
        :param list persons: the list of :py:class:`~radarclient.model.Person` objects to add.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure.

        Example::

            query = radar_client.query_for_id(123456)
            people = [sub for sub in query.subscribers if isinstance(sub, Person)]
            for person in people:
                print(person)
            subscribers_to_remove = [people[1], people[3]]
            radar_client.remove_persons_from_query(query, subscribers_to_remove)

        """
        return self._update_query_subscriber_permissions(query, persons, 'remove')

    def add_groups_to_query(self, query, groups, permission):
        """
        Add 1 or more :py:class:`~radarclient.model.AccessGroup` or :py:class:`~radarclient.model.WorkGroup` objects as
        subscribers to the specified query with the specified permissions.

        A :py:class:`~radarclient.model.Query` object can be obtained from :py:meth:`~query_for_id`,
        :py:meth:`~create_query`, :py:meth:`~find_queries`, or :py:meth:`~subscribed_queries`.

        Group objects can be obtained from :py:meth:`~access_group_for_id`, :py:meth:`~work_group_for_id`,
        :py:meth:`~access_group_for_name`, :py:meth:`~work_group_for_name`, or :py:meth:`~find_radar_groups`.

        :param Query query: The Query object to update.
        :param list groups: The list of :py:class:`~radarclient.model.AccessGroup` or \
        :py:class:`~radarclient.model.WorkGroup` objects to add.
        :param str permission: type of permission to grant. The valid type values are listed in the
            `Query Permissions Docs`_ but is typically ``Read Only``, ``Read & Write``, or ``Owner (Read & Write)``.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure.

        Example::

            query = radar_client.query_for_id(123456)
            some_group = radar_client.access_group_for_id(445566)
            another_group = radar_client.work_group_for_id(112233)
            groups = [some_group, another_group]
            permission = 'Read Only'
            query = radar_client.add_groups_to_query(query, groups, permission)

        """
        return self._update_query_subscriber_permissions(query, groups, 'upsert', permission)

    def add_group_to_query(self, query, group, permission):
        """
        A convenience method that calls :py:meth:`~add_groups_to_query` for a single Group.

        :param Query query: The Query object to update.
        :param RadarGroup group: The :py:class:`~radarclient.model.AccessGroup` or \
        :py:class:`~radarclient.model.WorkGroup` object to add.
        :param str permission: type of permission to grant. The valid type values are listed in the
            `Query Permissions Docs`_ but is typically ``Read Only``, ``Read & Write``, or ``Owner (Read & Write)``.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure
        """
        return self.add_groups_to_query(query, [group], permission)

    def remove_groups_from_query(self, query, groups):
        """
        Unsubscribe 1 or more :py:class:`~radarclient.model.AccessGroup` or
        :py:class:`~radarclient.model.WorkGroup` objects from a Query.

        A :py:class:`~radarclient.model.Query` object can be obtained from :py:meth:`~query_for_id`,
        :py:meth:`~create_query`, :py:meth:`~find_queries`, or :py:meth:`~subscribed_queries`.

        Group objects can be obtained from :py:meth:`~access_group_for_id`, :py:meth:`~work_group_for_id`,
        :py:meth:`~access_group_for_name`, :py:meth:`~work_group_for_name`, or :py:meth:`~find_radar_groups`.

        :param Query query: The Query object to update.
        :param list groups: The list of :py:class:`~radarclient.model.AccessGroup` or \
        :py:class:`~radarclient.model.WorkGroup` objects to add.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure.

        Example::

            query = radar_client.query_for_id(123456)
            sub_groups = [sub for sub in query.subscribers if not isinstance(sub, Person)]
            for group in sub_groups:
                print(group)
            groups_to_remove = [groups[1], groups[3]]
            radar_client.remove_groups_from_query(query, groups_to_remove)

        """
        return self._update_query_subscriber_permissions(query, groups, 'remove')

    def remove_group_from_query(self, query, group):
        """
        A convenience method that calls :py:meth:`~remove_groups_from_query` for a single Group.

        :param Query query: The Query object to update.
        :param RadarGroup group: The :py:class:`~radarclient.model.AccessGroup` or \
        :py:class:`~radarclient.model.WorkGroup` object to add.
        :return: The updated :py:class:`~radarclient.model.Query` object, or an Exception on failure
        """
        return self.remove_groups_from_query(query, [group])

    def board_for_id(self, board_id):
        """
        Find a Radar :py:class:`~radarclient.model.RadarBoard` by ID

        For more information, please reference the `Boards API Documentation`_

        :param int board_id: The ID of the :py:class:`~radarclient.model.RadarBoard` to find
        :rtype: RadarBoard
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, board_data = self.build_and_send_request(url_components=(RadarBoard.BASE_URL, board_id))
        return RadarBoard(board_data, client=self)

    def available_boards(self):
        """
        Get all ``active`` :py:class:`~radarclient.model.RadarBoard` objects accessible to the logged-in user

        Does not return ``archived`` boards

        For more information, please reference the `Boards API Documentation`_

        :rtype: list[RadarBoard]
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, board_data = self.build_and_send_request(url_components=[RadarBoard.BASE_URL], method="GET")
        return [self.board_for_id(board.get("id")) for board in board_data if board.get("state") != "archived"]

    def create_board(self, default_component_id, description, title, access_list, state_columns):
        """Create a :py:class:`~radarclient.model.RadarBoard` object

        For more information, please reference the `Boards API Documentation`_

        :param int default_component_id: The default component ID to assign to the board
        :param str title: The title of the Board
        :param str description: The description of the Board
        :param list(dict) access_list: The access list of the Board
        :param list(dict) state_columns: The state columns for the Board

        Example::

            state_columns = [
                {
                    "maxState": "analyze-nominate",
                    "title": "Defined"
                },
                {
                    "maxState": "integrate",
                    "title": "In Progress"
                },
                {
                    "maxState": "verify",
                    "title": "Complete"
                },
                {
                    "maxState": "closed",
                    "title": "Accepted"
                }
            ]
            title = "Radar boards Example"
            description = "Radar Boards Example Script"
            component_id = 515346
            board = client.create_board(
                default_component_id=component_id,
                title=title, description=description,
                state_columns=state_columns,
                access_list=board_access_list)

        :rtype: RadarBoard
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "accessList": access_list,
            "defaultComponentId": default_component_id,
            "description": description,
            "title": title,
            "stateColumns": state_columns
        }
        status, board_data = self.build_and_send_json_request(url_components=[RadarBoard.BASE_URL], method="POST", request_data=data)
        return RadarBoard(board_data, client=self)

    def sprints_for_board_id(self, board_id):
        """
        Find all :py:class:`~radarclient.model.RadarBoardSprint` objects for a :py:class:`~radarclient.model.RadarBoard` by ID

        For more information, please reference the `Boards API Documentation`_

        :param int board_id: The ID of the `~radarclient.model.RadarBoard` to find
        :rtype: list[RadarBoardSprint]
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, sprint_data = self.build_and_send_request(url_components=(RadarBoard.BASE_URL, board_id, RadarBoardSprint.BASE_URL))
        return RadarBoardSprint.parse_webservice_data(sprint_data, client=self)

    def epics_for_board_id(self, board_id):
        """
        Find all :py:class:`~radarclient.model.RadarBoardEpic` objects for a :py:class:`~radarclient.model.RadarBoard` by ID

        For more information, please reference the `Boards API Documentation`_

        :param int board_id: The ID of the :py:class:`~radarclient.model.RadarBoard` to find
        :rtype: list[RadarBoardEpic]
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, epic_data = self.build_and_send_request(url_components=(RadarBoard.BASE_URL, board_id, RadarBoardEpic.BASE_URL))
        return RadarBoardEpic.parse_webservice_data(epic_data, client=self)

    def jobs_for_board_id(self, board_id):
        """
        Find all :py:class:`~radarclient.model.RadarBoardJob` objects for a :py:class:`~radarclient.model.RadarBoard` by ID

        For more information, please reference the `Get Jobs API Documentation`_

        :param int board_id: The ID of the :py:class:`~radarclient.model.RadarBoard` to find
        :rtype: list[RadarBoardJob]
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, job_data = self.build_and_send_json_request(url_components=(RadarBoard.BASE_URL, board_id, RadarBoardJob.BASE_URL), request_data=None)
        return [RadarBoardJob(job, self) for job in job_data]

    def radar_board_job_for_id(self, board_id, job_id):
        """
        Helper method to return an individual :py:class:`~radarclient.model.RadarBoardJob` by ID

        For more information, please reference the `Get Jobs API Documentation`_

        :param int board_id: The ID of the :py:class:`~radarclient.model.RadarBoard`
        :param int job_id: The ID of the :py:class:`~radarclient.model.RadarBoardJob`
        :rtype: RadarBoardJob
        :raises: :py:class:`radarclient.exceptions.ObjectNotFoundException`
        """
        all_jobs = self.jobs_for_board_id(board_id)
        if all_jobs:
            specific_job = [job for job in all_jobs if job.jobId == job_id]
            if len(specific_job) == 1:
                return specific_job[0]
        raise ObjectNotFoundException


    def sprint_for_id(self, board_id, sprint_id):
        """
        Find a :py:class:`~radarclient.model.RadarBoardSprint` by ID

        For more information, please reference the `Get Sprint API Documentation`_

        :param int board_id: The Board ID of the :py:class:`~radarclient.model.RadarBoardSprint` to find
        :param int sprint_id: The ID of the :py:class:`~radarclient.model.RadarBoardSprint` to find
        :rtype: RadarBoardSprint
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, sprint_data = self.build_and_send_request(url_components=(RadarBoard.BASE_URL, board_id, RadarBoardSprint.BASE_URL, sprint_id))
        return RadarBoardSprint(sprint_data, self)

    def epic_for_id(self, board_id, epic_id):
        """
        Find a :py:class:`~radarclient.model.RadarBoardEpic` by ID

        For more information, please reference the `Get Epic API Documentation`_

        :param int board_id: The Board ID of the :py:class:`~radarclient.model.RadarBoardEpic` to find
        :param int epic_id: The ID of the :py:class:`~radarclient.model.RadarBoardEpic` to find
        :rtype: RadarBoardEpic
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, epic_data = self.build_and_send_request(url_components=(RadarBoard.BASE_URL, board_id, RadarBoardEpic.BASE_URL, epic_id))
        return RadarBoardEpic(epic_data, self)

    def story_for_id(self, board_id, story_id):
        """
        Find a :py:class:`~radarclient.model.RadarBoardStory` by ID

        For more information, please reference the `Get Story API Documentation`_

        :param int board_id: The Board ID of the :py:class:`~radarclient.model.RadarBoardStory` to find
        :param int story_id: The ID of the :py:class:`~radarclient.model.RadarBoardStory` to find
        :rtype: RadarBoardStory
        :raises: :py:class:`radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, story_data = self.build_and_send_request(url_components=(RadarBoard.BASE_URL, board_id, RadarBoardStory.BASE_URL, story_id))
        return RadarBoardStory(story_data, self)

    def _id_for_category_item(self, attribute_cache_name, item_value, category_type):
        attribute_cache = getattr(self, attribute_cache_name)
        if attribute_cache is None:
            logger.debug('Caching categories of type {}'.format(category_type))
            setattr(self, attribute_cache_name, self.test_categories_for_type_map(category_type))
            attribute_cache = getattr(self, attribute_cache_name)

        return attribute_cache[item_value].id

    def id_for_scheduled_test_status(self, status_string):
        """
        Get the ID for a specific scheduled test status string

        :param str status_string: status string of a scheduled test

        :return: int ID of the specified string
        """
        return self._id_for_category_item('_scheduled_test_statuses', status_string, 'TEST_STATUS')

    def id_for_test_category(self, category_string):
        """
        Get the ID for a specific test category

        :param str category_string: category string to find the ID of

        :return: int ID of the category
        """
        return self._id_for_category_item('_test_categories', category_string, 'TEST_TYPE')

    def id_for_test_suite_status(self, status_string):
        """
        Get the ID for the status of a test suite

        :param str status_string: The status string of the test suite

        :return: int ID of the test suite status
        """
        return self._id_for_category_item('_test_statuses', status_string, 'SCRIPT_STATUS')

    def id_for_test_track_name(self, track_name):
        """
        Get the ID for a test track name

        :param str track_name: track name to get the ID of

        :return: int ID of the track name
        """
        return self._id_for_category_item('_track_names', track_name, 'TRACK')

    def id_for_test_complexity(self, complexity):
        """
        Get the ID for a test complexity

        :param str complexity: complexity to get the ID of

        :return: int ID of the test complexity
        """
        return self._id_for_category_item('_test_complexities', complexity, 'TEST_LEVEL')

    def id_for_business_process(self, business_process):
        """
        Get the ID for a business process

        :param str business_process: business process to get the ID of

        :return: int ID of the business practice
        """
        return self._id_for_category_item('_business_processes', business_process, 'BUSINESS_PROCESS')

    def id_for_scheduled_test_case_status(self, status):
        """
        Get the ID for a scheduled test case status

        :param str status: scheduled test case status to get the ID of

        :return: int ID of the scheduled test case status
        """
        return self._id_for_category_item('_scheduled_test_case_statuses', status, 'SCH_TEST_CASE_STATUS')

    def id_for_application_name(self, app_name):
        """
        Get the ID for an application name

        :param str app_name: application name to get the ID of

        :return: int ID of the application name
        """
        return self._id_for_category_item('_application_names', app_name, 'APPLICATION_NAME')

    def id_for_test_cycle(self, cycle):
        """
        Get the ID for a test cycle

        :param str cycle: test cycle to get the ID of

        :return: int ID of the test cycle
        """
        return self._id_for_category_item('_test_cycles', cycle, 'SCHEDULED_TEST_NAME')

    def id_for_test_geography(self, geography):
        """
        Get the ID for a test geography

        :param str geography: test geography to get the ID of

        :return: int ID of the test geography
        """
        return self._id_for_category_item('_test_geographies', geography, 'GEOGRAPHY')

    @staticmethod
    def _build_test_category_reference_dict_from_response(categories):
        """
        Builds a dictionary that uses both the value of the category and the id of the category

        :param categories: the list of category dicts as returned in `attributes`

        :return: dict
        """
        to_return = {}
        for category in categories:
            to_return[category.value] = category
            to_return[category.id] = category

        return to_return

    def all_test_categories_map(self):
        """
        Gets all test categories and returns them in a nested dictionary with the first level representing category
        types and the second level consisting of all categories of that type in a dictionary that can be referenced
        by both the ``id`` and the ``value``. `Test Categories API Docs`_

        Example::

            # Assume a fake category of type FAKE_CAT with the id 1 and value "Fake Category" exists
            all_categories = client.all_test_categories()

            # Get category by value
            cat_by_value = all_categories['FAKE_CAT']['Fake Category']

            # Get category by id
            cat_by_id = all_categories['FAKE_CAT'][1]

        :return: nested dict with type as the top level key and both the id and value as the secondary level keys to
            get :py:class:`~radarclient.model.TestCategory` objects
        """
        _, data = self.build_and_send_request((TestCategory.BASE_URL,))

        to_return = {}
        for category_type in data:
            to_return[category_type['type']] = (
                self._build_test_category_reference_dict_from_response((TestCategory(info) for info
                                                                        in category_type['attributes'])))

        return to_return

    def all_test_categories(self):
        """
        Gets all categories as a nested dictionary with the type being the top level holding a list of
        :py:class:`~radarclient.model.TestCategory` objects from the Test Categories API as documented at `Test
        Categories API Docs`_

        returns: dictionary with keys being the type holding a list  of :py:class:`~radarclient.model.TestCategory`
            objects
        """
        _, data = self.build_and_send_request((TestCategory.BASE_URL,))
        to_return = {}
        for category_type in data:
            to_return[category_type['type']] = [TestCategory(category) for category in category_type['attributes']]

        return to_return

    def test_categories_for_type_map(self, category_type):
        """
        Gets all test categories of the matching type

        :param str category_type: the string name of the type of category

        :return: A dictionary with keys of category values and category id to get the matching
            :py:class:`~radarclient.model.TestCategory` object
        """
        return self._build_test_category_reference_dict_from_response(self.test_categories_for_type(category_type))

    def test_categories_for_type(self, category_type):
        """
        Get a generator of :py:class:`~radarclient.model.TestCategory` for the specified type

        :param str category_type: the type name of the category

        :return: generator of :py:class:`~radarclient.model.TestCategory` objects
        """
        _, data = self.build_and_send_request((TestCategory.BASE_URL, category_type))
        if not isinstance(data, dict):
            return {}
        else:
            return (TestCategory(category) for category in data['attributes'])

    def suggestions(self, search_string, types, limit=None):
        """
        Access suggestions using the `Suggestions API Docs`_. If looking to get suggestions for only 1 type,
        it is recommended that you use one of the convenience methods for that type such as
        :py:meth:`~radarclient.client.RadarClient.build_suggestions`.

        :param str search_string: The search string to use
        :param list[str] types: The types of items you would like returned
        :param int limit: The maximum number of items returned for each type. ``None`` will use the API default which
            as of November 2023 is 5. Some suggestion endpoints may use this value as a maximum for the number of
            subtypes to return. For example, calling an endpoint with 3 subtypes and a limit of 5 will return at most
            15 items

        :return: list of returned items with those that can be converted in to RadarClient objects converted
        """

        type_converters = {
            'build': Build,
            'person': Person,
            'component': Component,
            'bundle': ComponentBundle,
            'bundlegroup': ComponentBundleGroup,
            'keyword': Keyword,
            'milestone': Milestone,
            'event': Event,
            'category': Category,
            'tentpole': Tentpole,
            'label': Label,
            'dsgroup': None,
            'accessgroup': AccessGroup,
            'workgroup': WorkGroup,
            'board': RadarBoard,
            'sprint': RadarBoardSprint
        }

        url_components = ('suggestion',)
        request_data = {
            'search': search_string,
            'rows': limit,
            'types': types
        }

        _, data = self.build_and_send_json_request(url_components, request_data, method='POST')

        to_return = []
        for item in data:
            # Don't use get here to ensure error is raised if key is not added to type_converters
            type_converter = type_converters[item['type']]
            if type_converter == RadarBoard or type_converter == RadarBoardSprint:
                to_return.append(type_converter(item, self))
            elif type_converter is not None:
                to_return.append(type_converter(item))
            else:
                to_return.append(item)

        return to_return

    def build_suggestions(self, search_string, limit=None):
        """
        Get build suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Build` objects
        """
        return self.suggestions(search_string, ['build'], limit=limit)

    def person_suggestions(self, search_string, limit=None):
        """
        Get person suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return for each subcategory which there are 3 of. ``None``
            will use the radar API default which is 5 as of November 2023

        :return: list of :py:class:`~radarclient.model.Person` objects
        """
        return self.suggestions(search_string, ['person'], limit=limit)

    def component_suggestions(self, search_string, limit=None):
        """
        Get component suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Component` objects
        """
        return self.suggestions(search_string, ['component'], limit=limit)

    def component_bundle_suggestions(self, search_string, limit=None):
        """
        Get component bundle suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.ComponentBundle` objects
        """
        return self.suggestions(search_string, ['bundle'], limit=limit)

    def component_bundle_group_suggestions(self, search_string, limit=None):
        """
        Get component bundle group suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.ComponentBundleGroup` objects
        """
        return self.suggestions(search_string, ['bundlegroup'], limit=limit)

    def keyword_suggestions(self, search_string, limit=None):
        """
        Get keyword suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Keyword` objects
        """
        return self.suggestions(search_string, ['keyword'], limit=limit)

    def milestone_suggestions(self, search_string, limit=None):
        """
        Get milestone suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Milestone` objects
        """
        return self.suggestions(search_string, ['milestone'], limit=limit)

    def event_suggestions(self, search_string, limit=None):
        """
        Get event suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Event` objects
        """
        return self.suggestions(search_string, ['event'], limit=limit)

    def category_suggestions(self, search_string, limit=None):
        """
        Get category suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Category` objects
        """
        return self.suggestions(search_string, ['category'], limit=limit)

    def tentpole_suggestions(self, search_string, limit=None):
        """
        Get tentpole suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Tentpole` objects
        """
        return self.suggestions(search_string, ['tentpole'], limit=limit)

    def label_suggestions(self, search_string, limit=None):
        """
        Get label suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.Label` objects
        """
        return self.suggestions(search_string, ['label'], limit=limit)

    def group_suggestions(self, search_string, limit=None):
        """
        Get group suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return for each type of group, dsgroup, Access Group,
            or Work Group. ``None`` will use the radar API default which is 5 as of November 2023

        :return: list of dict objects for DS Groups, :py:class:`~radarclient.model.WorkGroup` objects for work groups
            and :py:class:`~radarclient.model.AccessGroup` objects for access groups

        .. note::
            This endpoint, as of November 2023, does not currently function as documented. rdar://118335438
            (Suggestions API For Groups Does not Return the Correct Information)
        """
        return self.suggestions(search_string, ['group'], limit=limit)

    def board_suggestions(self, search_string, limit=None):
        """
        Get board suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.RadarBoard` objects
        """
        return self.suggestions(search_string, ['board'], limit=limit)

    def sprint_suggestions(self, search_string, limit=None):
        """
        Get sprint suggestions from the suggestions API per the `Suggestions API Docs`_

        :param str search_string: Search string to use
        :param int limit: The maximum number of items to return. ``None`` will use the radar API default which is 5
            as of November 2023

        :return: list of :py:class:`~radarclient.model.RadarBoardSprint` objects
        """
        return self.suggestions(search_string, ['sprint'], limit=limit)

    def api_endpoints(self):
        """
        Retrieve the full catalog of available API endpoints.

        :rtype: :py:class:`list` of :py:class:`~radarclient.model.RadarAPIEndpoint` objects.
        """
        endpoints_url = ('endpoints',)
        status, response = self.build_and_send_request(endpoints_url)
        if response_code_is_success(status):
            return [RadarAPIEndpoint(item) for item in response]

    def _get_api_endpoint_access(self, endpoint_data):
        user_dsid = self.authentication_strategy.radar_access_token().dsid
        endpoint_access_url = ('entities', user_dsid, 'checkMyAccess')
        status, response = self.build_and_send_json_request(endpoint_access_url, endpoint_data)
        if response_code_is_success(status):
            return RadarAPIEndpointAccessCheck(response)

    def api_endpoint_access_for_name(self, endpoint_name):
        """
        Retrieve the current user's access/permissions for a specific API endpoint. A convenience wrapper method for
        :py:meth:`~api_endpoint_access_for_names`.

        :param str endpoint_name: The ``name`` value of the :py:class:`~radarclient.model.RadarAPIEndpoint` in question.

        :rtype: :py:class:`~radarclient.model.RadarAPIEndpointAccessCheck`
        """
        return self.api_endpoint_access_for_names([endpoint_name])

    def api_endpoint_access_for_names(self, endpoint_names):
        """
        Retrieve the current user's access/permissions for specific API endpoints.

        :param list endpoint_names: :py:class:`list` of the ``name`` values of the \
        :py:class:`~radarclient.model.RadarAPIEndpoint` objects in question.

        :rtype: :py:class:`~radarclient.model.RadarAPIEndpointAccessCheck`
        """
        endpoint_data = {'endpointNames': endpoint_names}
        return self._get_api_endpoint_access(endpoint_data)

    def api_endpoint_access_for_id(self, endpoint_id):
        """
        Retrieve the current user's access/permissions for a specific API endpoint. A convenience wrapper method for
        :py:meth:`~api_endpoint_access_for_ids`.

        :param int endpoint_id: The ``id`` value of the :py:class:`~radarclient.model.RadarAPIEndpoint` in question.

        :rtype: :py:class:`~radarclient.model.RadarAPIEndpointAccessCheck`
        """
        return self.api_endpoint_access_for_ids([endpoint_id])

    def api_endpoint_access_for_ids(self, endpoint_ids):
        """
        Retrieve the current user's access/permissions for specific API endpoints.

        :param list endpoint_ids: :py:class:`list` of the ``id`` values of the \
        :py:class:`~radarclient.model.RadarAPIEndpoint` objects in question.

        :rtype: :py:class:`~radarclient.model.RadarAPIEndpointAccessCheck`
        """
        endpoint_data = {'endpointIds': endpoint_ids}
        return self._get_api_endpoint_access(endpoint_data)

    def key_values_for_radar_id(self, radar_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given :py:class:`~radarclient.model.Radar`, by
        its ``id``.

        This is provided as an alternative to the :py:class:`~radarclient.model.Radar.key_values` attribute specific to
        the :py:class:`~radarclient.model.Radar` class, for consistency with other classes that support Key-Value Pairs.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int radar_id: The ``id`` of the target :py:class:`~radarclient.model.Radar`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_radar = self.radar_for_id(radar_id, fields=['id', 'title'])
        kv_store = KeyValueStore(self, source_radar)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def key_values_for_component_id(self, component_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given :py:class:`~radarclient.model.Component`,
        by its ``id``.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int component_id: The ``id`` of the target :py:class:`~radarclient.model.Component`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_component = self.component_for_id(component_id)
        kv_store = KeyValueStore(self, source_component)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def key_values_for_access_group_id(self, access_group_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given
        :py:class:`~radarclient.model.AccessGroup`, by its ``id``.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int access_group_id: The ``id`` of the target :py:class:`~radarclient.model.AccessGroup`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_access_group = self.access_group_for_id(access_group_id)
        kv_store = KeyValueStore(self, source_access_group)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def key_values_for_work_group_id(self, work_group_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given
        :py:class:`~radarclient.model.WorkGroup`, by its ``id``.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int work_group_id: The ``id`` of the target :py:class:`~radarclient.model.WorkGroup`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_work_group = self.work_group_for_id(work_group_id)
        kv_store = KeyValueStore(self, source_work_group)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def key_values_for_test_suite_id(self, test_suite_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given
        :py:class:`~radarclient.model.TestSuite`, by its ``id``.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int test_suite_id: The ``suiteId`` of the target :py:class:`~radarclient.model.TestSuite`.
        :param list key_names: [optional] A list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_test_suite = self.test_suite_for_id(test_suite_id)
        kv_store = KeyValueStore(self, source_test_suite)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def key_values_for_test_case_id(self, test_case_id, test_suite_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a :py:class:`~radarclient.model.TestCase` within
        a specific :py:class:`~radarclient.model.TestSuite`.

        .. note::
            As of March 2025 and Radar API v2.2, Key-Value Pairs are only allowed for Test Cases that are specifically
            part of a Test Suite. Free-floating/standalone Test Cases do not support Key-Value Pairs.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int test_case_id: The ``id`` of the target :py:class:`~radarclient.model.TestCase`.
        :param int test_suite_id: The ``suiteId`` of the target :py:class:`~radarclient.model.TestSuite` containing
            the associated :py:class:`~radarclient.model.TestCase`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_test_case = self.test_suite_case_for_id(test_case_id)
        source_test_suite = self.test_suite_for_id(test_suite_id)
        kv_store = KeyValueStoreForTestSuiteCase(self, source_test_case, source_test_suite)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store


    def key_values_for_scheduled_test_id(self, scheduled_test_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given
        :py:class:`~radarclient.model.ScheduledTest`, by its ``id``.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int scheduled_test_id: The ``id`` of the target :py:class:`~radarclient.model.ScheduledTest`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_scheduled_test = self.scheduled_test_for_id(scheduled_test_id)
        kv_store = KeyValueStore(self, source_scheduled_test)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def key_values_for_scheduled_test_case_id(self, scheduled_test_case_id, key_names=None):
        """
        Retrieve the :py:class:`~radarclient.model.KeyValueStore` for a given
        :py:class:`~radarclient.model.ScheduledTestCase`, by its ``id``.

        **No key-value pairs will be loaded automatically unless provided in the 'key_names' parameter.**
        :py:class:`~radarclient.model.KeyValuePair` objects can be loaded into an instantiated
        :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.

        :param int scheduled_test_case_id: The ``id`` of the target :py:class:`~radarclient.model.ScheduledTestCase`.
        :param list key_names: An [optional] list of ``name`` :py:class:`str` for which the corresponding
            :py:class:`~radarclient.model.KeyValuePair` objects will be automatically loaded.

        :rtype: :py:class:`~radarclient.model.KeyValueStore`
        """
        source_scheduled_test_case = self.scheduled_test_case_for_id(scheduled_test_case_id)
        kv_store = KeyValueStore(self, source_scheduled_test_case)
        if key_names:
            kv_store.load_pairs_for_keys(key_names)
        return kv_store

    def problem_summary_multithreaded(self, radars, max_thread_count=4):
        """
        A multithreaded version of :py:meth:`~radarclient.model.Radar.problem_summary`.

        :param list[Radar] radars: The :py:class:`~radarclient.model.Radar` objects to get the problem summary for.
        :param int max_thread_count: [optional] How many parallel threads to open to the Radar API. Default is 4.
        :param bool return_result_queue: Pass in ``True`` to return a tuple containing
            ``(result_queue, exception_queue, thread_set)``. You can use the queue as input for a multiprocessed
            system. All 3 items in the tuple can be used with
            :py:class:`~radarclient.utilities.wait_for_multithreaded_completion_helper` to wait for all threads to
            complete and add appropriate sentinel values to the ``result_queue`` to stop your spawned processes. This
            should only be used when you need to access the ``Queue`` of radar results directly.
        :return: A Generator for the :py:class:`~radarclient.model.Radar` objects matching the provided ``radars`` or,
            if ``return_result_queue=True``, a tuple containing ``(result_queue, exception_queue, thread_set)``.

        Example::

            radars = radar_client.radars_for_query(query_id=123456)
            radars_with_summaries = radar_client.problem_summary_multithreaded(radars)
            for radar in radars_with_summaries:
                print(radar.problem_summary()

        """
        manager = SimpleThreadManager(radars, max_thread_count=max_thread_count, client=self)
        return manager.get_threaded_results(radars, 'problem_summary')

    @deprecated(replacement=create_query, version=6.16)
    def create_shared_report(self, name, search_attrs, description=None, is_public=False, report_type='Problem Query'):
        pass

    @deprecated(replacement=delete_query, version=6.16)
    def delete_shared_report(self, shared_report):
        pass

    @deprecated_and_removed('radar_ids_for_query', 6.16)
    def radar_ids_for_shared_report(self, shared_report_id, limit=None, return_id_list=False):
        pass

    @deprecated(replacement=radars_for_query, version=6.16)
    def radars_for_shared_report(self, shared_report_id, additional_fields=None, limit=None):
        pass

    @deprecated(replacement=radar_count_for_query, version=6.16)
    def radar_count_for_shared_report(self, shared_report_id):
        pass

    @deprecated(replacement=_run_test_suite_query, version=6.16)
    def _run_test_suite_shared_report(self, shared_report_id, additional_fields=None):
        pass

    @deprecated(replacement=test_suite_ids_for_query, version=6.16)
    def test_suite_ids_for_shared_report(self, shared_report_id):
        pass

    @deprecated(replacement=test_suites_for_query, version=6.16)
    def test_suites_for_shared_report(self, shared_report_id, additional_fields=None):
        pass

    @deprecated_and_removed('find_queries', 6.16)
    def available_shared_reports(self):
        pass

    @deprecated_and_removed('available_shared_reports', version=3.107)
    def shared_reports(self):
        pass

    @deprecated_and_removed('set_subscriber_permissions_for_query', 6.16)
    def set_person_permissions_for_shared_report(self, shared_report, person, permission):
        pass

    @deprecated(replacement=remove_person_from_query, version=6.16)
    def remove_person_from_shared_report(self, shared_report, person):
        pass

    @deprecated_and_removed('set_person_permissions_for_shared_report', 3.108)
    def subscribe_person_to_shared_report(self, shared_report_id, person, permission):
        pass

    @deprecated_and_removed('set_subscriber_permissions_for_query', 6.16)
    def set_group_permissions_for_shared_report(self, shared_report, group, permission):
        pass

    @deprecated(replacement=remove_group_from_query, version=6.16)
    def remove_group_from_shared_report(self, shared_report, group):
        pass

    @deprecated_and_removed('set_group_permissions_for_shared_report', 3.108)
    def subscribe_group_to_shared_report(self, shared_report_id, group_name, permission, group_type):
        pass

    @deprecated(replacement=query_for_id, version=6.16)
    def shared_report_for_id(self, shared_report_id):
        pass

    @deprecated_and_removed('create_workflow', 6.16)
    def create_problem_subscription(self, subscription_query, notifications):
        pass

    @deprecated(replacement=workflows_for_current_user, version=6.16)
    def problem_subscriptions_for_current_user(self):
        pass

    @deprecated_and_removed('update_workflow', 6.16)
    def update_problem_subscription(self, subscription_id, subscription_query, notifications):
        pass

    @deprecated_and_removed('delete_workflow', 6.16)
    def delete_problem_subscription(self, subscription_id):
        pass


class SimpleThreadManager:
    """
    This class is used to send multithreaded requests to the Radar API and collect the responses.

    :param list chunked_input: Either a list of lists of per-thread chunks (for client methods such as
        ``radars_for_ids``), or a list of per-thread base objects (for object methods such as
        :py:meth:`~radarclient.model.Radar.combined_history`).
    :param str chunked_kwarg: [RadarClient-based methods only] Key name for the primary positional argument when it is
        different for each thread. This is used for compatibility with python 2.7. For example, ``problem_ids`` when
        used for :py:meth:`RadarClient.radars_for_ids_multithreaded`.
    :param int max_thread_count: The maximum number of parallel threads to open. Default is ``5``.
    :param RadarClient client: [optional] The instance of RadarClient to be deep-copied, per-thread. Only applicable
        to object-based methods such as :py:meth:`~radarclient.model.Radar.combined_history`.
    :return: :py:class:`Generator`
    :rtype: :py:meth:`~radarclient.utilities.multithreaded_results_gen`
    :raises: If an error is raised in any thread that error will be raised in the main thread. If multiple threads raise
        an error, only the first error is raised.

    It is designed for these scenarios:

    - A single RadarClient method with multiple input values, such as date-range chunks from \
    :py:class:`~radarclient.utilities.ChunkQueryDictGenerator` for \
    :py:meth:`~radarclient.client.RadarClient.find_radar_ids_multithreaded` or :py:class:`~radarclient.model.Radar` IDs\
    for :py:meth:`~radarclient.client.RadarClient.radars_for_ids_multithreaded`.
    - A single object method to be run in-parallel on multiple instances of that object type, such as \
    :py:meth:`~radarclient.model.Radar.combined_history`.

    For example usage, see :py:meth:`~radarclient.client.RadarClient.radars_for_ids_multithreaded`,
    :py:meth:`~radarclient.client.RadarClient.combined_history_multithreaded`, or
    :py:meth:`~radarclient.client.RadarClient.find_radar_ids_multithreaded`.

    """
    def __init__(self, chunked_input, chunked_kwarg=None, max_thread_count=5, client=None):
        self.chunked_input = chunked_input
        self.chunked_kwarg = chunked_kwarg
        self.max_thread_count = max_thread_count
        self.client = client
        if self.client:
            assert isinstance(self.client, RadarClient), ("The 'client' parameter must be an instance of "
                                                          "radarclient.RadarClient or NoneType!")

    def get_threaded_results(self, base_obj, base_obj_method, return_result_queue=False, **kwargs):
        """
        Splits the requests for ``base_obj.base_obj_method`` into threads for parallel processing and collects the
        threaded responses together into unified results.

        :param varies base_obj: Either a static instance of :py:class:`~radarclient.client.RadarClient` or a
            :py:class:`list` of objects on which the ``base_obj_method`` will be called.
        :param str base_obj_method: The name of the method/function to be called, passed in as a :py:class:`str`.
        :param bool return_result_queue: Pass in ``True`` to return a tuple containing
            ``(result_queue, exception_queue, thread_set)``. You can use the queue as input for a multiprocessed
            system. All 3 items in the tuple can be used with
            :py:class:`~radarclient.utilities.wait_for_multithreaded_completion_helper` to wait for all threads to
            complete and add appropriate sentinel values to the ``result_queue`` to stop your spawned processes. This
            should only be used when you need to access the ``Queue`` of radar results directly.

        .. note::
            ``**kwargs`` should be all the arguments normally sent to ``base_obj_method`` when called directly. They
            must be declared `with` their keywords. When the intended usage is a single RadarClient method with multiple
            input values, pass in a value of ``None`` for the primary positional argument (such as ``problem_ids`` or
            ``request_data``) when calling ``get_threaded_results``. The actual input values are passed in as
            ``chunked_input`` when creating the ``SimpleThreadManager`` instance. See the examples linked above for
            assistance.
        """
        input_queue = compat.queue_module.Queue()
        if return_result_queue:
            result_queue = mpQueue()
        else:
            result_queue = compat.queue_module.Queue()
        exception_queue = compat.queue_module.Queue(1)

        def _thread_worker():
            if isinstance(base_obj, RadarClient):
                # For usage with RadarClient methods (i.e. radars_for_ids()) the base_obj is a local copy of the
                # RadarClient object itself.
                local_data = thread_local()
                local_data.thread_client = deepcopy(base_obj)
                while not exception_queue.full():
                    thread_input = input_queue.get(timeout=10)  # timeout to prevent potential hangs in python 2.7
                    if thread_input is None or exception_queue.full():
                        break
                    try:
                        # The primary positional argument needs to be populated with the chunk for each particular
                        # thread ('request_data=', 'problem_ids=', etc.).
                        if self.chunked_kwarg:
                            kwargs[self.chunked_kwarg] = thread_input
                        result = getattr(local_data.thread_client, base_obj_method)(**kwargs)
                        if isinstance(result, list):
                            for item in result:
                                result_queue.put(item, timeout=120)
                        else:
                            result_queue.put(result, timeout=120)
                        input_queue.task_done()
                    except Exception as ex:
                        input_queue.task_done()
                        try:
                            exception_queue.put_nowait(ex)
                            compat.log_exception(logger, ex)
                        except compat.queue_module.Full:
                            pass
            elif isinstance(base_obj, list):
                # For usage with RadarClient object-based methods(i.e. radar.combined_history()), the base_obj becomes
                # the next object in the list of self.chunked_input (thread_input).
                while not exception_queue.full():
                    thread_input = input_queue.get(timeout=10)  # timeout to prevent potential hangs in python 2.7
                    if thread_input is None or exception_queue.full():
                        break
                    try:
                        if self.client and hasattr(base_obj, 'client'):
                            setattr(base_obj, 'client', deepcopy(self.client))
                        result = getattr(thread_input, base_obj_method)(**kwargs)
                        result_queue.put(thread_input, timeout=120)
                    except Exception as ex:
                        input_queue.task_done()
                        try:
                            exception_queue.put_nowait(ex)
                            compat.log_exception(logger, ex)
                        except compat.queue_module.Full:
                            pass

        thread_count = min(len(self.chunked_input), self.max_thread_count)

        thread_set = set()
        for _ in range(thread_count):
            t = Thread(target=_thread_worker)
            t.daemon = True
            t.start()
            thread_set.add(t)

        for input_chunk in self.chunked_input:
            if exception_queue.full():
                break
            input_queue.put(input_chunk)

        for _ in range(thread_count):
            if exception_queue.full():
                break
            input_queue.put(None)

        if return_result_queue:
            return result_queue, exception_queue, thread_set
        else:
            return utilities.multithreaded_results_gen(result_queue, exception_queue, thread_set)
