#!/usr/bin/env python

import re
from threading import Condition, current_thread
import copy
import time
from random import randrange
from .utilities import logger
from .decorators import cached_class_property
from logging import DEBUG as LOGGING_LEVEL_DEBUG
import re

class RateLimitPolicy(object):
    """
    Builds a policy for rate-limiting of requests sent to the Radar API to avoid hitting HTTP 429 "Too Many Requests" errors.
    The policy is a list of :py:class:`RateLimitPolicyRule` objects that are evaluated (in order) to determine
    which rate limit (if any) should be applied to a request. The first rule that matches an API request
    will be used to rate-limit the request transmission on the client side to hopefully avoid hitting the rate limit
    on the server, although this :py:class:`RateLimitPolicy` can be used with :py:class:`~radarclient.retrypolicy.RetryPolicy` to do an
    exponential backoff if an HTTP 429 is still returned despite the client-side rate-limiting.

    :param list rules: A list of :py:class:`RateLimitPolicyRule` objects. If not specified, the default set of rate limits are used.
    :param callable logging_callback: [optional] Callback function to use for logging when the rate limit is
        exceeded. The three required arguments map to the request, the :py:class:`RateLimitPolicyRule` matching the request, and
        the number of seconds that the request was delayed by to avoid exceeding the rate limit.

    The :py:class:`RateLimitPolicy` will attempt to delay any API calls that would have exceeded the rate limit. For multithreaded
    implementations, the rate-limiting behavior is assessed globally, so if 10 threads attempt each make an
    API call for an endpoint that has a rate limit of 5 Transactions Per Second, the first 5 will execute, followed
    by the remaining 5 calls as soon as possible as long as the rate limit is not exceeded.

    Users can opt in to the :py:class:`RateLimitPolicy` class and behavior by configuring it on their
    :py:class:`~radarclient.client.RadarClient` instance.

    A set of pre-configured rate limit objects is provided by default, but you can use your own if desired, as well
    as use the ``default_rules`` class property to prepend new rules to match with greater precedence. This may
    be useful if your account has an raised rate limit for an endpoint, and you want to allow more requests
    per second to be made for that endpoint

    To see the available/pre-built :py:class:`RateLimitPolicyRule` objects for a :py:class:`~radarclient.client.RadarClient` object:

    Example::

        radar_client = RadarClient(
            authentication_strategy,
            system_identifier,
            retry_policy=radarclient.RetryPolicy(),
            rate_limit_policy=radarclient.RateLimitPolicy()
        )
        for rule in radar_client.ratelimit_policy.rules:
            print(rule)

    A custom rate limit for the ``rules`` :py:class:`list` is built like this:

    Example::

        custom_rules = [
            RateLimitPolicyRule(30, method="GET", endpoint_re=re.compile(r'/problems/\\d+/keywords$'))
        ]
        rules = custom_rules + RateLimitPolicy.default_rules
        radar_client = RadarClient(
            authentication_strategy,
            system_identifier,
            retry_policy=radarclient.RetryPolicy(),
            rate_limit_policy=radarclient.RateLimitPolicy(rules=rules)
        )

    The endpoint regular expression should properly handle variable parts of the URL, such as components
    that include an ID or name.

    A rate limit policy can optionally specify a logging callback that is invoked when the policy is applied:

    Example::

        def rate_limit_callback(request, rule, delay):
            print(f'Radar API rate limit avoided by delaying {request.method} {request.get_path()} by {delay} second(s)')

        radar_client = RadarClient(
            authentication_strategy,
            system_identifier,
            retry_policy=radarclient.RetryPolicy(),
            rate_limit_policy=radarclient.RateLimitPolicy(logging_callback=rate_limit_callback)
        )


    """
    ABSOLUTE_MAX_TPS = 60

    def __init__(self, rules=None, logging_callback=None):
        all_rules = rules or RateLimitPolicy.default_rules
        assert(all_rules)
        self.rules = all_rules
        self.logging_callback = logging_callback

    @cached_class_property
    def default_rules(cls):
        """
        This is the default list of :py:class:`RateLimitPolicyRule` objects for existing document
        rate limits at their base rate-limit levels. This list can be used to construct
        a custom :py:class:`RateLimitPolicy` rule specification with new entries prepended, or
        existing entries removed.
        """
        return [
RateLimitPolicyRule(2, # AddAdministratorToComponentBundle
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundles/\d+/admins/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # AddAdministratorToComponentBundleGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+/admins/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # AddComponentAdmin
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/admins/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # AddComponentBundleGroupToComponentBundleGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+/memberGroups/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # AddComponentBundleToComponentBundleGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+/memberBundles/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # AddComponentRequest
                    method="POST",
                    endpoint_re=re.compile(r"""(/componentrequest)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # AddComponentToBundle
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundles/\d+/components)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # AddComponentToComponentBundle
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundles/\d+/components/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # AddEditRelatedProblem
                    method="PUT",
                    endpoint_re=re.compile(r"""(//problems/\d+/related-problems/[^/]+/\d+|
                                                /problems/\d+/related-problems/[^/]+/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # AddEventToComponent
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/events|
                                                /components/\d+/events)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(10, # AddKeyValue
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/key-values|
                                                /groups/[^/]+/[^/]+/key-values|
                                                /problems/\d+/key-values|
                                                /problems/\d+/key-values/|
                                                /scheduled-tests/\d+/cases/\d+/key-values|
                                                /scheduled-tests/\d+/key-values|
                                                /test-suites/\d+/cases/\d+/key-values|
                                                /test-suites/\d+/key-values)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # AddLocationSpace
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/resources/locations/spaces)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # AddMultipleKeywordsToProblem
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/keywords/add)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(10, # AddOtherRelatedItems
                    method="POST",
                    endpoint_re=re.compile(r"""(//problems//[^/]+//other-related-items|
                                                //problems//[^/]+//other-related-items/|
                                                //problems//[^/]+/other-related-items|
                                                //problems/[^/]+//other-related-items|
                                                //problems/[^/]+/other-related-items|
                                                //problems/[^/]+/other-related-items/|
                                                /problems//[^/]+//other-related-items|
                                                /problems//[^/]+/other-related-items|
                                                /problems//[^/]+/other-related-items/|
                                                /problems/[^/]+//other-related-items|
                                                /problems/[^/]+/other-related-items|
                                                /problems/[^/]+/other-related-items/|
                                                /problems/[^/]+/other-related-items/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # AddProblemKeyword
                    method="PUT",
                    endpoint_re=re.compile(r"""(//problems/\d+/keywords/[^/]+|
                                                /problems//keywords/[^/]+|
                                                /problems/\d+/keywords/[^/]+|
                                                /problems/\d+/keywords/[^/]+/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(8, # AddProblemKeywords
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/\d+/keywords|
                                                /problems/\d+/keywords/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # AddRelatedProblems
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/\d+/related-problems)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CancelJob
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/tests/modify/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CancelModifyProblemJob
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/problems/modify/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CloneComponent
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/clone)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # CloneProblem
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/\d+/clone)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # CloneQuery
                    method="POST",
                    endpoint_re=re.compile(r"""(/query/\d+/clone)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(8, # CloneScheduledTestCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/\d+/clone)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # CloneTestCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/cases/\d+/clone)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # CloneTestSuite
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/suites/\d+/clone)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateBulkScheduledTests
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/bulk)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateComponent
                    method="POST",
                    endpoint_re=re.compile(r"""(/components)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateComponentAccessGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/accessgroups)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # CreateComponentBuild
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/builds)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateComponentBundle
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundles)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # CreateComponentBundleGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundle-groups)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # CreateComponentCategory
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/categories)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateComponentKeyword
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/keywords)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateComponentMilestone
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/milestones)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # CreateComponentNotification
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/notifications)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # CreateComponentSharedKeywordSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # CreateComponentTentpole
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/tentpoles)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # CreateGroupRequest
                    method="POST",
                    endpoint_re=re.compile(r"""(/grouprequest)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateNewProblem
                    method="POST",
                    endpoint_re=re.compile(r"""(//problems|
                                                /problems)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # CreateQuery
                    method="POST",
                    endpoint_re=re.compile(r"""(/query)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateResource
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/resources)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateResourceDefinition
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/resourcedefinitions)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateScheduledResource
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledresources)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateScheduledResourceDefinition
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledresourcedefinitions)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateScheduledTest
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # CreateScheduledTestCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # CreateSharedKeyword
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet/\d+/keywords)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # CreateSharedLabel
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet/[^/]+/labels)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # CreateSharedLabelSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # CreateTemplate
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/templates)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # CreateTestCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/cases)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # CreateTestSuite
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/suites)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # DeleteComponentAccessGroup
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/accessgroups/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # DeleteComponentAdmin
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/admins/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteComponentBuilds
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/builds/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteComponentBundle
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundles/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteComponentBundleGroup
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # DeleteComponentCategories
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/categories/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # DeleteComponentEvents
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/events/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # DeleteComponentKeyword
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/keywords/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # DeleteComponentMilestones
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/milestones/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteComponentNotificationById
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/notifications/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteComponentTentpoles
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/tentpoles/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # DeleteOtherRelatedItems
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/[^/]+/other-related-items/delete)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # DeleteQuery
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/query/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteScheduledTest
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteScheduledTestCase
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteSharedKeyword
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet/[^/]+/keywords/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteSharedKeywordSet
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteSharedLabel
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet/\d+/labels/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteSharedLabelSet
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # DeleteTemplateById
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/templates/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # DeleteTestCase
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/tests/cases/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # EditKeyValue
                    method="PUT",
                    endpoint_re=re.compile(r"""(/components/\d+/key-values/[^/]+|
                                                /groups/[^/]+/[^/]+/key-values/[^/]+|
                                                /problems/\d+/key-values/[^/]+|
                                                /scheduled-tests/\d+/cases/\d+/key-values/[^/]+|
                                                /scheduled-tests/\d+/key-values/[^/]+|
                                                /test-suites/\d+/cases/\d+/key-values/[^/]+|
                                                /test-suites/\d+/key-values/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(10, # ExecuteQuery
                    method="GET",
                    endpoint_re=re.compile(r"""(/query/\d+/execute)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(15, # FindComponent
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/Find|
                                                /components/find|
                                                /components/find/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # FindComponentBundle
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundles/find|
                                                /component-bundles/find/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindComponentBundleGroups
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindComponentRequest
                    method="POST",
                    endpoint_re=re.compile(r"""(/componentrequest/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # FindDSGroups
                    method="POST",
                    endpoint_re=re.compile(r"""(/dsgroups/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindGroupRequest
                    method="POST",
                    endpoint_re=re.compile(r"""(/grouprequest/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(9, # FindKeywordSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/keyword-sets/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindKeywords
                    method="POST",
                    endpoint_re=re.compile(r"""(//keywords//find/|
                                                //keywords/find|
                                                //keywords/find/|
                                                /keywords//find/|
                                                /keywords/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(7, # FindLabelSets
                    method="POST",
                    endpoint_re=re.compile(r"""(/label-sets/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # FindProblemQueryAdapter
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/find/query/adapter/notification)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # FindProblemQueryValidator
                    method="POST",
                    endpoint_re=re.compile(r"""(/problems/find/query/validator/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(9, # FindProblems
                    method="POST",
                    endpoint_re=re.compile(r"""(///problems/find|
                                                //problems/find|
                                                /problems/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # FindQuery
                    method="POST",
                    endpoint_re=re.compile(r"""(/query/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindResourceDefinition
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/resourcedefinitions/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindScheduledResourceDefinition
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledresourcedefinitions/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindScheduledResources
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledresources/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindScheduledTestCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # FindScheduledTests
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # FindTestCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/cases/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # FindTestResource
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/resources/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # FindTestSuites
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/suites/find)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # GetAllLabelSets
                    method="GET",
                    endpoint_re=re.compile(r"""(/label-sets)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetCategories
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/categories)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetCategoriesByType
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/categories/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetComponentAccessGroups
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/accessgroups)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetComponentAdmins
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/admins)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # GetComponentBuilds
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/builds|
                                                /components/[^/]+/builds|
                                                /components/\d+/builds)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(12, # GetComponentBundle
                    method="GET",
                    endpoint_re=re.compile(r"""(/component-bundles/[^/]+|
                                                /component-bundles/[^/]+|
                                                /component-bundles/[^/]+/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(10, # GetComponentBundleGroup
                    method="GET",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # GetComponentCategories
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/categories|
                                                /components/[^/]+/[^/]+/categories/|
                                                /components/\d+/categories)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetComponentCategoryById
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/categories/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # GetComponentEventById
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/events/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetComponentEvents
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/events|
                                                /components/[^/]+/[^/]+/events/|
                                                /components/\d+/events)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetComponentHistory
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/history/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # GetComponentKeywords
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/keywords)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # GetComponentMilestoneById
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/milestones/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetComponentMilestones
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/milestones|
                                                /components/[^/]+/[^/]+/milestones/|
                                                /components/\d+/milestones)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetComponentNotification
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/notifications)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # GetComponentPeople
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/people)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # GetComponentRecents
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/recents|
                                                /core/components/recents)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetComponentRequest
                    method="GET",
                    endpoint_re=re.compile(r"""(/componentrequest/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetComponentRequestGroup
                    method="GET",
                    endpoint_re=re.compile(r"""(/componentrequest/notificationhistory/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetComponentSharedKeywordSet
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetComponentTemplates
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/templates)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetComponentTentpole
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/tentpoles/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetComponentTentpoles
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/tentpoles|
                                                /components/\d+/tentpoles|
                                                /components/\d+/tentpoles/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(6, # GetComponentTree
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/componentTree)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetConfigurationTextById
                    method="GET",
                    endpoint_re=re.compile(r"""(/configurations/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # GetDefaultDescriptionTemplate
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/default-description-template)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetDefaultDescriptionTemplateByName
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/[^/]+/[^/]+/default-description-template)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetGroupRequestById
                    method="GET",
                    endpoint_re=re.compile(r"""(/grouprequest/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetGroupRequestNotificationHistory
                    method="GET",
                    endpoint_re=re.compile(r"""(/grouprequest/notificationhistory/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetJobDetails
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/modify/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(20, # GetKeyValueById
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/key-values|
                                                /groups/[^/]+/[^/]+/key-values|
                                                /problems/\d+/key-values|
                                                /problems/\d+/key-values/|
                                                /scheduled-tests/\d+/cases/\d+/key-values|
                                                /scheduled-tests/\d+/cases/\d+/key-values/|
                                                /scheduled-tests/\d+/key-values|
                                                /scheduled-tests/\d+/key-values|
                                                /test-suites/\d+/cases/\d+/key-values|
                                                /test-suites/\d+/key-values)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(15, # GetKeyValueByName
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/key-values/[^/]+|
                                                /groups/[^/]+/[^/]+/key-values/[^/]+|
                                                /problems/\d+/key-values/[^/]+|
                                                /scheduled-tests/\d+/cases/\d+/key-values/[^/]+|
                                                /scheduled-tests/\d+/key-values/[^/]+|
                                                /test-suites/\d+/cases/\d+/key-values/[^/]+|
                                                /test-suites/\d+/key-values/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # GetKeywordById
                    method="GET",
                    endpoint_re=re.compile(r"""(//keywords/[^/]+|
                                                /keywords//[^/]+|
                                                /keywords/[^/]+|
                                                /keywords/[^/]+/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # GetKeywordSets
                    method="GET",
                    endpoint_re=re.compile(r"""(/keyword-sets|
                                                /keyword-sets/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetLabelSetById
                    method="GET",
                    endpoint_re=re.compile(r"""(/label-sets/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetLookUpCategoryByType
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resources/attributes/lookupcategory/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetModifyProblemJobById
                    method="GET",
                    endpoint_re=re.compile(r"""(/problems/modify/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # GetNewProblemTemplate
                    method="GET",
                    endpoint_re=re.compile(r"""(/problems/new-problem-template)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(7, # GetOtherRelatedItems
                    method="GET",
                    endpoint_re=re.compile(r"""(//problems//[^/]+//other-related-items|
                                                //problems//[^/]+//other-related-items/|
                                                //problems//[^/]+/other-related-items|
                                                //problems/[^/]+//other-related-items|
                                                //problems/[^/]+/other-related-items|
                                                /problems//[^/]+//other-related-items|
                                                /problems//[^/]+/other-related-items|
                                                /problems//[^/]+/other-related-items/|
                                                /problems/[^/]+//other-related-items|
                                                /problems/[^/]+//other-related-items|
                                                /problems/[^/]+//other-related-items/|
                                                /problems/[^/]+/other-related-items|
                                                /problems/[^/]+/other-related-items/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetOtherRelatedItemsSystemsList
                    method="GET",
                    endpoint_re=re.compile(r"""(//other-related-items//systems|
                                                //other-related-items//systems/|
                                                //other-related-items/systems|
                                                /other-related-items//systems|
                                                /other-related-items/systems|
                                                /other-related-items/systems/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(10, # GetProblemByIds
                    method="GET",
                    endpoint_re=re.compile(r"""(//problems/[^/]+|
                                                /problems//[^/]+|
                                                /problems/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(7, # GetProblemKeywordInformation
                    method="GET",
                    endpoint_re=re.compile(r"""(/problems/\d+/keywords/[^/]+|
                                                /problems/\d+/keywords/[^/]+/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetProblemProtectionMask
                    method="GET",
                    endpoint_re=re.compile(r"""(/problems/\d+/mask)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetQuery
                    method="GET",
                    endpoint_re=re.compile(r"""(/query/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetRecentScheduledTestCases
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/recents)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetRecentScheduledTests
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/recents)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetResource
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resources/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetResourceAttributes
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resources/attributes)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetResourceAttributesCategories
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resources/attributes/categories)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetResourceAttributesProperties
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resources/attributes/properties)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetResourceDefinition
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resourcedefinitions/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # GetResourceLocation
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/resources/locations)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetRootComponentById
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/component-root)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetScheduledCaseHistory
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/\d+/history)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetScheduledCaseReviews
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/suites/\d+/scheduledcases/reviews)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetScheduledResource
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledresources/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetScheduledResourceDefinition
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledresourcedefinitions/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetScheduledTest
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(8, # GetScheduledTestCase
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetScheduledTestHistory
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/\d+/history)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetScheduledTestSummary
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/\d+/summary)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # GetSharedLabelSet
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(10, # GetSubComponentsById
                    method="GET",
                    endpoint_re=re.compile(r"""(/components/\d+/subcomponents)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(12, # GetTestCaseById
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/cases/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # GetTestSuiteById
                    method="GET",
                    endpoint_re=re.compile(r"""(/tests/suites/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # LabelReorder
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet/[^/]+/labels/reorder)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # ListAccessibleComponentBundles
                    method="GET",
                    endpoint_re=re.compile(r"""(/component-bundles)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # ListComponentBundleGroup
                    method="GET",
                    endpoint_re=re.compile(r"""(/component-bundle-groups)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(15, # ListProblemKeywords
                    method="GET",
                    endpoint_re=re.compile(r"""(//problems/\d+/keywords|
                                                /problems/\d+/keywords|
                                                /problems/\d+/keywords/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # ListRecentProblems
                    method="GET",
                    endpoint_re=re.compile(r"""(//problems/recents|
                                                //problems/recents/|
                                                /problems//recents/|
                                                /problems/recents|
                                                /problems/recents//)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # MarkProblemAsViewed
                    method="PUT",
                    endpoint_re=re.compile(r"""(/problems/view/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyBulkCase
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/cases/modify)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyBulkScheduledCaseAsync
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/modify/async)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyBulkScheduledTest
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/modify)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyBulkScheduledTestAsync
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/modify/async)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyBulkScheduledTestCases
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/modify)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyBulkTestSuites
                    method="POST",
                    endpoint_re=re.compile(r"""(/tests/suites/modify)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # ModifyComponentBundle
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundles/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ModifyProblems
                    method="POST",
                    endpoint_re=re.compile(r"""(//problems/modify|
                                                //problems/modify/|
                                                /problems/modify|
                                                /problems/modify/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # ModifyScheduledCaseReview
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/suites/\d+/scheduledcases/\d+/reviews)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # MoveKeyWordsBetweenComponents
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/keywords-move)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(20, # ProblemTree
                    method="POST",
                    endpoint_re=re.compile(r"""(/problem/tree)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # RemoveAdministratorFromComponentBundle
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundles/\d+/admins/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # RemoveAdministratorFromComponentBundleGroup
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+/admins/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # RemoveComponentBundleFromComponentBundleGroup
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+/memberBundles/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # RemoveComponentBundleGroupFromComponentBundleGroup
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+/memberGroups/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # RemoveComponentFromBundle
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/component-bundles/\d+/components/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # RemoveKeyValue
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/components/\d+/key-values/[^/]+|
                                                /groups/[^/]+/[^/]+/key-values/[^/]+|
                                                /problems/\d+/key-values/[^/]+|
                                                /scheduled-tests/\d+/cases/\d+/key-values/[^/]+|
                                                /scheduled-tests/\d+/key-values/[^/]+|
                                                /test-suites/\d+/cases/\d+/key-values/[^/]+|
                                                /test-suites/\d+/key-values/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # RemoveMultipleKeywordsFromProblem
                    method="PUT",
                    endpoint_re=re.compile(r"""(/problems/keywords/remove)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # RemoveProblemKeyword
                    method="DELETE",
                    endpoint_re=re.compile(r"""(//problems/\d+/keywords/[^/]+|
                                                /problems/[^/]+/keywords/[^/]+/|
                                                /problems/\d+/keywords/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # ReorderTestSuites
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/suites/\d+/reorder)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # SetActiveLabelSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/label-sets/\d+/active)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # SubscribeKeywordSet
                    method="PUT",
                    endpoint_re=re.compile(r"""(/keyword-sets/[^/]+/subscribe)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # SubscribeToLabelSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/label-sets/\d+/subscribe)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UnrelateProblem
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/problems/\d+/related-problems/[^/]+/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UnsubscribeFromLabelSet
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/label-sets/\d+/subscribe)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UnsubscribeKeywordSet
                    method="DELETE",
                    endpoint_re=re.compile(r"""(/keyword-sets/[^/]+/unsubscribe)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateComponentAccessGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/accessgroups/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UpdateComponentBuild
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/builds/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # UpdateComponentBundleGroup
                    method="POST",
                    endpoint_re=re.compile(r"""(/component-bundle-groups/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateComponentById
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateComponentCategoryById
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/categories/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateComponentEvent
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/events/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateComponentKeyword
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/keywords/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateComponentMilestoneById
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/milestones/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # UpdateComponentMilestoneInheritance
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/milestonesInheritance)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # UpdateComponentNotificationById
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/notifications/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateComponentRequest
                    method="POST",
                    endpoint_re=re.compile(r"""(/componentrequest/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UpdateComponentSharedKeywordSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateComponentTentpoleById
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/tentpoles/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateGroupRequest
                    method="POST",
                    endpoint_re=re.compile(r"""(/grouprequest/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UpdateLabelSet
                    method="PUT",
                    endpoint_re=re.compile(r"""(/label-sets/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateProblem
                    method="POST",
                    endpoint_re=re.compile(r"""(//problems/\d+|
                                                /problems//\d+|
                                                /problems/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateQuery
                    method="POST",
                    endpoint_re=re.compile(r"""(/query/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateResource
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/resources/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateResourceDefinition
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/resourcedefinitions/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateScheduledResource
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/scheduledresources/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateScheduledResourceDefinition
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/scheduledresourcedefinitions/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateScheduledTest
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(12, # UpdateScheduledTestCase
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/scheduledcases/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateScheduledTestReorder
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/scheduledtests/\d+/reorder)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UpdateSharedKeyword
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedKeywordSet/[^/]+/keywords/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UpdateSharedLabel
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet/[^/]+/labels/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # UpdateSharedLabelSet
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/sharedLabelSet/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(2, # UpdateTemplate
                    method="POST",
                    endpoint_re=re.compile(r"""(/components/\d+/templates/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateTestCase
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/cases/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(3, # UpdateTestSuite
                    method="PUT",
                    endpoint_re=re.compile(r"""(/tests/suites/\d+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(1, # AddOtherRelatedItem
                    method="PUT",
                    endpoint_re=re.compile(r"""(//problems//[^/]+//other-related-items/[^/]+/[^/]+|
                                                //problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+//other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems//[^/]+//other-related-items/[^/]+/[^/]+|
                                                /problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+//other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+/other-related-items/[^/]+/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(5, # EditOtherRelatedItem
                    method="POST",
                    endpoint_re=re.compile(r"""(//problems//[^/]+//other-related-items/[^/]+/[^/]+|
                                                //problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+//other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems//[^/]+//other-related-items/[^/]+/[^/]+|
                                                /problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+//other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+/other-related-items/[^/]+/[^/]+)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # GetComponent
                    method="GET",
                    endpoint_re=re.compile(r"""(//components/[^/]+/[^/]+|
                                                //components/\d+|
                                                //components/\d+/|
                                                /components/[^/]+/[^/]+|
                                                /components/\d+|
                                                /components/\d+/)$""",
                                           re.VERBOSE)),
RateLimitPolicyRule(4, # RemoveOtherRelatedItem
                    method="DELETE",
                    endpoint_re=re.compile(r"""(//problems//[^/]+//other-related-items/[^/]+/[^/]+|
                                                //problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+//other-related-items/[^/]+/[^/]+|
                                                //problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems//[^/]+//other-related-items/[^/]+/[^/]+|
                                                /problems//[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+//other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+/other-related-items/[^/]+/[^/]+|
                                                /problems/[^/]+/other-related-items/[^/]+/[^/]+)$""",
                                           re.VERBOSE)),
        ]

    def _get_rate_limit_rule(self, method, endpoint):
        for rule in self.rules:
            if rule.matches(method, endpoint):
                return rule

        return None

    def _wait_if_needed(self, request):
        path_only = request.get_path()
        method = request.method
        rule = self._get_rate_limit_rule(method, path_only)
        if rule is None:
            # no rate-limit
            return

        return rule._wait_if_needed(request, self.logging_callback)

    def __deepcopy__(self, memo):
        raise TypeError("Cannot deepcopy() RateLimitPolicy, this object must be shared directly")

    def __repr__(self):
        return u'<RateLimitPolicy with {} RateLimitPolicyRule instances>'.format(len(self.rules))

class RateLimitPolicyRule(object):
    """
    An object that specifies the rate-limiting behavior for requests matching a specific combination of
    HTTP method and Radar API endpoint. The endpoint regular expression is matched against the
    path component if the API URL, e.g. for ``https://radar-webservices.apple.com/problems/123/keywords``
    it would be evaluated against just ``/problems/123/keywords``, and if it matches (and the method
    also matches), the rate limit would be applied to that API call.

    :param str rate_limit: The maximum transactions per second that are supported. See more below.
    :param str method: The HTTP method, ie. ``GET``, ``POST``, ``PUT``, etc.
    :param str endpoint_re: A compiled :py:class:`re.Pattern`

    See more info at :py:class:`RateLimitPolicy`.
    """

    def __init__(self, rate_limit=RateLimitPolicy.ABSOLUTE_MAX_TPS, method=None, endpoint_re=None):
        self.method = method
        self.endpoint_re = endpoint_re
        self.rate_limit = rate_limit
        assert(method and endpoint_re)

        self.rate_limit_condition = Condition()
        self.requests_in_last_second = []
        self.waiters = []

    def _wait_if_needed(self, request, rate_limit_callback):
        first_timestamp = None

        self.rate_limit_condition.acquire()
        self.waiters.append(current_thread()) # our place in line
        while True:
            now = time.time()
            if first_timestamp is None:
                first_timestamp = now

            # first, remove requests from the log that were more than a second ago
            one_second_ago = now - 1.0
            while len(self.requests_in_last_second):
                if self.requests_in_last_second[0] < one_second_ago:
                    self.requests_in_last_second.pop(0)
                else:
                    break

            # now we know how many requests are left within the rate limit
            requests_left = self.rate_limit - len(self.requests_in_last_second)

            if requests_left and self.waiters.index(current_thread()) < requests_left:

                # the first few requests in FIFO order should fit, so whether we are at
                # the head of the line or not, proceed
                self.waiters.remove(current_thread())
                self.requests_in_last_second.append(now)
                self.rate_limit_condition.release()

                if first_timestamp != now:
                    # this wasn't the first time through the loop, so call the callback
                    delay = time.time() - first_timestamp
                    logger.log(LOGGING_LEVEL_DEBUG, 'Under rate limit of {} TPS for {} {} by delaying {:.3f}s, {} requests left'.format(self.rate_limit, self.method, request.get_path(), delay, requests_left-1))
                    if rate_limit_callback:
                        rate_limit_callback(request, self, delay)

                return

            # the rate limit has been exceeded for this second. Indicate that we are blocking
            # and wait for a timeout for when we expect more capacity to be available
            if self.requests_in_last_second:
                earliest_wakeup_time = self.requests_in_last_second[0] + 1.0
            else:
                earliest_wakeup_time = now + .001
            wait_time = earliest_wakeup_time - now
            logger.log(LOGGING_LEVEL_DEBUG, 'Exceeded rate limit of {} TPS for {} {}, waiting at least {:.3f}s'.format(self.rate_limit, self.method, request.get_path(), wait_time))
            while wait_time >= 0.0:
                self.rate_limit_condition.wait(wait_time)
                now = time.time()
                wait_time = earliest_wakeup_time - now

            # now that we've waited long enough for (probably) the first request to expire, go back
            # to the beginning of the loop and re-evaluate

        assert(False) # should not get here

    def matches(self, method, endpoint):
        if method != self.method:
            return False

        m = self.endpoint_re.match(endpoint)
        if m is not None:
            return True
        else:
            return False

    def __eq__(self, other):
        if type(self) == type(other) and vars(self) == vars(other):
            return True
        return False

    def __getstate__(self):
        return {
            "method": self.method,
            "endpoint_re": self.endpoint_re,
            "rate_limit": self.rate_limit
        }

    def __setstate__(self, state):
        self.__dict__.update(state)

        # these fields cannot be serialized
        self.rate_limit_condition = Condition()
        self.requests_in_last_second = []
        self.waiters = []

    def __repr__(self):
        return u'<RateLimitPolicyRule for {} {}, {} transactions per second>'.format(
            self.method,
            self.endpoint_re,
            self.rate_limit
        )
