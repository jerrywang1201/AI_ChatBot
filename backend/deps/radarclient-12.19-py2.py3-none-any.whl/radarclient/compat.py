#!/usr/bin/env python

from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import sys
import unittest
import json

def _package_resource_bytes_using_deprecated_pkg_resources(path):
    import pkg_resources
    return pkg_resources.resource_string('radarclient', path)


PY2 = False
try:
    import urllib2
    import urllib
    import httplib
    import cookielib
    import urlparse
    import StringIO
    import Queue

    urllib_urlparse = urlparse.urlparse
    urllib_parse_qs = urlparse.parse_qs
    urllib_url_quote = urllib.quote
    urllib_urlencode = urllib.urlencode
    urllib_ProxyHandler = urllib2.ProxyHandler
    urllib_build_opener = urllib2.build_opener
    urllib_install_opener = urllib2.install_opener
    urllib_Request = urllib2.Request
    urllib_version = urllib2.__version__
    urllib_URLError = urllib2.URLError
    urllib_HTTPError = urllib2.HTTPError
    urllib_HTTPErrorProcessor = urllib2.HTTPErrorProcessor
    urllib_HTTPCookieProcessor = urllib2.HTTPCookieProcessor
    urllib_HTTPSHandler = urllib2.HTTPSHandler
    cookie_CookieJar = cookielib.CookieJar
    http_FORBIDDEN = httplib.FORBIDDEN
    http_NOT_FOUND = httplib.NOT_FOUND
    http_IncompleteRead = httplib.IncompleteRead
    http_RemoteDisconnected = None
    builtins_ConnectionError = None
    builtins_BrokenPipeError = None
    builtins_ConnectionAbortedError = None
    builtins_ConnectionRefusedError = None
    builtins_ConnectionResetError = None
    builtins_TimeoutError = None
    StringIO = StringIO.StringIO
    unicode_string_type = unicode
    test_assertRegex = unittest.TestCase.assertRegexpMatches
    test_assertRaisesRegex = unittest.TestCase.assertRaisesRegexp
    string_types = basestring
    urlopen = urllib2.urlopen
    open_flags_read_unified_line_endings = 'rU'
    queue_module = Queue

    def package_resource_bytes(path):
        return _package_resource_bytes_using_deprecated_pkg_resources(path)

    def unicode_string_for_argument_string(argument_string):
        return argument_string.decode('utf-8')
    
    def unicode_string_for_stringio_value(string_io):
        return string_io.getvalue().decode('utf-8')

    def file_output_representation_for_unicode_string(string):
        if isinstance(string, unicode):
            string = string.encode('utf-8')
        return string

    def print_unicode_string(string, file=sys.stdout):
        print(string.encode('utf-8'), file=file)
    
    def string_representation_for_exception(e):
        return unicode(str(e), encoding='utf-8')
    
    def json_loads(data):
        return json.loads(data, encoding='utf-8')
    
    def selector_for_request(request):
        return request.get_selector()
    
    def log_exception(logger, exception):
        # For Python 2 we have to do it this way to handle UnicodeDecodeErrors when the server message contains non-ASCII characters
        logger.error('Exception occurred: {!r}'.format(exception))

    PY2 = True

except ImportError:
    import builtins
    import urllib.request
    import urllib.error
    import urllib.parse
    import http.client
    import http.cookiejar
    import io
    import queue

    urllib_urlparse = urllib.parse.urlparse
    urllib_parse_qs = urllib.parse.parse_qs
    urllib_url_quote = urllib.parse.quote
    urllib_urlencode = urllib.parse.urlencode
    urllib_ProxyHandler = urllib.request.ProxyHandler
    urllib_build_opener = urllib.request.build_opener
    urllib_install_opener = urllib.request.install_opener
    urllib_Request = urllib.request.Request
    urllib_version = urllib.request.__version__
    urllib_URLError = urllib.error.URLError
    urllib_HTTPError = urllib.error.HTTPError
    urllib_HTTPErrorProcessor = urllib.request.HTTPErrorProcessor
    urllib_HTTPCookieProcessor = urllib.request.HTTPCookieProcessor
    urllib_HTTPSHandler = urllib.request.HTTPSHandler
    cookie_CookieJar = http.cookiejar.CookieJar
    http_FORBIDDEN = http.client.FORBIDDEN
    http_NOT_FOUND = http.client.NOT_FOUND
    http_IncompleteRead = http.client.IncompleteRead
    http_RemoteDisconnected = http.client.RemoteDisconnected
    builtins_ConnectionError = ConnectionError
    builtins_BrokenPipeError = BrokenPipeError
    builtins_ConnectionAbortedError = ConnectionAbortedError
    builtins_ConnectionRefusedError = ConnectionRefusedError
    builtins_ConnectionResetError = ConnectionResetError
    builtins_TimeoutError = TimeoutError
    StringIO = io.StringIO
    unicode_string_type = str
    test_assertRegex = unittest.TestCase.assertRegex
    test_assertRaisesRegex = unittest.TestCase.assertRaisesRegex
    string_types = str
    urlopen = urllib.request.urlopen
    open_flags_read_unified_line_endings = 'r'
    queue_module = queue

    def package_resource_bytes(path):
        if sys.version_info[0] == 3 and sys.version_info[1] < 9:
            return _package_resource_bytes_using_deprecated_pkg_resources(path)

        import importlib.resources
        ref = importlib.resources.files('radarclient').joinpath(path)
        assert ref
        data = ref.read_bytes()
        assert len(data) > 0
        return data

    def unicode_string_for_argument_string(argument_string):
        return argument_string

    def unicode_string_for_stringio_value(string_io):
        return string_io.getvalue()

    def file_output_representation_for_unicode_string(string):
        return string

    def print_unicode_string(string, file=sys.stdout):
        print(string, file=file)

    def string_representation_for_exception(e):
        return e

    def json_loads(data):
        return json.loads(data)

    def selector_for_request(request):
        return request.selector

    def log_exception(logger, exception):
        logger.exception(exception)


def repr_from_unicode(f):
    if PY2:
        def generated_repr(self):
            return unicode(self).encode('utf-8', 'replace')
    else:
        def generated_repr(self):
            return self.__unicode__()

    return generated_repr

def write_unicode_string_to_file(file_object, string):
    file_object.write(file_output_representation_for_unicode_string(string))
