from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import re
import radarclient.compat as compat


class NoActiveAppleConnectException(Exception):
    pass


class SPNegoUnavailableException(Exception):
    pass


class AppleConnectUnavailableException(Exception):
    pass

class AuthenticationError(Exception):
    pass

class UnsuccessfulResponseException(Exception):
    """
    This exception subclass contains information about a failed request to the Radar web API.

    :param int code: The HTTP status code
    :param str reason: The HTTP status message, or alternatively a status/error message from a JSON response payload, or the raw binary response payload
    :param str message: The exception message

    """

    def __init__(self, code, reason, message):
        super(UnsuccessfulResponseException, self).__init__(compat.file_output_representation_for_unicode_string(message))
        self.code = code
        self.reason = reason
        self.message = message

    def __reduce__(self):
        return (UnsuccessfulResponseException, (self.code, self.reason, self.message))


class CorruptedResponseException(UnsuccessfulResponseException):
    """
    This exception subclass represents a Radar web API response that is corrupted
    because it does not match the documentation and/or normal behavior.

    """
    pass


class RadarAccessDeniedResponseException(UnsuccessfulResponseException):
    """
    This class specializes :py:class:`UnsuccessfulResponseException` for the
    case where the response represents an access denied response. It provides
    a convenience method to access the component owner e-mail address that is
    embedded in the reason string.

    """

    def component_owner_information(self):
        """
        Returns a two-item tuple with the toplevel component owner contact information contained in the reason string:

        - full name
        - e-mail address

        Returns None if the information could not be parsed out of the response string.

        """

        matches = re.findall(r'Component Owner - (.+) \((.+)\)', self.reason)
        if matches:
            return matches[0]
        else:
            return None


class ClosedComponentNoFollowOnException(UnsuccessfulResponseException):
    """
    This class specializes :py:class:`UnsuccessfulResponseException` for
    Radar creation requests that failed because the specified component was
    closed without a follow-on component.
    """
    pass


class ObjectNotFoundException(UnsuccessfulResponseException):
    """
    This class specializes :py:class:`UnsuccessfulResponseException` for
    read requests that failed because the requested object was not found
    in the Radar database.
    """
    pass


class AttachmentLockedException(UnsuccessfulResponseException):
    """
    This class specializes :py:class:`UnsuccessfulResponseException` for
    Radar attachments that are locked by the system for security reasons,
    and thus unable to be downloaded.
    """
    pass


class MaximumSendAttemptsExceededException(UnsuccessfulResponseException):
    """
    This class specializes :py:class:`UnsuccessfulResponseException` for
    Radar API requests that failed after the maximum number of retry attempts.
    """

    def __init__(self, status_code, reason):
        message = 'Failed on the final retry attempt with status {}: {}'.format(status_code, reason)
        super(MaximumSendAttemptsExceededException, self).__init__(
            status_code,
            reason,
            compat.file_output_representation_for_unicode_string(message)
        )


class NetworkErrorMaximumAttemptsExceededException(Exception):
    """
    This class represents transient networking errors encountered while sending requests to the Radar API, in the
    intermediary layers (socket, urllib, ssl, http.client, etc.), after the maximum number of retry attempts.
    """
    pass


class ComponentNotFoundException(ObjectNotFoundException):
    """
    This class specializes :py:class:`ObjectNotFoundException` for
    Radar creation requests that failed because the specified component
    was not found.
    """
    pass


class KeyValuePairNotFoundException(ObjectNotFoundException):
    """
    This class specializes :py:class:`ObjectNotFoundException` for
    Key-Value Pair requests that failed because the specified Key-Value Pair
    was not found.
    """
    pass


class KeyValuePairAlreadyExistsException(UnsuccessfulResponseException):
    """
    This Exception will be raised when attempting to add a Key-Value Pair that already exists.
    """
    pass
    # def __init__(self, key_name):
    #     message = "A Key-Value Pair with name {} already exists.".format(key_name)
    #     super(KeyValuePairAlreadyExistsException, self).__init__(message)


class KeyValuePairNotSupportedException(Exception):
    """
    This Exception will be raised when attempting to utilize Key-Value Pair functionality for a class that
    does not support it.
    """
    pass


class NoAPIException(Exception):
    """
    Exception to raise when the Radar API does not support the request

    :param str radar_info: radar info, preferably with link
    """

    def __init__(self, radar_info):
        message = 'This is not currently possible with the Radar API. Tracking radar is {}'.format(
            radar_info)
        super(NoAPIException, self).__init__(message)


class DeprecatedMethodException(Exception):
    """
    Exception to raise when a radarclient function/method is deprecated and cannot be wrapped to a new function/method
    with 1:1 equivalence, and the deprecated code is completely non-functional. Used in conjunction with the
    ``@deprecated_and_removed`` decorator.

    :param str message: The message referencing the suggested replacement method and the radarclient version it became
        effective.
    """
    def __init__(self, message):
        super(DeprecatedMethodException, self).__init__(message)


class UpdateByIDLookUpError(Exception):
    """
    Exception to use when a user provides a value for an item like test geography that doesn't match any value from
    the server
    """
    def __init__(self, message):
        super(UpdateByIDLookUpError, self).__init__(message)


class ReorderDuplicatePlacementException(Exception):
    pass


class IncompatibleFieldsRequestException(Exception):
    pass


class BulkTestSuiteSchedulingException(Exception):
    pass


class APIJobException(Exception):
    pass


class APIJobErrorException(APIJobException):
    def __init__(self, message, errors):
        super(APIJobErrorException, self).__init__(message)
        self.errors = errors


class APIJobTimeoutException(APIJobException):
    pass


class UnsuccessfulRadarJobException(APIJobException):
    pass
