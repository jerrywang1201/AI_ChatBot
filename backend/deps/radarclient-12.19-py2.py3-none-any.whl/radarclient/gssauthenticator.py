#!/usr/bin/env python

# Based on the implementation in the NUCore framework in NUCAuthenticator+SPNEGO.m
# https://github.pie.apple.com/innersource/nucore/blob/main/OSX/NUCore/Classes/NUCAuthenticator/NUCAuthenticator%2BSPNEGO.m


from __future__ import print_function
from __future__ import unicode_literals

import ctypes
import base64
import contextlib
from .utilities import logger

class GssNameWrapper(object):

    def __init__(self, gss):
        self.gss = gss
        self.name = ctypes.c_void_p()

    def ref(self):
        return ctypes.byref(self.name)

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        if self.name.value:
            minor_status = ctypes.c_uint32()
            self.gss.gss_release_name(ctypes.byref(minor_status), self.ref())


class GssCredentialWrapper(object):

    def __init__(self, gss):
        self.gss = gss
        self.credential = ctypes.c_void_p()

    def ref(self):
        return ctypes.byref(self.credential)

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        if self.credential.value:
            minor_status = ctypes.c_uint32()
            self.gss.gss_release_cred(ctypes.byref(minor_status), self.ref())


class GssBufferDescOut(ctypes.Structure):
    _fields_ = [("length", ctypes.c_size_t),
                ("value", ctypes.POINTER(ctypes.c_char))]


class GssBufferDesc(ctypes.Structure):
    _fields_ = [("length", ctypes.c_size_t),
                ("value", ctypes.c_char_p)]

    @classmethod
    def buffer_for_bytes(cls, value):
        return cls(len(value), value)


class Token(object):

    def __init__(self, value):
        self._base64_value = base64.b64encode(value)

    def base64_value(self):
        return self._base64_value


class GSSAuthenticator(object):

    GSS_S_COMPLETE = 0
    GSS_C_NO_OID = 0
    GSS_C_NO_OID_SET = 0
    GSS_C_INITIATE = 1
    GSS_C_NO_CONTEXT = 0
    GSS_C_INDEFINITE = 0xffffffff
    GSS_C_NO_CHANNEL_BINDINGS = None
    GSS_C_NO_BUFFER = None

    _cached_gss_handle = None
    _did_check_gss_library = False

    def __init__(self, username, realm):
        self.username = username
        self.realm = realm
        self.gss = self.gss_library_handle()
        self.token = None

    @classmethod
    def gss_library_handle(cls):
        """
        Find the appropriate Kerberos library to authenticate with. For example, the Heimdal Kerberos library as used in
        `/examples/heimdal-docker`.
        """
        if not cls._did_check_gss_library:
            cls._did_check_gss_library = True
            libraries = [
                "/System/Library/Frameworks/GSS.framework/Versions/A/GSS",
                "/usr/heimdal/lib/libgssapi.so.3",
                "libgssapi_krb5.so.2",
                "libgssapi.so.3",
            ]
            for library_path in libraries:
                try:
                    cls._cached_gss_handle = ctypes.cdll.LoadLibrary(library_path)
                    logger.debug('Found GSS API at {}'.format(library_path))
                    break
                except:
                    pass
        return cls._cached_gss_handle

    @classmethod
    def gss_is_available(cls):
        return cls.gss_library_handle() is not None

    def attach_token_to_request(self, request):
        base64_token = self.base64_token_value(self.host_from_request(request))
        if not base64_token:
            raise Exception('Unable to acquire token. Check your Kerberos session.')
        request.add_header('Authorization', 'Negotiate ' + base64_token.decode('utf-8'))

    @classmethod
    def host_from_request(cls, request):
        try:
            return request.get_host()
        except:
            return request.host

    def base64_token_value(self, host):
        self.token = self.spnego_token_for_host(host)
        if not self.token:
            logger.error('Failed to acquire SPNego token')
            return None
        return self.token.base64_value()

    def principal(self):
        return '{}@{}'.format(self.username, self.realm)

    def spnego_token_for_host(self, host):
        assert host
        attempts = 0
        while attempts < 2:
            attempts += 1

            if attempts > 1:
                logger.warning('Repeated attempt to acquire token')

            with self.acquire_credential() as credential_wrapper:
                if not credential_wrapper:
                    return None

                context_name_buffer = GssBufferDesc.buffer_for_bytes(u'HTTP/{}@{}'.format(host, self.realm).encode('utf-8'))
                with GssNameWrapper(self.gss) as context_name_wrapper:
                    minor_status = ctypes.c_uint32()
                    major_status = self.gss.gss_import_name(ctypes.byref(minor_status),
                                                            ctypes.byref(context_name_buffer),
                                                            self.GSS_C_NO_OID,
                                                            context_name_wrapper.ref())

                    if major_status != self.GSS_S_COMPLETE:
                        logger.error('Failed to import name: {}/{}'.format(major_status, minor_status))
                        continue

                    ctx = ctypes.c_void_p()
                    token_out_buffer = GssBufferDescOut()
                    major_status = self.gss.gss_init_sec_context(ctypes.byref(minor_status),
                                                                credential_wrapper.credential,
                                                                ctypes.byref(ctx),
                                                                context_name_wrapper.name,
                                                                self.GSS_C_NO_OID,
                                                                0,
                                                                self.GSS_C_INDEFINITE,
                                                                self.GSS_C_NO_CHANNEL_BINDINGS,
                                                                self.GSS_C_NO_BUFFER,
                                                                None,
                                                                ctypes.byref(token_out_buffer),
                                                                None,
                                                                None)

                    if major_status != self.GSS_S_COMPLETE:
                        logger.error('Failed to acquire token: {}/{}'.format(major_status, minor_status))
                        continue

                    token_data = token_out_buffer.value[:token_out_buffer.length]
                    if not (token_data):
                        logger.error('Failed to acquire token, no token data')

                    major_status = self.gss.gss_release_buffer(ctypes.byref(minor_status), ctypes.byref(token_out_buffer))
                    if major_status != self.GSS_S_COMPLETE:
                        logger.error('Failed to release buffer: {}/{}'.format(major_status, minor_status))

                    major_status = self.gss.gss_delete_sec_context(ctypes.byref(minor_status), ctypes.byref(ctx), self.GSS_C_NO_BUFFER)
                    if major_status != self.GSS_S_COMPLETE:
                        logger.error('Failed to delete sec context: {}/{}'.format(major_status, minor_status))

                    return Token(token_data)

        return None

    @contextlib.contextmanager
    def acquire_credential(self):
        principal_name_buffer = GssBufferDesc.buffer_for_bytes(self.principal().encode('utf-8'))
        minor_status = ctypes.c_uint32()
        with GssNameWrapper(self.gss) as name_wrapper:
            major_status = self.gss.gss_import_name(ctypes.byref(minor_status),
                                     ctypes.byref(principal_name_buffer),
                                     self.GSS_C_NO_OID,
                                     name_wrapper.ref())

            if major_status != self.GSS_S_COMPLETE:
                logger.error('Failed to import name: {}/{}'.format(major_status, minor_status))
                return

            with GssCredentialWrapper(self.gss) as cred:
                major_status = self.gss.gss_acquire_cred(
                    ctypes.byref(minor_status),
                    name_wrapper.name,
                    self.GSS_C_INDEFINITE,
                    self.GSS_C_NO_OID_SET,
                    self.GSS_C_INITIATE,
                    cred.ref(),
                    None,
                    None
                )

                if major_status == self.GSS_S_COMPLETE:
                    yield cred
                else:
                    logger.error('Failed to acquire credentials: {}/{}'.format(major_status, minor_status))