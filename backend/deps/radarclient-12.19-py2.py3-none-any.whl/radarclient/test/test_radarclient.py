#!/usr/bin/env python


from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import

import os
import sys
import unittest
import inspect
import time
import hashlib
import math
import json
import pickle
import logging
import contextlib
import datetime
import ssl
import random

from copy import deepcopy
from types import GeneratorType
from functools import partial, wraps
from multiprocessing import Process, Value
from threading import Lock
from unittest.case import expectedFailure

from radarclient import directory
from radarclient import http_request_utilities
from radarclient import authenticationstrategy
from radarclient.model import *
import radarclient.gssauthenticator
from radarclient import compat

# The imports here are done this way to check for backwards
# compatibility after the older auth strategies were all moved into
# the separate authenticationstrategy.py file.
from radarclient.client import RadarClient, AuthenticationStrategyWebCookie, AuthenticationStrategyOIDC, \
    AuthenticationStrategySPNego, AuthenticationStrategyAppToApp, ModifyRadarsJob, ClientSystemIdentifier, ModifyTestCasesJob, \
    ModifyTestSuitesJob, ModifyScheduledTestsJob, ModifyScheduledTestCasesJob

from radarclient.test import testing_utils
from radarclient.utilities import RadarProtocolVersion, wait_for_multithreaded_completion_helper, logger as \
    library_logger
from radarclient.retrypolicy import RetryPolicy, RetryScheme
from radarclient.ratelimitpolicy import RateLimitPolicy, RateLimitPolicyRule
from radarclient.exceptions import UnsuccessfulResponseException, MaximumSendAttemptsExceededException, \
    RadarAccessDeniedResponseException, KeyValuePairNotFoundException, KeyValuePairAlreadyExistsException, \
    KeyValuePairNotSupportedException, APIJobErrorException, APIJobTimeoutException, AttachmentLockedException
from radarclient.decorators import cached_class_property

ISOLATED_TESTS = None

ENABLE_SPNEGO = True

# # UAT test accounts credentials from <rdar://problem/11904229> Radar UAT : shared accounts distribution
# UAT_ACCOUNT_USERNAME = 'radardev_tester'
# UAT_ACCOUNT_EMAIL = 'radardev_tester@apple.com'
# UAT_ACCOUNT_PASSWORD_URL = 'https://locker-uat.radar.apple.com/api/password/' + UAT_ACCOUNT_USERNAME
# try:
#     data = radarclient.compat.urlopen(UAT_ACCOUNT_PASSWORD_URL)
#     UAT_ACCOUNT_PASSWORD = json.loads(data.read())['password']
# #    print UAT_ACCOUNT_PASSWORD
# except Exception as e:
#     print('Will skip UAT tests: Unable to read UAT test user password from {}: "{}"'.format(UAT_ACCOUNT_PASSWORD_URL, e), file=sys.stderr)
#     UAT_ACCOUNT_PASSWORD = None
#     #sys.exit(0)

UAT_ACCOUNT_PASSWORD = None

def attempts_with_increasing_delay(max_attempts=5):
    delay_seconds = 1
    attempt = 0
    while True:
        attempt += 1
        if attempt > max_attempts:
            raise Exception('Exceeded max number of attempts {}'.format(max_attempts))
        if attempt > 1:
            print('\nRetrying after {:2.1f}s, attempt {} of {}'.format(delay_seconds, attempt, max_attempts), file=sys.stderr)
        is_final_attempt = attempt == max_attempts
        yield is_final_attempt, attempt, delay_seconds
        time.sleep(delay_seconds)
        delay_seconds *= 1.5


def queue_to_set(q, sentinel=None):
    to_return = set()
    result_item = q.get()
    while result_item != sentinel:
        to_return.add(result_item)
        result_item = q.get()
    return to_return


class TestConfiguration(object):

    _cachedSharedInstance = None

    def __init__(self):
        self.configuration = {}
        key = 'RADARCLIENT_UNITTEST_OVERRIDE_CONFIG_PATH'
        if key in os.environ:
            path = os.environ[key]
            if not os.path.exists(path):
                raise Exception('Unit test configuration file from environment variable "{}" does not exist at path "{}"'.format(key, path))
            with open(path, 'r') as f:
                self.configuration = json.load(f)
            logging.warn('Overriding unit test configuration values with data from "{}" because "{}" environment variable is set'.format(path, key))

    @classmethod
    def default_values(cls):
        return {
            'default_component_name_version': {'name': 'python-radarclient-test bugs', 'version': '1.0'},
            'default_component_id': {'id': 515346},
            'default_keywords': [
                {'id': 196144, 'name': 'radarclient-python test'},
                {'id': 514505, 'name': 'radarclient-python test 2'}
            ]
        }

    @classmethod
    def default_components(cls):
        for component_config_key in ['default_component_name_version', 'default_component_id']:
            yield cls.value(component_config_key)

    def configuration_value(self, key):
        if key in self.configuration:
            return self.configuration[key]
        default_values = self.default_values()
        if key in default_values:
            return default_values[key]
        raise Exception('Unknown unit test configuration key "{}"'.format(key))

    @classmethod
    def value(cls, key):
        if not cls._cachedSharedInstance:
            cls._cachedSharedInstance = cls()
        return cls._cachedSharedInstance.configuration_value(key)


class BenchmarkWrapper(object):

    def __init__(self, label, count=10):
        assert count > 0
        self.count = count
        self.label = label

    def __iter__(self):
        measurements = []
        for i in range(1, self.count + 1):
            t1 = datetime.datetime.now()
            yield i
            t2 = datetime.datetime.now()
            s = (t2 - t1).total_seconds()
            measurements.append(s)
            print('{} {}: {:0.3f}s'.format(self.label, i, s))

        measurements_sum = sum(measurements)
        avg = measurements_sum / self.count
        print('{} average ({:0.3f}/{}): {:0.3f}s'.format(self.label, measurements_sum, self.count, avg))


# from http://www.johndcook.com/standard_deviation.html
class RunningStats(object):

    def __init__(self):
        self.n = 0
        self.old_m = 0
        self.new_m = 0
        self.old_s = 0
        self.new_s = 0

    def clear(self):
        self.n = 0

    def push(self, x):
        self.n += 1

        if self.n == 1:
            self.old_m = self.new_m = x
            self.old_s = 0
        else:
            self.new_m = self.old_m + (x - self.old_m) / self.n
            self.new_s = self.old_s + (x - self.old_m) * (x - self.new_m)

            self.old_m = self.new_m
            self.old_s = self.new_s

    def mean(self):
        return self.new_m if self.n else 0.0

    def variance(self):
        return self.new_s / (self.n - 1) if self.n > 1 else 0.0

    def standard_deviation(self):
        return math.sqrt(self.variance())

class ThreadsafeRetryCallback(object):
    def __init__(self):
        self.lock = Lock()
        self.count = 0
        self.accum_delay = 0.0

    def __call__(self, request, e, scheme, delay):
        logging.info('Retry will be used for {} {} due to {}, delaying by {:.3f} second(s)'.format(request.method, request.get_path(), getattr(e, 'code', e.args), delay))
        self.lock.acquire()
        self.count += 1
        self.accum_delay += delay
        self.lock.release()

    def retry_count(self):
        self.lock.acquire()
        count = self.count
        self.lock.release()
        return count

class ThreadsafeRateLimitCallback(object):
    def __init__(self):
        self.lock = Lock()
        self.count = 0
        self.accum_delay = 0.0

    def __call__(self, request, rule, delay):
        logging.info('Radar API rate limit avoided by delaying %s %s by %.3f second(s)', request.method, request.get_path(), delay)
        self.lock.acquire()
        self.count += 1
        self.accum_delay += delay
        self.lock.release()

    def rate_limit_wait_count(self):
        self.lock.acquire()
        count = self.count
        self.lock.release()
        return count

class TestCachedClassPropertyClassA(object):
    @cached_class_property
    def ccp(cls):
        return ["TestCachedClassPropertyClassA"]

class TestCachedClassPropertyClassB(TestCachedClassPropertyClassA):
    @cached_class_property
    def ccp(cls):
        return super(TestCachedClassPropertyClassB, cls).ccp + ["TestCachedClassPropertyClassB"]

class TestCachedClassPropertyClassC(TestCachedClassPropertyClassB):
    pass

class TestRadarClientCompat(unittest.TestCase):

    def test_url_quote(self):
        self.assertEqual(radarclient.compat.urllib_url_quote('f oo'), 'f%20oo')


class TestRadarClient(unittest.TestCase):
    FILE_DOWNLOAD_DIR = os.path.join(os.getcwd(), 'generated')

    def skip_unless_enabled(f):
        if not ISOLATED_TESTS or f.__name__ in set(ISOLATED_TESTS.split()):
            return f
        return unittest.skip('test is not in isolated set')(f)

    def skip_if_not_marc(self):
        if getattr(self, 'cached_user_email', None) is None:
            self.cached_user_email = self.client.current_user().email
        if self.cached_user_email != 'liyanage@apple.com':
            self.skipTest('Need more permissions to run')

    def skip_if_api_v2_2(self, related_radar_id=None):
        if self.client.protocol_version == RadarProtocolVersion('2.2'):
            if related_radar_id:
                self.skipTest('Not supported on Radar API v2.2 due to rdar://{}'.format(related_radar_id))
            else:
                self.skipTest('Not supported on Radar API v2.2')

    def skip_if_app_to_app_env_vars_are_missing(f):
        required_env_params = [os.getenv('APP_TO_APP_AUTH_APP_ID', None), os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', None), os.getenv('APP_TO_APP_AUTH_APP_CONTEXT', None)]
        if None in required_env_params:
            return unittest.skip('skip: test needs APP_TO_APP_AUTH_APP_ID and APP_TO_APP_AUTH_APP_PASSWORD and APP_TO_APP_AUTH_APP_CONTEXT env values')(f)
        return f

    def user_is_marc(self):
        user = self.client.current_user()
        return user.dsid == 299156498

    @contextlib.contextmanager
    def client_protocol_version(self, version):
        old_version = self.client.protocol_version
        self.client.protocol_version = RadarProtocolVersion(version)
        try:
            yield
        finally:
            self.client.protocol_version = old_version

    @classmethod
    def authentication_strategy_webcookie(cls):
        cls.check_appleconnect_environment_variables()
        return AuthenticationStrategyWebCookie(os.environ['APPLECONNECT_USERNAME'], os.environ['APPLECONNECT_PASSWORD'], request_timeout=300)

    @classmethod
    def authentication_strategy_oidc(cls):
        return AuthenticationStrategyOIDC(client_id=os.environ['RADARCLIENT_UNIT_TEST_OIDC_CLIENT_ID'], client_secret=os.environ['RADARCLIENT_UNIT_TEST_OIDC_CLIENT_SECRET'],
                                          radar_environment=radarclient.RadarEnvironment('uat-alt'), request_timeout=300)

    @classmethod
    def authentication_strategy_spnego(cls):
        return AuthenticationStrategySPNego()

    @classmethod
    def system_identifier(cls):
        return radarclient.ClientSystemIdentifier('python-radarclient-unittest', radarclient.__version__)

    @classmethod
    def authenticated_radar_client_webcookie(cls):
        return RadarClient(
            cls.authentication_strategy_webcookie(),
            cls.system_identifier(),
            retry_policy=RetryPolicy(),
            rate_limit_policy=RateLimitPolicy()
        )

    @classmethod
    def authenticated_radar_client_oidc(cls):
        return RadarClient(
            cls.authentication_strategy_oidc(),
            cls.system_identifier(),
            retry_policy=RetryPolicy(),
            rate_limit_policy=RateLimitPolicy()
        )

    @classmethod
    def authenticated_radar_client_spnego(cls):
        if 'RADARCLIENT_UNIT_TEST_PROTOCOL_VERSION_OVERRIDE' in os.environ:
            prot_ver = os.environ['RADARCLIENT_UNIT_TEST_PROTOCOL_VERSION_OVERRIDE']
            return RadarClient(
                cls.authentication_strategy_spnego(),
                cls.system_identifier(),
                protocol_version=prot_ver,
                retry_policy=RetryPolicy(),
                rate_limit_policy=RateLimitPolicy()
            )
        else:
            return RadarClient(
                cls.authentication_strategy_spnego(),
                cls.system_identifier(),
                retry_policy=RetryPolicy(),
                rate_limit_policy=RateLimitPolicy()
            )

    @classmethod
    def authenticated_radar_client_spnego_pre_release(cls):
        return RadarClient(cls.authentication_strategy_spnego(), cls.system_identifier(), protocol_version='pre-release')

    @classmethod
    def authenticated_radar_client_spnego_v2_2(cls):
        return RadarClient(cls.authentication_strategy_spnego(), cls.system_identifier(), protocol_version='2.2')

    @classmethod
    def authenticated_radar_client(cls):
        if AuthenticationStrategySPNego.available() and ENABLE_SPNEGO:
            return cls.authenticated_radar_client_spnego()
        else:
            if not (os.environ.get('APPLECONNECT_USERNAME') and os.environ.get('APPLECONNECT_PASSWORD')):
                print('Attempting to get AppleConnect credentials for web cookie authentication from keychain', file=sys.stderr)
                result = radarclient.radartool.KeychainPassword.find_generic_username_and_password(label='AppleConnect')
                if result:
                    os.environ['APPLECONNECT_USERNAME'], os.environ['APPLECONNECT_PASSWORD'] = result

            return cls.authenticated_radar_client_webcookie()

    @classmethod
    def setUpClass(cls):
        cls.maxDiff = None
        cls.client = cls.authenticated_radar_client()

        if not os.path.exists(cls.FILE_DOWNLOAD_DIR):
            os.mkdir(cls.FILE_DOWNLOAD_DIR)

        os.environ['RADARCLIENT_SUPPRESS_DRY_RUN_OUTPUT'] = '1'
        os.environ['RADARCLIENT_SUPPRESS_DEPRECATION_WARNINGS'] = '1'

    @classmethod
    def tearDownClass(cls):
        del os.environ['RADARCLIENT_SUPPRESS_DRY_RUN_OUTPUT']
        del os.environ['RADARCLIENT_SUPPRESS_DEPRECATION_WARNINGS']

    def tearDown(self):
        for filename in os.listdir(self.FILE_DOWNLOAD_DIR):
            os.unlink(os.path.join(self.FILE_DOWNLOAD_DIR, filename))

    def validate_test_case_order(self, suite_id, expected_order):
        test_suite = self.client.test_suite_for_id(suite_id, additional_fields=['associatedTests'])
        new_case_order = [case.database_id_attribute_value() for case in test_suite.cases]
        self.assertListEqual(
            expected_order,
            new_case_order,
            'Cases are not in expected order'
        )

    def base_tstt_item_attachment_test(self, test_item):
        """
        Performs various attachment tests on DictionaryBasedTSTTModel objects that attach files
        via change tracking

        :param DictionaryBasedTSTTModel test_item: item to test
        :return: None
        """
        test_item.load_attachments(self.client)
        expected_attachment_count = len(test_item.attachments)
        # Add an additional simple attribute change to make sure those continue to function
        test_title = 'Test Attachments Title {}'.format(time.time())
        test_item.title = test_title

        # Test upload via upload_content
        test_bytes = bytearray('123345', encoding='utf-8')
        test_name = 'test{}.txt'.format(datetime.datetime.now())
        new_attachment = test_item.add_attachment(test_name)
        new_attachment.set_upload_content(test_bytes)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)
        expected_attachment_count += 1

        # Verify attachment added
        test_item.load_attachments(self.client)
        self.assertEqual(
            len(test_item.attachments), expected_attachment_count, 'File count stayed the same '
                                                                   'after upload_content'
        )

        attach_2_name = 'fuji_test{}'.format(datetime.datetime.now())
        script_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        fuji_path = os.path.join(
            os.path.dirname(os.path.dirname(script_path)), 'extras/Mt. Fuji.jpg'
        )
        new_attachment_2 = test_item.add_attachment(attach_2_name)
        with open(fuji_path, 'rb') as tf:
            new_attachment_2.set_upload_file(tf)
            test_item.commit_changes(self.client)
        expected_attachment_count += 1

        test_item.load_attachments(self.client)
        self.assertEqual(
            len(test_item.attachments), expected_attachment_count,
            'File count stayed the same after set_upload_file test'
        )

        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
            overwrite_attachment = test_item.add_attachment(test_name, overwrite=False)
            overwrite_attachment.set_upload_content(test_bytes)
            test_item.commit_changes(self.client, dry_run=True)
            test_item.commit_changes(self.client)
        test_item.clear_change_records()

        overwrite_attachment = test_item.add_attachment(test_name, overwrite=True)
        overwrite_attachment.set_upload_content(test_bytes)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)

        test_item.load_attachments(self.client)
        self.assertEqual(
            len(test_item.attachments), expected_attachment_count,
            'File count changed after overwrite'
        )

        test_item.delete_attachment(new_attachment)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)
        expected_attachment_count -= 1

        # Verify attachment removed
        test_item.load_attachments(self.client)
        self.assertEqual(
            len(test_item.attachments), expected_attachment_count, 'File count stayed the same'
        )

        # Test upload file with upload_file
        test_name_2 = 'test_2{}'.format(datetime.datetime.now())
        upload_test_path = os.path.join(self.FILE_DOWNLOAD_DIR, test_name_2)
        with open(upload_test_path, 'wb') as f:
            f.write(os.urandom(20480))

        attachment_two = test_item.add_attachment(test_name_2)
        attachment_two.set_upload_file(open(upload_test_path, 'rb'))
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)
        expected_attachment_count += 1

        # Verify attachment added
        test_item.load_attachments(self.client)
        self.assertEqual(
            len(test_item.attachments), expected_attachment_count, 'File count stayed the same'
        )

        test_item.delete_attachment(attachment_two)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)
        expected_attachment_count -= 1

        # Verify attachment removed
        test_item.load_attachments(self.client)
        self.assertEqual(
            len(test_item.attachments), expected_attachment_count, 'File count stayed the same'
        )

        # Test download with content dump
        test_download_file = test_item.attachments[0]
        download_path = os.path.join(self.FILE_DOWNLOAD_DIR, test_download_file.fileName)
        with open(download_path, 'wb') as f:
            f.write(test_download_file.content(client=self.client))
        self.assertGreater(os.path.getsize(download_path), 0, 'Downloaded file has a 0 size')

        # Test download with write file
        test_download_file = test_item.attachments[0]
        download_path = os.path.join(self.FILE_DOWNLOAD_DIR, test_download_file.fileName)
        with open(download_path, 'wb') as f:
            test_download_file.write_to_file(f, client=self.client)
        self.assertGreater(os.path.getsize(download_path), 0, 'Downloaded file has a 0 size')

        # Test changing name of attachment
        test_item.load_attachments(self.client)
        new_name = 'Updated Name {}'.format(datetime.datetime.now())
        test_item.attachments[0].fileName = new_name
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)

        test_item.load_attachments(self.client)
        self.assertIn(
            new_name,
            (attachment.fileName for attachment in test_item.attachments),
            'Updated file name not found'
        )

        for attachment in test_item.attachments:
            test_item.delete_attachment(attachment)
        test_item.commit_changes(self.client)

        for is_final_attempt, attempt, delay_seconds in attempts_with_increasing_delay(6):
            try:
                test_item.load_attachments(self.client)
                self.assertEqual(0, len(test_item.attachments), 'Attachments remained after deleting all')
                break
            except AssertionError:
                if is_final_attempt:
                    raise

    def base_tstt_item_picture_test(self, test_item):
        test_item.load_pictures(self.client)
        expected_picture_count = len(test_item.pictures)
        # Test also changing a simple attribute at the same time
        test_item.title = 'Picture test title change {}'.format(time.time())

        # Test upload via upload_content
        single_pixel_image = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00' \
                             b'\x01\x01\x03\x00\x00\x00%\xdbV\xca\x00\x00\x00\x03PLTE\x00\x00\x00' \
                             b'\xa7z=\xda\x00\x00\x00\x01tRNS\x00@\xe6\xd8f\x00\x00\x00\nIDAT\x08' \
                             b'\xd7c`\x00\x00\x00\x02\x00\x01\xe2!\xbc3\x00\x00\x00\x00IEND\xaeB' \
                             b'`\x82'
        test_name = 'test{}.png'.format(datetime.datetime.now())
        new_picture = test_item.add_picture(test_name)
        new_picture.set_upload_content(single_pixel_image)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)
        expected_picture_count += 1

        # Verify picture added
        test_item.load_pictures(self.client)
        self.assertEqual(
            len(test_item.pictures), expected_picture_count, 'File count stayed the same after '
                                                             'upload_content test'
        )

        test_2_name = 'fuji_test{}.jpg'.format(datetime.datetime.now())
        script_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        fuji_path = os.path.join(
            os.path.dirname(os.path.dirname(script_path)), 'extras/Mt. Fuji.jpg'
        )
        new_pic_2 = test_item.add_picture(test_2_name)
        with open(fuji_path, 'rb') as tf:
            new_pic_2.set_upload_file(tf)
            test_item.commit_changes(self.client)
        expected_picture_count += 1

        self.assertEqual(
            len(test_item.pictures), expected_picture_count, 'File count stayed the same after '
                                                             'set_upload_file test'
        )

        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
            overwrite_pic = test_item.add_picture(test_name, overwrite=False)
            overwrite_pic.set_upload_content(single_pixel_image)
            test_item.commit_changes(self.client, dry_run=True)
            test_item.commit_changes(self.client)
        test_item.clear_change_records()

        overwrite_pic = test_item.add_picture(test_name, overwrite=True)
        overwrite_pic.set_upload_content(single_pixel_image)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)

        test_item.load_pictures(self.client)
        self.assertEqual(
            len(test_item.pictures), expected_picture_count, 'File count changed after overwrite'
        )

        test_item.delete_picture(new_picture)
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)
        expected_picture_count -= 1

        # Verify picture removed
        test_item.load_pictures(self.client)
        self.assertEqual(
            len(test_item.pictures), expected_picture_count, 'File count stayed the same after '
                                                             'delete test'
        )

        # Test download with content dump
        test_download_file = test_item.pictures[0]
        download_path = os.path.join(self.FILE_DOWNLOAD_DIR, test_download_file.fileName)
        with open(download_path, 'wb') as f:
            f.write(test_download_file.content(client=self.client))
        self.assertGreater(os.path.getsize(download_path), 0, 'Downloaded file has a 0 size')
        os.unlink(download_path)

        # Test download with write file
        test_download_file = test_item.pictures[0]
        download_path = os.path.join(self.FILE_DOWNLOAD_DIR, test_download_file.fileName)
        with open(download_path, 'wb') as f:
            test_download_file.write_to_file(f, client=self.client)
        self.assertGreater(os.path.getsize(download_path), 0, 'Downloaded file has a 0 size')

        # Test changing name of picture
        test_item.load_pictures(self.client)
        new_name = 'Updated Name {}.jpg'.format(datetime.datetime.now())
        test_item.pictures[0].fileName = new_name
        test_item.commit_changes(self.client, dry_run=True)
        test_item.commit_changes(self.client)

        test_item.load_pictures(self.client)
        self.assertIn(
            new_name,
            (picture.fileName for picture in test_item.pictures),
            'Updated file name not found'
        )

        for picture in test_item.pictures:
            test_item.delete_picture(picture)
        test_item.commit_changes(self.client)

        # Delay to avoid race condition
        time.sleep(5)
        test_item.load_pictures(self.client)
        self.assertEqual(0, len(test_item.pictures), 'After deleting all, pictures remain')

    @skip_unless_enabled
    def test_tstt_suite_attachment_loading(self):
        test_suite_id = 1548827
        sched_suite_id = 7490457
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        sched_test = self.client.scheduled_test_for_id(sched_suite_id, additional_fields=['cases'])

        # These tests use the load_associated_case_attachments_and_pictures function because
        # they just call the other functions. If that has changed and you are reading this,
        # please update the test
        test_suite.load_associated_case_attachments_and_pictures(self.client)
        sched_test.load_associated_case_attachments_and_pictures(self.client)

    @skip_unless_enabled
    def test_dictionary_based_model_merge_single_item(self):
        test_id = 7490457
        sched_test_1 = self.client.find_scheduled_tests(
            {'scheduledTestId': test_id}, limit=1, additional_fields=['percentOfCasesInStatus'],
            return_results_directly=True
        )[0]
        sched_test_2 = self.client.scheduled_test_for_id(test_id, additional_fields=['cases'])
        sched_test_1.merge(sched_test_2)
        self.assertTrue(hasattr(sched_test_1, 'percentOfCasesInStatus'))
        self.assertTrue(hasattr(sched_test_1, 'cases'))

        # Assert it raises if the type of object does not match
        with self.assertRaises(ValueError):
            sched_test_1.merge(sched_test_1.cases[0])

        # Assert it raises if type matches, but ID is different
        test_2 = self.client.scheduled_test_for_id(7411780)
        with self.assertRaises(ValueError):
            sched_test_1.merge(test_2)

    @skip_unless_enabled
    def test_dictionary_based_model_merge_lists(self):
        query = {'component': TestConfiguration.value('default_component_name_version')}
        found_tests = self.client.find_scheduled_tests(
            query, additional_fields=['percentOfCasesInStatus'], limit=10, return_results_directly=True
        )
        ids = [test.id for test in found_tests]
        by_id_tests = self.client.scheduled_tests_for_ids(ids, additional_fields=['cases'])

        fully_merged = ScheduledTest.merge_lists(by_id_tests, found_tests)
        self.assertTrue(fully_merged)
        for test in by_id_tests:
            self.assertTrue(hasattr(test, 'percentOfCasesInStatus'))
            self.assertTrue(hasattr(test, 'cases'))

    @skip_unless_enabled
    def test_scheduled_tstt_item_attachments_and_pictures(self):
        test_id = 6429552
        sched_test = self.client.scheduled_test_for_id(
            test_id, additional_fields=['cases']
        )
        print('Testing with {}'.format(sched_test))
        self.base_tstt_item_picture_test(sched_test)
        # TODO: Remove the shenanigans below once <rdar://problem/68994370> is resolved
        try:
            self.base_tstt_item_attachment_test(sched_test)
        except radarclient.exceptions.UnsuccessfulResponseException:
            logging.exception('File upload test failed for suite {}'.format(sched_test))
            test_id_2 = 7411780
            new_sched_test = self.client.scheduled_test_for_id(test_id_2)
            self.base_tstt_item_attachment_test(new_sched_test)

        case = sched_test.cases[0]
        print('Testing with {}'.format(case))
        self.base_tstt_item_picture_test(case)
        self.base_tstt_item_attachment_test(case)

    @skip_unless_enabled
    def test_base_tstt_item_attachments(self):
        suite_id = 1548817
        test_suite = self.client.test_suite_for_id(suite_id, additional_fields=['associatedTests', 'attachments'])

        print('Testing with {}'.format(test_suite))
        self.base_tstt_item_attachment_test(test_suite)

        case = test_suite.cases[0]
        print('Testing with {}'.format(case))
        self.base_tstt_item_attachment_test(case)

    @skip_unless_enabled
    def test_base_tstt_item_pictures(self):
        suite_id = 1548817
        test_suite = self.client.test_suite_for_id(suite_id, additional_fields=['associatedTests', 'pictures'])

        print('Testing with {}'.format(test_suite))
        self.base_tstt_item_picture_test(test_suite)

        case = test_suite.cases[0]
        print('Testing with {}'.format(case))
        self.base_tstt_item_picture_test(case)

    @skip_unless_enabled
    def test_load_test_suite_with_attachments_and_pictures(self):
        test_id = 2516648
        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['attachments', 'pictures'])

    @skip_unless_enabled
    def test_running_stats(self):
        rs = RunningStats()
        rs.push(17)
        rs.push(19)
        rs.push(24)

        self.assertEqual(rs.mean(), 20)
        self.assertEqual(rs.variance(), 13)
        self.assertEqual(rs.standard_deviation(), 3.605551275463989)

    @skip_unless_enabled
    def test_webservice_urls(self):
        url = radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url')
        expected = '{}/problems/11725080'.format(url)
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(radar.id, 11725080)
        self.assertEqual(radar.webservice_url(), expected)
        self.assertEqual(radarclient.model.DescriptionEntry.webservice_url_for_radar(radar), expected + '/description')
        self.assertEqual(
            radarclient.model.DiagnosisEntry.webservice_url_for_radar(radar, type='user'), expected + '/diagnosis/user')
        self.assertEqual(radarclient.model.DiagnosisEntry.webservice_url_for_radar(radar), expected + '/diagnosis/all')
        self.assertEqual(
            radarclient.model.DiagnosisEntry.webservice_url_for_radar(radar, type='user'), expected + '/diagnosis/user')
        self.assertEqual(
            radarclient.model.DiagnosisEntry.webservice_url_for_radar(radar, type='all'), expected + '/diagnosis/all')
        self.assertEqual(
            radarclient.model.DiagnosisEntry.webservice_url_for_radar(radar, type='history'), expected + '/diagnosis/history')

    @unittest.skip('Long-running benchmark, enable when needed')
    @skip_unless_enabled
    def test_latency(self):
        for i in BenchmarkWrapper('Authentication WebCookie'):
            client = RadarClient(self.authentication_strategy_webcookie(), self.system_identifier())

        for i in BenchmarkWrapper('Request WebCookie'):
            radar = client.radar_for_id(11725080, additional_fields=['targetStartDate'])

        if AuthenticationStrategySPNego.available():
            for i in BenchmarkWrapper('Authentication SPNego'):
                client = RadarClient(self.authentication_strategy_spnego(), self.system_identifier())

            for i in BenchmarkWrapper('Request SPNego'):
                radar = client.radar_for_id(11725080, additional_fields=['targetStartDate'])

    @skip_unless_enabled
    def test_system_identifier(self):
        si = self.system_identifier()
        self.assertEqual(si.user_agent_string(), 'python-radarclient-unittest/{}'.format(radarclient.__version__))

        def test(name, version):
            radarclient.ClientSystemIdentifier(name, version)
        compat.test_assertRaisesRegex(self, AssertionError, 'Invalid system identifier name', test, 'invalid name', 'invalid version')
        compat.test_assertRaisesRegex(self, AssertionError, 'Invalid system identifier version', test, 'valid-name', 'invalid version')

    @skip_unless_enabled
    def test_spnego(self):
        self.skip_if_not_marc()
        if not AuthenticationStrategySPNego.available():
            self.skipTest('SPNego is not available')
        client = self.authenticated_radar_client_spnego()

        radars = client.radars_for_ids([12179571, 11725080])
        self.assertEqual(len(radars), 2)
        radar = client.radar_for_id(11725080, additional_fields=['effortCurrentTotalEstimate'])
        self.assertIsInstance(radar, Radar)

    @skip_unless_enabled
    def test_spnego_pre_release(self):
        if not AuthenticationStrategySPNego.available():
            self.skipTest('SPNego is not available')
        client = self.authenticated_radar_client_spnego_pre_release()

        user = client.current_user()
        self.assertIsNotNone(user)

    @skip_unless_enabled
    def test_spnego_v2_2(self):
        if not AuthenticationStrategySPNego.available():
            self.skipTest('SPNego is not available')
        client = self.authenticated_radar_client_spnego_v2_2()

        user = client.current_user()
        self.assertIsNotNone(user)

    @skip_unless_enabled
    def test_gss_authenticator(self):
        self.skip_if_not_marc()
        authenticator = radarclient.gssauthenticator.GSSAuthenticator('mliyanage', 'APPLECONNECT.APPLE.COM')
        url = '{}/problems/16791997'.format(radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url'))
        request = compat.urllib_Request(url)
        authenticator.attach_token_to_request(request)
        response = http_request_utilities.urlopen(request, AuthenticationStrategySPNego().ca_cert_bundle_data())
        self.assertEqual(response.getcode(), 200)

    @skip_unless_enabled
    def test_ca_cert_bundle(self):
        client = self.authenticated_radar_client()
        auth_strategy = client.authentication_strategy
        bundle_data = auth_strategy.ca_cert_bundle_data()
        self.assertIsNotNone(bundle_data)

        # Info about test URLS: https://a1391192.slack.com/archives/CKZEGD6AF/p1685645218902599
        test_urls = [
            'https://valid-acr-rsa.apple.com',
            'https://revoked-acr-rsa.apple.com',
            'https://valid-acr2-ecc.apple.com',
            'https://revoked-acr2-ecc.apple.com',
        ]
        for test_url in test_urls:
            try:
                ssl_context = ssl.create_default_context(cadata=bundle_data)
                response = radarclient.compat.urlopen(test_url, context=ssl_context)
            except Exception as e:
                self.fail('Failed to open URL {}: {}'.format(test_url, e))

        test_urls = [
            'https://expired-acr-rsa.apple.com',
            'https://expired-acr2-ecc.apple.com',
        ]

        for test_url in test_urls:
            with self.assertRaises(compat.urllib_URLError) as exception_info:
                ssl_context = ssl.create_default_context(cadata=bundle_data)
                response = radarclient.compat.urlopen(test_url, context=ssl_context)

            if compat.PY2:
                self.assertIsInstance(exception_info.exception.reason, ssl.SSLError)
                self.assertIn('certificate verify failed', str(exception_info.exception))
            else:
                self.assertIsInstance(exception_info.exception.reason, ssl.SSLCertVerificationError)
                self.assertIn('certificate has expired', str(exception_info.exception))



    @skip_unless_enabled
    def test_radar_access_token(self):
        payload = {
            'accessToken': 'foo',
            'tokenType': 'bar',
            'tokenExpiresIn': '15 Seconds',
            'user': {
                'appleConnectName': 'foobar',
                'id': 1234,
            },
        }
        token = authenticationstrategy.RadarAccessToken.token_for_signon_response_payload(payload)

        is_valid, expiration_datetime, seconds_remaining = token.expiration_status_information()
        self.assertTrue(is_valid)

        payload = {
            'accessToken': 'foo',
            'tokenType': 'bar',
            'tokenExpiresIn': '10 Seconds',
            'user': {
                'appleConnectName': 'foobar',
                'id': 1234,
            },
        }
        token = authenticationstrategy.RadarAccessToken.token_for_signon_response_payload(payload)
        is_valid, expiration_datetime, seconds_remaining = token.expiration_status_information()
        self.assertFalse(is_valid)

    @skip_unless_enabled
    def test_client_radar_access_token(self):

        client = self.authenticated_radar_client()
        cached_token = client.authentication_strategy.cached_radar_access_token
        self.assertIsNone(cached_token)
        self.assertIsNotNone(client.retry_policy)
        self.assertIsNotNone(client.rate_limit_policy)

        dump = pickle.dumps(client)
        client = pickle.loads(dump)
        self.assertIsInstance(client, RadarClient)

        cached_token = client.authentication_strategy.cached_radar_access_token
        self.assertIsNone(cached_token)
        radar = client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertIsInstance(radar, Radar)
        cached_token = client.authentication_strategy.cached_radar_access_token
        self.assertIsInstance(cached_token, authenticationstrategy.RadarAccessToken)
        is_valid, expiration_datetime, seconds_remaining = cached_token.expiration_status_information()
        self.assertTrue(is_valid)

        dump = pickle.dumps(client)
        client = pickle.loads(dump)
        self.assertIsInstance(client, RadarClient)
        cached_token = client.authentication_strategy.cached_radar_access_token
        self.assertIsInstance(cached_token, authenticationstrategy.RadarAccessToken)
        is_valid, expiration_datetime, seconds_remaining = cached_token.expiration_status_information()
        self.assertTrue(is_valid)
        radar = client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertIsInstance(radar, Radar)

        # after two pickle cycles, ensure these fields are still present
        self.assertIsNotNone(client.retry_policy)
        self.assertIsNotNone(client.rate_limit_policy)

    @skip_unless_enabled
    def test_client_radar_access_token_deepcopy(self):

        client = self.authenticated_radar_client()
        cached_token = client.authentication_strategy.cached_radar_access_token
        self.assertIsNone(cached_token)
        self.assertIsNotNone(client.retry_policy)
        self.assertIsNotNone(client.rate_limit_policy)

        client_copy = deepcopy(client)
        self.assertIsInstance(client, RadarClient)
        self.assertNotEqual(id(client.authentication_strategy), id(client_copy.authentication_strategy))
        self.assertEqual(client.rate_limit_policy, client_copy.rate_limit_policy)
        self.assertEqual(id(client.rate_limit_policy), id(client_copy.rate_limit_policy))

        self.assertIsNone(client.authentication_strategy.cached_radar_access_token)
        self.assertIsNone(client_copy.authentication_strategy.cached_radar_access_token)
        radar1 = client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        radar2 = client_copy.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        radar3 = client_copy.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertIsInstance(radar1, Radar)
        self.assertIsInstance(radar2, Radar)
        self.assertIsInstance(radar3, Radar)

        # each client should have negotiated a token independently
        self.assertIsNotNone(client.authentication_strategy.cached_radar_access_token)
        self.assertIsNotNone(client_copy.authentication_strategy.cached_radar_access_token)
        self.assertNotEqual(client.authentication_strategy.cached_radar_access_token, client_copy.authentication_strategy.cached_radar_access_token)

        # all these Radars are semantically equivalent, but 2+3 should refer to the same cached object
        self.assertEqual(radar1, radar2)
        self.assertEqual(radar2, radar3)
        self.assertNotEqual(id(radar1), id(radar2))
        self.assertEqual(id(radar2), id(radar3))

        # do the same after authentication has been negotiated
        client_copy = deepcopy(client)
        self.assertIsInstance(client, RadarClient)
        self.assertNotEqual(id(client.authentication_strategy), id(client_copy.authentication_strategy))

        self.assertIsNotNone(client.authentication_strategy.cached_radar_access_token)
        self.assertIsNotNone(client_copy.authentication_strategy.cached_radar_access_token)
        radar4 = client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        radar5 = client_copy.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        radar6 = client_copy.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertIsInstance(radar4, Radar)
        self.assertIsInstance(radar5, Radar)
        self.assertIsInstance(radar6, Radar)

        # each client should have negotiated a token independently
        self.assertIsNotNone(client.authentication_strategy.cached_radar_access_token)
        self.assertIsNotNone(client_copy.authentication_strategy.cached_radar_access_token)
        self.assertNotEqual(client.authentication_strategy.cached_radar_access_token, client_copy.authentication_strategy.cached_radar_access_token)

        # all these Radars are semantically equivalent, but 2+3 should refer to the same cached object
        self.assertEqual(radar1, radar4)
        self.assertEqual(radar4, radar5)
        self.assertEqual(radar5, radar6)
        self.assertEqual(id(radar1), id(radar4))
        self.assertNotEqual(id(radar4), id(radar5))
        self.assertEqual(id(radar5), id(radar6))

    @skip_unless_enabled
    def test_app_to_app_missing_params(self):
        try:
            AuthenticationStrategyAppToApp()
        except Exception as e:
            self.assertEqual(str(e),
                             'AuthenticationStrategyAppToApp: You must provide values for application_id, application_password, radar_app_to_app_context, person_dsid')
            return

        self.assertEqual(1, 'AuthenticationStrategyAppToApp: validation didnt work')

    @skip_unless_enabled
    def test_app_to_app_missing_param_1(self):
        try:
            AuthenticationStrategyAppToApp(application_id='some_id')
        except Exception as e:
            self.assertEqual(str(e),
                             'AuthenticationStrategyAppToApp: You must provide values for application_password, radar_app_to_app_context, person_dsid')
            return

        self.assertEqual(1, 'AuthenticationStrategyAppToApp: validation didnt work')

    @skip_unless_enabled
    def test_app_to_app_missing_param_2(self):
        try:
            AuthenticationStrategyAppToApp(application_id='some_id',
                                           application_password='some_password')
        except Exception as e:
            self.assertEqual(str(e),
                             'AuthenticationStrategyAppToApp: You must provide values for radar_app_to_app_context, person_dsid')
            return

        self.assertEqual(1, 'AuthenticationStrategyAppToApp: validation didnt work')

    @skip_unless_enabled
    def test_app_to_app_missing_param_3(self):
        try:
            AuthenticationStrategyAppToApp(application_id='some_id',
                                           application_password='some_password',
                                           radar_app_to_app_context='some_context')
        except Exception as e:
            self.assertEqual(str(e), 'AuthenticationStrategyAppToApp: You must provide values for person_dsid')
            return

        self.assertEqual(1, 'AuthenticationStrategyAppToApp: validation didnt work')

    @skip_unless_enabled
    def test_app_to_app_missing_param_4(self):
        try:
            AuthenticationStrategyAppToApp(person_dsid='some_dsid')
        except Exception as e:
            self.assertEqual(str(e),
                             'AuthenticationStrategyAppToApp: You must provide values for application_id, application_password, radar_app_to_app_context')
            return

        self.assertEqual(1, 'AuthenticationStrategyAppToApp: validation didnt work')

    @skip_unless_enabled
    def test_app_to_app_invalid_a3_params(self):
        app_to_app = AuthenticationStrategyAppToApp(application_id='some_id',
                                                    application_password='some_password',
                                                    radar_app_to_app_context='some_context',
                                                    person_dsid='some_dsid',
                                                    radar_environment=radarclient.RadarEnvironment('uat'))
        try:
            app_to_app.setup_user_session()
        except Exception as e:
            self.assertEqual(str(e), 'HTTP Error 401: ')

    @skip_if_app_to_app_env_vars_are_missing
    def test_app_to_app_valid_a3_params(self):
        app_to_app = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_TO_APP_AUTH_APP_ID', 'some_id'),
                                                    application_password=os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', 'some_pass'),
                                                    radar_app_to_app_context=os.getenv('APP_TO_APP_AUTH_APP_CONTEXT', 'some_context'),
                                                    person_dsid='973544353',
                                                    radar_environment=radarclient.RadarEnvironment('uat'))
        try:
            app_to_app.setup_user_session()
        except Exception as e:
            self.assertEqual(str(e),
                             '401 Client Error: Unauthorized for url: https://rws-sandbox.apple.com/signon')

    @skip_if_app_to_app_env_vars_are_missing
    def test_app_to_app_valid_a3_params_retrieve_radar_details_uat_alt(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_TO_APP_AUTH_APP_ID', 'some_id'),
                                                           application_password=os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', 'some_pass'),
                                                           radar_app_to_app_context=os.getenv('APP_TO_APP_AUTH_APP_CONTEXT', 'some_context'),
                                                           person_dsid='973544353',
                                                           radar_environment=radarclient.RadarEnvironment('uat-alt'))
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            client.radar_for_id(38849356)
            client.radar_for_id(38849456)

        except Exception as e:
            self.assertEqual(1, 'AuthenticationStrategyAppToApp: this should work!')

    @skip_if_app_to_app_env_vars_are_missing
    def test_app_to_app_valid_a3_params_retrieve_user_name(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_TO_APP_AUTH_APP_ID', 'some_id'),
                                                           application_password=os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', 'some_pass'),
                                                           radar_app_to_app_context=os.getenv('APP_TO_APP_AUTH_APP_CONTEXT',
                                                                                              'some_context'),
                                                           person_dsid='973544353',
                                                           radar_environment=radarclient.RadarEnvironment('uat-alt'))
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            client.radar_for_id(38849356)
            self.assertIsNotNone(client.username())
        except Exception as e:
            self.assertEqual(1, 'AuthenticationStrategyAppToApp: this should work!')

    @skip_if_app_to_app_env_vars_are_missing
    def test_app_to_app_valid_a3_params_retrieve_user_name_direct_username_invoked_call(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_TO_APP_AUTH_APP_ID', 'some_id'),
                                                           application_password=os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', 'some_pass'),
                                                           radar_app_to_app_context=os.getenv('APP_TO_APP_AUTH_APP_CONTEXT',
                                                                                              'some_context'),
                                                           person_dsid='973544353',
                                                           radar_environment=radarclient.RadarEnvironment('uat-alt'))
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            self.assertIsNotNone(client.username())
        except Exception as e:
            self.assertEqual(1, 'AuthenticationStrategyAppToApp: this should work!')

    @skip_if_app_to_app_env_vars_are_missing
    def test_app_to_app_valid_a3_params_sign_in_and_sign_off(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_TO_APP_AUTH_APP_ID', 'some_id'),
                                                           application_password=os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', 'some_pass'),
                                                           radar_app_to_app_context=os.getenv('APP_TO_APP_AUTH_APP_CONTEXT', 'some_context'),
                                                           person_dsid='973544353',
                                                           radar_environment=radarclient.RadarEnvironment('uat-alt'))
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            client.radar_for_id(38849356)
            client.radar_for_id(38849456)
            auth_strategy.end_session()
            client.radar_for_id(38849456)

        except Exception as e:
            self.assertEqual(str(e),
                             'HTTP Error 405: Method Not Allowed')

    @skip_unless_enabled
    def test_app_to_app_invalid_a3_params_radar_client(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id='some_id',
                                                    application_password='some_password',
                                                    radar_app_to_app_context='some_context',
                                                    person_dsid='some_dsid',
                                                    radar_environment=radarclient.RadarEnvironment('uat'))
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            client.radar_for_id(38849356)

        except Exception as e:
            self.assertEqual(str(e), 'HTTP Error 401: ')

    @skip_unless_enabled
    def test_app_to_app_missing_param_1_radar_client(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id='some_id')
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            client.radar_for_id(38849356)
        except Exception as e:
            self.assertEqual(str(e),
                             'AuthenticationStrategyAppToApp: You must provide values for application_password, radar_app_to_app_context, person_dsid')
            return
        self.assertEqual(1, 'AuthenticationStrategyAppToApp: validation didnt work')

    @skip_if_app_to_app_env_vars_are_missing
    def test_app_to_app_valid_a3_params_valid_credentials_not_authorized_user_radar_client(self):
        try:
            auth_strategy = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_TO_APP_AUTH_APP_ID', 'some_id'),
                                                           application_password=os.getenv('APP_TO_APP_AUTH_APP_PASSWORD', 'some_pass'),
                                                           radar_app_to_app_context=os.getenv('APP_TO_APP_AUTH_APP_CONTEXT', 'some_context'),
                                                           person_dsid='97354435311111',
                                                           radar_environment=radarclient.RadarEnvironment('uat-alt'))
            client = radarclient.RadarClient(auth_strategy,
                                             radarclient.ClientSystemIdentifier('python-radarclient-unittest',
                                                                                radarclient.__version__))
            client.radar_for_id(38849356)
            client.radar_for_id(38849456)

        except Exception as e:
            self.assertEqual(str(e),
                             'Non-200 response code 401: You are unauthorized to use this service. Invalid authentication parameters.')

    @skip_unless_enabled
    def test_create_radar(self):
        for default_component in TestConfiguration.default_components():
            self._test_create_radar(default_component)

    def _test_create_radar(self, component):
        self.skip_if_not_marc()
        query = {'component': component}

        # todo: make the "component" item take a new Component class instance.
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': component,
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }
        radar = self.client.create_radar(data)
        self.assertIsInstance(radar, Radar)
        compat.test_assertRegex(self, str(radar.id), r'^\d+$')

        self.assertEqual(radar.component['id'], 515346)
        self.assertEqual(radar.component['name'], u'python-radarclient-test bugs')
        self.assertEqual(radar.component['version'], u'1.0')

        keyword = self.client.keywords_for_ids([514505])[0]
        radar.add_keyword(keyword)
        radar.commit_changes()

        radar.state = 'Verify'
        radar.resolution = 'Not Applicable'
        radar.commit_changes()
        radar.state = 'Closed'
        radar.commit_changes()
        radar_id = radar.id

        entry = radarclient.model.DiagnosisEntry()
        entry.text = u'\u2192 new entry from unit test 1/2'
        radar.diagnosis.add(entry)
        entry = radarclient.model.DiagnosisEntry()
        entry.text = u'\u2192 new entry from unit test 2/2'
        radar.diagnosis.add(entry)

        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(radar_id, additional_fields=['effortCurrentTotalEstimate'])
        self.assertEqual(radar.effortCurrentTotalEstimate, None)
        self.assertEqual(len(radar.change_records), 0)
        radar.effortCurrentTotalEstimate = 10
        self.assertEqual(len(radar.change_records), 1)
        self.assertEqual(radar.effortCurrentTotalEstimate, 10)
        self.assertEqual(radar.state, 'Closed')

    @skip_unless_enabled
    def test_radar_counts_object(self):
        r = self.client.radar_for_id(112977991)

        self.assertEqual(r.counts['otherRelatedItems'], r.counts.otherRelatedItems)

    @unittest.skip('Skip to avoid creating a component on every test run, enable when needed')
    @skip_unless_enabled
    def test_create_component(self):
        # Get current user DSID
        user_dsid = self.client.current_user().dsid
        # Specify component name, version and work group
        component_name = "unittest for create_component"
        now = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M')
        component_version = "v{}-{}".format(self.client.protocol_version, now)
        work_group = 53006 # radarclient-python-workgroup (must be specified by ID, rdar://98525355)

        data = {
            'description': 'Test for Python RadarClient.create_component()',
            'isOpenToExternals': False,
            'isRestricted': True,
            'isRootLevel': True,
            'name': component_name,
            'ownerId': user_dsid,
            'version': component_version,
            'workGroup': work_group,
        }
        component = self.client.create_component(data)
        self.assertIsInstance(component, Component)
        compat.test_assertRegex(self, str(component.id), r'^\d+$')

        self.assertEqual(component.name, component_name)
        self.assertEqual(component.version, component_version)

        # Build a subcomponent on the new parent
        data = {
            'description': 'Test for Python RadarClient.create_component()',
            'isOpenToExternals': False,
            'isRestricted': True,
            'isRootLevel': False,
            'name': "unittest subcomponent for create_component",
            'ownerId': user_dsid,
            'version': component_version,
            'workGroup': work_group,
            'parent': {
                'id': component.id,
            },
            'doesInheritBuildsAndMilestones': True,
            'doesInheritAccessGroups': True,
            'doesInheritDescriptionTemplates': True,
            'doesInheritTentpole': True,
            'doesInheritCategory': True,
            'doesInheritSysDiagnostics': True,
        }
        subcomponent = self.client.create_component(data)
        self.assertIsInstance(subcomponent, Component)
        compat.test_assertRegex(self, str(subcomponent.id), r'^\d+$')

        self.assertEqual(subcomponent.name, "unittest subcomponent for create_component")
        self.assertEqual(subcomponent.version, component_version)

        # Next, build and send JSON request to close the components
        for comp in [component, subcomponent]:
            now = datetime.datetime.now(tz=radarclient.model.UTC()).replace(microsecond=0, second=0)
            request_data = {
                'isClosed': True,
                'lastModifiedAt': radarclient.model.ISO8601UTCDateValueConverter.encode_radar_value(now)
            }
            status, _ = self.client.build_and_send_json_request(('components', comp.id), request_data, method='POST')
            self.assertEqual(status, 200)

            # Check that component is closed
            print("Waiting 5sec for component {} to close...".format(comp.id))
            time.sleep(5) # Wait 5sec for DB to update
            reloaded_component = self.client.component_for_id(comp.id)
            self.assertTrue(reloaded_component.isClosed)

    @skip_unless_enabled
    def test_create_radar_with_build_related_field(self):
        for default_component in TestConfiguration.default_components():
            self._test_create_radar_with_build_related_field_for_component(default_component)

    def _test_create_radar_with_build_related_field_for_component(self, component):
        self.skip_if_not_marc()
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': component,
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        if self.client.protocol_version >= RadarProtocolVersion('2.1'):
            data.update({'builds': {
                'buildInfo': {
                    'insert': [
                        {'id': 'build123'}
                    ]
                }
            }})
        else:
            data.update({'buildInfo': ['build123']})

        radar = self.client.create_radar(data)
        self.assertIsInstance(radar, Radar)

        time.sleep(3)

        radar = self.client.radar_for_id(radar.id, additional_fields=['buildInfo'])
        self.assertIsInstance(radar, Radar)
        self.assertEqual([x.name for x in radar.buildInfo.items()], ['build123'])

        radar.state = 'Verify'
        radar.resolution = 'Not Applicable'
        radar.commit_changes()
        radar.state = 'Closed'
        radar.commit_changes()

    @skip_unless_enabled
    def test_create_radar_closed_component(self):
        self.skip_if_not_marc()
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {'name': 'python-radarclient-test bugs', 'version': 'closed version'},
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        radar = self.client.create_radar(data)

        self.assertIsInstance(radar, Radar)
        self.assertFalse(radar.is_placeholder())
        compat.test_assertRegex(self, str(radar.id), r'^\d+$')

        self.assertEqual(radar.component['id'], 515346)
        self.assertEqual(radar.component['name'], u'python-radarclient-test bugs')
        self.assertEqual(radar.component['version'], u'1.0')

        radar.state = 'Verify'
        radar.resolution = 'Not Applicable'
        radar.commit_changes()
        radar.state = 'Closed'
        radar.commit_changes()

        radar_id = radar.id

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(radar_id)
        self.assertEqual(radar.state, 'Closed')

    @skip_unless_enabled
    def test_create_radar_closed_component_no_follow_on(self):
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {'name': 'python-radarclient-test bugs', 'version': 'closed version no follow-on'},
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        with self.assertRaises(radarclient.exceptions.ClosedComponentNoFollowOnException) as exception_info:
            radar = self.client.create_radar(data)

        self.assertEqual(exception_info.exception.code, 400)
        self.assertEqual(exception_info.exception.reason, 'Closed component with no follow on.')
        if self.client.protocol_version >= RadarProtocolVersion('2.1'):
            self.assertIn('Closed component with no follow on', str(exception_info.exception))

    @skip_unless_enabled
    def test_create_radar_unknown_component(self):
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {'name': 'python-radarclient-test bugs', 'version': 'no access'},
            'description': u'Please ignore, Python Radar client unit test',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        with self.assertRaises(radarclient.exceptions.ComponentNotFoundException) as exception_info:
            radar = self.client.create_radar(data)

        if self.client.protocol_version >= RadarProtocolVersion('2.1'):
            self.assertEqual(exception_info.exception.code, 400)
            self.assertEqual(exception_info.exception.reason, u'Component does not exist.')
            self.assertIn(u'Component does not exist', str(exception_info.exception))

    @unittest.skip('Noisy for component owner, enable when needed')
    @skip_unless_enabled
    def test_create_radar_inaccessible_dropbox_component(self):
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {'name': 'python-radarclient-test-bugs', 'version': 'no access'},
            'description': u'Please ignore, Python Radar client unit test',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        result = self.client.create_radar(data)
        self.assertIsInstance(result, radarclient.model.RadarPlaceholder)
        self.assertIsInstance(result.id, int)
        self.assertTrue(result.is_placeholder())

    @skip_unless_enabled
    def test_create_radar_inaccessible_component(self):
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {'name': 'python-radarclient-test-bugs', 'version': 'no access no dropbox'},
            'description': u'Please ignore, Python Radar client unit test',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        with self.assertRaises(RadarAccessDeniedResponseException):
            result = self.client.create_radar(data)

    @skip_unless_enabled
    def test_kerberos_parsing_live_system(self):
        self.skip_if_not_marc()
        klist_tool_wrapper = directory.KerberosKlistToolWrapper()
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertGreaterEqual(len(accounts), 1)
        marc_account = next(x for x in accounts if x.username == 'mliyanage')
        self.assertEqual(marc_account.full_username, 'mliyanage@APPLECONNECT.APPLE.COM')

    @skip_unless_enabled
    def test_kerberos_parsing_live_system_disable_json(self):
        self.skip_if_not_marc()
        klist_tool_wrapper = directory.KerberosKlistToolWrapper(_unittest_support_suppress_json=True)
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertGreaterEqual(len(accounts), 1)
        marc_account = next(x for x in accounts if x.username == 'mliyanage')
        self.assertEqual(marc_account.full_username, 'mliyanage@APPLECONNECT.APPLE.COM')

    @skip_unless_enabled
    def test_kerberos_parsing_tool_wrapper_dummy(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/file-cache-single/dash-l.txt', {'FILE:/tmp/krb5cc_0': 'linux/file-cache-single/dash-c.txt'})
        self.assertIn('Cache name', klist_tool_wrapper.cache_list_output())
        self.assertIn('Ticket cache', klist_tool_wrapper.output_for_cache_id('FILE:/tmp/krb5cc_0'))

    @skip_unless_enabled
    def test_kerberos_parsing_mac_no_caches_suppress_json(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('macos/dash-l-no-caches.txt', {})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 0)

    @skip_unless_enabled
    def test_kerberos_parsing_mac_no_caches_json(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy(None, {}, 'macos/dash-l-json-no-caches.txt')
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 0)

    @skip_unless_enabled
    def test_kerberos_parsing_mac_multiple_suppress_json(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('macos/dash-l-multiple-expired.txt', {})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 2)

        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

        self.assertEqual(accounts[1].username, 'psystem36')
        self.assertEqual(accounts[1].full_username, 'psystem36@APPLECONNECT.APPLE.COM')
        self.assertTrue(accounts[1].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_mac_multiple_expired_json(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy(None, {}, 'macos/dash-l-json-multiple-expired.txt')
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 2)

        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

        self.assertEqual(accounts[1].username, 'psystem36')
        self.assertEqual(accounts[1].full_username, 'psystem36@APPLECONNECT.APPLE.COM')
        self.assertTrue(accounts[1].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_mac_multiple_non_user_principal_json(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy(None, {}, 'macos/dash-l-json-non-user-principal.txt')
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 1)

        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_mac_multiple_2_suppress_json(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('macos/dash-l-multiple-expired-second-line-active.txt', {})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 2)

        self.assertEqual(accounts[0].username, 'psystem36')
        self.assertEqual(accounts[0].full_username, 'psystem36@APPLECONNECT.APPLE.COM')
        self.assertTrue(accounts[0].expired)

        self.assertEqual(accounts[1].username, 'mliyanage')
        self.assertEqual(accounts[1].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[1].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_no_caches(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/no-caches/dash-l.txt', {})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 0)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_file_cache(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/file-cache-single/dash-l.txt', {'FILE:/tmp/krb5cc_0': 'linux/file-cache-single/dash-c.txt'})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_file_cache_long(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/file-cache-single-long/dash-l.txt', {'FILE:/tmp/krb5cc_1213510111': 'linux/file-cache-single-long/dash-c.txt'})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(accounts[0].username, 'xxxxxx_x_yyyyyyyy')
        self.assertEqual(accounts[0].full_username, 'xxxxxx_x_yyyyyyyy@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_file_cache_expired(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/file-cache-single/dash-l-expired.txt', {'FILE:/tmp/krb5cc_0': 'linux/file-cache-single/dash-c.txt'})
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertTrue(accounts[0].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_dir_cache(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/dir-cache-multiple/dash-l.txt', {
            'DIR::/tmp/mydir/tktbnBAOK': 'linux/dir-cache-multiple/dash-c-cache-2.txt',
            'DIR::/tmp/mydir/tkt': 'linux/dir-cache-multiple/dash-c-cache-1.txt',
        })
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 1)
        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_dir_cache_expired(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/dir-cache-multiple/dash-l-expired.txt', {
            'DIR::/tmp/mydir/tktbnBAOK': 'linux/dir-cache-multiple/dash-c-cache-2.txt',
            'DIR::/tmp/mydir/tkt': 'linux/dir-cache-multiple/dash-c-cache-1.txt',
        })
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 1)
        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertTrue(accounts[0].expired)

    @skip_unless_enabled
    def test_kerberos_parsing_linux_dir_cache_multiple(self):
        klist_tool_wrapper = self.klist_tool_wrapper_dummy('linux/dir-cache-multiple-appleconnect/dash-l.txt', {
            'DIR::/tmp/mydir/tkt': 'linux/dir-cache-multiple-appleconnect/dash-c-cache-2.txt',
            'DIR::/tmp/mydir/tkt1KMN9P': 'linux/dir-cache-multiple-appleconnect/dash-c-cache-1.txt',
        })
        parser = directory.KerberosKlistOutputParser(klist_tool_wrapper, radarclient.RadarEnvironment.default_environment())
        accounts = parser.logged_in_appleconnect_accounts()
        self.assertEqual(len(accounts), 2)

        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[0].expired)

        self.assertEqual(accounts[1].username, 'psystem36')
        self.assertEqual(accounts[1].full_username, 'psystem36@APPLECONNECT.APPLE.COM')
        self.assertFalse(accounts[1].expired)

    @skip_unless_enabled
    def test_klist_tool_wrapper_live_system(self):
        helper = directory.KerberosKlistToolWrapper()
        self.assertIn('Cache name', helper.cache_list_output())

    @skip_unless_enabled
    def test_klist_tool_wrapper_live_system_json(self):
        self.skip_if_not_marc()
        helper = directory.KerberosKlistToolWrapper()
        output = helper.cache_list_json_output()
        self.assertGreaterEqual(len(output), 1)
        self.assertIn('Cache name', output[0])

    def klist_tool_wrapper_dummy(self, klist_l_filename, klist_cache_id_to_filename_map, cache_list_json_output_filename=None):
        cache_list_json = None
        if cache_list_json_output_filename:
            cache_list_json = json.loads(self.klist_test_content(cache_list_json_output_filename))

        return directory.KerberosKlistToolWrapperUnitTestDummy(
            self.klist_test_content(klist_l_filename),
            {cache_id: self.klist_test_content(cache_filename) for cache_id, cache_filename in klist_cache_id_to_filename_map.items()},
            cache_list_json
        )

    def klist_test_content(self, filename):
        if filename is None:
            return None
        base = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(base, 'klist_test_output', filename)
        with open(file_path, 'r') as f:
            return f.read()

    @skip_unless_enabled
    def test_apple_directory(self):
        self.skip_if_not_marc()
        dsid_list = radarclient.AppleDirectoryQuery.member_dsid_list_for_group_name('Radar Review Board')
        self.assertTrue(len(dsid_list) > 0)
        self.assertIsInstance(dsid_list[0], int)

        user = radarclient.AppleDirectoryQuery.user_entry_for_appleconnect_username('mliyanage')
        self.assertEqual(user.dsid(), 299156498)
        self.assertEqual(user.email(), 'liyanage@apple.com')
        self.assertEqual(user.first_name(), 'Marc')
        self.assertEqual(user.last_name(), 'Liyanage')

        user = radarclient.AppleDirectoryQuery.user_entry_for_dsid(299156498)
        self.assertEqual(user.dsid(), 299156498)
        self.assertEqual(user.email(), 'liyanage@apple.com')
        self.assertEqual(user.first_name(), 'Marc')
        self.assertEqual(user.last_name(), 'Liyanage')

        # This test case added for rdar://151721687 (AppleDirectoryQuery.user_entry_for_dsid returns None)
        # after a regression in 12.15 for rdar://150829460
        user = radarclient.AppleDirectoryQuery.user_entry_for_dsid(19489579)
        self.assertEqual(user.dsid(), 19489579)
        self.assertEqual(user.email(), 'michael_lopp@apple.com')
        self.assertEqual(user.first_name(), 'Michael')
        self.assertEqual(user.last_name(), 'Lopp')

        accounts = radarclient.AppleDirectoryQuery.logged_in_appleconnect_accounts()
        self.assertTrue(len(accounts) > 0)
        self.assertEqual(accounts[0].username, 'mliyanage')
        self.assertEqual(accounts[0].full_username, 'mliyanage@APPLECONNECT.APPLE.COM')
        self.assertEqual(accounts[0].expired, False)

        test_klist_output = b'''\
            Name                                Cache name                                 Expires
        mdouet@APPLECONNECT.APPLE.COM       API:34D60D1A-DF05-4927-BD50-BB2ED3143C3C   >>> Expired <<<
        * mdouet@APPLECONNECT-UAT.APPLE.COM   API:06117FE1-9827-4405-957D-C36F3ACF5C13   Sep  3 19:44:56 2021
            '''
        accounts = radarclient.AppleDirectoryQuery.logged_in_appleconnect_accounts(_unit_test_support_klist_output=test_klist_output)
        self.assertEqual(len(accounts), 1)
        self.assertEqual(accounts[0].username, 'mdouet')
        self.assertEqual(accounts[0].full_username, 'mdouet@APPLECONNECT.APPLE.COM')
        self.assertEqual(accounts[0].expired, True)

        accounts = radarclient.AppleDirectoryQuery.logged_in_appleconnect_accounts(radar_environment=radarclient.RadarEnvironment('uat'), _unit_test_support_klist_output=test_klist_output)
        self.assertEqual(len(accounts), 1)
        self.assertEqual(accounts[0].username, 'mdouet')
        self.assertEqual(accounts[0].full_username, 'mdouet@APPLECONNECT-UAT.APPLE.COM')
        self.assertEqual(accounts[0].expired, False)

    @skip_unless_enabled
    def test_apple_directory_manager_dsid(self):
        user = radarclient.AppleDirectoryQuery.user_entry_for_dsid(299156498)
        self.assertEqual(user.dsid(), 299156498)
        self.assertEqual(user.email(), 'liyanage@apple.com')
        self.assertEqual(user.first_name(), 'Marc')
        self.assertEqual(user.last_name(), 'Liyanage')

        manager_dsid = user.manager_dsid()
        self.assertIsInstance(manager_dsid, int)
        self.assertNotEqual(manager_dsid, 299156498)
        self.assertGreater(manager_dsid, 0)

        manager_user = radarclient.AppleDirectoryQuery.user_entry_for_dsid(manager_dsid)
        self.assertIsInstance(manager_user, radarclient.AppleDirectoryUserEntry)

    @skip_unless_enabled
    def test_apple_directory_manager_dsids_for_dsids(self):
        user_dsids = [299156498, 1447413647, 2319797369]
        manager_dsids = radarclient.AppleDirectoryQuery.manager_dsids_for_dsids(user_dsids)
        self.assertEqual(len(user_dsids), len(manager_dsids))
        for dsid, manager_dsid in manager_dsids:
            if dsid == 2319797369:
                self.assertIsNone(manager_dsid, 'Unexpected manager dsid {}, should be None'.format(manager_dsid))
            else:
                self.assertIsInstance(manager_dsid, int)
                self.assertNotIn(manager_dsid, user_dsids)
                self.assertGreater(manager_dsid, 0)
                manager_user = radarclient.AppleDirectoryQuery.user_entry_for_dsid(manager_dsid)
                self.assertIsInstance(manager_user, radarclient.AppleDirectoryUserEntry)

    @skip_unless_enabled
    def test_apple_directory_user_entries_for_attribute_values(self):
        user_dsids = [299156498, 1447413647, 999]
        user_tuples = radarclient.AppleDirectoryQuery.user_entries_for_dsids(user_dsids)
        self.assertEqual(len(user_tuples), len(user_dsids))
        for index, dsid in enumerate(user_dsids):
            user_tuple = user_tuples[index]
            self.assertIsInstance(user_tuple, tuple)
            result_dsid, user = user_tuple
            self.assertEqual(dsid, result_dsid)
            if dsid == 999:
                self.assertIsNone(user)
            else:
                self.assertIsInstance(user, radarclient.AppleDirectoryUserEntry)

    @skip_unless_enabled
    def test_camelcase(self):
        self.assertEqual(radarclient.model.CamelCase.encode('foo_bar_baz'), 'fooBarBaz')
        self.assertEqual(radarclient.model.CamelCase.decode('fooBarBaz'), 'foo_bar_baz')

    @skip_unless_enabled
    def test_extract_radar_ids_from_text(self):
        self.assertEqual(radarclient.RadarClient.extract_radar_ids_from_text('abc 12345 123456 1234567 12345678 223456789 def'), ['1234567', '12345678', '223456789'])
        self.assertEqual(radarclient.RadarClient.extract_radar_ids_from_text('commit 0ce3d46ae458fd6b094456891f13a9bc358b0046'), [])

    @skip_unless_enabled
    def test_radarclient(self):
        self.skip_if_not_marc()
        def print_progress(progress, loaded_count, total_count):
            pass
#            print >> sys.stderr, 'Loading data: {} of {}, {:.0%} complete'.format(loaded_count, total_count, progress)

        radars = self.client.radars_for_ids([12179571, 11725080], progress_callback=print_progress)
        self.assertEqual(len(radars), 2)
        radar = self.client.radar_for_id(11725080, additional_fields=['effortCurrentTotalEstimate'])
        self.assertIsInstance(radar, Radar)

    @skip_unless_enabled
    def test_radars_for_ids_preserves_order(self):
        ids_in = [70362095,70373191,70377897,70390248,70390448,70391090,70391957,70391973,70394240,70397035,70401833,70401837,70401845,70401846]
        radars = self.client.radars_for_ids(ids_in)
        ids_out = [rdr.id for rdr in radars]
        self.assertEqual(ids_in, ids_out)

        radars = self.client.radars_for_ids([str(x) for x in ids_in])
        ids_out = [rdr.id for rdr in radars]
        self.assertEqual(ids_in, ids_out)

        ids_in = [70362095,70373191,9999999999,70377897,70390248,70390448,70391090,70391957,70391973,70394240,70397035,70401833,70401837,70401845,70401846]
        radars = self.client.radars_for_ids(ids_in)
        ids_out = [rdr.id for rdr in radars]
        self.assertEqual(len(ids_out), len(ids_in) - 1)
        del(ids_in[2])
        self.assertEqual(ids_in, ids_out)

    @skip_unless_enabled
    def test_load_radar_no_permission(self):
        errors = []

        def error_callback(radar_id, error):
            errors.append((radar_id, error))

        radars = self.client.radars_for_ids([16785790, 11725080, 16859987, 17514278], error_callback=error_callback)
        self.assertEqual(len(radars), 2)
        self.assertEqual(len(errors), 2)
        self.assertEqual(set([16859987, 16785790]), set([i[0] for i in errors]))
        for e in errors:
            if isinstance(e, radarclient.exceptions.RadarAccessDeniedResponseException):
                self.assertIn('@', e[1].component_owner_information()[1])

        errors = []
        radars = self.client.radars_for_ids([16785790, 11725080, 16859987, 17514278], error_callback=error_callback)
        self.assertEqual(len(radars), 2)
        self.assertEqual(len(errors), 2)
        self.assertEqual(set([16859987, 16785790]), set([i[0] for i in errors]))

        errors = []
        radars = self.client.radars_for_ids([16785790, 11725080, 16859987, 17514278])
        self.assertEqual(len(radars), 2)
        self.assertEqual(len(errors), 0)

        errors = []
        radar = self.client.radar_for_id(16859987, error_callback=error_callback)
        self.assertIsNone(radar)
        self.assertEqual(len(errors), 1)
        self.assertEqual(set([16859987]), set([i[0] for i in errors]))

        with self.assertRaises(radarclient.RadarAccessDeniedResponseException) as exception_info:
            radar = self.client.radar_for_id(16859987)

    @skip_unless_enabled
    def test_load_radar_not_found(self):
        errors = []

        def error_callback(radar_id, error):
            errors.append((radar_id, error))

        radars = self.client.radars_for_ids([16785790, 11725080, 99999999999999], error_callback=error_callback)
        self.assertEqual(len(radars), 1)
        self.assertEqual(len(errors), 2)
        self.assertEqual(set([99999999999999, 16785790]), set([i[0] for i in errors]))
        for radar_id, error in errors:
            if radar_id == 99999999999999:
                self.assertIsInstance(error, radarclient.exceptions.ObjectNotFoundException)
            elif radar_id == 16785790:
                self.assertIsInstance(error, radarclient.exceptions.RadarAccessDeniedResponseException)
                self.assertIn('@', error.component_owner_information()[1])
            else:
                self.fail('Unexpected radar ID in error callback')

    @skip_unless_enabled
    def test_predefined_cookie_value(self):
        if ENABLE_SPNEGO:
            self.skipTest('Test requires web cookie authentication strategy')
        cookie_value = self.client.authentication_strategy.cookie_value

        client = RadarClient(AuthenticationStrategyWebCookie(cookie_value=cookie_value), self.system_identifier())
        radars = client.radars_for_ids([12179571, 11725080])
        self.assertEqual(len(radars), 2)

        radar = client.radar_for_id(11725080, additional_fields=['effortCurrentTotalEstimate'])
        self.assertIsInstance(radar, Radar)

        if UAT_ACCOUNT_PASSWORD is None:
            return

        auth_strategy = AuthenticationStrategyWebCookie(UAT_ACCOUNT_USERNAME, UAT_ACCOUNT_PASSWORD, radar_environment=radarclient.RadarEnvironment('uat'))
        client = radarclient.RadarClient(auth_strategy, self.system_identifier())
        cookie_value = client.authentication_strategy.cookie_value

        client = RadarClient(AuthenticationStrategyWebCookie(cookie_value=cookie_value, radar_environment=radarclient.RadarEnvironment('uat')), self.system_identifier())
        radar = client.radar_for_id(12353876)  # 12344253#12345307
        self.assertIsInstance(radar, Radar)

    @skip_unless_enabled
    def test_predefined_oidc_access_token_value(self):
        if ENABLE_SPNEGO:
            self.skipTest('Test requires OIDC authentication strategy')

        key = 'RADARCLIENT_UNIT_TEST_OIDC_ACCESS_TOKEN'
        if key not in os.environ:
            self.skipTest('Skipping OIDC-based unit test because the "{}" environment variable is not set: {}'.format(key))

        access_token = os.environ.get(key)

        client = RadarClient(AuthenticationStrategyOIDC(access_token=access_token, radar_environment=radarclient.RadarEnvironment('uat-alt')), self.system_identifier())
        radars = client.radars_for_ids([11725080])
        self.assertEqual(len(radars), 1)

        radar = client.radar_for_id(11725080, additional_fields=['effortCurrentTotalEstimate'])
        self.assertIsInstance(radar, Radar)

    @skip_unless_enabled
    def test_find_radar_none_id(self):
        with self.assertRaises(AssertionError) as exception_info:
            radar = self.client.radar_for_id(None)
        self.assertIn('None value passed for Radar ID', str(exception_info.exception))

        with self.assertRaises(AssertionError) as exception_info:
            radar = self.client.radars_for_ids([None])
        self.assertIn('None value passed for Radar ID', str(exception_info.exception))

    @skip_unless_enabled
    def test_add_remove_keyword(self):
        keyword = self.client.keywords_for_ids([514505])[0]
        self.assertEqual(keyword.id, 514505)
        self.assertEqual(keyword.name, 'radarclient-python test 2')

        radar_id = 18726508
        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        self.assertEqual(len(associations), 1, 'Unexpected existing keywords attached to radar:{}'.format(radar_id))

        radar.add_keyword(keyword)
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        self.assertEqual(len(associations), 2, 'Unexpected keyword count mismatch in radar:{}'.format(radar_id))

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(radar_id)
        radar.remove_keyword(keyword)
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        self.assertEqual(len(associations), 1)

    @skip_unless_enabled
    def test_add_existing_keyword(self):
        radar_id = 18726508
        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        self.assertEqual(len(associations), 1, 'Expected 1 keyword attached to radar:{} but got {}'.format(radar_id, len(associations)))

        keyword = self.client.keywords_for_ids([514505])[0]
        self.assertEqual(keyword.id, 514505)
        self.assertEqual(keyword.name, 'radarclient-python test 2')
        radar.add_keyword(keyword)
        radar.commit_changes()
        self.client.clear_radar_cache()

        def checker(expected, r):
            a = r.keyword_associations()
            self.assertEqual(
                expected,
                len(a),
                'Unexpected keyword count in radar:{} - got {}'.format(radar_id, len(a))
            )

        def fetcher():
            self.client.clear_radar_cache()
            return self.client.radar_for_id(radar_id)

        radar = testing_utils.validate_with_retry(fetcher, partial(checker, 2))

        radar.add_keyword(keyword)
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = testing_utils.validate_with_retry(fetcher, partial(checker, 2))

        radar.remove_keyword(keyword)
        radar.commit_changes()
        self.client.clear_radar_cache()

        testing_utils.validate_with_retry(fetcher, partial(checker, 1))

    @skip_unless_enabled
    def test_add_keyword_dry_run(self):
        keyword = self.client.keywords_for_ids([514505])[0]
        self.assertEqual(keyword.id, 514505)
        self.assertEqual(keyword.name, 'radarclient-python test 2')

        radar_id = 18726508
        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        self.assertEqual(len(associations), 1, 'Unexpected keyword count != 1 in radar:{}'.format(radar_id))

        @contextlib.contextmanager
        def captured_output():
            old_value = os.environ.get('RADARCLIENT_SUPPRESS_DRY_RUN_OUTPUT', None)
            if old_value is not None:
                del os.environ['RADARCLIENT_SUPPRESS_DRY_RUN_OUTPUT']
            new_out, new_err = compat.StringIO(), compat.StringIO()
            old_out, old_err = sys.stdout, sys.stderr
            try:
                sys.stdout, sys.stderr = new_out, new_err
                yield sys.stdout, sys.stderr
            finally:
                sys.stdout, sys.stderr = old_out, old_err
                if old_value is not None:
                    os.environ['RADARCLIENT_SUPPRESS_DRY_RUN_OUTPUT'] = old_value

        with captured_output() as (stdout, stderr):
            radar.add_keyword(keyword)
            radar.commit_changes(dry_run=True)
        output = stdout.getvalue().strip()
        url = radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url')
        self.assertIn('PUT request to {}/problems/{}/keywords/514505'.format(url, radar_id), output)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(radar_id)

        with captured_output() as (stdout, stderr):
            radar.remove_keyword(keyword)
            radar.commit_changes(dry_run=True)
        output = stdout.getvalue().strip()
        url = radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url')
        self.assertIn('DELETE request to {}/problems/{}/keywords/514505'.format(url, radar_id), output)

    @skip_unless_enabled
    def test_add_closed_keyword_throws(self):
        keyword = self.client.keywords_for_ids([1138153])[0]
        self.assertEqual(keyword.id, 1138153)
        self.assertEqual(keyword.name, 'radarclient-python test closed')

        radar_id = 48626189
        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        self.assertEqual(len(associations), 0, 'More than 0 keyword attached to radar:{}'.format(radar_id))

        radar.add_keyword(keyword)
        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException) as exception_info:
            radar.commit_changes()
        self.assertEqual(404, exception_info.exception.code)

        self.assertEqual("Non-2xx/success response code 404 for request path \"/problems/48626189/keywords/1138153\": The keyword with id '1138153' does not exist or you may not have the privilege.", str(exception_info.exception))

    @skip_unless_enabled
    def test_load_personal_keywords(self):
        self.skip_if_not_marc()
        keyword = self.client.keywords_for_ids([153249], additional_fields=['component', 'description', 'isClosed', 'isCopiedOnClone', 'source', 'type'])[0]
        self.assertEqual(keyword.name, 'Marc Liyanage Bookmarked')
        self.assertEqual(keyword.source, 'Personal')
        self.assertEqual(keyword.type, 'Personal')
        self.assertEqual(keyword.description, "Marc Liyanage's Bookmarked Radars")
        self.assertIsNone(keyword.component)
        self.assertIsInstance(keyword.isClosed, bool)
        self.assertIsInstance(keyword.isCopiedOnClone, bool)

    @skip_unless_enabled
    def test_load_public_keywords(self):
        keyword = self.client.keywords_for_ids([196144], additional_fields=['component', 'description', 'isClosed', 'isCopiedOnClone', 'source', 'type'])[0]
        self.assertEqual(keyword.id, 196144)
        self.assertEqual(keyword.name, 'radarclient-python test')
        self.assertEqual(keyword.source, 'Public')
        self.assertEqual(keyword.type, 'Normal')
        self.assertEqual(keyword.description, "Test keyword for radarclient-python unit tests")
        self.assertIsInstance(keyword.component, radarclient.model.Component)
        self.assertEqual(keyword.component.name, "python-radarclient-test bugs")
        self.assertEqual(keyword.component.version, "1.0")
        self.assertIsInstance(keyword.isClosed, bool)
        self.assertIsInstance(keyword.isCopiedOnClone, bool)

        keywords = self.client.keywords_for_name('radarclient-python test')
        self.assertEqual(len(keywords), 3)
        self.assertIsInstance(keywords[0], radarclient.model.Keyword)
        self.assertEqual(keywords[0].id, 196144)

        radar_id = 18726508
        radar = self.client.radar_for_id(radar_id)
        associations = radar.keyword_associations()
        if len(associations) > 1:
            # clean up state from interrupted tests
            keyword = next(ka for ka in associations if ka.keyword.id == 514505).keyword
            radar.remove_keyword(keyword)
            radar.commit_changes()
            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(radar_id)
            associations = radar.keyword_associations()

        self.assertEqual(len(associations), 1, 'Unexpected keywords attached to radar:{}'.format(radar_id))
        association = associations[0]

        self.assertIsInstance(association.addedAt, datetime.datetime)
        new_datestring = '2020-07-29T19:21:32+00:00'
        new_datevalue = radarclient.model.ISO8601UTCDateValueConverter.decode_radar_value(new_datestring)
        self.assertEqual(association.addedAt, new_datevalue, 'Date mismatch for keyword addition in radar:{}: expected {}, got {}'.format(radar_id, new_datevalue, association.addedAt))

        self.assertIsInstance(association.addedBy, Person)
        self.assertEqual(association.addedBy.dsid, 299156498)
        self.assertEqual(association.addedBy.email, 'liyanage@apple.com')
        self.assertEqual(association.addedBy.type, 'Employee')
        self.assertEqual(association.addedBy.firstName, 'Marc')
        self.assertEqual(association.addedBy.lastName, 'Liyanage')

        self.assertIsInstance(keywords[0], radarclient.model.Keyword)
        self.assertIsInstance(association.keyword, radarclient.model.Keyword)
        self.assertEqual(association.keyword.id, 196144)
        self.assertEqual(association.keyword.name, 'radarclient-python test')

        keywords = radar.keywords()
        self.assertEqual(len(keywords), 1)
        self.assertEqual(keywords[0], association.keyword)

        # Test with all invalid
        invalid_id = 100000000000
        with self.assertRaises(Exception) as exception_info:
            invalid_list = self.client.keywords_for_ids([invalid_id])
            self.assertIsInstance(exception_info, radarclient.RadarAccessDeniedResponseException)

        # Test with mixed invalid
        valid_id = 196144
        expected_list = self.client.keywords_for_ids([valid_id])
        response_list = self.client.keywords_for_ids([invalid_id, valid_id])
        self.assertEqual(expected_list, response_list)

    @skip_unless_enabled
    def test_find_keywords(self):
        for default_component in TestConfiguration.default_components():
            self._test_find_keywords(default_component)

    def _test_find_keywords(self, component):
        keywords = self.client.find_keywords({'component': component})
        self.assertEqual(len(keywords), 3)
        self.assertIsInstance(keywords[0], radarclient.model.Keyword)
        self.assertEqual(keywords[0].id, 196144)

    @skip_unless_enabled
    def test_keyword_for_id(self):
        keyword_id = 196144
        not_real_id = 10000000000000

        # Test with no additional_fields
        keyword = self.client.keyword_for_id(keyword_id)
        self.assertIsInstance(keyword, radarclient.model.Keyword)

        # Test with additional fields
        fields = ['component', 'description', 'isClosed', 'isCopiedOnClone', 'source', 'type']
        keyword_with_fields = self.client.keyword_for_id(keyword_id, additional_fields=fields)
        self.assertEqual(keyword, keyword_with_fields)
        for field in fields:
            self.assertIsNotNone(getattr(keyword_with_fields, field))

        # This throws ObjectNotFoundException in v2.1, checking for more general error in case that changes
        #   (in v2.2 it's RadarAccessDeniedResponseException) (-maybe not? -Ben 11/14/22)
        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
            self.client.keyword_for_id(not_real_id)

    @skip_unless_enabled
    def test_find_radar_groups(self):
        query = {'hasExternalUsers': True}
        groups = self.client.find_radar_groups(query, limit=20)
        combined_groups = groups['Access Groups'] + groups['Work Groups']

        # TODO: remove this workaround after Radar server bug fix for: rdar://71270616 (Radar API v2.1 regression: server does not respect X-Rowlimit for /groups/find)
        combined_groups = combined_groups[:20]

        self.assertEqual(20, len(combined_groups))

        for group in combined_groups:
            self.assertTrue(isinstance(group, AccessGroup) or isinstance(group, WorkGroup))
            self.assertIsInstance(group.id, int)
            self.assertIsInstance(group.hasExternalUsers, bool)
            self.assertIsInstance(group.description, compat.unicode_string_type)
            self.assertIsInstance(group.isActive, bool)
            self.assertIsInstance(group.name, compat.unicode_string_type)
            self.assertIsInstance(group.type, compat.unicode_string_type)

    @skip_unless_enabled
    def test_get_work_groups(self):
        query = {
            'hasExternalUsers': True,
            'type': {'eq': 'Work Group'}
        }
        found_groups = self.client.find_radar_groups(query, limit=5)['Work Groups']

        # TODO: remove this workaround after Radar server bug fix for: rdar://71270616 (Radar API v2.1 regression: server does not respect X-Rowlimit for /groups/find)
        found_groups = found_groups[:5]

        self.assertEqual(len(found_groups), 5, 'result/row limit not respected')

        group_ids = []
        group_names = []
        for group in found_groups:
            group_ids.append(group.id)
            group_names.append(group.name)

        groups_by_id = [self.client.work_group_for_id(group_id) for group_id in group_ids]
        groups_by_name = [self.client.work_group_for_name(name) for name in group_names]

        self.assertEqual(groups_by_id, groups_by_name)
        all_fields = ['administrators', 'assignToRoleHolder', 'autoAssignToOriginatorOnVerify',
                      'components', 'members', 'resetStateOnComponentChange']

        full_groups = [self.client.work_group_for_id(gid, additional_fields=all_fields) for gid in group_ids]

        for group in full_groups:
            self.assertIsInstance(group, radarclient.model.WorkGroup)
            for attr in radarclient.model.WorkGroupRoles.property_names:
                self.assertIsInstance(getattr(group.roles, attr), Person)
            for admin in group.administrators:
                self.assertIsInstance(admin, radarclient.model.RadarGroupMember)
            for component in group.components:
                self.assertIsInstance(component, radarclient.model.Component)
            for member in group.members:
                self.assertIsInstance(member, radarclient.model.RadarGroupMember)

    @skip_unless_enabled
    def test_get_access_groups(self):
        query = {
            'hasExternalUsers': True,
            'type': {'eq': 'Access Group'}
        }
        found_groups = self.client.find_radar_groups(query, limit=5)['Access Groups']

        self.assertEqual(len(found_groups), 5, 'result/row limit not respected')
        group_ids = []
        group_names = []
        for group in found_groups:
            group_ids.append(group.id)
            group_names.append(group.name)

        groups_by_id = [self.client.access_group_for_id(group_id) for group_id in group_ids]
        groups_by_name = [self.client.access_group_for_name(name) for name in group_names]

        self.assertEqual(groups_by_id, groups_by_name)
        all_fields = ['administrators', 'components', 'members']

        full_groups = [
            self.client.access_group_for_id(gid, additional_fields=all_fields) for gid in group_ids
        ]

        for group in full_groups:
            self.assertIsInstance(group, radarclient.model.AccessGroup)
            if hasattr(group, 'roles') and group.roles is not None:
                self.assertIsInstance(group.roles.owner, radarclient.model.Person)
            for field in all_fields:
                # TODO: remove workaround for rdar://71272050 (Radar API v2.1 regression: server ignores "components" in X-Fields-Requested)
                if self.client.protocol_version >= RadarProtocolVersion('2.1'):
                    if field in ['components', 'administrators']:
                        continue
                self.assertTrue(hasattr(group, field), 'Group "{}" missing field "{}"'.format(group, field))

            for member in group.members:
                self.assertIsInstance(member, radarclient.model.RadarGroupMember)

    @skip_unless_enabled
    def test_add_delete_cc_memberships(self):
        self.skip_if_not_marc()
        person = self.client.find_people(False, email="liyanage@apple.com")[0]

        radar = self.client.radar_for_id(18726508)
        memberships = list(radar.cc_memberships.items())
        self.assertEqual(len(memberships), 1, msg='Initial CC membership count in radar:18726508 mismatch, expected 1')
        self.assertEqual(memberships[0].person.dsid, 299156498)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(18726508)
        radar.delete_cc(person)
        radar.commit_changes()
        time.sleep(2)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(18726508)
        memberships = list(radar.cc_memberships.items())
        self.assertEqual(len(memberships), 0, msg='CC membership count in radar:18726508 mismatch, expected 0')

        radar.add_cc(person)
        radar.commit_changes()
        time.sleep(2)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(18726508)
        memberships = list(radar.cc_memberships.items())
        self.assertEqual(len(memberships), 1)

    @skip_unless_enabled
    def test_load_cc_memberships(self):
        radar = self.client.radar_for_id(18726508)
        memberships = list(radar.cc_memberships.items())
        self.assertEqual(len(memberships), 1, msg='CC membership count mismatch in radar:18726508, expected 1')
        membership = memberships[0]

        self.assertIsInstance(membership.person, Person)
        self.assertEqual(membership.person.dsid, 299156498)
        self.assertEqual(membership.person.email, "liyanage@apple.com")
        self.assertEqual(membership.person.type, "Employee")
        self.assertEqual(membership.person.firstName, "Marc")
        self.assertEqual(membership.person.lastName, "Liyanage")

        self.assertIsInstance(membership.isProblemVisible, bool)
        self.assertEqual(membership.isProblemVisible, True)

    @skip_unless_enabled
    def test_radar_component_unicode(self):
        self.skip_if_not_marc()
        with self.assertRaises(radarclient.RadarAccessDeniedResponseException) as exception_info:
            radar = self.client.radar_for_id(29857517)
        self.assertIn('You do not have enough privileges to view the problem', compat.unicode_string_type(exception_info.exception))

    @skip_unless_enabled
    def test_non_success_response_no_payload_data(self):
        self.skip_if_not_marc()
        csi = radarclient.ClientSystemIdentifier('python-radarclient-unittest-script', radarclient.__version__, _unit_test_override_name_checks=True)
        client = RadarClient(self.authentication_strategy_spnego(), csi)
        with self.assertRaises(radarclient.RadarAccessDeniedResponseException) as exception_info:
            radar = client.radar_for_id(29857517)
        self.assertIn('Non-2xx/success response code 403', compat.unicode_string_type(exception_info.exception))

    @skip_unless_enabled
    def test_change_radar(self):
        self.skip_if_not_marc()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertEqual(radar.title, u'test \u2192 bug')
        self.assertEqual(radar.priority, 5)

        datestring = '2013-10-01'
        datevalue = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring)
        self.assertEqual(len(radar.change_records), 0)
        radar.targetStartDate = datevalue
        self.assertEqual(len(radar.change_records), 1)

        datestring2 = '2013-10-12'
        datevalue2 = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring2)
        radar.targetCompletionCurrent = datevalue2

        self.assertEqual(len(radar.change_records), 2)

        radar.priority = 5
        radar.commit_changes()

        self.assertEqual(len(radar.change_records), 0)
        radar.priority = 4
        self.assertEqual(radar.priority, 4)
        self.assertEqual(len(radar.change_records), 1)
        radar.commit_changes()
        self.assertEqual(len(radar.change_records), 0)

        radar.priority = 5
        self.assertEqual(radar.priority, 5)
        self.assertEqual(len(radar.change_records), 1)
        self.assertEqual(radar.targetStartDate, datevalue)
        self.assertEqual(radar.targetCompletionCurrent, datevalue2)

        datestring = '2014-10-01'
        datevalue = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring)
        radar.targetStartDate = datevalue

        self.assertEqual(len(radar.change_records), 2)

        datestring2 = '2014-10-12'
        datevalue2 = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring2)
        radar.targetCompletionCurrent = datevalue2

        self.assertEqual(len(radar.change_records), 3)

        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertEqual(radar.targetStartDate, datevalue)
        self.assertEqual(radar.targetCompletionCurrent, datevalue2)

        datestring = '2013-10-01'
        datevalue = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring)
        radar.targetStartDate = datevalue

        datestring2 = '2013-10-12'
        datevalue2 = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring2)
        radar.targetCompletionCurrent = datevalue2

        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['targetStartDate', 'targetCompletionCurrent'])
        self.assertEqual(radar.targetStartDate, datevalue)
        self.assertEqual(radar.targetCompletionCurrent, datevalue2)

    @skip_unless_enabled
    def test_radar_protocol_version(self):
        v1_1 = radarclient.RadarProtocolVersion('1.1')
        v2_1 = radarclient.RadarProtocolVersion('2.1')
        pre_release = radarclient.RadarProtocolVersion(radarclient.RadarProtocolVersion.pre_release_string)

        self.assertEqual(str(pre_release), 'pre-release')
        self.assertEqual(str(v2_1), '2.1')
        self.assertEqual(str(v1_1), '1.1')
        self.assertLess(v1_1, v2_1)
        self.assertGreater(v2_1, v1_1)
        self.assertNotEqual(v1_1, v2_1)
        self.assertEqual(v1_1, radarclient.RadarProtocolVersion('1.1'))

        self.assertLess(v1_1, pre_release)
        self.assertGreater(pre_release, v1_1)
        self.assertNotEqual(v1_1, pre_release)

        self.assertEqual(pre_release, radarclient.RadarProtocolVersion('pre-release'))
        self.assertGreaterEqual(pre_release, radarclient.RadarProtocolVersion('2.1.1'))

        self.assertEqual(v1_1, radarclient.RadarProtocolVersion('1.1.0'))
        self.assertNotEqual(v1_1, radarclient.RadarProtocolVersion('1.1.1'))
        self.assertLess(v1_1, radarclient.RadarProtocolVersion('1.1.1'))
        self.assertGreaterEqual(radarclient.RadarProtocolVersion('2.1'), v2_1)
        self.assertGreaterEqual(radarclient.RadarProtocolVersion('2.1.1'), v2_1)
        self.assertGreater(radarclient.RadarProtocolVersion('2.1.1'), v2_1)
        self.assertGreater(v2_1, radarclient.RadarProtocolVersion('2.0.2'))
        self.assertGreater(radarclient.RadarProtocolVersion('2.2'), v2_1)
        self.assertGreaterEqual(radarclient.RadarProtocolVersion('3.0'), v2_1)
        self.assertLessEqual(v2_1, radarclient.RadarProtocolVersion('3.0'))
        self.assertEqual(v1_1, radarclient.RadarProtocolVersion('1.1'))

    @skip_unless_enabled
    def test_person(self):
        radar = self.client.radar_for_id(11725080)
        self.assertIsInstance(radar.originator, Person)
        self.assertEqual(radar.originator.dsid, 299156498)

    @skip_unless_enabled
    def test_date_valueconverter(self):
        # datestring = '2012-10-08T01:46:36+0000'
        # datestring = '2012-11-07T08:06:48+0000'
        datestring = '2013-01-08T01:00:00+0000'
        datevalue = radarclient.model.ISO8601UTCDateValueConverter.decode_radar_value(datestring)
        self.assertIsNotNone(datevalue.tzinfo)
        self.assertEqual(datevalue.isoformat(), '2013-01-08T01:00:00+00:00')

        localdate = datevalue.astimezone(radarclient.model.ISO8601UTCDateValueConverter.local)
        self.assertTrue(localdate.isoformat() == '2013-01-07T18:00:00-07:00' or localdate.isoformat() == '2013-01-07T17:00:00-08:00')
        self.assertEqual(str(datevalue.date()), '2013-01-08')
        self.assertEqual(str(localdate.date()), '2013-01-07')

        datestring = '2013-01-08'
        datevalue = radarclient.model.ISO8601DateOnlyValueConverter.decode_radar_value(datestring)
        self.assertEqual(datevalue.isoformat(), datestring)

    @skip_unless_enabled
    def test_find_people(self):
        people_list = self.client.find_people(firstName='Marc', lastName='Liyanage')
        self.assertEqual(len(people_list), 1)
        self.assertEqual(people_list[0].dsid, 299156498)
        people_list = self.client.find_people(email='liyanage@apple.com')
        self.assertEqual(len(people_list), 1)
        self.assertEqual(people_list[0].dsid, 299156498)

        # Test with invalid
        people_list = self.client.find_people(email='sadihjbacdk@aol.com')
        self.assertEqual([], people_list)

        # This test is a bit shaky but it assumes there will always be someone named John
        test_name = 'John'
        people_list_name_only = self.client.find_people(firstName=test_name)
        people_list_internal = self.client.find_people(firstName=test_name, type='Internal')
        people_list_external = self.client.find_people(firstName=test_name, includeExternal=True)
        self.assertGreater(len(people_list_external), len(people_list_internal))
        self.assertEqual(len(people_list_name_only), len(people_list_external))

    @skip_unless_enabled
    def test_find_people_dsids(self):
        people_list = self.client.find_people(dsids=[299156498, 2700804558], type='Internal')
        self.assertEqual(len(people_list), 1)
        self.assertEqual(people_list[0].email, 'liyanage@apple.com')

        people_list = self.client.find_people(dsids=[299156498, 2700804558])
        self.assertEqual(len(people_list), 2)
        self.assertEqual(people_list[0].email, 'liyanage@apple.com')
        self.assertEqual(people_list[1].email, 'pythonradarclient_system@apple.com')

        people_list = self.client.find_people(dsids=[299156498, 2700804558], type='All')
        self.assertEqual(len(people_list), 2)
        self.assertEqual(people_list[0].email, 'liyanage@apple.com')
        self.assertEqual(people_list[1].email, 'pythonradarclient_system@apple.com')

        people_list = self.client.find_people(dsids=[299156498, 9999999999])
        self.assertEqual(len(people_list), 1)
        self.assertEqual(people_list[0].email, 'liyanage@apple.com')

    @skip_unless_enabled
    def test_change_person(self):
        self.skip_if_not_marc()
        radar = self.client.radar_for_id(11725080)
        assignee = radar.assignee
        self.assertEqual(assignee.dsid, 299156498, msg='Unexpected assignee in radar:11725080')

        people_list = self.client.find_people(email='pythonradarclient_system@apple.com', includeExternal=True)
        self.assertEqual(len(people_list), 1)
        new_assignee = people_list[0]
        self.assertEqual(new_assignee.dsid, 2700804558)
        radar.assignee = new_assignee
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(radar.assignee.dsid, 2700804558)

        new_assignee = Person({'dsid': 299156498})
        radar.assignee = new_assignee
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(radar.assignee.dsid, 299156498)

    @skip_unless_enabled
    def test_change_person_and_milestone_using_query_result_objects(self):
        for default_component in TestConfiguration.default_components():
            self._test_change_person_and_milestone_using_query_result_objects(default_component)

    def _test_change_person_and_milestone_using_query_result_objects(self, component):
        self.skip_if_not_marc()
        new_radar_data = {
            'title': 'test_change_person_and_milestone_using_query_result_objects test bug',
            'component': component,
            'description': 'test_change_person_and_milestone_using_query_result_objects test bug',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }

        radar = self.client.create_radar(new_radar_data)
        new_radar_id = radar.id

        component, = self.client.find_components({'id': 515346})
        milestones = self.client.milestones_for_component(component)
        radar.milestone = milestones[0]

        radar.commit_changes()

        radar = self.client.radar_for_id(new_radar_id)
        self.assertEqual(radar.milestone.name, milestones[0].name)

        person = Person({'dsid': 1405889817})
        radar.assignee = person
        radar.commit_changes()

        radar = self.client.radar_for_id(new_radar_id)
        self.assertEqual(radar.assignee.dsid, 1405889817)

        radar.state = 'Verify'
        radar.resolution = 'Not Applicable'
        radar.commit_changes()

        radar.state = 'Closed'
        radar.commit_changes()

    @skip_unless_enabled
    def test_change_dri(self):
        self.skip_if_not_marc()
        radar = self.client.radar_for_id(11725080)
        dri = radar.dri
        self.assertEqual(dri, None, msg='Unexpected non-None DRI in radar:11725080')

        people_list = self.client.find_people(email='pythonradarclient_system@apple.com', includeExternal=True)
        self.assertEqual(len(people_list), 1)
        new_dri = people_list[0]
        self.assertEqual(new_dri.dsid, 2700804558)
        radar.dri = new_dri
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(radar.dri.dsid, 2700804558)

        new_dri = None
        radar.dri = new_dri
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(radar.dri, None)

    @skip_unless_enabled
    def test_load_description(self):
        radar = self.client.radar_for_id(11725080)
        items = list(radar.description.items())
        self.assertTrue(len(items) > 0)
        self.assertIsInstance(items[0].addedBy, radarclient.model.CommentAuthor)

        radar = self.client.radar_for_id(11725080, additional_fields=["description"])
        items = list(radar.description.loaded_items)
        self.assertTrue(len(items) > 0)
        self.assertIsInstance(items[0].addedBy, radarclient.model.CommentAuthor)

    @unittest.skip('enable when needed, skipping to avoid accumulating garbage in test bug')
    @skip_unless_enabled
    def test_add_description_entry(self):
        radar = self.client.radar_for_id(11725080)
        items = list(radar.description.items())
        old_len = len(items)
        entry = radarclient.model.DescriptionEntry()
        entry.text = u'\u2192 new entry from unit test 1/2'
        radar.description.add(entry)
        # Instantiate using dictionary_representation directly
        radar.description.add(radarclient.model.DescriptionEntry({'text': u'\u2192 new entry from unit test 2/2'}))
        items = list(radar.description.items())
        new_len = len(items)
        self.assertEqual(new_len, old_len + 2)
        self.assertEqual(items[-1].text, u'\u2192 new entry from unit test 2/2')

        radar.commit_changes()

        radar = self.client.radar_for_id(11725080)
        items = list(radar.description.items())
        new_len = len(items)
        self.assertEqual(new_len, old_len + 2)
        self.assertEqual(items[-1].text, u'\u2192 new entry from unit test 2/2')
        self.assertIsNotNone(items[-1].addedBy.name)

    @skip_unless_enabled
    def test_load_diagnosis(self):
        self.client.clear_radar_cache()

        initial_request_count = self.client.sent_request_count
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(self.client.sent_request_count, initial_request_count + 1)
        items = radar.diagnosis.items()
        self.assertEqual(self.client.sent_request_count, initial_request_count + 2)

        radar = self.client.radar_for_id(11725080, additional_fields=["diagnosis"])
        self.assertEqual(self.client.sent_request_count, initial_request_count + 3)
        items = radar.diagnosis.items()
        self.assertEqual(self.client.sent_request_count, initial_request_count + 3)
        count_preloaded = len(items)
        self.assertTrue(count_preloaded > 0)

        items = radar.diagnosis.items(type='all')
        self.assertEqual(self.client.sent_request_count, initial_request_count + 4)
        count_items_all = len(items)
        self.assertTrue(count_items_all > count_preloaded)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(self.client.sent_request_count, initial_request_count + 5)
        items = radar.diagnosis.items(type='all')
        self.assertEqual(self.client.sent_request_count, initial_request_count + 6)
        count_1 = len(items)
        items = radar.diagnosis.items(type='user')
        self.assertEqual(self.client.sent_request_count, initial_request_count + 7)
        count_2 = len(items)
        self.assertGreater(count_1, count_2, u'count of "all" type diagnosis items ({}) not larger than type "user" ({}) as expected in radar:11725080'.format(count_1, count_2))
        self.assertGreater(count_2, 0, u'count of "user" type diagnosis items not > 0'.format())

        self.assertIsInstance(items[0].addedBy, radarclient.model.CommentAuthor)
        self.assertEqual(items[0].addedBy.name, 'Marc Liyanage')
        self.assertEqual(items[0].addedBy.email, 'liyanage@apple.com')

        self.assertIsInstance(items[0].addedBy, radarclient.model.CommentAuthor)
        self.assertEqual(items[0].addedBy.name, 'Marc Liyanage')
        self.assertEqual(items[0].addedBy.email, 'liyanage@apple.com')

        radar = self.client.radar_for_id(11725080, additional_fields=["diagnosis"])
        self.assertEqual(self.client.sent_request_count, initial_request_count + 8)
        items = list(radar.diagnosis.loaded_items)
        self.assertTrue(len(items) > 0)
        self.assertIsInstance(items[0].addedBy, radarclient.model.CommentAuthor)

    @unittest.skip('enable when needed, skipping to avoid accumulating garbage in test bug')
    @skip_unless_enabled
    def test_add_diagnosis_entry(self):
        radar = self.client.radar_for_id(11725080)
        items = list(radar.diagnosis.items(type='user'))
        old_len = len(items)
        print(old_len)
        entry = radarclient.model.DiagnosisEntry()
        entry.text = u'\u2192 new entry from unit test 1/2'
        radar.diagnosis.add(entry)
        # Instantiate using the text parameter directly
        radar.diagnosis.add(radarclient.model.DiagnosisEntry(text=u'\u2192 new entry from unit test 2/2'))
        items = list(radar.diagnosis.items(type='user'))
        new_len = len(items)
        self.assertEqual(new_len, old_len + 2)
        self.assertEqual(items[-1].text, u'\u2192 new entry from unit test 2/2')

        radar.commit_changes()
        self.client.clear_radar_cache()

        radar = self.client.radar_for_id(11725080)
        items = list(radar.diagnosis.items(type='user'))
        new_len = len(items)
        expected = old_len + 2
        self.assertEqual(new_len, expected, 'Unexpected diagnosis item count, expected {}, got {}'.format(expected, new_len))
        self.assertEqual(items[-1].text, u'\u2192 new entry from unit test 2/2')
        self.assertIsNotNone(items[-1].addedBy.name)

    @unittest.skip('enable when needed, skipping to avoid accumulating garbage in test bug')
    @skip_unless_enabled
    def test_add_diagnosis_entry_with_mentions(self):
        radar = self.client.radar_for_id(11725080)
        items = list(radar.diagnosis.items(type='user'))
        old_len = len(items)
        print(old_len)
        marc = self.client.person_for_dsid(299156498)
        _entry_text = u'\u2192 Adding a new entry with an @ Mention for {} from unit test 1/1'.format(marc.mention())
        entry = radarclient.model.DiagnosisEntry()
        entry.text = _entry_text
        radar.diagnosis.add(entry)
        items = list(radar.diagnosis.items(type='user'))
        new_len = len(items)
        self.assertEqual(new_len, old_len + 1)
        self.assertEqual(items[-1].text, _entry_text)

        radar.commit_changes()
        self.client.clear_radar_cache()

        radar = self.client.radar_for_id(11725080, additional_fields=['mentions'])
        items = list(radar.diagnosis.items(type='user'))
        new_len = len(items)
        expected = old_len + 1
        self.assertEqual(new_len, expected, 'Unexpected diagnosis item count, expected {}, got {}'.format(expected, new_len))
        latest_entry = items[-1]
        latest_mention = sorted(radar.mentions, key=lambda l: l.mentionedTimeStamp)[-1]
        self.assertEqual(latest_entry.text, _entry_text)
        (self.assertEqual(latest_entry.addedAt, latest_mention.mentionedTimeStamp),
            "Latest entry.addedAt ({}) and latest mention.mentionedTimeStamp ({}) don't match!".format(
                latest_entry.addedAt, latest_mention.mentionedTimeStamp))

    @skip_unless_enabled
    def test_load_enclosures(self):
        radar = self.client.radar_for_id(11725080)

        pictures = list(radar.pictures.items())
        self.assertIsInstance(pictures[0], radarclient.model.Picture)
        self.assertEqual(pictures[0].fileName, u'Some screenshot \u2602')
        url = radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url')
        self.assertEqual(pictures[0].content_url(), '{}/problems/11725080/pictures/Some%20screenshot%20%E2%98%82'.format(url))
        content = pictures[0].content()
        self.assertEqual(hashlib.md5(content).hexdigest(), '60d39f367eced38e4599a0ed618434a4')
        self.assertEqual(pictures[0].fileSize, len(content))

        attachments = list(radar.attachments.items())
        self.assertIsInstance(attachments[0], radarclient.model.Attachment)
        self.assertEqual(attachments[0].fileName, u'enclosure test/foo\u2602.txt')
        self.assertEqual(attachments[0].fileId, 'ATTACHMENT/PROBLEM/0000/1172/5080/023ABD6CFB5FA882F4F43781C228F2FC')
        self.assertEqual(attachments[0].addedBy.dsid, 299156498)
        # Expected to fail for now: <rdar://problem/34478551> fileId value for attachment changed for existing Radar/attachment
        self.assertEqual(attachments[0].addedAt.isoformat(), '2012-10-25T21:38:53+00:00')
        url = radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url')
        self.assertEqual(attachments[0].content_url(), '{}/problems/11725080/attachments/enclosure%20test/foo%E2%98%82.txt'.format(url))
        content = attachments[0].content()
        self.assertEqual(attachments[0].fileSize, len(content))
        self.assertEqual(hashlib.md5(content).hexdigest(), 'd3b07384d113edec49eaa6238ad5ff00')
        self.assertEqual(content, b'foo\n')

    @skip_unless_enabled
    def test_load_enclosures2(self):
        radar = self.client.radar_for_id(11725080)
        attachments = list(radar.attachments.items())
        self.assertIsInstance(attachments[0], radarclient.model.Attachment)
        with open('/tmp/radar-attachment-test.out', 'wb') as f:
            attachments[0].write_to_file(f)

    @skip_unless_enabled
    def test_download_enclosure_archive(self):
        radar = self.client.radar_for_id(11725080)
        archive_enclosure = radar.attachment_archive_download_enclosure()
        self.assertIsInstance(archive_enclosure,
                              radarclient.model.RadarAttachmentArchiveEnclosure)
        with open('/tmp/radar-attachment-test.out', 'wb') as f:
            archive_enclosure.write_to_file(f)

    @skip_unless_enabled
    def test_read_file_wrapper_description(self):
        radar = self.client.radar_for_id(11725080)
        new_enclosure = radar.new_attachment('enclosure test/foo.txt')

        filename = u'/tmp/foo\u2602.txt'
        with open(filename, 'w') as f:
            pass

        with open(filename) as f:
            wrapper = radarclient.EnclosureBase.ReadProgressReportingFileWrapper(new_enclosure, f)
            string = '{}'.format(wrapper)
            self.assertEqual(string, '<ReadProgressReportingFileWrapper wrapping file handle "/tmp/foo\u2602.txt" for enclosure "enclosure test/foo.txt">')

            new_enclosure.set_upload_file(f)
            radar.attachments.add(new_enclosure)

            with self.assertRaises(Exception) as exception_info:
                radar.commit_changes()
            expected_assertion_message = 'Upload_content/upload_file not set for enclosure (None/<ReadProgressReportingFileWrapper wrapping file handle "/tmp/foo\u2602.txt" for enclosure "enclosure test/foo.txt">). Check for zero-length file.'
            self.assertEqual(expected_assertion_message, compat.unicode_string_type(exception_info.exception))

    @skip_unless_enabled
    def test_add_enclosures(self):
        radar = self.client.radar_for_id(11725080)

        # Verify initial state, to clean up after previously interrupted runs
        if len(list(radar.pictures.items())) == 2:
            picture = radar.new_picture('Mt. Fuji.jpg')
            radar.pictures.delete(picture)
            radar.commit_changes()
            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(11725080)

        if len(list(radar.attachments.items())) == 2:
            attachment = radar.new_attachment('enclosure test 2/bar.txt')
            radar.attachments.delete(attachment)
            radar.commit_changes()
            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(11725080)

        self.assertEqual(len(list(radar.attachments.items())), 1)
        self.assertEqual(len(list(radar.pictures.items())), 1)

        # Attachment enclosures
        attachment = radar.new_attachment('enclosure test 2/bar.txt')
        attachment.upload_should_reset_read_by_assignee = False
        attachment.set_upload_content(b'\x8b')
        radar.attachments.add(attachment)
        self.assertEqual(len(list(radar.attachments.items())), 2)
        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        attachments = list(radar.attachments.items())
        self.assertEqual(len(attachments), 2)

        attachment = [i for i in attachments if i.fileName == 'enclosure test 2/bar.txt'][0]
        self.assertEqual(attachment.fileName, 'enclosure test 2/bar.txt')

        # These three won't work as expected when using SPNego authentication,
        # see <rdar://problem/12504133> Radar Web Service - adding attachments have wrong 'Enclosed by'
        if not ENABLE_SPNEGO:
            self.assertEqual(attachment.addedBy.firstName, 'Marc')
            self.assertEqual(attachment.addedBy.lastName, 'Liyanage')
            self.assertEqual(attachment.addedBy.dsid, 299156498)

        attachment = radar.new_attachment('enclosure test 2/bar.txt')
        radar.attachments.delete(attachment)
        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        attachments = list(radar.attachments.items())
        self.assertEqual(len(attachments), 1)

        # Picture enclosures
        picture = radar.new_picture('Mt. Fuji.jpg')
        script_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        test_file_path = os.path.join(os.path.dirname(os.path.dirname(script_path)), 'extras/Mt. Fuji.jpg')
        with open(test_file_path, 'rb') as f:
            picture.set_upload_content(f.read())
        radar.pictures.add(picture)
        self.assertEqual(len(list(radar.pictures.items())), 2)
        radar.commit_changes()
        self.assertEqual(len(list(radar.pictures.items())), 2)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(len(list(radar.pictures.items())), 2)

        picture = radar.new_picture('Mt. Fuji.jpg')
        radar.pictures.delete(picture)
        self.assertEqual(len(list(radar.pictures.items())), 2)
        radar.commit_changes()
        self.assertEqual(len(list(radar.pictures.items())), 1)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        self.assertEqual(len(list(radar.pictures.items())), 1)

    def _test_get_radar_without_attachments(self, radar_id):
        radar = self.client.radar_for_id(radar_id)
        if len(radar.attachments.items()) > 0:
            for attachment in radar.attachments.items():
                radar.attachments.delete(attachment)
            radar.commit_changes()
            del radar
            self.client.clear_radar_cache()
            time.sleep(0.3)  # Brief delay to let changes propagate
            radar = self.client.radar_for_id(radar_id)
            num_attachments = len(radar.attachments.items())
            assert num_attachments == 0, "rdar://{} has too many attachments {}".format(radar_id, num_attachments)
        return radar

    def _create_source_attachments_on_radar(self, radar, count=1):
        for i in range(count):
            suffix = '_{}'.format(i+1) if i > 0 else ''
            new_attachment = radar.new_attachment('linked{}.txt'.format(suffix))
            # new_attachment_bytes = bytearray('This is a text file created by the python-radarclient.\n',
            #                                  encoding='utf-8')
            new_attachment.set_upload_content('This is a text file created by the python-radarclient.\n'.encode())
            new_attachment.upload_should_reset_read_by_assignee = False
            radar.attachments.add(new_attachment)
        radar.commit_changes()

    def _validate_linked_atts(self, source_radar_id, target_radar_id):
        self.client.clear_radar_cache()
        time.sleep(0.5)
        source_radar = self.client.radar_for_id(source_radar_id)
        target_radar = self.client.radar_for_id(target_radar_id)
        # Check that the target Radar has one LinkedAttachment from the source Radar
        self.assertEqual(len(target_radar.attachments.items()), 1)
        valid_linked_att = None
        for s_att in target_radar.attachments.items():
            self.assertIsInstance(s_att, LinkedAttachment)
            self.assertEqual(len(s_att.links), 0)
            self.assertIsInstance(s_att.sourceFile, AttachmentLink)
            self.assertEqual(s_att.sourceFile.linked_radar_id, source_radar_id)
            valid_linked_att = s_att
        # Check that the source Radar has one attachment that is linked to the target Radar
        self.assertEqual(len(source_radar.attachments.items()), 1)
        valid_source_att = None
        for l_att in source_radar.attachments.items():
            self.assertIsInstance(l_att, Attachment)
            self.assertEqual(len(l_att.links), 1)
            self.assertIsInstance(l_att.links[0], AttachmentLink)
            self.assertEqual(l_att.links[0].linked_radar_id, target_radar_id)
            valid_source_att = l_att
        self.assertIsNotNone(valid_source_att)
        return source_radar, target_radar, valid_source_att, valid_linked_att

    @skip_unless_enabled
    def test_link_unlink_attachments_from_source(self):
        source_radar_id = 147359038
        target_radar_id = 147359058
        # Retrieve the test Radars, removing all attachments (if any)
        source_radar = self._test_get_radar_without_attachments(source_radar_id)
        target_radar = self._test_get_radar_without_attachments(target_radar_id)
        # Create the new, real attachment on the source Radar
        self._create_source_attachments_on_radar(source_radar)
        # Link the new attachment to the target Radar from the source Radar
        valid_att = None
        for att in source_radar.attachments.items():
            if att.fileName == "linked.txt":
                valid_att = att
                break
        assert valid_att, "The expected attachment was not found on rdar://{}".format(source_radar_id)
        new_link = AttachmentLink(
            attachment=valid_att,
            type=AttachmentLink.ATTACHMENT_TYPE_SOURCE,
            radar=source_radar,
            linked_radar=target_radar
        )
        source_radar.attachments.link(new_link)
        source_radar.commit_changes()
        # Refresh the test radars & validate the expected attachment types/counts
        del source_radar
        del target_radar
        source_radar, target_radar, valid_source_att, _ = self._validate_linked_atts(source_radar_id, target_radar_id)
        # Unlink by deleting the attachment from the source Radar
        source_radar.attachments.delete(valid_source_att)
        source_radar.commit_changes()
        # Refresh the test radars again
        del source_radar
        del target_radar
        self.client.clear_radar_cache()
        time.sleep(0.5)
        source_radar = self.client.radar_for_id(source_radar_id)
        target_radar = self.client.radar_for_id(target_radar_id)
        # Ensure both Radars have zero attachments
        self.assertEqual(len(source_radar.attachments.items()), 0)
        self.assertEqual(len(target_radar.attachments.items()), 0)

    @skip_unless_enabled
    def test_link_unlink_attachments_from_destination(self):
        source_radar_id = 147359038
        target_radar_id = 147359058
        # Retrieve the test Radars, removing all attachments (if any)
        source_radar = self._test_get_radar_without_attachments(source_radar_id)
        target_radar = self._test_get_radar_without_attachments(target_radar_id)
        # Create the new, real attachment on the source Radar
        self._create_source_attachments_on_radar(source_radar)
        # Create a new LinkedAttachment on the target Radar
        new_attachment = target_radar.new_attachment('linked.txt')
        new_link = AttachmentLink(
            attachment=new_attachment,
            type=AttachmentLink.ATTACHMENT_TYPE_LINKED,
            radar=target_radar,
            linked_radar=source_radar
        )
        target_radar.attachments.link(new_link)
        target_radar.commit_changes()
        # Refresh the test radars & validate the expected attachment types/counts
        del source_radar
        del target_radar
        source_radar, target_radar, valid_source_att, valid_linked_att = self._validate_linked_atts(source_radar_id,
                                                                                                    target_radar_id)
        # Unlink the LinkedAttachment via the target Radar
        target_radar.attachments.unlink(valid_linked_att.sourceFile)
        target_radar.commit_changes()
        # Refresh the target radar again and validate attachment count
        del target_radar
        self.client.clear_radar_cache()
        time.sleep(0.5)
        target_radar = self.client.radar_for_id(target_radar_id)
        self.assertEqual(len(target_radar.attachments.items()), 0)
        # Delete the source attachment on the source Radar
        source_radar.attachments.delete(valid_source_att)
        source_radar.commit_changes()
        # Refresh the target radar again and validate attachment count
        del source_radar
        self.client.clear_radar_cache()
        time.sleep(0.5)
        source_radar = self.client.radar_for_id(source_radar_id)
        self.assertEqual(len(source_radar.attachments.items()), 0)

    @skip_unless_enabled
    def test_link_unlink_all_attachments(self):
        source_radar_id = 147359038
        target_radar_id = 147359058
        # Retrieve the test Radars, removing all attachments (if any)
        source_radar = self._test_get_radar_without_attachments(source_radar_id)
        target_radar = self._test_get_radar_without_attachments(target_radar_id)
        # Create three new, real attachments on the source Radar
        self._create_source_attachments_on_radar(source_radar, 2)
        # Link all attachments from the source Radar to the target Radar
        target_radar.link_all_attachments_from_radar_id(source_radar_id)
        target_radar.commit_changes()
        # Refresh the test radars
        del source_radar
        del target_radar
        self.client.clear_radar_cache()
        time.sleep(0.5)
        source_radar = self.client.radar_for_id(source_radar_id)
        target_radar = self.client.radar_for_id(target_radar_id)
        # Ensure both Radars have the correct # of attachments
        self.assertEqual(len(source_radar.attachments.items()), 2)
        self.assertEqual(len(target_radar.attachments.items()), 2)
        # Unlink all attachments from the target Radar
        target_radar.unlink_all_attachments_from_radar_id(source_radar_id)
        target_radar.commit_changes()
        # Refresh the target radar again and validate attachment count
        del source_radar
        del target_radar
        self.client.clear_radar_cache()
        time.sleep(0.5)
        target_radar = self.client.radar_for_id(target_radar_id)
        self.assertEqual(len(target_radar.attachments.items()), 0)
        # Remove the source Radar's attachments and verify
        source_radar = self._test_get_radar_without_attachments(source_radar_id)
        self.assertEqual(len(source_radar.attachments.items()), 0)

    @skip_unless_enabled
    def test_locked_attachments(self):
        radar = self.client.radar_for_id(138056966)
        for attachment in radar.attachments.items():
            if attachment.fileName == "locked.text":
                self.assertTrue(attachment.locked)
                # Attempt to download attachment
                with self.assertRaises(AttachmentLockedException):
                    with open('/tmp/{}'.format(attachment.fileName), 'wb') as f:
                        attachment.write_to_file(f)
                # Attempt to rename attachment
                with self.assertRaises(AttachmentLockedException):
                    attachment.fileName = "locked_with_new_name.txt"
                    radar.commit_changes()
                break

    @skip_unless_enabled
    def test_relationships(self):
        radar = self.client.radar_for_id(11725080)
        self.assertIsNone(radar.loaded_relationships)
        relationship = radar.relationships([radarclient.model.Relationship.TYPE_CLONED_TO])[0]
        self.assertIsInstance(relationship, radarclient.model.Relationship)
        self.assertEqual(relationship.radar.id, 11725080)
        self.assertEqual(relationship.related_radar_id, 12595023)
        self.assertEqual(relationship.type, radarclient.model.Relationship.TYPE_CLONED_TO)
        related = radar.related_radars([radarclient.model.Relationship.TYPE_CLONED_TO])[0]
        self.assertEqual(related.id, 12595023)

        relationship = related.relationships()[0]
        self.assertEqual(relationship.related_radar.id, 11725080)
        self.assertEqual(relationship.type, radarclient.model.Relationship.TYPE_CLONE_OF)
        radar2 = relationship.related_radar
        self.assertEqual(id(radar), id(radar2))

        self.assertEqual([len(i) for i in radar.all_relationships()], [1, 2, 3, 1, 2, 3])
        self.assertEqual([len(i) for i in radar.all_unique_relationships()], [1, 2, 3])

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080)
        relationships = radar.relationships(load_related_radars=False)
        for relationship in relationships:
            self.assertIsNone(relationship.related_radar)

    @skip_unless_enabled
    def test_all_relationships_default_error_callback(self):
        class RelationshipTraversalDelegate(object):
            def should_follow_relationship(self, relationship):
                return relationship.type == Relationship.TYPE_ORIGINAL_OF

            def traversal_progress(self, processed_radar_count, total_radar_count):
                pass

        test_id = 105843488
        radar = self.client.radar_for_id(test_id)
        chains = radar.all_relationships(delegate=RelationshipTraversalDelegate())

        for chain in chains:
            print(chain)

    @skip_unless_enabled
    def test_relationship_loading_with_related_problems(self):
        radar_id = 11725080
        radar = self.client.radar_for_id(radar_id, additional_fields=['relatedProblems'])
        self.assertEqual(2, len(radar.loaded_relationships))

        radar.relationships()
        for relationship in radar.loaded_relationships:
            self.assertIsNotNone(relationship.related_radar)

    @skip_unless_enabled
    def test_add_relationship(self):
        radar_id = 12676561
        radar = self.client.radar_for_id(radar_id)
        relationships = radar.relationships([radarclient.model.Relationship.TYPE_PARENT_OF])
        self.assertListEqual(relationships, [], 'Unexpected existing relationships in radar:{}'.format(radar_id))

        radar2 = self.client.radar_for_id(12676568)
        relationships = radar.relationships([radarclient.model.Relationship.TYPE_SUBTASK_OF])
        self.assertListEqual(relationships, [])

        relationship = radarclient.model.Relationship(radarclient.model.Relationship.TYPE_PARENT_OF, radar, radar2)
        radar.add_relationship(relationship)
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        fetched_relationships = radar.relationships([radarclient.model.Relationship.TYPE_PARENT_OF])
        self.assertEqual(1, len(fetched_relationships), 'Unexpected relationship count in radar:{}'.format(radar_id))
        fetched_relationship = fetched_relationships[0]
        self.assertEqual(relationship, fetched_relationship)

        radar.delete_relationship(relationship)
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        radar = self.client.radar_for_id(radar_id)
        relationships = radar.relationships([radarclient.model.Relationship.TYPE_PARENT_OF])
        self.assertListEqual([], relationships, 'Unexpected relationships in radar:{}'.format(radar_id))

    @skip_unless_enabled
    def test_add_already_related(self):
        for default_component in TestConfiguration.default_components():
            self._test_add_already_related(default_component)

    def _test_add_already_related(self, component):
        """
        Test change for rdar://86643343 (Client should not throw an error for response code 304 (Not Modified))

        :return: None
        """
        existing_radar_id = 73723257
        existing_radar = self.client.radar_for_id(existing_radar_id)

        data = {
            'title': u'test relationship radar',
            'component': component,
            'description': u'new test radar to relate',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }
        created_radar = self.client.create_radar(data)

        relationship = radarclient.model.Relationship(
            radarclient.model.Relationship.TYPE_RELATED_TO, existing_radar, created_radar
        )
        created_radar.add_relationship(relationship)
        created_radar.commit_changes()

        # Add the same relationship again
        created_radar.add_relationship(relationship)
        created_radar.commit_changes()

        # Validate an actual error still raises
        dupe_relationship = radarclient.model.Relationship(
            radarclient.model.Relationship.TYPE_DUPLICATE_OF, existing_radar, created_radar
        )
        created_radar.add_relationship(dupe_relationship)
        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
            created_radar.commit_changes()

    @skip_unless_enabled
    def load_related_radars(self):
        radar = self.client.radar_for_id(11725080)
        relationships = radar.relationships()  # noqa

    @skip_unless_enabled
    def test_ultimate_original(self):
        original_id = 67215546
        middle_id = 68690503
        ultimate_original_id = 69048502

        # Test from bottom of dupe chain
        starting_radar = self.client.radar_for_id(original_id)
        middle_radar = self.client.radar_for_id(middle_id)
        ending_radar = self.client.radar_for_id(ultimate_original_id)

        ultimate_original_radar = starting_radar.ultimate_original()
        self.assertEqual(ending_radar, ultimate_original_radar)

        # Test from bottom with additional_fields
        ultimate_original_radar = starting_radar.ultimate_original(additional_fields=['recentAssignees'])
        self.assertEqual(ending_radar, ultimate_original_radar)
        self.assertIsNotNone(ultimate_original_radar.recentAssignees)

        # Test from middle
        ultimate_original_radar = middle_radar.ultimate_original()
        self.assertEqual(ending_radar, ultimate_original_radar)

        # Test from original
        ultimate_original_radar = ending_radar.ultimate_original()
        self.assertEqual(ending_radar, ultimate_original_radar)

        # Test from original with additional_fields
        ultimate_original_radar = ending_radar.ultimate_original(additional_fields=['recentAssignees'])
        self.assertEqual(ending_radar, ultimate_original_radar)
        self.assertIsNotNone(ultimate_original_radar.recentAssignees)

        # Test no access to original
        no_access_original_id = 36712361
        no_access_radar = self.client.radar_for_id(no_access_original_id)
        with self.assertRaises(radarclient.exceptions.RadarAccessDeniedResponseException):
            no_access_radar.ultimate_original()

        # Test dupe more than 10 levels deep
        expected_original = self.client.radar_for_id(98854732)
        ten_deep_start = self.client.radar_for_id(98593240)

        self.assertEqual(ten_deep_start.ultimate_original(), expected_original)

    @skip_unless_enabled
    def test_authenticated_request_webcookie(self):
        self.skip_if_not_marc()
        try:
            client = self.authenticated_radar_client_webcookie()
            radars = client.radars_for_ids([12179571, 11725080])
            self.assertEqual(len(radars), 2)
        except Exception as e:
            if 'this account is configured to use a YubiKey' in compat.unicode_string_type(e):
                self.skipTest('Skipping WebCookie-based test for account that uses YubiKey')

        client = None
        try:
            client = self.authenticated_radar_client_webcookie()
        except Exception as e:
            if 'This account is configured to use a YubiKey' in compat.unicode_string_type(e):
                self.skipTest('Skipping test incompatible with AppleConnect account using YubiKey')
            raise e

        radars = client.radars_for_ids([12179571, 11725080])
        self.assertEqual(len(radars), 2)

    @skip_unless_enabled
    def test_authenticated_request_oidc(self):
        self.check_appleconnect_oidc_environment_variables()
        self.skip_if_not_marc()
        try:
            client = self.authenticated_radar_client_oidc()
            radars = client.radars_for_ids([12179571, 11725080])
            self.assertEqual(len(radars), 2)
        except Exception as e:
            if 'this account is configured to use a YubiKey' in compat.unicode_string_type(e):
                self.skipTest('Skipping OIDC-based test for account that uses YubiKey')

    @skip_unless_enabled
    def test_authenticated_request_spnego(self):
        self.skip_if_not_marc()
        if AuthenticationStrategySPNego.available():
            client = self.authenticated_radar_client_spnego()
            radars = client.radars_for_ids([12179571, 11725080])
            self.assertEqual(len(radars), 2)

    @skip_unless_enabled
    def test_escape_hatch_methods(self):
        radar_id = 28374491
        problem_history_url = self.client.webservice_url_for_path_components('problems', radar_id, 'history')
        request = self.client.request_for_json_url(problem_history_url)
        response_status, response_data = self.client.send_request(request)
        self.assertTrue(radarclient.utilities.response_code_is_success(response_status))
        self.assertGreater(len(response_data), 0)

    @skip_unless_enabled
    def test_escape_hatch_methods_post(self):
        self.skip_if_not_marc()
        request_data = {
            'problemIDs': [28374491],
            'priority': 2
        }
        request_json = json.dumps(request_data)
        modify_url = self.client.webservice_url_for_path_components('problems', 'modify')
        request = self.client.request_for_json_url(modify_url, json_string=request_json)
        response_status, response_data = self.client.send_request(request)
        self.assertTrue(radarclient.utilities.response_code_is_success(response_status))

    @skip_unless_enabled
    def test_find_radar_ids_by_id(self):
        request_data = {"id": [11725080, 11811590]}
        radar_list = self.client.find_radar_ids(request_data)
        self.assertEqual(len(radar_list), 2)

    @skip_unless_enabled
    def test_find_radar_ids_by_title_that_exists(self):
        request_data = {"title": {'eq': u'test \u2192 bug'}}
        radar_list = self.client.find_radar_ids(request_data)

        self.assertGreaterEqual(len(radar_list), 5)

    @skip_unless_enabled
    def test_find_radar_ids_by_title_that_does_not_exist(self):
        request_data = {"title": {'eq': u'fdjsafdsfsdanfadsfasdfas'}}
        radar_list = self.client.find_radar_ids(request_data)
        self.assertEqual(len(radar_list), 0)

    @skip_unless_enabled
    def test_resolved_by(self):
        self.skip_if_not_marc()
        request_data = {"id": [11725080]}

        radar_list = self.client.find_radars(request_data, additional_fields=['resolvedBy'])
        self.assertEqual(len(radar_list), 1)
        radar = radar_list[0]

        person = radar.resolvedBy
        self.assertIsInstance(person, Person)

        if person.dsid != 299156498:
            radar.resolvedBy = radarclient.Person({'dsid': 299156498})
            radar.commit_changes()
            self.client.clear_radar_cache()
            radar_list = self.client.find_radars(request_data, additional_fields=['resolvedBy'])
            self.assertEqual(len(radar_list), 1)
            radar = radar_list[0]
            person = radar.resolvedBy

        self.assertEqual(person.dsid, 299156498, msg='Unexpected resolved by person in radar:11725080')

        people_list = self.client.find_people(email='pythonradarclient_system@apple.com', includeExternal=True)
        self.assertEqual(len(people_list), 1)
        new_resolver = people_list[0]
        self.assertEqual(new_resolver.dsid, 2700804558)
        radar.resolvedBy = new_resolver
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['resolvedBy'])
        self.assertEqual(radar.resolvedBy.dsid, 2700804558)

        new_resolver = Person({'dsid': 299156498})
        radar.resolvedBy = new_resolver
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['resolvedBy'])
        self.assertEqual(radar.resolvedBy.dsid, 299156498)

    @skip_unless_enabled
    def test_build_fields_type_assertions(self):
        self.skip_if_not_marc()
        radar = self.client.radar_for_id(11725080, additional_fields=['buildInfo', 'fixedInBuild'])

        with self.assertRaises(Exception) as exception_info:
            radar.buildInfo.add(str('test'))
        self.assertEqual('Item "test" (type str) is not of expected type "NamedBuild"', str(exception_info.exception))
        with self.assertRaises(Exception) as exception_info:
            radar.fixedInBuild.add(radarclient.model.NamedBuild({'name': 'foo'}))
        self.assertEqual('Item "<Build foo>" (type NamedBuild) is not of expected type "Build"', str(exception_info.exception))

    @skip_unless_enabled
    def test_build_fields_name_only_build(self):
        self.skip_if_not_marc()
        radar = self.client.radar_for_id(11725080, additional_fields=['buildInfo', 'fixedInBuild'])

        existing_items = radar.buildInfo.items()
        if existing_items:
            for item in radar.buildInfo.items():
                radar.buildInfo.delete(item)
        radar.priority = 5
        radar.commit_changes()

        time.sleep(3)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['buildInfo', 'fixedInBuild'])
        self.assertEqual(radar.priority, 5)
        radar.priority = 4
        radar.buildInfo.add(radarclient.model.NamedBuild({'name': 'build info 1'}))
        radar.commit_changes()

        time.sleep(3)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['buildInfo', 'fixedInBuild'])
        self.assertEqual(radar.priority, 4)
        self.assertEqual([x.name for x in radar.buildInfo.items()], ['build info 1'], 'Wrong build info in radar:11725080')
        radar.priority = 5
        radar.buildInfo.delete(radar.buildInfo.items()[0])
        radar.buildInfo.add(radarclient.model.NamedBuild({'name': 'build info 2'}))
        radar.commit_changes()

        time.sleep(3)

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(11725080, additional_fields=['buildInfo', 'fixedInBuild'])
        self.assertEqual(radar.priority, 5)
        self.assertEqual([x.name for x in radar.buildInfo.items()], ['build info 2'], 'Build info mismatch in radar:11725080')

    @skip_unless_enabled
    def test_build_fields_build_with_identifier(self):
        self.skip_if_not_marc()
        id_based_build_properties = [x for x in Radar.build_attrs if x != 'buildInfo']
        component, = self.client.find_components({'id': 514369})
        builds = self.client.builds_for_component(component)
        self.assertEqual(len(builds), 2)
        build_map = {b.id: b for b in builds}

        for property_name in id_based_build_properties:
            radar = self.client.radar_for_id(11725080, additional_fields=id_based_build_properties)

            collection_property_for_property_name = getattr(radar, property_name)
            self.assertIsInstance(collection_property_for_property_name,
                                  radarclient.model.CollectionProperty)
            existing_items = collection_property_for_property_name.items()
            if existing_items:
                for item in collection_property_for_property_name.items():
                    collection_property_for_property_name.delete(item)
            radar.priority = 5
            radar.commit_changes()

            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(11725080, additional_fields=id_based_build_properties)
            collection_property_for_property_name = getattr(radar, property_name)
            self.assertEqual(radar.priority, 5)
            radar.priority = 4
            collection_property_for_property_name.add(build_map[400946])
            radar.commit_changes()

            time.sleep(3)

            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(11725080, additional_fields=id_based_build_properties)
            collection_property_for_property_name = getattr(radar, property_name)
            self.assertEqual(radar.priority, 4)
            value_names = [x.name for x in collection_property_for_property_name.items()]
            self.assertEqual(value_names, ['Test Build 1'], msg='Build field value mismatch for property {} in radar:11725080: {}'.format(property_name, value_names))
            radar.priority = 5
            collection_property_for_property_name.delete(build_map[400946])
            collection_property_for_property_name.add(build_map[400947])
            radar.commit_changes()

            time.sleep(3)

            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(11725080, additional_fields=id_based_build_properties)
            collection_property_for_property_name = getattr(radar, property_name)
            self.assertEqual(radar.priority, 5)
            items = collection_property_for_property_name.items()
            self.assertEqual(len(items), 1, msg='item count mismatch for property {} in radar:11725080'.format(property_name))
            value_names = [x.name for x in items]
            self.assertEqual([x.name for x in collection_property_for_property_name.items()], ['Test Build 2'], msg='Build field value mismatch for property {} in radar:11725080: {}'.format(property_name, value_names))

    @skip_unless_enabled
    def test_find_radars_order_by(self):
        request_data = {
            'id': [11725080, 11811590],
            'orderBy': [{'field': 'priority', 'order': 'ascending'}]
        }
        radars = self.client.find_radars(request_data, additional_fields=['history'])
        self.assertTrue(hasattr(radars[0], 'history'), 'Radar object does not have expected "history" attribute')
        self.assertIsNotNone(radars[0].history)

    @skip_unless_enabled
    def test_find_radar_count_by_ids(self):
        request_data = {"id": [11725080, 11811590]}
        radar_count = self.client.find_radar_count(request_data)
        self.assertEqual(radar_count, 2)

    @skip_unless_enabled
    def test_find_radar_count_by_title_that_exists(self):
        request_data = {"title": {'eq': u'test \u2192 bug'}}
        print(request_data['title'])
        radar_count = self.client.find_radar_count(request_data)
        expected = 5
        self.assertGreaterEqual(radar_count, expected, 'Unexpected radar count (expected {}, got {}) for query {}'.format(expected, radar_count, request_data))

    @skip_unless_enabled
    def test_find_radar_count_by_title_that_does_not_exist(self):
        request_data = {"title": {'eq': u'fdjsafdsfsdanfadsfasdfas'}}
        radar_count = self.client.find_radar_count(request_data)
        self.assertEqual(radar_count, 0)

    @skip_unless_enabled
    def test_find_component_bundle_names(self):
        self.skip_if_not_marc()
        name = 'radarclient-python'
        component_bundle_name_list = self.client.find_component_bundle_names(name)
        self.assertEqual(len(component_bundle_name_list), 1, 'item count does not match: {}'.format(component_bundle_name_list))

        name = 'radarclient spaces test'
        component_bundle_name_list = self.client.find_component_bundle_names(name)
        self.assertEqual(len(component_bundle_name_list), 1, 'item count does not match: {}'.format(component_bundle_name_list))

        name = 'radarclient fdsafdsa'
        component_bundle_name_list = self.client.find_component_bundle_names(name)
        self.assertEqual(len(component_bundle_name_list), 0)

    @skip_unless_enabled
    def test_component(self):
        component = Component(name='foo', version='bar', id=11223344)
        dict = {'name': 'foo', 'version': 'bar', 'id': 11223344}
        self.assertEqual(component.radar_encoded_representation(), dict['id'])
        component = Component(dict)
        self.assertEqual(component.radar_encoded_representation(), dict['id'])

        component2 = Component(name='foo', version='bar', id=11223344)
        self.assertEqual(component, component2)
        component3 = Component(name='foo', version='something else', id=12345678)
        self.assertNotEqual(component, component3)

    @skip_unless_enabled
    def test_component_hashing(self):
        comp1 = Component(name='A', version='B', id=1)
        comp2 = Component(name='A', version='B', id=1)
        comp3 = Component(name='C', version='D', id=3)
        comp4 = Component(name='C', version='D', id=4)

        built_dict = {c:c.name for c in (comp1, comp2, comp3)}

        self.assertEqual(built_dict, {comp1: 'A', comp3: 'C'})
        self.assertEqual(built_dict, {comp2: 'A', comp3: 'C'})

        # Name and version are not the identifiers for components!
        # Two components can have the same name and version, but be in
        # different bundle groups, or different parts of the tree.
        built_dict = {c:c.name for c in (comp1, comp2, comp3, comp4)}
        self.assertEqual(built_dict, {comp1: 'A', comp3: 'C', comp4: 'C'})

    @skip_unless_enabled
    def test_component_for_id(self):
        component = self.client.component_for_id(514369)
        self.assertIsInstance(component, radarclient.model.Component)
        self.assertEqual(component.id, 514369)
        self.assertEqual(component.name, 'python-radarclient')
        self.assertEqual(component.version, '1.0')

    @skip_unless_enabled
    def test_components_for_ids(self):
        # Use Core OS | all tree hierchy, which has several thousand components
        components = self.client.component_tree_for_component(605966, flattened_by="depth_first")
        self.assertGreaterEqual(len(components), 4000)

        # filter for accessible ones
        componentIds = [x.id for x in components if type(x) != radarclient.model.ComponentInaccessible]
        self.assertGreaterEqual(len(componentIds), 4000)
        logging.info("Looking up %d components...", len(componentIds))
        components2 = self.client.components_for_ids(componentIds)
        components2.sort(key=lambda x:x.id)
        self.assertEqual(len(componentIds), len(components2))

        logging.info("Looking up %d components (997 at a time)...", len(componentIds))
        components3 = self.client.components_for_ids(componentIds, batch_size=997)
        components3.sort(key=lambda x:x.id)
        self.assertEqual(components2, components3)

        logging.info("Looking up %d components (>limit at a time)...", len(componentIds))
        components4 = self.client.components_for_ids(componentIds, batch_size=1003)
        components4.sort(key=lambda x:x.id)
        self.assertEqual(components2, components4)

    @skip_unless_enabled
    def test_find_components(self):
        dict = {'description': 'A Python wrapper for the Radar web service API'}
        components = self.client.find_components(dict)
        self.assertEqual(len(components), 1)
        self.assertIsInstance(components[0], radarclient.model.Component)
        self.assertEqual(components[0].id, 514369)
        self.assertEqual(components[0].name, 'python-radarclient')
        self.assertEqual(components[0].version, '1.0')

    @skip_unless_enabled
    def test_component_parent(self):
        dict = {'id': 515346}
        components = self.client.find_components(dict, additional_fields=['parent', 'isRootLevel'])
        self.assertEqual(len(components), 1)
        self.assertIsInstance(components[0], radarclient.model.Component)
        self.assertEqual(components[0].id, 515346)
        self.assertEqual(components[0].name, 'python-radarclient-test bugs')
        self.assertEqual(components[0].version, '1.0')
        print(components[0].parent)

    @skip_unless_enabled
    def test_component_tree_for_component(self):
        tree = self.client.component_tree_for_component(514369)
        self.assertIsInstance(tree, radarclient.model.Component)
        self.assertGreaterEqual(len(tree.subcomponents), 5)

        traversal_list_bfs = self.client.component_tree_for_component(514369, flattened_by='breadth_first')
        self.assertIsInstance(traversal_list_bfs, list)
        self.assertEqual([x.id for x in traversal_list_bfs], [514369, 789373, 1721208, 817150, 819496, 1517554, 515346, 1703520, 618791, 1304996])

        traversal_list_dfs = self.client.component_tree_for_component(514369, flattened_by='depth_first')
        self.assertIsInstance(traversal_list_dfs, list)
        self.assertGreaterEqual(len(traversal_list_dfs), 7)
        self.assertEqual([x.id for x in traversal_list_dfs], [514369, 789373, 1721208, 817150, 819496, 1517554, 515346, 1304996, 1703520, 618791])

    @skip_unless_enabled
    def test_components_for_bundle(self):
        components = self.client.components_for_bundle(39685) # rdar://bundle/39685 (python-radarclient-test)
        self.assertGreaterEqual(len(components), 7)

    @skip_unless_enabled
    def test_components_for_bundle_group(self):
        components = self.client.components_for_bundle_group(25771) # rdar://bundlegroup/25771 (python-radarclient-test-bundle-group)
        self.assertGreaterEqual(len(components), 7)

    @skip_unless_enabled
    def test_milestones_for_component(self):
        dict = {'id': 514369}
        component, = self.client.find_components(dict)
        milestones = self.client.milestones_for_component(component)
        milestones = sorted(milestones, key=lambda l: l.id)
        self.assertEqual(len(milestones), 4, 'Milestone count mismatch in radar://component/514369'.format())

        milestones = self.client.milestones_for_component(component, include_closed=True)
        milestones = sorted(milestones, key=lambda l: l.id)
        self.assertEqual(len(milestones), 6, 'Milestone count mismatch in radar://component/514369'.format())

        self.assertIsInstance(milestones[0], radarclient.model.Milestone)
        self.assertEqual(milestones[0].id, 186625)
        self.assertEqual(milestones[0].name, 'Test Milestone 1')
        if self.client.protocol_version == RadarProtocolVersion('2.1'):
            self.assertIsInstance(milestones[0].beginsAt, datetime.datetime)
            self.assertIsInstance(milestones[0].endsAt, datetime.datetime)
        if self.client.protocol_version == RadarProtocolVersion('2.2'):
            self.assertIsInstance(milestones[0].startDate, datetime.datetime)
            self.assertIsInstance(milestones[0].endDate, datetime.datetime)

    @skip_unless_enabled
    def test_builds_for_component(self):
        dict = {'id': 514369}
        component, = self.client.find_components(dict)
        builds = self.client.builds_for_component(component)
        self.assertEqual(len(builds), 2)
        self.assertIsInstance(builds[0], radarclient.model.Build)
        self.assertEqual(builds[0].id, 400946)
        self.assertEqual(builds[0].name, 'Test Build 1')
        self.assertIsInstance(builds[0].beginsAt, datetime.datetime)
        self.assertIsInstance(builds[0].endsAt, datetime.datetime)

    @skip_unless_enabled
    def test_access_groups_for_component_id(self):
        access_groups = self.client.access_groups_for_component_id(515346)
        self.assertIsInstance(access_groups[0], AccessGroup)
        assert not hasattr(access_groups[0], 'roles')

    @skip_unless_enabled
    def test_work_groups_for_component_id(self):
        work_group = self.client.work_group_for_component_id(515346)
        self.assertIsInstance(work_group, WorkGroup)

    @skip_unless_enabled
    def test_milestone(self):
        component = Component(name='foo', version='bar', id=1234)
        milestone = Milestone(component=component, name='baz')
        component_dict = {'name': 'foo', 'version': 'bar', 'id': 1234}
        milestone_dict = {'component': component_dict, 'name': 'baz'}

        milestone2 = Milestone(milestone_dict)
        self.assertEqual(milestone, milestone2)
        milestone3 = Milestone({'component': component_dict, 'name': 'something else'})
        self.assertNotEqual(milestone, milestone3)
        milestone4 = Milestone({'component': {'name': 'foo', 'version': 'something else', 'id': 5678}, 'name': 'baz'})
        self.assertNotEqual(milestone, milestone4)

    @skip_unless_enabled
    def test_milestone_hashing(self):
        component1 = Component(name='A', version='B', id=1)
        component2 = Component(name='C', version='D', id=2)
        milestone1 = Milestone(component=component1, name='1')
        milestone2 = Milestone(component=component1, name='1')
        milestone3 = Milestone(component=component2, name='2')
        milestone4 = Milestone(component=component2, name='1')

        built_dict = {m:m.name for m in (milestone1, milestone2, milestone3, milestone4)}

        self.assertEqual(built_dict, {milestone1: '1', milestone3: '2', milestone4: '1'})
        self.assertEqual(built_dict, {milestone2: '1', milestone3: '2', milestone4: '1'})

    @skip_unless_enabled
    def test_change_component(self):
        component = TestConfiguration.value('default_component_id')
        component1 = self.client.find_components(component)[0]
        component1_data = component # 'id': 515346,
        if self.user_is_marc():
            component2 = Component(name='python-radarclient-test bugs', version='version with spaces', id=618791)
            component2_data = {'name': 'python-radarclient-test bugs', 'version': 'version with spaces', 'id': 618791}
            comp2_id = 618791
        else:
            component2 = Component(name='python-radarclient-test bugs', version='version/with slash', id=1304996)
            component2_data = {'name': 'python-radarclient-test bugs', 'version': 'version/with slash', 'id': 1304996}
            comp2_id = 1304996

        self.assertIsInstance(component1, Component)
        self.assertEqual(component1.id, 515346)

        radar = self.client.radar_for_id(28374491)
        if radar.component['id'] != 515346:
            radar.component = component1_data
            radar.commit_changes()
            self.client.clear_radar_cache()
            radar = self.client.radar_for_id(28374491)

        self.assertIsInstance(radar.component, dict)
        self.assertEqual(radar.component['id'], 515346, 'Component mismatch (got {}, expected 515346) in radar:28374491'.format(radar.component['id']))

        radar.component = component2_data
        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(28374491)
        self.assertIsInstance(radar.component, dict)
        self.assertEqual(radar.component['id'], comp2_id, 'component mismatch in radar:{}'.format(28374491))
        radar.component = component1_data
        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(28374491)
        self.assertIsInstance(radar.component, dict)
        self.assertEqual(radar.component['id'], 515346)
        radar.component = component2
        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(28374491)
        self.assertIsInstance(radar.component, dict)
        self.assertEqual(radar.component['id'], comp2_id)
        radar.component = component1
        radar.commit_changes()

        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(28374491)
        self.assertIsInstance(radar.component, dict)
        self.assertEqual(radar.component['id'], 515346)

    @skip_unless_enabled
    def test_component_bundle_for_id(self):
        self.skip_if_not_marc()
        bundle = self.client.component_bundle_for_id(2368)
        self.assertIsInstance(bundle, ComponentBundle)
        self.assertEqual(bundle.id, 2368)
        self.assertEqual(bundle.name, u'radarclient-python')
        self.assertIsInstance(bundle.owner, Person)

        bundle = self.client.component_bundle_for_id(2368)
        self.assertIsInstance(bundle, ComponentBundle)
        self.assertEqual(bundle.name, u'radarclient-python')
        self.assertIsInstance(bundle.components, list)
        self.assertEqual(len(bundle.components), 2)
        bundle_item = bundle.components[0]
        self.assertIsInstance(bundle_item, ComponentBundleMember)
        self.assertEqual(bundle_item.id, 515346)
        self.assertEqual(bundle_item.name, 'python-radarclient-test bugs')
        self.assertEqual(bundle_item.isComponentTreeIncluded, False)
        self.assertEqual(bundle_item.subcomponents, [])

        bundle = self.client.component_bundle_for_id(2368, include_component_children=True)
        bundle_item = bundle.components[0]
        self.assertIsInstance(bundle_item.subcomponents, list)
        self.assertEqual(len(bundle_item.subcomponents), 8)
        component = bundle_item.subcomponents[0]
        self.assertIsInstance(component, ComponentBundleMember)
        self.assertEqual(component.id, 789373)
        self.assertEqual(component.name, 'python-radarclient-test bugs')

        with self.assertRaises(radarclient.exceptions.ObjectNotFoundException) as exception_info:
            bundle = self.client.component_bundle_for_id(99999999999999)

    @unittest.skip('Fails with server API 2.2 and is deprecated afterwards, to be rewritten')
    @skip_unless_enabled
    def test_deprecated_find_component_bundles(self):
        """
        This method serves to test the old implementation of find_component_bundles which simply
        took in a name. A new function called component_bundles_for_name has been written. This
        test will test that until the logic to call it is removed. This should then be rewritten
        to call that function directly

        :return: None
        """
        self.skip_if_not_marc()
        name = 'radarclient'
        component_bundle_list = self.client.find_component_bundles(name)
        self.assertGreaterEqual(len(component_bundle_list), 2, 'item count does not match: {}'.format(component_bundle_list))
        bundle = component_bundle_list[1]
        self.assertIsInstance(bundle, ComponentBundle)
        self.assertIsInstance(bundle.owner, Person)

        self.assertEqual(len(bundle.components), 2)

        bundle_item = bundle.components[0]
        self.assertIsInstance(bundle_item, ComponentBundleMember)
        self.assertEqual(bundle_item.id, 514369)
        self.assertEqual(bundle_item.name, u'python-radarclient')
        self.assertEqual(bundle_item.isComponentTreeIncluded, True)
        self.assertEqual(bundle_item.subcomponents, [])

        component_bundle_list = self.client.find_component_bundles(name, include_component_children=True)
        self.assertGreaterEqual(len(component_bundle_list), 2, 'item count does not match: {}'.format(component_bundle_list))
        bundle = component_bundle_list[1]
        self.assertIsInstance(bundle, ComponentBundle)
        self.assertIsInstance(bundle.owner, Person)
        bundle_item = bundle.components[0]
        self.assertIsInstance(bundle_item.subcomponents, list)
        self.assertEqual(len(bundle_item.subcomponents), 4)
        component = bundle_item.subcomponents[0]
        self.assertIsInstance(component, ComponentBundleMember)
        self.assertEqual(component.id, 515346)
        self.assertEqual(component.name, 'python-radarclient-test bugs')

        name = 'fdsafdsafdsafdsafdsafdsa'
        component_bundle_list = self.client.find_component_bundles(name)
        self.assertEqual(len(component_bundle_list), 0)

    @skip_unless_enabled
    def test_component_bundles_for_ids(self):
        # Invalid doesn't raise
        bundles = self.client.component_bundles_for_ids([1])
        self.assertEqual([], bundles)

        bundles = self.client.component_bundles_for_ids([39685], include_component_children=True)
        bundle = bundles[0]
        self.assertGreater(len(bundle.components[0].subcomponents), 0)

        bundles = self.client.component_bundles_for_ids([39685])
        bundle = bundles[0]
        self.assertEqual([], bundle.components[0].subcomponents)

    @skip_unless_enabled
    def test_find_component_bundles(self):
        # Test broad query with limit
        query = {'isPublic': True}
        bundles = self.client.find_component_bundles(query, limit=5, return_results_directly=True)
        self.assertEqual(5, len(bundles), 'Incorrect number of bundles returned')
        for bundle in bundles:
            self.assertIsInstance(bundle, radarclient.model.ComponentBundle)
            self.assertEqual([], bundle.components, "Bundle has empty 'components' list? {}".format(bundle))

        # Test with subcomponents included
        query = {'id': 39685}
        bundle = self.client.find_component_bundles(query, include_component_children=True)[0]
        self.assertGreater(len(bundle.components[0].subcomponents), 0)

        # Test empty return
        query = {'name': 'ipasdyibwqyeugf'}
        bundles = self.client.find_component_bundles(query)
        self.assertEqual([], bundles)

    @skip_unless_enabled
    def test_component_bundle_group_for_id(self):
        self.skip_if_not_marc()
        group = self.client.component_bundle_group_for_id(3340)
        self.assertIsInstance(group, ComponentBundleGroup)
        self.assertEqual(group.id, 3340)
        self.assertEqual(group.name, u'radarclient-python bundle group')
        self.assertEqual(group.admins, [])
        self.assertIsInstance(group.isActive, bool)
        self.assertEqual(group.isActive, True)
        self.assertIsInstance(group.isPublic, bool)
        self.assertEqual(group.isPublic, False)
        self.assertIsInstance(group.owner, Person)

        self.assertIsInstance(group.memberBundles, list)
        self.assertEqual(len(group.memberBundles), 1)
        item = group.memberBundles[0]
        self.assertIsInstance(item, ComponentBundleGroupMemberBundle)
        self.assertEqual(item.id, 2368)
        self.assertEqual(item.name, 'radarclient-python')
        self.assertEqual(item.description, 'Components related to the radarclient-python module')

        self.assertIsInstance(group.memberGroups, list)
        self.assertEqual(len(group.memberGroups), 1)
        item = group.memberGroups[0]
        self.assertIsInstance(item, ComponentBundleGroupMemberGroup)
        self.assertEqual(item.id, 3341)
        self.assertEqual(item.name, 'radarclient-python bundle group 2')
        self.assertEqual(item.description, 'Component bundles related to the radarclient-python module 2')

    @skip_unless_enabled
    def test_components_for_name(self):
        name = 'python-radarclient'
        component_list = sorted(self.client.components_for_name(name), key=lambda x: x.id)
        self.assertEqual(len(component_list), 3, 'item count does not match: {}'.format(component_list))
        self.assertIsInstance(component_list[0], Component)
        self.assertEqual(component_list[0].id, 514369)

        component_list = self.client.components_for_name('python-radarclient-test bugs', version='version with spaces')
        self.assertEqual(len(component_list), 1, 'item count does not match: {}'.format(component_list))
        self.assertIsInstance(component_list[0], Component)
        self.assertEqual(component_list[0].id, 618791)

        name = 'python-radarclient asdfasdfasdf'
        component_list = self.client.components_for_name(name)
        self.assertEqual(len(component_list), 0)

        name = 'python-radarclient'
        additional_fields = 'isRootLevel isOpenToExternals isDropBox doesInheritAccessGroups doesInheritBuildsAndMilestones doesInheritDescriptionTemplates parent subcomponents owner epm screener integrator builder verifier treeLimited followOnComponent'.split()
        component_list = sorted(self.client.components_for_name(name, additional_fields=additional_fields), key=lambda x: x.id)
        self.assertEqual(len(component_list), 3, 'item count does not match: {}'.format(component_list))
        component = component_list[0]
        for property in 'owner epm screener integrator builder verifier'.split():
            self.assertIsInstance(getattr(component, property), Person, msg='Unexpected None person in role "{}" in component {}'.format(property, component))

        self.assertIsNone(component.parent) # root component has no parent
        subcomponent = sorted(component.subcomponents, key=lambda x: x.id)[0]
        self.assertIsInstance(subcomponent, Component)
        self.assertEqual(subcomponent.id, 515346)
        self.assertEqual(subcomponent.name, 'python-radarclient-test bugs')
        self.assertEqual(subcomponent.version, '1.0')
        self.assertTrue(component.isRootLevel, True)

        subcomponent2 = self.client.components_for_name(subcomponent.name, subcomponent.version, additional_fields=additional_fields)[0]
        self.assertIsInstance(subcomponent2.parent, Component)
        self.assertEqual(subcomponent2.parent.id, component.id)
        self.assertEqual(subcomponent2.parent.name, 'python-radarclient')
        self.assertEqual(subcomponent2.parent.version, '1.0')

    @skip_unless_enabled
    def test_component_for_name_and_version(self):
        name = 'python-radarclient'
        version = '1.0'
        component = self.client.component_for_name_and_version(name, version)
        self.assertIsInstance(component, Component)
        self.assertEqual(component.id, 514369)

        name = 'python-radarclient-test bugs'
        version = 'closed version'
        additional_fields = 'isRootLevel isOpenToExternals isDropBox doesInheritAccessGroups doesInheritBuildsAndMilestones doesInheritDescriptionTemplates parent subcomponents owner epm screener integrator builder verifier treeLimited followOnComponent'.split()
        component = self.client.component_for_name_and_version(name, version, additional_fields=additional_fields)
        self.assertIsInstance(component, Component)
        self.assertEqual(component.id, 789373)
        for property in 'owner screener integrator builder verifier'.split():
            self.assertIsInstance(getattr(component, property), Person, msg='Unexpected None person in role "{}" in component {}'.format(property, component))

    @skip_unless_enabled
    def test_find_radars(self):
        request_data = {'milestone': 'Liberty', 'keyword': 'Program Top Issue'}
        radar_list = self.client.find_radars(request_data, additional_fields=['originator', 'resolvedBy', 'createdAt', 'resolvedAt'])
        self.assertIsInstance(radar_list[0], Radar)

        request_data = {"id": [11725080, 11811590]}
        radar_list = self.client.find_radars(request_data)
        self.assertEqual(len(radar_list), 2)

        request_data = {"title": u'test \u2192 bug'}
        radar_list = self.client.find_radars(request_data, additional_fields=['effortCurrentTotalEstimate'])
        self.assertIsInstance(radar_list[0], Radar)

        request_data = {"title": u'fdjsafdsfsdanfadsfasdfas'}
        radar_list = self.client.find_radars(request_data)
        self.assertEqual(len(radar_list), 0)

        people_list = self.client.find_people(email='liyanage@apple.com')
        if people_list:
            self.assertEqual(len(people_list), 1)
            assignee = people_list[0]
            self.assertEqual(assignee.dsid, 299156498)
            request_data = {"assignee": assignee.dsid}
            radar_list = self.client.find_radars(request_data, limit=10)
            self.assertEqual(len(radar_list), 10)
            self.assertIsInstance(radar_list[0], Radar)

    @skip_unless_enabled
    def test_find_radars_override_default_fields(self):
        request_data = {'milestone': 'Liberty', 'keyword': 'Program Top Issue', 'resolution': 'Configuration Changed'}
        radar_list = self.client.find_radars(request_data, return_find_results_directly=True, fields=['title', 'id', 'createdAt', 'resolvedAt'])
        self.assertIsInstance(radar_list[0], Radar)
        for radar in radar_list:
            for attr in ['resolution', 'component', 'assignee', 'state']:
                self.assertFalse(hasattr(radar, attr), "Radar object for {} has an unexpected attribute: {}".format(radar.id, attr))

        request_data = {'milestone': 'Liberty', 'keyword': 'Program Top Issue', 'resolution': 'Configuration Changed'}
        radar_list = self.client.find_radars(request_data, fields=['title', 'originator', 'createdAt', 'resolvedAt', 'configuration'])
        self.assertIsInstance(radar_list[0], Radar)
        for radar in radar_list:
            for attr in ['resolution', 'component', 'assignee', 'state']:
                self.assertFalse(hasattr(radar, attr), "Radar object for {} has an unexpected attribute: {}".format(radar.id, attr))

        request_data = {"id": [11725080, 11811590]}
        radar_list = self.client.find_radars(request_data, fields=['title'])
        self.assertEqual(len(radar_list), 2)
        for radar in radar_list:
            for attr in ['id', 'title']:
                self.assertTrue(hasattr(radar, attr), "Radar object for {} is missing expected attribute: {}".format(radar.id, attr))
            self.assertFalse(hasattr(radar, 'assignee'), "Radar object for {} should not have 'assignee' attr!")

    @skip_unless_enabled
    def test_radars_for_ids_override_default_fields(self):
        radar_ids = [73723257, 96810790, 96810690, 93052650, 95799918,
                     95820373, 95820369, 95816854, 95816851, 95816848,
                     95816835, 95816832, 95799926, 95799922, 96234122]
        requested_fields = ['id', 'title', 'state', 'createdAt']
        radar_list = self.client.radars_for_ids(radar_ids, fields=requested_fields)
        for radar in radar_list:
            for attr in ['resolution', 'component', 'assignee', 'milestone', 'resolvedAt']:
                self.assertFalse(hasattr(radar, attr), "Radar object for {} has an unexpected attribute: {}".format(radar.id, attr))
            for attr in requested_fields:
                self.assertTrue(hasattr(radar, attr), "Radar object for {} is missing expected attribute: {}".format(radar.id, attr))

    @skip_unless_enabled
    def test_other_related_items(self):
        self.skip_if_not_marc()
        url = radarclient.RadarEnvironment.default_environment().configuration_value('webservice_url')
        self.assertEqual(self.client.webservice_url_for_other_related_item_systems(), '{}/other-related-items/systems'.format(url))

        systems_list = self.client.other_related_item_systems()
        self.assertTrue(len(systems_list) > 0)
        self.assertIsInstance(systems_list[0], radarclient.model.OtherRelatedItemSystem)

        radar = self.client.radar_for_id(12760751)
        other_related_items = list(radar.other_related_items.items())
        self.assertEqual(len(other_related_items), 0, 'Expecting no other related items in radar:12760751')

        item = radarclient.model.OtherRelatedItem({'id': '1234', 'system': 'AppsRally Defect', 'title': 'DE1'})
        radar.other_related_items.add(item)
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(12760751)
        other_related_items = list(radar.other_related_items.items())
        self.assertEqual(len(other_related_items), 1)
        self.assertEqual(other_related_items[0].title, 'DE1')
        self.assertEqual(other_related_items[0].id, '1234')

        self.client.clear_radar_cache()
        item = radarclient.model.OtherRelatedItem({'id': '1234', 'system': 'AppsRally Defect'})
        radar.other_related_items.delete(item)
        radar.commit_changes()
        self.client.clear_radar_cache()
        radar = self.client.radar_for_id(12760751)
        other_related_items = list(radar.other_related_items.items())
        self.assertEqual(len(other_related_items), 0)

    @skip_unless_enabled
    def test_other_related_items_id_is_string(self):
        # <rdar://problem/51588186> BATS Updates to Other Related Items are now displaying links in scientific notification
        radar = self.client.radar_for_id(12760751)
        item = radarclient.model.OtherRelatedItem({'id': 1234, 'system': 'AppsRally Defect', 'title': 'DE1'})
        radar.other_related_items.add(item)
        json_code = radar.change_records[0].json_code()
        data = json.loads(json_code)
        id_value = data[0]['id']
        self.assertIsInstance(id_value, compat.unicode_string_type)

        radar = self.client.radar_for_id(12760751)
        item = radarclient.model.OtherRelatedItem({'id': 1234, 'system': 'AppsRally Defect', 'title': 'DE1'})
        item.id = 5678
        radar.other_related_items.add(item)
        json_code = radar.change_records[0].json_code()
        data = json.loads(json_code)
        id_value = data[0]['id']
        self.assertIsInstance(id_value, compat.unicode_string_type)

    @skip_unless_enabled
    def test_label(self):
        self.skip_if_not_marc()
        labels = self.client.labels_by_name()
        self.assertIn('Radar Client Unit Test', labels)
        self.assertIsInstance(labels['Radar Client Unit Test'], radarclient.model.Label)
        self.assertEqual(labels['Radar Client Unit Test'].id, 1507798)

        labels = self.client.labels_by_id()
        self.assertTrue(len(labels) > 0)
        self.assertIsInstance(labels[1507798], radarclient.model.Label)
        self.assertEqual(labels[1507798].name, 'Radar Client Unit Test')

        radar = self.client.radar_for_id(12760751, additional_fields=['label'])
        radar.label = labels[1507798]
        radar.commit_changes()
        self.client.clear_radar_cache()

        radar = self.client.radar_for_id(12760751, additional_fields=['label'])
        self.assertIsInstance(radar.label, radarclient.model.Label)
        self.assertEqual(radar.label.id, 1507798)

        radar.label = None
        radar.commit_changes()
        self.client.clear_radar_cache()

        radar = self.client.radar_for_id(12760751, additional_fields=['label'])
        self.assertEqual(radar.label, None)

    # Broken in 2.1+? rdar://73718862 (Radar API v2.1 regression: error 500 for label-set request: "We are experiencing difficulty retrieving the data from the server")
    @skip_unless_enabled
    def test_label_sets(self):
        self.skip_if_not_marc()

        design = [{
            'methods': ['GET', 'POST'],
            'endpoints': ['label-sets'],
            'status_codes': [429],
            'delay_type': RetryPolicy.DELAY_TYPE_EXPONENTIAL_BACKOFF,
            'max_send_attempts': 3
        }]
        retry_client = RadarClient(
            self.authentication_strategy_spnego(),
            self.system_identifier(),
            retry_policy=RetryPolicy(scheme_design=design)
        )

        shared_set_1 = 'radarclient test 1' # id: 998631
        shared_set_2 = 'radarclient test 2' # id: 998633
        expected_labels_dict = {
            shared_set_1: {'Orange Test', 'Yellow Test'},
            shared_set_2: {'Red Test', 'Blue Test'}
        }
        # Clean up in case already subscribed
        for label_set in shared_set_1, shared_set_2:
            try:
                retry_client.unsubscribe_from_label_set_by_name(label_set)
            except:
                pass

        def validate_label_set(to_validate, expected_names=None):
            """
            Validates a label set and labels

            :param LabelSet to_validate: LabelSet to validate
            :param set[str] expected_names: Set of expected names. If None, no validation run

            :return: None
            """
            self.assertIsInstance(to_validate, radarclient.model.LabelSet)

            label_names = set()
            for label in to_validate.labels:
                self.assertIsInstance(label, radarclient.model.Label)
                label_names.add(label.name)

            if expected_names is not None:
                self.assertEqual(expected_names, label_names)

        starting_set = retry_client.get_active_label_set()
        validate_label_set(starting_set)

        # Setting active label set to already active does not raise
        retry_client.set_active_label_set(starting_set)

        fetched_label_sets = [
            retry_client.find_label_sets({'name': shared_set_1}, limit=1)[0],
            retry_client.find_label_sets({'name': shared_set_2}, limit=1)[0]
        ]
        for label_set in fetched_label_sets:
            label_set.load_labels(retry_client)
            validate_label_set(label_set, expected_names=expected_labels_dict.get(label_set.name, None))

        initial_subscribed_sets = retry_client.get_subscribed_label_sets()

        retry_client.subscribe_to_label_set(fetched_label_sets[1])
        # Subscribe again and make sure it doesn't raise an error
        retry_client.subscribe_to_label_set(fetched_label_sets[1])

        retry_client.subscribe_to_label_set(fetched_label_sets[0])

        for is_final_attempt, attempt, delay_seconds in attempts_with_increasing_delay(6):
            try:
                new_subscribed_sets = retry_client.get_subscribed_label_sets()
                self.assertEqual(len(initial_subscribed_sets) + 2, len(new_subscribed_sets))
                break
            except AssertionError:
                if is_final_attempt:
                    raise

        for label_set in new_subscribed_sets:
            expected = expected_labels_dict.get(label_set.name, None)
            label_set.load_labels(retry_client)
            validate_label_set(label_set, expected_names=expected)

        test_set = fetched_label_sets[0]
        retry_client.subscribe_to_label_set(test_set)
        retry_client.set_active_label_set(test_set)

        for is_final_attempt, attempt, delay_seconds in attempts_with_increasing_delay(6):
            try:
                self.assertEqual(retry_client.get_active_label_set(), test_set)
                break
            except AssertionError:
                if is_final_attempt:
                    raise

        retry_client.set_active_label_set(starting_set)
        time.sleep(3)

        # Unsubscribe
        retry_client.unsubscribe_from_label_set(fetched_label_sets[0])
        retry_client.unsubscribe_from_label_set(fetched_label_sets[1])

        # Validate unsubscribe for not subscribed does not raise
        retry_client.unsubscribe_from_label_set_by_name(shared_set_1)

        after_unsub_sets = retry_client.get_subscribed_label_sets()
        self.assertEqual(len(initial_subscribed_sets), len(after_unsub_sets))

        # Assert subscribe to non existent raises
        with self.assertRaises(AssertionError):
            retry_client.subscribe_to_label_set_by_name('iiuhuysgdf')

    @skip_unless_enabled
    def test_source_changes(self):
        self.skip_if_not_marc()
        radar = self.client.radar_for_id(12760751, additional_fields=['sourceChanges'])
        radar.sourceChanges = 'source changes test'
        radar.commit_changes()
        self.client.clear_radar_cache()

        radar = self.client.radar_for_id(12760751, additional_fields=['sourceChanges'])
        self.assertEqual(radar.sourceChanges, 'source changes test')

        radar.sourceChanges = None
        radar.commit_changes()
        self.client.clear_radar_cache()

        radar = self.client.radar_for_id(12760751, additional_fields=['sourceChanges'])
        self.assertEqual(radar.sourceChanges, None)

    @skip_unless_enabled
    def test_test_suite_for_id_no_additional_fields(self):
        test_id = 548405
        suite = self.client.test_suite_for_id(test_id)
        self.assertIsInstance(suite, radarclient.model.TestSuite)
        self.assertIsInstance(suite.createdAt, datetime.datetime)
        self.assertIsInstance(suite.lastModifiedAt, datetime.datetime)
        self.assertEqual(suite.suiteId, test_id)
        self.assertEqual(suite.counts.keywords, 1)

    @skip_unless_enabled
    def test_test_suite_for_id_with_additional_fields(self):
        test_id = 548405
        suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests', 'keywords', 'geography'])
        # This will also test the conversion of associatedTests to cases

        case = suite.cases[0]
        self.assertIsInstance(case, radarclient.model.TestCase)
        self.assertEqual(case.caseId, 11102034)
        self.assertIsInstance(case.priority, int)

        keyword = suite.keywords[0]
        self.assertIsInstance(keyword, radarclient.model.Keyword)
        self.assertEqual(keyword.id, 196144)
        self.assertEqual(keyword.name, 'radarclient-python test')

    @skip_unless_enabled
    def test_test_suite_for_id_with_fields(self):
        fields = ['author']
        test_id = 548405

        suite = self.client.test_suite_for_id(test_id, fields=fields)
        self.assertIsNotNone(suite.author)
        self.assertIsNotNone(suite.database_id_attribute_value())

    @skip_unless_enabled
    def test_test_suites_for_ids_with_fields(self):
        fields = ['author']
        test_ids = [2498464, 2498466, 2498468, 2498500, 2498502]

        test_suites = self.client.test_suites_for_ids(test_ids, fields=fields)

        for suite in test_suites:
            self.assertIsNotNone(suite.author)
            self.assertIsNotNone(suite.database_id_attribute_value())

    @skip_unless_enabled
    def test_test_suite_sub_suite_parsing(self):
        test_id = 2583358
        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        self.assertEqual(8, len(test_suite.cases), 'Incorrect number of cases')
        expected_cases = [11102034, 24144887, 24144894, 24144945, 24144950, 24144934, 24144895, 24144907]

        self.assertListEqual(expected_cases, [case.database_id_attribute_value() for case in test_suite.cases])

    @skip_unless_enabled
    def test_find_test_suites_no_additional_fields(self):
        test_keyword_id = 196144
        # Test with returning results directly
        suite = self.client.find_test_suites({'keywordId': {'eq': test_keyword_id}}, limit=1,
                                             return_results_directly=True)[0]

        # Test with pass through to get by ID
        suite = self.client.find_test_suites({'keywordId': {'eq': test_keyword_id}}, limit=1)[0]
        self.assertIsInstance(suite, radarclient.model.TestSuite)
        self.assertIsInstance(suite.createdAt, datetime.datetime)
        self.assertIsInstance(suite.lastModifiedAt, datetime.datetime)

    @skip_unless_enabled
    def test_find_test_suites_with_additional_fields(self):
        test_keyword_id = 196144
        query = {'keywordId': {'eq': test_keyword_id}}

        # Test with returning results directly with a valid additional field
        suite = self.client.find_test_suites(query, limit=1, additional_fields=['applicationName'],
                                             return_results_directly=True)[0]
        # Validate applicationName exists
        suite.applicationName

        # Test with returning results directly with a field only available by ID
        with self.assertRaises(UnsuccessfulResponseException):
            _ = self.client.find_test_suites(query, limit=1, additional_fields=['ccList'], return_results_directly=True)

        # Test with additional fields not returned directly and only available on IDs
        suite = self.client.find_test_suites(query, limit=1, additional_fields=['associatedTests'])[0]
        self.assertIsInstance(suite.cases[0], radarclient.model.TestCase)

    @skip_unless_enabled
    def test_find_test_suites_return_results_directly(self):
        test_keyword_id = 196144
        query = {'keywordId': {'eq': test_keyword_id}}

        suites = self.client.find_test_suites(query, return_results_directly=True)

        for suite in suites:
            self.assertTrue(isinstance(suite, TestSuite))
            self.assertIsNotNone(suite.component)

    @skip_unless_enabled
    def test_find_test_suite_case_ids(self):
        test_id = 24152704
        query = {'caseId': test_id}
        expected = [test_id]

        fetched_case_ids = self.client.find_test_suite_case_ids(query)
        self.assertListEqual(expected, fetched_case_ids)

    @skip_unless_enabled
    def test_find_test_suite_cases_returned_directly(self):
        test_id = 24152704
        query = {'caseId': test_id}
        expected_ids = [test_id]

        fetched_cases = self.client.find_test_suite_cases(query, return_results_directly=True)
        self.assertTrue(isinstance(fetched_cases[0], TestCase))
        self.assertListEqual(expected_ids, [case.database_id_attribute_value() for case in fetched_cases])

    @skip_unless_enabled
    def test_find_test_suite_cases_not_returned_directly(self):
        test_id = 24152704
        query = {'caseId': test_id}
        expected_ids = [test_id]

        fetched_cases = self.client.find_test_suite_cases(query, return_results_directly=False)
        self.assertTrue(isinstance(fetched_cases[0], TestCase))
        self.assertListEqual(expected_ids, [case.database_id_attribute_value() for case in fetched_cases])

    @skip_unless_enabled
    def test_test_suite_and_test_case_item_find(self):
        query = {'component': TestConfiguration.value('default_component_name_version')}

        def run_tstt_test_variation(find_method, additional_fields, invalid_additional,
                                    item_class, item_id):
            limit = 1
            results = find_method(query, limit=limit, return_results_directly=True,
                                  additional_fields=additional_fields)
            self.assertEqual(limit, len(results))
            for result in results:
                self.assertIsInstance(result, item_class)
                self.assertIsNotNone(getattr(result, item_id))

            # Test for empty
            results = find_method({item_id: [0]})
            self.assertEqual([], results)

            # Test with invalid additional fields and getting by ID
            results = find_method(query, limit=limit, additional_fields=invalid_additional)
            for result in results:
                self.assertIsInstance(result, item_class)
                for field in invalid_additional:
                    self.assertIsNotNone(getattr(result, field))

            # Test with unsupported field for return initial
            with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
                find_method(query, limit=limit, additional_fields=invalid_additional,
                            return_results_directly=True)

        run_tstt_test_variation(self.client.find_test_suites,
                                ['author', 'approvedBy', 'casesCount', 'ccCount', 'createdAt',
                                 'label', 'lastModifiedBy', 'relatedTestSuitesCount', 'reviewCasesCount',
                                 'scheduledTestsCount', 'testTypes'],
                                ['diagnosis', 'associatedTests'],
                                radarclient.model.TestSuite, TestSuite.identifier_attrs[0])

        run_tstt_test_variation(self.client.find_test_suite_cases, ['author'],
                                ['history'], radarclient.model.TestCase,
                                TestCase.identifier_attrs[0])

    def run_tstt_find_variation(self, find_method, additional_fields, item_class, return_results_directly=False):
        query = {'component': TestConfiguration.value('default_component_name_version')}
        limit = 10

        # Test with no additional fields
        results = find_method(query, limit=limit, return_results_directly=return_results_directly)

        self.assertEqual(limit, len(results))
        for result in results:
            self.assertIsInstance(result, item_class)

        # Test with additional fields
        results = find_method(query, additional_fields=additional_fields, limit=limit,
                              return_results_directly=return_results_directly)

        self.assertEqual(limit, len(results))
        for result in results:
            self.assertIsInstance(result, item_class)
            for field in additional_fields:
                self.assertIsNotNone(getattr(result, field))

    @skip_unless_enabled
    def test_find_scheduled_tests_returned_directly(self):
        self.run_tstt_find_variation(self.client.find_scheduled_tests, ['author'],
                                     ScheduledTest, return_results_directly=True)

    @skip_unless_enabled
    def test_find_scheduled_tests_not_returned_directly(self):
        self.run_tstt_find_variation(self.client.find_scheduled_tests, ['author', 'cases'], ScheduledTest,
                                     return_results_directly=False)

    @skip_unless_enabled
    def test_find_scheduled_tests_radar_122633228_fix(self):
        query = {"all": [{"suiteId": {"eq": 1557189}}]}
        sch_tests = self.client.find_scheduled_tests(query, limit=10, return_results_directly=False)
        self.assertEqual(len(sch_tests), 10)

    @skip_unless_enabled
    def test_find_scheduled_test_cases(self):
        self.run_tstt_find_variation(self.client.find_scheduled_test_cases, ['tester'],
                                     ScheduledTestCase)

    @skip_unless_enabled
    def test_find_scheduled_test_cases_nothing_found(self):
        # Test for rdar://124234851 (Exception when searching for scheduled test cases in an empty scheduled test)
        result = self.client.find_scheduled_test_cases(
            {'title': 'asdioufhoas', "component":{"eq":{"includeSubcomponents": False, "id": 515346}}},
            return_results_directly=True
        )
        self.assertListEqual([], result)

    @skip_unless_enabled
    def test_find_scheduled_test_cases_returned_directly(self):
        self.run_tstt_find_variation(self.client.find_scheduled_test_cases, ['tester'], ScheduledTestCase,
                                     return_results_directly=True)

    @skip_unless_enabled
    def test_find_scheduled_test_cases_not_returned_directly(self):
        self.run_tstt_find_variation(self.client.find_scheduled_test_cases, ['tester'], ScheduledTestCase)

    @skip_unless_enabled
    def test_test_suite_extend_fields_for_all_cases_defaults(self):
        test_id = 2621376
        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        test_suite.extend_fields_for_all_cases(self.client)

        for case in test_suite.cases:
            self.assertIsNotNone(case.createdAt)

    @skip_unless_enabled
    def test_scheduled_test_extend_fields_for_all_cases_defaults(self):
        # For the time being, the fields are identical for cases on scheduled test suites so this test may need to be
        # revisited in the future. For now, it simply serves to ensure it doesn't crash if a user uses the method
        test_id = 21057300
        test_suite = self.client.scheduled_test_for_id(test_id, additional_fields=['cases'])
        test_suite.extend_fields_for_all_cases(self.client)


    @skip_unless_enabled
    def test_test_suite_extend_fields_for_all_cases_additional(self):
        test_id = 2621376
        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        test_suite.extend_fields_for_all_cases(self.client, additional_fields=['description'])

        for case in test_suite.cases:
            self.assertIsNotNone(case.createdAt)
            self.assertTrue(hasattr(case, 'description'))

    @skip_unless_enabled
    def test_test_suite_extend_fields_for_all_cases_fields(self):
        test_id = 2621376
        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        test_suite.extend_fields_for_all_cases(self.client, fields=['description'])

        for case in test_suite.cases:
            self.assertIsNone(case.createdAt)
            self.assertTrue(hasattr(case, 'description'))

    @skip_unless_enabled
    def test_simple_str_field_validator(self):
        # None value can_be_none True
        self.assertIsNone(radarclient.model.TestCase._simple_str_field_validator(
            'test', None, True, 20))

        # None value can_be_none False
        output = radarclient.model.TestCase._simple_str_field_validator(
            'test', None, False, 20)
        self.assertEqual(
            'test is required to be something other than None',
            output
        )

        # Test not a string
        output = radarclient.model.TestCase._simple_str_field_validator('test', 5, True, 20)
        self.assertEqual(
            "test must be a unicode string, not type int",
            output
        )

        # Test greater than max
        output = radarclient.model.TestCase._simple_str_field_validator('test', 'test', False, 2)
        self.assertEqual(
            'test must be less than 2 characters',
            output
        )

        # Test valid with max
        self.assertIsNone(
            radarclient.model.TestCase._simple_str_field_validator('test', 'test', True,
                                                                   10))

        # Test valid without max
        self.assertIsNone(
            radarclient.model.TestCase._simple_str_field_validator('test', 'test', True))

    @skip_unless_enabled
    def test_simple_integer_field_validator(self):
        # None value can_be_none True
        self.assertIsNone(radarclient.model.TestCase._simple_integer_field_validator(
            'test', None, True, min=0, max=10))

        # None value can_be_none False
        output = radarclient.model.TestCase._simple_integer_field_validator(
            'test', None, False, min=0, max=10)
        self.assertEqual(
            'test is required to be something other than None',
            output
        )

        # Test not an int
        output = radarclient.model.TestCase._simple_integer_field_validator(
            'test', 'test', False, min=0, max=10)
        self.assertEqual(
            'test must be an int',
            output
        )

        # Test less than min
        output = radarclient.model.TestCase._simple_integer_field_validator(
            'test', -1, False, min=0, max=10)
        self.assertEqual(
            'test must be greater than or equal to 0',
            output
        )

        # Test greater than max
        output = radarclient.model.TestCase._simple_integer_field_validator(
            'test', 100, True, max=50)
        self.assertEqual(
            'test must be less than or equal to 50',
            output
        )

        # Test valid with min and max
        self.assertIsNone(radarclient.model.TestCase._simple_integer_field_validator(
            'test', 10, True, 0, 10))

        # Test valid without min or max
        self.assertIsNone(radarclient.model.TestCase._simple_integer_field_validator(
            'test', 10, True))

    @skip_unless_enabled
    def test_validate_create_and_add_dict(self):
        # Test empty dict
        output = radarclient.model.TestCase.validate_test_case_creation_dict({})
        self.assertEqual(
            1,
            len(output)
        )

        test_dict = {
            'componentId': 56789,
            'title': 'Test',
            'data': 'Test',
            'expectedResult': 'Expected',
            'expectedTimeInSeconds': 901,
            'instructions': 'instructions',
            'priority': 1
        }

        # Valid dictionary with all required and optional keys
        self.assertEqual(
            [],
            radarclient.model.TestCase.validate_test_case_creation_dict(test_dict)
        )

        # All keys but all invalid
        test_dict = {
            'componentId': 'test name',
            'title': 'A' * 241,
            'data': 'T' * 1000001,
            'expectedResult': 'E' * 4001,
            'expectedTimeInSeconds': '000:15:01',
            'instructions': 'i' * 4001,
            'priority': -10
        }
        expected_invalid_list = [
            'data must be less than 1000000 characters',
            'expectedResult must be less than 4000 characters',
            'priority must be greater than or equal to 1',
            'title must be less than 240 characters'
        ]

        invalid_list = radarclient.model.TestCase.validate_test_case_creation_dict(test_dict)
        print(invalid_list)
        self.assertListEqual(
            invalid_list,
            expected_invalid_list
        )

        valid_dict_missing_optional = {
            'componentId': 6432,
            'title': 'Not None',
            'expectedResult': None,
            'expectedTimeInSeconds': 600,
            'instructions': None,
            'priority': 1,
            'description': None
        }

        self.assertEqual(
            [],
            radarclient.model.TestCase.validate_test_case_creation_dict(valid_dict_missing_optional)
        )

    @skip_unless_enabled
    def test_invalid_test_suite(self):
        callback_args = {}

        with self.assertRaises(radarclient.exceptions.RadarAccessDeniedResponseException) as exception_info:
            suite = self.client.test_suite_for_id(1000000)
        self.assertEqual(exception_info.exception.code, 403)
        self.assertIn(u'You do not have privileges', exception_info.exception.reason)

        with self.assertRaises(radarclient.exceptions.ObjectNotFoundException) as exception_info:
            suite = self.client.test_suite_for_id(4160375)
        self.assertEqual(exception_info.exception.code, 404)

    @skip_unless_enabled
    def test_test_case_error_throws(self):
        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
            self.client.test_suite_for_id(1)

    def _test_create_test_suite(self, fetch_created_suite=True, additional_fields=None,
                                component_id=TestConfiguration.value('default_component_id')['id']):
        title = 'Create Test Suite Test {}'.format(str(datetime.datetime.now()))
        request_data = {
            'title': title,
            'componentId': component_id
        }

        return self.client.create_test_suite(request_data, fetch_full_object=fetch_created_suite,
                                             additional_fields=additional_fields), title

    @skip_unless_enabled
    def test_create_test_suite_only_id_returned(self):
        suite, _ = self._test_create_test_suite(fetch_created_suite=False)
        self.assertIsInstance(suite, TestSuite, 'Returned object was not a TestSuite')
        self.assertIsNone(suite.title)

        self.client.delete_test_suite_by_id(suite.database_id_attribute_value())

    @skip_unless_enabled
    def test_create_test_suite_full_suite_returned_no_additional_fields(self):
        suite, expected_title = self._test_create_test_suite()
        self.assertIsInstance(suite, radarclient.TestSuite)
        self.assertEqual(expected_title, suite.title)

        self.client.delete_test_suite(suite)

    @skip_unless_enabled
    def test_create_test_suite_full_suite_returned_with_additional_fields(self):
        additional_fields = ['primaryData']
        suite, expected_title = self._test_create_test_suite(additional_fields=additional_fields)
        self.assertIsInstance(suite, radarclient.TestSuite)
        self.assertEqual(expected_title, suite.title)

        for field in additional_fields:
            self.assertTrue(hasattr(suite, field), 'Suite does not have the attribute {}'.format(field))

        self.client.delete_test_suite(suite)


    @skip_unless_enabled
    def test_create_test_suite_invalid(self):
        request_data = {
            'title': 'This is an invalid test suite'
        }

        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException) as exception_info:
            test_suite = self.client.create_test_suite(request_data)

    @skip_unless_enabled
    def test_delete_test_suite(self):
        test_suite, _ = self._test_create_test_suite()

        self.client.delete_test_suite(test_suite)
        with self.assertRaises(UnsuccessfulResponseException):
            self.client.test_suite_for_id(test_suite.database_id_attribute_value())

    @skip_unless_enabled
    def test_delete_test_suite_by_id(self):
        test_suite, _ = self._test_create_test_suite()

        self.client.delete_test_suite_by_id(test_suite.database_id_attribute_value())
        with self.assertRaises(UnsuccessfulResponseException):
            self.client.test_suite_for_id(test_suite.database_id_attribute_value())

    @skip_unless_enabled
    def test_update_test_suite(self):
        added_fields = [
            'diagnosis', 'primaryData', 'assignee', 'author', 'geography', 'complexity', 'status', 'trackName',
            'category'
        ]
        test_suite_id = 1726889
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=added_fields)
        test_timestamp = str(datetime.datetime.now())

        updated_title = u'This is a test updated title {}'.format(test_timestamp)
        updated_diagnosis = u'This is a test updated diagnosis with an emoji \U0001f9ea {}'.format(
            test_timestamp)
        updated_primary_data = u'This is test updated master data {}'.format(test_timestamp)

        new_priority = 5 if test_suite.priority == 1 else 1
        new_geography = 'EMEA' if test_suite.geography == 'AMR' else 'AMR'
        new_category = 'QuickLook' if test_suite.category == 'TestTypeDocumentation' else 'TestTypeDocumentation'
        new_complexity = 'High' if test_suite.complexity == 'Low' else 'Low'
        new_status = 'In Progress' if test_suite.status == 'Final Review' else 'Final Review'
        new_track = 'Unique Test' if test_suite.trackName == 'Misc. Test' else 'Misc. Test'
        new_person_dsid = 299156498 if test_suite.assignee is None or test_suite.assignee.dsid != 299156498 else 189512709

        test_suite.title = updated_title
        test_suite.priority = new_priority
        test_suite.diagnosis = updated_diagnosis
        test_suite.primaryData = updated_primary_data
        test_suite.geography = new_geography
        test_suite.category = new_category
        test_suite.complexity = new_complexity
        test_suite.status = new_status
        test_suite.trackName = new_track
        new_owner_and_assignee_person = self.client.person_for_dsid(new_person_dsid)
        test_suite.assignee = new_owner_and_assignee_person
        test_suite.owner = new_owner_and_assignee_person

        test_suite.commit_changes(self.client, dry_run=True)
        self.assertLess(
            0,
            len(test_suite.change_records),
            'change_records cleared after just a dry run'
        )
        test_suite.commit_changes(self.client)

        self.assertEqual(0,
                         len(test_suite.change_records),
                         'change_records not cleared after commit')

        test_suite = self.client.test_suite_for_id(test_suite_id, added_fields)
        self.assertEqual(
            updated_title,
            test_suite.title,
            'Title not updated'
        )

        self.assertEqual(
            new_priority,
            test_suite.priority,
            'Priority not updated'
        )

        self.assertEqual(
            updated_diagnosis,
            test_suite.diagnosis[-1]['text'],
            'Diagnosis not updated'
        )
        self.assertEqual(updated_primary_data, test_suite.primaryData, 'Primary data does not match')
        self.assertEqual(new_geography, test_suite.geography, 'Geography does not match')
        self.assertEqual(new_category, test_suite.category, 'Category does not match')
        self.assertEqual(new_complexity, test_suite.complexity, 'Complexity does not match')
        self.assertEqual(new_status, test_suite.status, 'Status does not match')
        self.assertEqual(new_track, test_suite.trackName, 'trackName does not match')
        self.assertIsNotNone(test_suite.assignee, 'assignee should not be none, should be set to person object with dsid {}'.format(new_person_dsid))
        self.assertEqual(new_person_dsid, test_suite.assignee.dsid, 'assignee does not match')
        self.assertEqual(new_person_dsid, test_suite.assignee.dsid, 'owner does not match')

    def run_relate_and_unrelate_radar_to_tstt_object_test(self, tstt_object, get_method):
        radar_by_id_id = 28200094
        radar_by_ids_ids = [28201609, 28201741]
        radar_as_radar = self.client.radar_for_id(21845471)
        radars_as_radars = self.client.radars_for_ids([21846735, 67880870])

        expected_relations = set()
        for item in [radar_as_radar] + radar_by_ids_ids + [radar_by_id_id] + radars_as_radars:
            if isinstance(item, radarclient.model.Radar):
                to_add = TSTTRelatedProblem(
                    {'id': item.id, 'relationType': TSTTRelatedProblem.TYPE_RELATED_TO},
                    tstt_object=tstt_object
                )
            else:
                to_add = TSTTRelatedProblem(
                    {'id': item, 'relationType': TSTTRelatedProblem.TYPE_RELATED_TO},
                    tstt_object=tstt_object
                )

            expected_relations.add(to_add)

        tstt_object.relate_radar_id(radar_by_id_id)
        tstt_object.relate_radars_by_ids(radar_by_ids_ids)
        tstt_object.relate_radar(radar_as_radar)
        tstt_object.relate_radars(radars_as_radars)

        tstt_object.commit_changes(self.client, dry_run=True)
        tstt_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['relatedProblems'])

        for relationship in expected_relations:
            self.assertIn(relationship, updated_object.relatedProblems)

        def remove_from_set_by_radar_id(radar_id):
            for rel in expected_relations:
                if rel.id == radar_id:
                    expected_relations.remove(rel)
                    break

        updated_object.remove_related_radar_by_id(radar_by_id_id)
        remove_from_set_by_radar_id(radar_by_id_id)
        updated_object.remove_related_radar(radar_as_radar)
        remove_from_set_by_radar_id(radar_as_radar.id)
        updated_object.remove_radar_relationship(expected_relations.pop())
        updated_object.remove_radar_relationships(list(expected_relations))

        updated_object.commit_changes(self.client, dry_run=True)
        updated_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['relatedProblems'])
        self.assertEqual(0, len(updated_object.relatedProblems))

    @skip_unless_enabled
    def test_add_and_delete_related_problems_from_test_suite(self):
        test_suite = self.get_simple_test_suite_for_test(additional_fields=['relatedProblems'])

        self.run_relate_and_unrelate_radar_to_tstt_object_test(test_suite, self.client.test_suite_for_id)

        try:
            self.client.delete_test_suite(test_suite)
        except Exception:
            logger.exception('Failed to delete the test suite after radar relationship test')

    @skip_unless_enabled
    def test_add_and_delete_related_problems_from_test_suite_case(self):
        test_case = self.get_simple_test_case_for_test(additional_fields=['relatedProblems'])

        self.run_relate_and_unrelate_radar_to_tstt_object_test(test_case, self.client.test_suite_case_for_id)

        try:
            self.client.delete_test_suite_case(test_case)
        except Exception:
            logger.exception('Failed to delete the test case after radar relationship test')

    @skip_unless_enabled
    def test_add_and_delete_related_problems_from_scheduled_test(self):
        scheduled_test = self.get_simple_scheduled_test_for_testing(additional_fields=['relatedProblems'])

        self.run_relate_and_unrelate_radar_to_tstt_object_test(scheduled_test, self.client.scheduled_test_for_id)

        try:
            self.client.delete_scheduled_test(scheduled_test)
        except Exception:
            logger.exception('Failed to delete scheduled test after radar relationship test')

    @skip_unless_enabled
    def test_add_and_delete_related_problems_from_scheduled_test_case(self):
        sch_test_case = self._create_scheduled_test_case_for_testing()
        # Have to get relatedProblems separately
        sch_test_case = self.client.scheduled_test_case_for_id(sch_test_case.database_id_attribute_value(),
                                                               additional_fields=['relatedProblems'])

        self.run_relate_and_unrelate_radar_to_tstt_object_test(sch_test_case, self.client.scheduled_test_case_for_id)

        try:
            self.client.delete_scheduled_test_case(sch_test_case)
        except Exception:
            logger.exception('Failed to delete scheduled test case after radar relationship test')

    @skip_unless_enabled
    def test_add_and_delete_related_problems_to_case_fetched_with_suite(self):
        test_id = 1549714
        suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        suite.extend_fields_for_all_cases(self.client, fields=['relatedProblems'])

        self.run_relate_and_unrelate_radar_to_tstt_object_test(suite.cases[0], self.client.test_suite_case_for_id)

    @skip_unless_enabled
    def run_add_and_remove_keyword_object_from_tstt_object_test(self, tstt_object, get_method):
        new_keyword = radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0])

        tstt_object.add_keyword(new_keyword)
        tstt_object.commit_changes(self.client, dry_run=True)
        tstt_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        self.assertIn(new_keyword, updated_object.keywords)

        updated_object.remove_keyword(new_keyword)
        updated_object.commit_changes(self.client, dry_run=True)
        updated_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        self.assertNotIn(new_keyword, updated_object.keywords)

    def run_add_and_remove_multiple_keyword_objects_from_tstt_object_test(self, tstt_object, get_method):
        new_keywords = [radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0]),
                        radarclient.model.Keyword(TestConfiguration.value('default_keywords')[1])]

        tstt_object.add_keywords(new_keywords)
        tstt_object.commit_changes(self.client, dry_run=True)
        tstt_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        for keyword in new_keywords:
            self.assertIn(keyword, updated_object.keywords)

        updated_object.remove_keywords(new_keywords)
        updated_object.commit_changes(self.client, dry_run=True)
        updated_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        for keyword in new_keywords:
            self.assertNotIn(keyword, updated_object.keywords)

    def run_add_and_remove_keyword_by_id_test_for_tstt_object(self, tstt_object, get_method):
        new_keyword = radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0])

        tstt_object.add_keyword_by_id(new_keyword.id)
        tstt_object.commit_changes(self.client, dry_run=True)
        tstt_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        self.assertIn(new_keyword, updated_object.keywords)

        updated_object.remove_keyword_by_id(new_keyword.id)
        updated_object.commit_changes(self.client, dry_run=True)
        updated_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        self.assertNotIn(new_keyword, updated_object.keywords)

    def run_add_and_remove_keywords_by_ids_test_for_tstt_object(self, tstt_object, get_method):
        new_keywords = [radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0]),
                        radarclient.model.Keyword(TestConfiguration.value('default_keywords')[1])]

        tstt_object.add_keywords_by_ids((k.id for k in new_keywords))
        tstt_object.commit_changes(self.client, dry_run=True)
        tstt_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        for keyword in new_keywords:
            self.assertIn(keyword, updated_object.keywords)

        updated_object.remove_keywords_by_ids((k.id for k in new_keywords))
        updated_object.commit_changes(self.client, dry_run=True)
        updated_object.commit_changes(self.client)

        updated_object = get_method(tstt_object.database_id_attribute_value(),
                                    additional_fields=['keywords'])
        for keyword in new_keywords:
            self.assertNotIn(keyword, updated_object.keywords)

    def get_simple_test_suite_for_test(self, additional_fields=None):
        component_id = TestConfiguration.value('default_component_id')['id']
        test_time = compat.unicode_string_type(datetime.datetime.now())
        title = 'Simple Test Suite for Testing {}'.format(test_time)
        request_data = {
            'title': title,
            'componentId': component_id
        }

        return self.client.create_test_suite(request_data, additional_fields=additional_fields)

    @skip_unless_enabled
    def test_add_and_remove_keywords_from_test_suite(self):
        test_suite = self.get_simple_test_suite_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_multiple_keyword_objects_from_tstt_object_test(
            test_suite, self.client.test_suite_for_id
        )

        try:
            self.client.delete_test_suite(test_suite)
        except Exception:
            logger.exception('Failed to delete the test suite after keyword tests')

    @skip_unless_enabled
    def test_add_and_remove_keyword_from_test_suite(self):
        test_suite = self.get_simple_test_suite_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_object_from_tstt_object_test(test_suite, self.client.test_suite_for_id)

        try:
            self.client.delete_test_suite(test_suite)
        except Exception:
            logger.exception('Failed to delete the test suite after keyword tests')

    @skip_unless_enabled
    def test_add_and_remove_keyword_by_id_from_test_suite(self):
        test_suite = self.get_simple_test_suite_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_by_id_test_for_tstt_object(test_suite, self.client.test_suite_for_id)

        try:
            self.client.delete_test_suite(test_suite)
        except Exception:
            logger.exception('Failed to delete the test suite after keyword tests')

    @skip_unless_enabled
    def test_add_and_remove_keywords_by_ids_from_test_suite(self):
        test_suite = self.get_simple_test_suite_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_keywords_by_ids_test_for_tstt_object(test_suite, self.client.test_suite_for_id)

        try:
            self.client.delete_test_suite(test_suite)
        except Exception:
            logger.exception('Failed to delete the test suite after keyword tests')

    def get_simple_test_case_for_test(self, additional_fields=None):
        component_id = TestConfiguration.value('default_component_id')['id']
        test_time = compat.unicode_string_type(datetime.datetime.now())
        title = 'Simple Test Case for Testing {}'.format(test_time)
        request_data = {
            'title': title,
            'componentId': component_id
        }

        return self.client.create_test_suite_case(request_data, additional_fields=additional_fields)

    @skip_unless_enabled
    def test_add_and_remove_keywords_from_test_case(self):
        test_case = self.get_simple_test_case_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_multiple_keyword_objects_from_tstt_object_test(test_case,
                                                                               self.client.test_suite_case_for_id)
        try:
            self.client.delete_test_suite_case(test_case)
        except Exception:
            logger.exception('Failed to delete test case after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keyword_from_test_case(self):
        test_case = self.get_simple_test_case_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_object_from_tstt_object_test(test_case, self.client.test_suite_case_for_id)

        try:
            self.client.delete_test_suite_case(test_case)
        except Exception:
            logger.exception('Failed to delete test case after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keyword_by_id_from_test_case(self):
        test_case = self.get_simple_test_case_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_by_id_test_for_tstt_object(test_case, self.client.test_suite_case_for_id)

        try:
            self.client.delete_test_suite_case(test_case)
        except Exception:
            logger.exception('Failed to delete test case after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keywords_by_ids_from_test_case(self):
        test_case = self.get_simple_test_case_for_test(additional_fields=['keywords'])

        self.run_add_and_remove_keywords_by_ids_test_for_tstt_object(test_case, self.client.test_suite_case_for_id)

        try:
            self.client.delete_test_suite_case(test_case)
        except Exception:
            logger.exception('Failed to delete test case after keyword test')

    @skip_unless_enabled
    def get_simple_scheduled_test_for_testing(self, additional_fields=None):
        suite_id = 2499590
        return self.client.schedule_test_for_test_suite_id(suite_id, additional_fields=additional_fields)

    @skip_unless_enabled
    def test_add_and_remove_keywords_from_scheduled_test(self):
        scheduled_test = self.get_simple_scheduled_test_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_multiple_keyword_objects_from_tstt_object_test(scheduled_test,
                                                                               self.client.scheduled_test_for_id)
        try:
            self.client.delete_scheduled_test_suite(scheduled_test)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keyword_from_scheduled_test(self):
        scheduled_test = self.get_simple_scheduled_test_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_object_from_tstt_object_test(scheduled_test, self.client.scheduled_test_for_id)

        try:
            self.client.delete_scheduled_test_suite(scheduled_test)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keyword_by_id_from_scheduled_test(self):
        scheduled_test = self.get_simple_scheduled_test_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_by_id_test_for_tstt_object(scheduled_test, self.client.scheduled_test_for_id)

        try:
            self.client.delete_scheduled_test_suite(scheduled_test)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keywords_by_ids_from_scheduled_test(self):
        scheduled_test = self.get_simple_scheduled_test_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_keywords_by_ids_test_for_tstt_object(scheduled_test, self.client.scheduled_test_for_id)

        try:
            self.client.delete_scheduled_test_suite(scheduled_test)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keywords_from_scheduled_test_case(self):
        scheduled_test_case = self._create_scheduled_test_case_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_multiple_keyword_objects_from_tstt_object_test(scheduled_test_case,
                                                                               self.client.scheduled_test_case_for_id)
        try:
            self.client.delete_scheduled_test_case(scheduled_test_case)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keyword_from_scheduled_test_case(self):
        scheduled_test_case = self._create_scheduled_test_case_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_object_from_tstt_object_test(scheduled_test_case,
                                                                     self.client.scheduled_test_case_for_id)
        try:
            self.client.delete_scheduled_test_case(scheduled_test_case)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keyword_by_id_from_scheduled_test_case(self):
        scheduled_test_case = self._create_scheduled_test_case_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_keyword_by_id_test_for_tstt_object(scheduled_test_case,
                                                                   self.client.scheduled_test_case_for_id)
        try:
            self.client.delete_scheduled_test_case(scheduled_test_case)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_add_and_remove_keywords_by_ids_from_scheduled_test_case(self):
        scheduled_test_case = self._create_scheduled_test_case_for_testing(additional_fields=['keywords'])

        self.run_add_and_remove_keywords_by_ids_test_for_tstt_object(scheduled_test_case,
                                                                     self.client.scheduled_test_case_for_id)
        try:
            self.client.delete_scheduled_test_case(scheduled_test_case)
        except Exception:
            logger.exception('Failed to delete scheduled test after keyword test')

    @skip_unless_enabled
    def test_scheduled_test_for_id(self):
        test_id = 7500643
        scheduled_test = self.client.scheduled_test_for_id(test_id)
        self.assertEqual(test_id, scheduled_test.database_id_attribute_value())

    @skip_unless_enabled
    def test_scheduled_tests_for_ids(self):
        valid_ids = [7500643, 7500646, 7500647, 7500650, 7500655, 7500658, 7500661, 7500664, 7500667, 7503693]
        invalid_ids = [9000000000000000, 1, 7500645]
        test_ids = valid_ids + invalid_ids

        scheduled_tests = self.client.scheduled_tests_for_ids(test_ids)

        # Validate list contains expected and list items missing as part of error
        missing_list = []
        returned_id_set = set((scheduled_test.database_id_attribute_value() for scheduled_test in scheduled_tests))
        for valid_id in valid_ids:
            if valid_id not in returned_id_set:
                missing_list.append(str(valid_id))
        self.assertTrue(
            len(missing_list) == 0, 'The following IDs were not returned {}'.format(', '.join(missing_list))
        )

        self.assertEqual(len(valid_ids), len(scheduled_tests))

    @skip_unless_enabled
    def test_update_scheduled_test(self):
        test_id = 7500643
        additional_fields = ['build', 'testCycle']
        scheduled_test = self.client.scheduled_test_for_id(test_id, additional_fields=additional_fields)

        test_title = 'This is a test {}'.format(time.time())
        if scheduled_test.build is not None and scheduled_test.build.name == 'Build123A456':
            test_build = self.client.build_suggestions('Test Build 1', limit=1)[0]
        else:
            test_build = self.client.build_suggestions('Build123A456', limit=1)[0]

        test_test_cycle = 'Automation Testing'
        if scheduled_test.testCycle == test_test_cycle:
            test_test_cycle = 'ATP01'

        scheduled_test.testCycle = test_test_cycle


        scheduled_test.title = test_title
        scheduled_test.build = test_build
        scheduled_test.commit_changes(self.client, dry_run=True)
        scheduled_test.commit_changes(self.client)

        updated_suite = self.client.scheduled_test_for_id(test_id, additional_fields=additional_fields)
        self.assertEqual(updated_suite.title, test_title)
        self.assertEqual(updated_suite.build, test_build)
        self.assertEqual(updated_suite.testCycle, test_test_cycle)

        # Test removing a build
        updated_suite.build = None
        updated_suite.commit_changes(self.client)

        no_build_suite = self.client.scheduled_test_for_id(test_id, additional_fields=additional_fields)
        self.assertIsNone(no_build_suite.build)

    @skip_unless_enabled
    def test_test_suite_for_id(self):
        test_id = 1571859
        test_suite = self.client.test_suite_for_id(test_id)
        self.assertEqual(test_id, test_suite.database_id_attribute_value())

    @skip_unless_enabled
    def test_test_suites_for_ids(self):
        ts_valid_ids = [1571859, 1571698, 1571283, 1571280, 1571279, 1571278, 1571277, 1571276,
                        1571275, 1571274, 1571266, 1571264, 1571263, 1571262, 1571227, 1571221]
        ts_invalid_ids = [1000000000000000, 1, 2]
        test_ids = ts_valid_ids + ts_invalid_ids

        test_suites = self.client.test_suites_for_ids(test_ids)
        self.assertEqual(len(ts_valid_ids), len(test_suites))

    @skip_unless_enabled
    def test_test_suite_case_for_id(self):
        test_id = 11102034
        test_case = self.client.test_suite_case_for_id(test_id)
        self.assertEqual(test_id, test_case.database_id_attribute_value())

    @skip_unless_enabled
    def test_test_suite_cases_for_ids(self):
        ts_valid_ids = [11102034, 24144887, 24144894, 24144895, 24144907, 24144909, 24144910, 24144915,
                        24144919, 24144920, 24144930, 24144933, 24144934, 24144945, 24144950, 24144951]
        ts_invalid_ids = [1000000000000000, 1, 2]
        test_ids = ts_valid_ids + ts_invalid_ids

        test_cases = self.client.test_suite_cases_for_ids(test_ids)
        self.assertEqual(len(ts_valid_ids), len(test_cases))

    @skip_unless_enabled
    def test_test_suite_cases_scheduled_tests_parsing(self):
        test_case_id = 24152701
        test_case = self.client.test_suite_case_for_id(test_case_id, additional_fields=['scheduledTests'])

        for scheduled_case in test_case.scheduledTests:
            self.assertIsInstance(scheduled_case, ScheduledTestCase)
            self.assertIsInstance(scheduled_case.scheduledStartDate, datetime.datetime)
            self.assertIsNotNone(scheduled_case.database_id_attribute_value())

    @skip_unless_enabled
    def test_test_suite_scheduled_tests_parsing(self):
        test_suite_id = 1553932
        test_suite = self.client.test_suite_for_id(test_suite_id, fields=['scheduledTests'])

        for scheduled_test in test_suite.scheduledTests:
            self.assertIsInstance(scheduled_test, ScheduledTest)
            if scheduled_test.build is not None:
                self.assertIsInstance(scheduled_test.build, Build)
            self.assertIsInstance(scheduled_test.scheduledStartDate, datetime.datetime)
            self.assertIsNotNone(scheduled_test.database_id_attribute_value())

    @skip_unless_enabled
    def test_scheduled_test_cases_for_ids(self):
        id_list = [121209815, 147516463, 147516464, 147516465, 147516466, 147516467, 147661353,
                   147661354]
        results = self.client.scheduled_test_cases_for_ids(id_list, additional_fields=['tester'])

        for result in results:
            self.assertIsInstance(result, ScheduledTestCase)
            self.assertIsNotNone(result.tester)

    @skip_unless_enabled
    def test_scheduled_test_cases_for_ids_with_fields(self):
        id_list = [121209815, 147516463, 147516464, 147516465, 147516466, 147516467, 147661353]
        cases = self.client.scheduled_test_cases_for_ids(id_list, fields=['tester'])

        for case in cases:
            self.assertIsNotNone(case.database_id_attribute_value())
            self.assertIsNotNone(case.tester)
            self.assertIsNone(case.priority)

    @skip_unless_enabled
    def test_get_scheduled_test_case_by_id(self):
        case_id = 149934642
        test_scheduled_case = self.client.scheduled_test_case_for_id(case_id, additional_fields=['instructions'])
        self.assertIsNotNone(test_scheduled_case.id)
        self.assertIsNotNone(test_scheduled_case.instructions)

    @skip_unless_enabled
    def test_scheduled_test_case_for_id_with_fields(self):
        case_id = 149934642
        case = self.client.scheduled_test_case_for_id(case_id, fields=['tester'])
        self.assertIsNotNone(case.database_id_attribute_value())
        self.assertIsNotNone(case.tester)
        self.assertIsNone(case.priority)

    @skip_unless_enabled
    def test_get_scheduled_test_cases_for_ids(self):
        test_ids = [149934639, 149934640, 149934641]
        test_scheduled_cases = self.client.scheduled_test_cases_for_ids(test_ids, additional_fields=['instructions'])

        for scheduled_case in test_scheduled_cases:
            self.assertIsNotNone(scheduled_case.id)
            self.assertIsNotNone(scheduled_case.instructions)

    @skip_unless_enabled
    def test_scheduled_test_case_update(self):
        test_id = 149934642
        test_scheduled_test_case = self.client.scheduled_test_case_for_id(test_id,
                                                                          additional_fields=['data', 'instructions'])
        test_title = 'Updated test title {}'.format(time.time())
        test_data = 'Updated data {}'.format(time.time())
        test_instructions = 'Updated instructions {}'.format(time.time())

        phil_user = self.client.person_for_dsid(189512709)
        if test_scheduled_test_case.tester != phil_user:
            new_tester = phil_user
        else:
            new_tester = self.client.person_for_dsid(299156498)

        test_scheduled_test_case.title = test_title
        test_scheduled_test_case.data = test_data
        test_scheduled_test_case.instructions = test_instructions
        test_scheduled_test_case.tester = new_tester
        test_scheduled_test_case.commit_changes(self.client)

        updated_test_case = self.client.scheduled_test_case_for_id(test_id,
                                                                          additional_fields=['data', 'instructions'])
        self.assertEqual(updated_test_case.title, test_title)
        self.assertEqual(updated_test_case.data, test_data)
        self.assertEqual(updated_test_case.instructions, test_instructions)
        self.assertEqual(updated_test_case.tester, new_tester)

    @skip_unless_enabled
    def test_load_parent_case_keywords(self):
        sched_id = 6429552
        sched_test = self.client.scheduled_test_for_id(sched_id, additional_fields=['cases'])
        case = sched_test.cases[0]
        case.load_parent_case_keywords(self.client)
        self.assertEqual(2, len(case.parent_case_keywords))

    @skip_unless_enabled
    def test_create_and_add_test_case_at_end(self):
        test_id = 1557189
        test_suite = self.client.test_suite_for_id(test_id)

        test_title = 'Test Create and Add Title {}'.format(time.time())
        test_case_data = {
            'title': test_title
        }
        test_suite.create_and_add_test_case(test_case_data)
        test_suite.commit_changes(self.client)

        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        self.assertEqual(test_suite.cases[-1].title, test_title)

        test_suite.remove_associated_test_case(test_suite.cases[-1])
        test_suite.commit_changes(self.client)

        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        self.assertNotEqual(test_suite.cases[-1].title, test_title)

    @skip_unless_enabled
    def test_create_and_add_test_case_at_beginning(self):
        test_id = 1557189
        test_suite = self.client.test_suite_for_id(test_id)

        test_title = 'Test Create and Add Title {}'.format(time.time())
        test_case_data = {
            'title': test_title
        }
        test_suite.create_and_add_test_case(test_case_data, order=1)
        test_suite.commit_changes(self.client)

        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        self.assertEqual(test_suite.cases[0].title, test_title)

        test_suite.remove_associated_test_case(test_suite.cases[0])
        test_suite.commit_changes(self.client)

        test_suite = self.client.test_suite_for_id(test_id, additional_fields=['associatedTests'])
        self.assertNotEqual(test_suite.cases[0].title, test_title)

    @skip_unless_enabled
    def test_add_and_remove_test_case_from_test_suite(self):
        test_test_case_id = 24158282
        test_test_case = self.client.test_suite_case_for_id(test_test_case_id)

        test_test_suite_id = 1557189
        test_test_suite = self.client.test_suite_for_id(test_test_suite_id, additional_fields=['associatedTests'])

        # Add test case at end of suite
        test_test_suite.add_test_case(test_test_case)
        test_test_suite.commit_changes(self.client)

        test_test_suite = self.client.test_suite_for_id(test_test_suite_id, additional_fields=['associatedTests'])
        self.assertEqual(test_test_suite.cases[-1], test_test_case)

        # Remove test case
        test_test_suite.remove_associated_test_case_by_id(test_test_case_id)
        test_test_suite.commit_changes(self.client)

        test_test_suite = self.client.test_suite_for_id(test_test_suite_id, additional_fields=['associatedTests'])
        self.assertNotEqual(test_test_suite.cases[-1], test_test_case)

        # Add case in middle
        order = 3
        test_test_suite.add_test_case(test_test_case, case_number=order)
        test_test_suite.commit_changes(self.client)

        test_test_suite = self.client.test_suite_for_id(test_test_suite_id, additional_fields=['associatedTests'])
        self.assertEqual(test_test_suite.cases[order - 1], test_test_case)

        # Remove it again
        test_test_suite.remove_associated_test_case_by_id(test_test_case_id)
        test_test_suite.commit_changes(self.client)

        test_test_suite = self.client.test_suite_for_id(test_test_suite_id, additional_fields=['associatedTests'])
        self.assertNotEqual(test_test_suite.cases[order - 1], test_test_case)

    @skip_unless_enabled
    def test_add_and_remove_test_suite_from_parent_suite(self):
        additional_fields = ['associatedTests']
        test_suite = self._test_create_test_suite(additional_fields=additional_fields)[0]
        test_case_ids = [24152704, 24152705, 24152703]
        for case_id in test_case_ids:
            test_suite.add_test_case_by_id(case_id)

        test_suite.commit_changes(self.client)

        test_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(),
                                                   additional_fields=additional_fields)

        suite_to_add_1 = self.client.test_suite_for_id(1549717)
        suite_to_add_2 = self.client.test_suite_for_id(1557189)

        test_suite.add_test_suite(suite_to_add_1)
        test_suite.add_test_suite(suite_to_add_2, order=3)
        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        updated_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(),
                                                      additional_fields=additional_fields)
        self.assertEqual(updated_suite.associatedTests[2], suite_to_add_2)
        self.assertEqual(updated_suite.associatedTests[-1], suite_to_add_1)

        updated_suite.remove_test_suite(suite_to_add_1)
        updated_suite.remove_test_suite(suite_to_add_2)
        updated_suite.commit_changes(self.client, dry_run=True)
        updated_suite.commit_changes(self.client)

        removed_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(),
                                                      additional_fields=additional_fields)
        self.assertNotIn(suite_to_add_1, removed_suite.associatedTests)
        self.assertNotIn(suite_to_add_2, removed_suite.associatedTests)

        self.client.delete_test_suite(removed_suite)


    @skip_unless_enabled
    def test_update_test_cases_in_suite_change_tracking(self):
        """
        This test covers creating a suite and then adding, removing, and reordering test cases
        using the change tracking and commit functionality of TestSuite. It also makes some
        changes to TestCases to validate those changes work
        """
        component_id = TestConfiguration.value('default_component_id')['id']
        expected_case_ordering = []
        test_time = compat.unicode_string_type(datetime.datetime.now())
        title = 'Update Suite and Cases Test {}'.format(test_time)
        request_data = {
            'title': title,
            'componentId': component_id
        }

        test_suite = self.client.create_test_suite(request_data)
        test_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(), additional_fields=[
            'keywords'])
        test_data = compat.unicode_string_type(datetime.datetime.now())
        test_expected_result = 'This should pass'
        test_expected_time_in_seconds = 600
        test_instructions = 'Do this test test'
        test_priority = 1
        test_description = 'A test description for a test'
        test_title = 'Test Title {}'.format(test_data)
        request_data = {
            'data': test_data,
            'expectedResult': test_expected_result,
            'expectedTimeInSeconds': test_expected_time_in_seconds,
            'instructions': test_instructions,
            'priority': test_priority,
            'description': test_description,
            'title': test_title
        }
        new_keywords = [radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0]),
                        radarclient.model.Keyword(TestConfiguration.value('default_keywords')[1])]
        test_suite.add_keywords(new_keywords)

        added, issue_list = test_suite.create_and_add_test_case(request_data, 1)
        self.assertListEqual(
            [],
            issue_list
        )
        self.assertTrue(added)

        # Make sure invalid request not added
        added, issue_list = test_suite.create_and_add_test_case({})
        self.assertFalse(added)
        self.assertGreater(len(issue_list), 0)
        test_case_ids = [24158288, 24158287, 24158286, 24158285, 24158284, 24158283, 24158282]
        test_cases = self.client.test_suite_cases_for_ids(test_case_ids)

        test_suite.add_test_case(test_cases[0])
        expected_case_ordering.append(test_cases[0])
        test_suite.add_test_case(test_cases[1])
        expected_case_ordering.append(test_cases[1])
        test_suite.add_test_case(test_cases[2], 2)
        expected_case_ordering.insert(0, test_cases[2])
        test_suite.add_test_cases(test_cases[3:5])
        expected_case_ordering += test_cases[3:5]

        updated_test_case = test_cases[5]
        updated_test_case.title = 'Updated as part of suite updates {}'.format(test_time)
        test_suite.add_test_case(updated_test_case)
        expected_case_ordering.append(updated_test_case)

        test_suite.commit_changes(self.client, True)
        test_suite.commit_changes(self.client)
        updated_test_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(),
                                                           additional_fields=['associatedTests', 'keywords'])
        self.assertListEqual(new_keywords, updated_test_suite.keywords, 'Keywords do not match')

        case_list = updated_test_suite.cases
        # Check titles match for case we don't have a TestCase for
        self.assertEqual(test_title, case_list[0].title)

        # Check that the rest of the cases exist as expected
        self.assertEqual(expected_case_ordering, case_list[1:])

        expected_case_ordering.insert(0, case_list[0])
        to_remove_one = expected_case_ordering.pop(2)
        updated_test_suite.remove_associated_test_case(to_remove_one)
        to_remove_two = expected_case_ordering.pop(0)
        updated_test_suite.remove_associated_test_case(to_remove_two)

        print()
        updated_test_suite.commit_changes(self.client, dry_run=True)
        updated_test_suite.commit_changes(self.client)

        updated_test_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(),
                                                           additional_fields=['associatedTests'])
        self.assertListEqual(expected_case_ordering, updated_test_suite.cases)

    @skip_unless_enabled
    def test_create_test_suite_case_with_only_title_and_component(self):
        component_id = TestConfiguration.value('default_component_id')['id']
        title = 'New Test Case Creation Test {}'.format(compat.unicode_string_type(datetime.datetime.now()))
        request_data = {
            'title': title,
            'componentId': component_id
        }

        test_case = self.client.create_test_suite_case(request_data)

        self.assertIsInstance(test_case, TestCase)
        self.assertEqual(test_case.title, title)
        self.assertEqual(component_id, test_case.component['id'])

    @skip_unless_enabled
    def test_delete_test_suite_case(self):
        request_data = {
            'title': 'This will be deleted',
            'componentId': TestConfiguration.value('default_component_id')['id']
        }

        test_case = self.client.create_test_suite_case(request_data)

        self.client.delete_test_suite_case(test_case)
        with self.assertRaises(UnsuccessfulResponseException):
            self.client.test_suite_case_for_id(test_case.database_id_attribute_value())

    @skip_unless_enabled
    def test_delete_test_suite_case_by_id(self):
        request_data = {
            'title': 'This will be deleted',
            'componentId': TestConfiguration.value('default_component_id')['id']
        }

        test_case = self.client.create_test_suite_case(request_data)

        self.client.delete_test_suite_case_by_id(test_case.database_id_attribute_value())
        with self.assertRaises(UnsuccessfulResponseException):
            self.client.test_suite_case_for_id(test_case.database_id_attribute_value())

    @skip_unless_enabled
    def test_just_adding_and_removing_case_change_tracking(self):
        component_id = TestConfiguration.value('default_component_id')['id']
        test_time = compat.unicode_string_type(datetime.datetime.now())
        title = 'Adding and Removing Cases with Change Tracking Test {}'.format(test_time)
        request_data = {
            'title': title,
            'componentId': component_id
        }

        test_suite = self.client.create_test_suite(request_data)

        # If changing the below list, keep it 7 items to properly test edge cases
        test_case_ids = [24158288, 24158287, 24158286, 24158285, 24158284, 24158283, 24158282]

        test_cases = self.client.test_suite_cases_for_ids(test_case_ids)

        for case in test_cases:
            test_suite.add_test_case(case)

        test_suite.commit_changes(self.client)

        test_suite.remove_associated_test_case(test_cases.pop(0))
        test_suite.remove_associated_test_case(test_cases.pop(5))
        test_suite.remove_associated_test_case(test_cases.pop(1))

        test_suite.commit_changes(self.client)

        updated_suite = self.client.test_suite_for_id(test_suite.database_id_attribute_value(),
                                                      additional_fields=['associatedTests'])

        self.assertListEqual(test_cases, updated_suite.cases)

    @skip_unless_enabled
    def test_update_test_case_change_tracking(self):
        additional_fields = ['expectedResult', 'description', 'expectedTimeInSeconds', 'keywords', 'relatedProblems']
        test_test_case_id = 24152581
        test_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)

        current_time = compat.unicode_string_type(datetime.datetime.now())
        new_title = 'Updated Title {}'.format(current_time)
        new_time = random.randint(1, 10000)
        new_expected_result = 'Update: This should still pass {}'.format(current_time)
        new_description = 'An updated description test description for a test description {}'.format(current_time)
        new_priority = test_case.priority + 1
        if new_priority >= 6:
            new_priority = 1

        test_case.title = new_title
        test_case.expectedTimeInSeconds = new_time
        test_case.expectedResult = new_expected_result
        test_case.description = new_description
        test_case.priority = new_priority

        new_keywords = [radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0]),
                        radarclient.model.Keyword(TestConfiguration.value('default_keywords')[1])]
        test_case.add_keywords(new_keywords)

        test_radar_id = 21846735
        test_relationship_type = TSTTRelatedProblem.TYPE_RELATED_TO

        test_case.relate_radar_id(test_radar_id, test_relationship_type)

        test_case.commit_changes(self.client, True)
        self.assertLess(
            0,
            len(test_case.change_records),
            'change_records cleared after dry run'
        )
        test_case.commit_changes(self.client)
        self.assertEqual(
            0,
            len(test_case.change_records),
            'change_records not cleared after commit'
        )

        updated_test_case = self.client.test_suite_case_for_id(test_test_case_id,
                                                               additional_fields=additional_fields)

        self.assertEqual(new_title, updated_test_case.title, 'Title not updated')
        self.assertEqual(new_time, updated_test_case.expectedTimeInSeconds, 'Expected time not updated')
        self.assertEqual(new_expected_result, updated_test_case.expectedResult,
                         'Expected results not updated')
        self.assertEqual(new_description, updated_test_case.description, 'Description not updated')
        self.assertEqual(new_priority, updated_test_case.priority, 'Priority not updated')

        keyword_set = set(updated_test_case.keywords)
        for keyword in new_keywords:
            self.assertIn(keyword, keyword_set, '{} not attached to updated test case'.format(keyword))

        validate_relationship = TSTTRelatedProblem(
            data={'id': test_radar_id, 'relationType':
            test_relationship_type}, tstt_object=updated_test_case
        )
        self.assertIn(validate_relationship, updated_test_case.relatedProblems)

        # Test removing keywords and relationships
        updated_test_case.remove_keywords(new_keywords)
        updated_test_case.remove_radar_relationship(validate_relationship)
        updated_test_case.commit_changes(self.client)
        validate_test_case = self.client.test_suite_case_for_id(test_test_case_id,
                                                                additional_fields=additional_fields)

        keyword_set = set(validate_test_case.keywords)
        for keyword in new_keywords:
            self.assertNotIn(keyword, keyword_set, '{} is still attached to test case'.format(keyword))

        self.assertNotIn(validate_relationship, validate_test_case._related_problems_set)

    @skip_unless_enabled
    def test_test_case_related_problems_add_and_remove(self):
        additional_fields = ['relatedProblems']
        test_test_case_id = 24152581
        test_radar = self.client.radar_for_id(21846735)

        test_test_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)

        test_test_case.relate_radar(test_radar)
        test_test_case.commit_changes(self.client)

        test_test_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)
        validate_data = {'id': test_radar.id, 'relationType': TSTTRelatedProblem.TYPE_RELATED_TO}
        validate_relationship = TSTTRelatedProblem(data=validate_data, tstt_object=test_test_case)
        self.assertIn(validate_relationship, test_test_case._related_problems_set)

        # Check that is doesn't raise an error when adding an existing relationship
        test_test_case.relate_radar(test_radar)
        test_test_case.commit_changes(self.client)

        # Remove the relationship
        test_test_case.remove_related_radar(test_radar)
        test_test_case.commit_changes(self.client)

        test_test_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)
        validate_relationship = TSTTRelatedProblem(data=validate_data, tstt_object=test_test_case)
        self.assertNotIn(validate_relationship, test_test_case._related_problems_set)

        # Check that an error isn't raised when removing a relationship that isn't there
        test_test_case.remove_related_radar(test_radar)
        test_test_case.commit_changes(self.client)

    @skip_unless_enabled
    def test_test_case_keyword_add_and_remove_by_id(self):
        test_test_case_id = 24152581
        additional_fields = ['keywords']

        test_test_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)
        test_keyword = radarclient.model.Keyword(TestConfiguration.value('default_keywords')[0])

        # test add by ID
        test_test_case.add_keyword_by_id(test_keyword.id)
        test_test_case.commit_changes(self.client)
        validate_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)
        self.assertIn(test_keyword, validate_case._keywords_set)

        # test adding the same keyword again doesn't raise error
        test_test_case.add_keyword_by_id(test_keyword.id)
        test_test_case.commit_changes(self.client)

        # test remove by ID
        test_test_case.remove_keyword_by_id(test_keyword.id)
        test_test_case.commit_changes(self.client)
        validate_case = self.client.test_suite_case_for_id(test_test_case_id, additional_fields=additional_fields)
        self.assertNotIn(test_keyword, validate_case.keywords)

        # test removing an ID already not there works without issue
        test_test_case.remove_keyword_by_id(test_keyword.id)
        test_test_case.commit_changes(self.client)

    @skip_unless_enabled
    def test_reorder_associated_case_by_id(self):
        test_suite_id = 1550008
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        expected_case_ids = [case.database_id_attribute_value() for case in test_suite.cases]
        test_case_id_to_move = expected_case_ids[0]

        test_suite.reorder_associated_case_by_id(test_case_id_to_move, 50)
        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        expected_case_ids.append(expected_case_ids.pop(0))
        self.validate_test_case_order(test_suite_id, expected_case_ids)

    @skip_unless_enabled
    def test_reorder_associated_case(self):
        test_suite_id = 1550008
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        expected_case_ids = [case.database_id_attribute_value() for case in test_suite.cases]
        test_case_to_move = test_suite.cases[0]

        test_suite.reorder_associated_case(test_case_to_move, 50)
        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        expected_case_ids.append(expected_case_ids.pop(0))
        self.validate_test_case_order(test_suite_id, expected_case_ids)

    @skip_unless_enabled
    def test_reorder_associated_case_most_recent_entry_used(self):
        test_suite_id = 1550008
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        test_case_to_move = test_suite.cases[0]

        test_suite.reorder_associated_case(test_case_to_move, 2)
        test_suite.reorder_associated_case(test_case_to_move, 4)
        test_suite.reorder_associated_case(test_case_to_move, 3)

        test_suite.commit_changes(self.client)

        up_to_date_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        self.assertEqual(test_case_to_move, up_to_date_suite.cases[2])

    @skip_unless_enabled
    def test_reorder_associated_suite_by_id(self):
        # Test requires a suite that contains only 2 sub-suite
        test_suite_id = 2516760
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        suite_id_to_move = test_suite.associatedTests[0].database_id_attribute_value()

        test_suite.reorder_associated_suite_by_id(suite_id_to_move, 30)
        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        up_to_date_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        self.assertEqual(test_suite.associatedTests[0], up_to_date_suite.associatedTests[1])
        self.assertEqual(test_suite.associatedTests[1], up_to_date_suite.associatedTests[0])

    def test_reorder_associated_suite(self):
        # Test requires a suite that contains only 2 sub-suite
        test_suite_id = 2516760
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        suite_to_move = test_suite.associatedTests[0]

        test_suite.reorder_associated_suite(suite_to_move, 30)
        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        up_to_date_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        self.assertEqual(test_suite.associatedTests[0], up_to_date_suite.associatedTests[1])
        self.assertEqual(test_suite.associatedTests[1], up_to_date_suite.associatedTests[0])

    @skip_unless_enabled
    def test_reordering_suite_and_cases_in_test_suite(self):
        test_suite_id = 2516648
        test_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])

        early_index = 4
        late_index = 9
        case_move_index = 7
        case_moved_to_index = 5
        early_suite = test_suite.associatedTests[early_index]
        late_suite = test_suite.associatedTests[late_index]
        case_to_move = test_suite.associatedTests[case_move_index]

        test_suite.reorder_associated_suite(early_suite, late_index + 1)
        test_suite.reorder_associated_suite(late_suite, early_index + 1)
        test_suite.reorder_associated_case(case_to_move, case_moved_to_index + 1)

        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        updated_suite = self.client.test_suite_for_id(test_suite_id, additional_fields=['associatedTests'])
        self.assertEqual(late_suite, updated_suite.associatedTests[early_index])
        self.assertEqual(early_suite, updated_suite.associatedTests[late_index])
        self.assertEqual(case_to_move, updated_suite.associatedTests[case_moved_to_index])

    @skip_unless_enabled
    def test_test_suite_case_for_id_no_additional_fields(self):
        case_id = 24152581
        test_case = self.client.test_suite_case_for_id(case_id)
        self.assertEqual(case_id, test_case.caseId, 'caseId values do not match')

    @skip_unless_enabled
    def test_test_suite_case_for_id_with_additional_fields(self):
        case_id = 24495190
        additional_fields = ['description', 'data', 'instructions']
        case = self.client.test_suite_case_for_id(case_id, additional_fields=additional_fields)
        self.assertIsInstance(case, radarclient.TestCase)

        self.assertEqual('Test Instructions', case.instructions)
        self.assertEqual('Test Data', case.data)
        self.assertEqual('Test Summary', case.description)

    @skip_unless_enabled
    def test_test_suite_case_for_id_with_fields(self):
        case_id = 24495190
        case = self.client.test_suite_case_for_id(case_id, fields=['author'])
        self.assertIsNotNone(case.database_id_attribute_value())
        self.assertIsNotNone(case.author)
        self.assertIsNone(case.title)

    @skip_unless_enabled
    def test_test_suite_cases_for_ids_with_fields(self):
        case_ids = [24152581, 24152580, 24152579]
        cases = self.client.test_suite_cases_for_ids(case_ids, fields=['author'])

        for case in cases:
            self.assertIsNotNone(case.database_id_attribute_value())
            self.assertIsNotNone(case.author)
            self.assertIsNone(case.title)

    def verify_scheduled_test_find(self, tests):
        for test in tests:
            self.assertIsInstance(test, ScheduledTest)

            # Check work around for
            # rdar://115851863 (Finding Scheduled Tests and Getting by ID Return the ID with Different Names)
            self.assertEqual(test.id, test.scheduledTestId)
            self.assertEqual(test.appName, test.applicationName)

    @skip_unless_enabled
    def test_get_scheduled_tests(self):
        test_scheduled_test_id = 7509443

        suite = self.client.scheduled_test_for_id(test_scheduled_test_id, additional_fields=['appName'])
        self.assertIsInstance(suite, ScheduledTest)

        # Test work around for
        # rdar://115851863 (Finding Scheduled Tests and Getting by ID Return the ID with Different Names)
        self.assertEqual(suite.appName, suite.applicationName)
        self.assertEqual(suite.id, suite.scheduledTestId)

        # 404 when no access raises
        with self.assertRaises(radarclient.exceptions.UnsuccessfulResponseException):
            self.client.scheduled_test_for_id(7440166)

    @skip_unless_enabled
    def test_scheduled_test_for_id_with_fields(self):
        test_scheduled_test_id = 7509443

        suite = self.client.scheduled_test_for_id(test_scheduled_test_id, fields=['tester'])
        self.assertIsNotNone(suite.database_id_attribute_value())
        self.assertIsNotNone(suite.tester)
        self.assertIsNone(suite.priority)

    def test_scheduled_tests_for_ids_with_fields(self):
        test_ids = [7500643, 7500646, 7500647, 7500650, 7500655]

        suites = self.client.scheduled_tests_for_ids(test_ids, fields=['tester'])

        for suite in suites:
            self.assertIsNotNone(suite.database_id_attribute_value())
            self.assertIsNotNone(suite.tester)
            self.assertIsNone(suite.priority)

    @skip_unless_enabled
    def test_create_and_add_scheduled_test_case(self):
        test_suite_id = 1557189
        scheduled_test = self.client.schedule_test_for_test_suite_id(test_suite_id, fetch_full_object=False)

        test_dict = {
            'title': 'Test Adding Test Case {}'.format(time.time()),
            'priority': 2
        }

        scheduled_test.create_and_add_scheduled_test_case(test_dict)
        scheduled_test.commit_changes(self.client, dry_run=True)
        scheduled_test.commit_changes(self.client)

        scheduled_test = self.client.scheduled_test_for_id(scheduled_test.id, additional_fields=['cases'])
        self.assertEqual(scheduled_test.cases[-1].title, test_dict['title'])

    def _create_scheduled_test_case_for_testing(self, scheduled_test_suite_id=6429552, additional_fields=None):
        scheduled_test_suite = self.client.scheduled_test_for_id(scheduled_test_suite_id)

        test_title = 'Test Case for Deletion {}'.format(time.time())
        test_dict = {'title': test_title}
        scheduled_test_suite.create_and_add_scheduled_test_case(test_dict)
        scheduled_test_suite.commit_changes(self.client)
        # Delay to find scheduled test case
        time.sleep(5)

        query = {
            'all': [
                {'component': {'eq': {'id': TestConfiguration.value('default_component_id')['id']}}},
                {'title': test_title}
            ]
        }

        return self.client.find_scheduled_test_cases(query, additional_fields=additional_fields)[0]

    @skip_unless_enabled
    def test_delete_scheduled_test_case(self):
        scheduled_test_case = self._create_scheduled_test_case_for_testing()

        self.client.delete_scheduled_test_case(scheduled_test_case)
        with self.assertRaises(UnsuccessfulResponseException):
            self.client.scheduled_test_case_for_id(scheduled_test_case.database_id_attribute_value())

    @skip_unless_enabled
    def test_delete_scheduled_test_case_by_id(self):
        scheduled_test_case = self._create_scheduled_test_case_for_testing()

        self.client.delete_scheduled_test_case_by_id(scheduled_test_case.database_id_attribute_value())
        with self.assertRaises(UnsuccessfulResponseException):
            self.client.scheduled_test_case_for_id(scheduled_test_case.database_id_attribute_value())

    @skip_unless_enabled
    def test_reorder_scheduled_test_cases_in_scheduled_test(self):
        test_id = 7514024
        scheduled_test = self.client.scheduled_test_for_id(test_id, additional_fields=['cases'])
        # This helps troubleshoot the test manually if needed and can be uncommented as needed
        # for i in range(len(scheduled_test.cases)):
        #     scheduled_test.cases[i].title = 'This was case {}'.format(i + 1)
        # scheduled_test.commit_changes(self.client)

        # Move a case to the end of the scheduled suite
        case_to_move_to_end = scheduled_test.cases[0]
        scheduled_test.reorder_associated_case(case_to_move_to_end, 50)

        # Move case by ID to the middle
        middle_order_number = 4
        case_to_move_to_middle_id = scheduled_test.cases[1].database_id_attribute_value()
        scheduled_test.reorder_associated_case_by_id(case_to_move_to_middle_id, middle_order_number)

        # Move case from near the end to near the front
        front_order_number = 3
        case_to_front = scheduled_test.cases[-2]
        scheduled_test.reorder_associated_case(case_to_front, front_order_number)

        # Move a couple of cases
        shift_batch_start = 1
        batch_case_1 = scheduled_test.cases[-4]
        batch_case_2 = scheduled_test.cases[-3]
        scheduled_test.reorder_associated_case(batch_case_1, shift_batch_start)
        scheduled_test.reorder_associated_case(batch_case_2, shift_batch_start + 1)

        scheduled_test.commit_changes(self.client, dry_run=True)
        scheduled_test.commit_changes(self.client)

        updated_test = self.client.scheduled_test_for_id(test_id, additional_fields=['cases'])
        self.assertEqual(updated_test.cases[-1], case_to_move_to_end)
        self.assertEqual(updated_test.cases[middle_order_number - 1].database_id_attribute_value(),
                         case_to_move_to_middle_id)
        self.assertEqual(updated_test.cases[front_order_number - 1], case_to_front)
        self.assertEqual(updated_test.cases[shift_batch_start - 1], batch_case_1)
        self.assertEqual(updated_test.cases[shift_batch_start], batch_case_2)

    @skip_unless_enabled
    def test_reorder_scheduled_test_cases_in_scheduled_test_raises_with_duplicates(self):
        test_id = 7500643
        scheduled_test = self.client.scheduled_test_for_id(test_id, additional_fields=['cases'])

        same_order_num = 5
        conflict_case_one = scheduled_test.cases[2]
        conflict_case_two = scheduled_test.cases[3]
        scheduled_test.reorder_associated_case(conflict_case_one, same_order_num)
        scheduled_test.reorder_associated_case(conflict_case_two, same_order_num)

        with self.assertRaises(ReorderDuplicatePlacementException):
            scheduled_test.commit_changes(self.client)

    @skip_unless_enabled
    def test_test_scheduling_methods_with_fetching(self):

        def run_test(method, first_arg, expect_list):
            """
            Run a test on various test scheduling methods
            :param method: method to test
            :param first_arg: the first argument, either suite IDs or TestSuite objects
            :param expect_list: If True, will validate list, otherwise, expects ScheduledTest
            """
            start = datetime.datetime.now(tz=radarclient.model.UTC()).replace(microsecond=0, second=0)
            start_str = radarclient.model.ISO8601UTCDateValueConverter.encode_radar_value(start)
            end = start = datetime.datetime.now(tz=radarclient.model.UTC()).replace(microsecond=0, second=0)
            end_str = radarclient.model.ISO8601UTCDateValueConverter.encode_radar_value(end)
            scheduled = method(
                first_arg, additional_request_data={'scheduledStartDate': start_str, 'scheduledEndDate': end_str},
                additional_fields=['cases'], fetch_full_object=True
            )

            if expect_list:
                self.assertIsInstance(scheduled, list)
            else:
                self.assertIsInstance(scheduled, ScheduledTest)

            # Make it a list for convenience
            if not expect_list:
                validation_list = [scheduled]
            else:
                validation_list = scheduled

            for sched_test in validation_list:
                self.assertEqual(start, sched_test.scheduledStartDate)
                for case in sched_test.cases:
                    self.assertIsInstance(case, radarclient.model.ScheduledTestCase)

                sched_test.status = 'Cancelled'
                sched_test.commit_changes(self.client)

                self.client.delete_scheduled_test_suite(sched_test)

        test_ids = [1548822, 1557189]
        run_test(self.client.schedule_test_for_test_suite_id, test_ids[0], expect_list=False)
        run_test(self.client.schedule_tests_for_test_suite_ids, test_ids, expect_list=True)

        test_test_suites = self.client.test_suites_for_ids(test_ids)
        run_test(self.client.schedule_test_for_test_suite, test_test_suites[0], expect_list=False)
        run_test(self.client.schedule_tests_for_test_suites, test_test_suites, expect_list=True)

    @skip_unless_enabled
    def test_schedule_test_without_fetching_full(self):
        test_ids = [1548822, 1557189]
        test_test_suites = self.client.test_suites_for_ids(test_ids)

        scheduled_tests_ids_only = self.client.schedule_tests_for_test_suites(test_test_suites, fetch_full_object=False)

        for scheduled_test in scheduled_tests_ids_only:
            self.assertIsNone(scheduled_test.author)

        for test in scheduled_tests_ids_only:
            self.client.delete_scheduled_test_suite(test)

    @skip_unless_enabled
    def test_schedule_test_with_case_filtering(self):
        case_filter = [{'all': [{'priority': {'lt': 3}}]}]
        test_id = 1557189

        scheduled_test = self.client.schedule_test_for_test_suite_id(
            test_id,
            additional_request_data={'casesFilterCriteria': case_filter},
            fetch_full_object=True,
            additional_fields=['cases']
        )

        self.assertEqual(
            1, len(scheduled_test.cases), 'expected 1 case but got {}'.format(len(scheduled_test.cases))
        )

        # Delete the scheduled test but don't fail if it fails
        try:
            self.client.delete_scheduled_test_suite(scheduled_test)
        except Exception as ex:
            logger.exception(ex)

    def test_scheduled_test_no_access(self):
        test_id = 1
        with self.assertRaises(APIJobErrorException):
            self.client.schedule_test_for_test_suite_id(test_id)

    def _validate_cases_for_priority_cases(self, suites, expected_count):
        """
        Validate the number of cases expected are part of each suite

        :param suites: list of scheduled test suites
        :param expected_count: list of expected count that matches with the suites list
        :return: None
        """

        for i in range(len(suites)):
            self.assertEqual(expected_count[i], len(suites[i].cases), 'Unexpected number of scheduled cases')
            try:
                self.client.delete_scheduled_test(suites[i])
            except Exception as ex:
                logger.exception('Failed to delete test suite with error: "{}"'.format(ex))

    @skip_unless_enabled
    def test_schedule_tests_for_test_suite_ids_with_cases_for_priority(self):
        test_ids = [1557189, 1571171]
        suites = self.client.schedule_tests_for_test_suite_ids_with_cases_for_priority(
            test_ids, [1, 4], additional_fields=['cases']
        )

        self._validate_cases_for_priority_cases(suites, [2, 3])

    @skip_unless_enabled
    def test_schedule_test_for_test_suite_id_with_cases_for_priority(self):
        test_id = 1557189
        suite = self.client.schedule_test_for_test_suite_id_with_cases_for_priority(
            test_id, [1, 4], additional_fields=['cases']
        )

        self._validate_cases_for_priority_cases([suite], [2])

    @skip_unless_enabled
    def test_schedule_test_for_test_suite_with_cases_for_priority(self):
        test_suite = self.client.test_suite_for_id(1557189)
        scheduled_suite = self.client.schedule_test_for_test_suite_with_cases_for_priority(
            test_suite, [1,4], additional_fields=['cases']
        )

        self._validate_cases_for_priority_cases([scheduled_suite], [2])

    @skip_unless_enabled
    def test_schedule_tests_for_test_suites_with_cases_for_priority(self):
        test_suites = self.client.test_suites_for_ids([1557189, 1571171])
        scheduled_suites = self.client.schedule_tests_for_test_suites_with_cases_for_priority(
            test_suites, [1,4], additional_fields=['cases']
        )

        self._validate_cases_for_priority_cases(scheduled_suites, [2, 3])

    @skip_unless_enabled
    def test_delete_scheduled_test_suite(self):
        test_suite = self.client.test_suite_for_id(1557189)
        scheduled = self.client.schedule_test_for_test_suite(test_suite)
        self.client.delete_scheduled_test_suite(scheduled)

        with self.assertRaises(UnsuccessfulResponseException):
            self.client.scheduled_test_for_id(scheduled.database_id_attribute_value())

    @skip_unless_enabled
    def test_delete_scheduled_test_suite_by_id(self):
        test_suite = self.client.test_suite_for_id(1557189)
        scheduled = self.client.schedule_test_for_test_suite(test_suite)
        self.client.delete_scheduled_test_suite_by_id(scheduled.database_id_attribute_value())

        with self.assertRaises(UnsuccessfulResponseException):
            self.client.scheduled_test_for_id(scheduled.database_id_attribute_value())

    @skip_unless_enabled
    def test_scheduled_test_change_tracking_modification(self):
        scheduled_test_id = 7411780
        case_index = -1
        scheduled_test = self.client.scheduled_test_for_id(
            scheduled_test_id, additional_fields=['cases']
        )
        scheduled_test.load_attachments_and_pictures(self.client)
        test_case = scheduled_test.cases[case_index]
        test_case.load_attachments_and_pictures(self.client)

        # Delete any files present
        for attachment in scheduled_test.attachments:
            scheduled_test.delete_attachment(attachment)
        for attachment in test_case.attachments:
            test_case.delete_attachment(attachment)

        test_time = datetime.datetime.now()
        new_title = 'Update Scheduled Title {}'.format(test_time)
        new_status = 'In Progress' if scheduled_test.status != 'In Progress' else 'Not Started'
        new_priority = 1 if scheduled_test.priority != 1 else 3
        test_bytes = bytearray('123345', encoding='utf-8')
        test_name = 'test{}.txt'.format(test_time)
        new_attachment = scheduled_test.add_attachment(test_name)
        new_attachment.set_upload_content(test_bytes)

        scheduled_test.title = new_title
        scheduled_test.status = new_status
        scheduled_test.priority = new_priority

        # Make case updates
        new_case_title = 'Updated Case Title {}'.format(test_time)
        new_case_status = 'N/A' if test_case.status != 'N/A' else 'No Value'
        new_case_priority = 1 if test_case.priority != 1 else 2
        test_case.title = new_case_title
        test_case.status = new_case_status
        test_case.priority = new_case_priority
        test_case_bytes = bytearray('789009876', encoding='utf-8')
        test_case_filename = 'test_case_file_{}.txt'.format(test_time)
        new_case_attachment = test_case.add_attachment(test_case_filename)
        new_case_attachment.set_upload_content(test_case_bytes)

        scheduled_test.commit_changes(self.client, dry_run=True)
        scheduled_test.commit_changes(self.client)

        # This works around a weird behavior in radar API that can lead to getting stale objects
        tries = 0
        while tries < 3 and scheduled_test.title != new_title:
            time.sleep(2)
            scheduled_test = self.client.scheduled_test_for_id(
                scheduled_test_id, additional_fields=['cases']
            )
            tries += 1
        scheduled_test.load_attachments_and_pictures(self.client)
        test_case = scheduled_test.cases[case_index]
        test_case.load_attachments_and_pictures(self.client)

        self.assertEqual(new_title, scheduled_test.title, 'Title not updated')
        self.assertEqual(new_status, scheduled_test.status, 'Status not updated')
        self.assertEqual(new_priority, scheduled_test.priority, 'Priority not updated')
        self.assertEqual(test_name, scheduled_test.attachments[0].fileName)

        self.assertEqual(new_case_title, test_case.title, 'case title not updated')
        self.assertEqual(new_case_status, test_case.status, 'case status not updated')
        self.assertEqual(new_case_priority, test_case.priority, 'case priority not updated')
        self.assertIn(
            test_case_filename,
            (attachment.fileName for attachment in test_case.attachments),
            'test case file not uploaded'
        )

        # Test modification of file name change records
        mod_suite_filename = 'scheduled test modified'
        mod_case_filename = 'test case modified'
        scheduled_test.attachments[0].fileName = mod_suite_filename
        scheduled_test.cases[case_index].attachments[0].fileName = mod_case_filename

        scheduled_test.commit_changes(self.client, dry_run=True)
        scheduled_test.commit_changes(self.client)

        # This works around a weird behavior in radar API that can lead to getting stale objects
        tries = 0
        while tries < 3 and scheduled_test.title != new_title:
            time.sleep(2)
            scheduled_test = self.client.scheduled_test_for_id(
                scheduled_test_id, additional_fields=['cases']
            )
            tries += 1
            scheduled_test.load_attachments_and_pictures(self.client)
            test_case = scheduled_test.cases[case_index]
            test_case.load_attachments_and_pictures(self.client)
            try:
                self.assertEqual(
                    mod_suite_filename,
                    scheduled_test.attachments[0].fileName,
                    'Scheduled attachment file name not changed'
                )
                self.assertEqual(
                    mod_case_filename,
                    scheduled_test.cases[case_index].attachments[0].fileName,
                    'Case attachment file name not changed'
                )
            except AssertionError:
                if tries == 3:
                    raise

        for attachment in scheduled_test.attachments:
            scheduled_test.delete_attachment(attachment)
        for attachment in scheduled_test.cases[case_index].attachments:
            scheduled_test.cases[case_index].delete_attachment(attachment)
            print('Deleting {}'.format(attachment))

        scheduled_test.commit_changes(self.client)

    @skip_unless_enabled
    def test_scheduled_test_find_versus_get_id_updates(self):
        """
        The find endpoint and get endpoints return the same attribute with different names. This can be used to
        test that updating still works with scheduled tests fetched via the find endpoint
        :return: None
        """
        test_id = 7406234
        query = {'all': [{'scheduledTestId': {'eq': test_id}}]}
        scheduled_test = self.client.find_scheduled_tests(query, additional_fields=['currentTester'],
                                                          return_results_directly=True)[0]
        scheduled_test.currentTester = self.client.current_user()
        scheduled_test.commit_changes(self.client)

    @skip_unless_enabled
    def test_simple_scheduled_test_multiple_test_case_modification(self):
        suite_id = 7490457
        start = 0
        end = 3

        def test_with_priority(priority):
            sched_test = self.client.scheduled_test_for_id(suite_id, additional_fields=['cases'])
            sched_test.modify_multiple_associated_scheduled_cases(
                {'priority': priority},
                sched_test.cases[start:end]
            )
            sched_test.commit_changes(self.client, dry_run=True)
            sched_test.commit_changes(self.client)

            # Prevent race condition
            time.sleep(3)

            updated = self.client.scheduled_test_for_id(suite_id, additional_fields=['cases'])
            for case in updated.cases[start:end]:
                self.assertEqual(
                    priority, case.priority, '{} not updated to {}'.format(case, priority)
                )

        test_with_priority(3)
        test_with_priority(2)

    @skip_unless_enabled
    def test_unit_test_config(self):
        self.assertEqual(TestConfiguration.value('default_component_id'), {'id': 515346})
        self.assertEqual(TestConfiguration.value('default_component_name_version'), {'name': 'python-radarclient-test bugs', 'version': '1.0'})

    @skip_unless_enabled
    def test_environments_oidc(self):
        self.check_appleconnect_oidc_environment_variables()
        auth_strategy = AuthenticationStrategyOIDC(os.environ['RADARCLIENT_UNIT_TEST_OIDC_CLIENT_ID'], os.environ['RADARCLIENT_UNIT_TEST_OIDC_CLIENT_SECRET'])
        self.assertEqual(auth_strategy.radar_environment.identifier, environment.identifier)
        client = radarclient.RadarClient(auth_strategy, self.system_identifier())
        self.assertEqual(client.webservice_base_url(), active_url)

        auth_strategy = AuthenticationStrategyOIDC(os.environ['RADARCLIENT_UNIT_TEST_OIDC_CLIENT_ID'], os.environ['RADARCLIENT_UNIT_TEST_OIDC_CLIENT_SECRET'],
                                                radar_environment=uat_alt_environment)
        self.assertEqual(auth_strategy.radar_environment.identifier, uat_alt_environment.identifier)
        client = radarclient.RadarClient(auth_strategy, self.system_identifier())
        self.assertEqual(client.webservice_base_url(), 'https://rdr-rws-test2.corp.apple.com')


    @skip_unless_enabled
    def test_environments(self):
        self.skip_if_not_marc()
        environment = radarclient.RadarEnvironment.default_environment()
        self.assertIsInstance(environment, radarclient.RadarEnvironment)
        self.assertIn(environment.configuration_value('webservice_url'), ['https://radar-webservices.apple.com', 'https://radar-webservices-alt.apple.com'])
        active_url = environment.configuration_value('webservice_url')

        uat_environment = radarclient.RadarEnvironment('uat')
        self.assertIsInstance(uat_environment, radarclient.RadarEnvironment)
        self.assertEqual(uat_environment.configuration_value('webservice_url'), 'https://rws-sandbox.apple.com')

        self.assertEqual(uat_environment.configuration_value('cookie_max_age_seconds'), 600)

        uat_alt_environment = radarclient.RadarEnvironment('uat-alt')
        self.assertIsInstance(uat_alt_environment, radarclient.RadarEnvironment)
        self.assertEqual(uat_alt_environment.configuration_value('webservice_url'), 'https://rdr-rws-test2.corp.apple.com')
        self.assertEqual(uat_alt_environment.configuration_value('idms_oauth_token_api_url'), 'https://idmsac-uat.corp.apple.com/auth/oauth2/token')

        try:
            self.check_appleconnect_environment_variables()
            auth_strategy = AuthenticationStrategyWebCookie(os.environ['APPLECONNECT_USERNAME'], os.environ['APPLECONNECT_PASSWORD'])
            self.assertEqual(auth_strategy.radar_environment.identifier, environment.identifier)
            client = radarclient.RadarClient(auth_strategy, self.system_identifier())
            self.assertEqual(client.webservice_base_url(), active_url)
        except Exception as e:
            if 'This account is configured to use a YubiKey' in compat.unicode_string_type(e):
                print('Skipping test incompatible with AppleConnect account using YubiKey')

        config_path = 'examples/example-radar-environment-configuration-override.json'
        environment = radarclient.RadarEnvironment(config_path)
        self.assertEqual(environment.configuration_value('webservice_url'), 'https://radar-webservices-dummy.apple.com')

        if UAT_ACCOUNT_PASSWORD is None:
            return

        # UAT test accounts credentials from <rdar://problem/11904229> Radar UAT : shared accounts distribution
        auth_strategy = AuthenticationStrategyWebCookie(UAT_ACCOUNT_USERNAME, UAT_ACCOUNT_PASSWORD, radar_environment=radarclient.RadarEnvironment('uat'))
        self.assertEqual(auth_strategy.radar_environment.identifier, uat_environment.identifier)
        client = radarclient.RadarClient(auth_strategy, self.system_identifier())
        self.assertEqual(client.webservice_base_url(), 'https://rws-sandbox.apple.com')

    @classmethod
    def check_appleconnect_environment_variables(cls):
        keys = 'APPLECONNECT_USERNAME', 'APPLECONNECT_PASSWORD'
        for key in keys:
            if key not in os.environ:
                print('Please set the {} environment variables'.format('/'.join(keys)), file=sys.stderr)
                print('# export {}'.format(' '.join(['{}=foo'.format(k) for k in keys])), file=sys.stderr)
                sys.exit(1)

    def check_appleconnect_oidc_environment_variables(self):
        keys = 'RADARCLIENT_UNIT_TEST_OIDC_CLIENT_ID', 'RADARCLIENT_UNIT_TEST_OIDC_CLIENT_SECRET'
        for key in keys:
            if key not in os.environ:
                self.skipTest('Skipping OIDC-based unit test because the "{}" environment variable is not set'.format(key))

    @skip_unless_enabled
    def test_current_user(self):
        current_user_person = self.client.current_user()
        self.skip_if_not_marc()
        self.assertIsInstance(current_user_person, radarclient.model.Person)
        self.assertEqual(current_user_person.email, os.environ['USER'] + '@apple.com')

        if UAT_ACCOUNT_PASSWORD is None:
            return

        auth_strategy = AuthenticationStrategyWebCookie(UAT_ACCOUNT_USERNAME, UAT_ACCOUNT_PASSWORD, radar_environment=radarclient.RadarEnvironment('uat'))
        client = radarclient.RadarClient(auth_strategy, self.system_identifier())
        current_user_person = client.current_user()
        self.assertIsInstance(current_user_person, radarclient.model.Person)
        self.assertEqual(current_user_person.email, UAT_ACCOUNT_EMAIL)

    @unittest.skip('Looping benchmark, enable when needed')
    @skip_unless_enabled
    def test_current_user_loop(self):
#        self.client.authentication_strategy.should_use_radar_access_token = False
        for i in range(10):
            current_user_person = self.client.current_user(ignore_cache=True)

    @skip_unless_enabled
    def test_clone_radar(self):
        for default_component in TestConfiguration.default_components():
            self._test_clone_radar(default_component)
            break   # No need to run this twice just using a component ID

    def _test_clone_radar(self, component):
        data = {
            'title': u'test_clone_radar test bug {}'.format(time.ctime(time.time())),
            'component': component,
            'description': u'test_clone_radar test bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }
        radar = self.client.create_radar(data)
        self.assertIsInstance(radar, Radar)
        original_radar_id = radar.id
        compat.test_assertRegex(self, compat.unicode_string_type(original_radar_id), r'^\d+$')
        radar.state = 'Verify'
        radar.resolution = 'Not Applicable'
        radar.commit_changes()
        radar.state = 'Closed'
        radar.commit_changes()

        new_title = u'test_clone_radar [cloned] test bug {}'.format(time.ctime(time.time()))
        new_description = u'Custom new Description text goes here.'
        clone = self.client.clone_radar(original_radar_id, u'Unit test: clone API', component, title=new_title,
                                        description=new_description, classification='Task')
        self.assertNotEqual(original_radar_id, clone.id, u'Radar clone operation response contains identical IDs')
        self.assertIsInstance(clone, radarclient.model.Radar)
        self.assertEqual(clone.title, new_title, u'Cloned radar {} has incorrect title, should be "{}"'.format(clone, new_title))
        self.assertEqual(clone.classification, 'Task', u'Cloned radar {} has incorrect Classification of "{}", should be "Task"'.format(clone, radar.classification))
        clone.state = 'Verify'
        clone.resolution = 'Not Applicable'
        clone.commit_changes()
        clone.state = 'Closed'
        clone.commit_changes()

        self.client.clear_radar_cache()
        reloaded_clone = self.client.radar_for_id(clone.id)
        # self.assertEqual(reloaded_clone.state, 'Closed', u'Cloned radar {} has incorrect state of "{}", should be "Closed"'.format(reloaded_clone.id, reloaded_clone.state))
        self.assertEqual(reloaded_clone.resolution, 'Not Applicable', u'Cloned radar {} has incorrect resolution of "{}", should be "Not Applicable"'.format(reloaded_clone.id, reloaded_clone.resolution))

    @skip_unless_enabled
    def test_milestone_associations(self):
        for default_component in TestConfiguration.default_components():
            self._test_milestone_associations(default_component)

    def _test_milestone_associations(self, component):
        data = component
        components = self.client.find_components(data)
        component = components[0]
        self.assertIsInstance(component, Component)
        radar = self.client.radar_for_id(99301139)
        assoc = radar.milestone_associations()
        self.assertEqual(len(assoc.events), 1, 'Unexpected milestone association event count mismatch in radar:99301139')
        self.assertEqual(len(assoc.categories), 1)
        self.assertEqual(len(assoc.tentpoles), 1)

        milestones = self.client.milestones_for_component(component)
        for milestone in milestones:
            if milestone.id == 807208:  # "API v2.2 Update"
                radar.reset_milestone_associations()
                assoc = radar.milestone_associations(milestone_override=milestone)
                self.assertEqual(len(assoc.events), 0)
                self.assertEqual(len(assoc.categories), 0)
                self.assertEqual(len(assoc.tentpoles), 0)
                break

    @skip_unless_enabled
    def test_milestone_associations_for_component_id(self):
        for default_component in TestConfiguration.default_components():
            self._test_milestone_associations_for_component_id(default_component)

    def _test_milestone_associations_for_component_id(self, component):
        data = component
        components = self.client.find_components(data)
        component = components[0]
        self.assertIsInstance(component, Component)
        assoc = self.client.milestone_associations_for_component_id(component.id)
        expected_event_count = 5
        self.assertEqual(len(assoc.events), expected_event_count, 'Unexpected milestone association event count mismatch (expected {}) (component {}): {}'.format(expected_event_count, component, assoc.events))
        self.assertEqual(len(assoc.categories), 3)
        self.assertEqual(len(assoc.tentpoles), 4)

        milestones = self.client.milestones_for_component(component)
        if milestones:
            assoc = self.client.milestone_associations_for_component_id(component.id, milestone_id=milestones[0].id)
            expected_event_count = 3
            self.assertEqual(len(assoc.events), expected_event_count, 'Unexpected milestone association event count mismatch (expected {}) (component {}): {}'.format(expected_event_count, component, assoc.events))
            self.assertEqual(len(assoc.categories), 2)
            self.assertEqual(len(assoc.tentpoles), 3)

        categories = self.client.categories_for_component(component)
        if categories:
            assoc = self.client.milestone_associations_for_component_id(component.id, category_id=categories[0].id)
            self.assertNotEqual(len(assoc.events), 0)
            self.assertEqual(len(assoc.categories), 0, 'Expected milestone association category count to be zero when using event_id')
            self.assertNotEqual(len(assoc.tentpoles), 0)

        events = self.client.events_for_component(component)
        if events:
            assoc = self.client.milestone_associations_for_component_id(component.id, event_id=events[0].id)
            self.assertEqual(len(assoc.events), 0, 'Expected milestone association event count to be zero when using event_id')
            self.assertNotEqual(len(assoc.categories), 0)
            self.assertNotEqual(len(assoc.tentpoles), 0)

        tentpoles = self.client.tentpoles_for_component(component)
        if tentpoles:
            assoc = self.client.milestone_associations_for_component_id(component.id, tentpole_id=tentpoles[0].id)
            self.assertNotEqual(len(assoc.events), 0)
            self.assertNotEqual(len(assoc.categories), 0)
            self.assertEqual(len(assoc.tentpoles), 0, 'Expected milestone association tentpole count to be zero when using tentpole_id')

    @skip_unless_enabled
    def test_program_management_component_properties_suite(self):
        for default_component in TestConfiguration.default_components():
            self._test_program_management_component_properties_suite(default_component)

    def _test_program_management_component_properties_suite(self, component):
        data = component
        components = self.client.find_components(data)
        component = components[0]
        self.assertIsInstance(component, Component)

        today = datetime.datetime.now().strftime("%Y%m%d-%H%M%S.%f")

        def _get_component_property_item(target_item, _items):
            for item in _items:
                if target_item.id == item.id:
                    return item
            return None

        # Events
        event_dict = {
            'name': u'unittest_Event_{}'.format(today),
            'startDate': '2022-07-01T00:00:00-0800',
            'endDate': '2022-08-01T00:00:00-0800',
            'milestoneAssociation': False,
            'tentpoleRequired': False,
            'closed': False
        }
        new_event = self.client.create_event_for_component(event_dict, component)
        self.assertIsInstance(new_event, radarclient.Event)
        events = self.client.events_for_component(component)
        event = _get_component_property_item(new_event, events)
        self.assertEqual(event, new_event)
        self.assertIsInstance(event.startDate, datetime.datetime)
        self.assertIsInstance(event.endDate, datetime.datetime)
        self.assertFalse(event.milestoneAssociation)
        self.assertFalse(event.tentpoleRequired)
        self.assertFalse(event.inherited)
        self.assertTrue(self.client.delete_component_events([event], component))

        # Milestones
        milestone_dict = {
            'name': u'unittest_Milestone_{}'.format(today),
            'startDate': '2022-07-01T00:00:00-0800',
            'endDate': '2022-08-01T00:00:00-0800',
            'restricted': False,
            'protected': False,
            'eventRequired': False,
            'categoryRequired': False,
            'tentpoleRequired': False,
            'closed': False
        }
        new_milestone = self.client.create_milestone_for_component(milestone_dict, component)
        self.assertIsInstance(new_milestone, radarclient.Milestone)
        milestones = self.client.milestones_for_component(component)
        milestone = _get_component_property_item(new_milestone, milestones)
        self.assertEqual(milestone, new_milestone)
        self.assertIsInstance(milestone.startDate, datetime.datetime)
        self.assertIsInstance(milestone.endDate, datetime.datetime)
        self.assertFalse(milestone.tentpoleRequired)
        self.assertFalse(milestone.eventRequired)
        self.assertFalse(milestone.categoryRequired)
        self.assertFalse(milestone.closed)
        self.assertFalse(milestone.protected)
        self.assertFalse(milestone.restricted)
        self.assertEqual(milestone.inheritanceType, 'Local')
        self.assertTrue(self.client.delete_component_milestones([milestone], component))

        # Builds
        build_dict = {
            'name': u'unittest_Build_{}'.format(today),
            'startDate': '2022-07-01T00:00:00-0800',
            'endDate': '2022-08-01T00:00:00-0800',
            'closed': False
        }
        new_build = self.client.create_build_for_component(build_dict, component)
        self.assertIsInstance(new_build, radarclient.Build)
        builds = self.client.builds_for_component(component)
        build = _get_component_property_item(new_build, builds)
        self.assertEqual(build, new_build)
        self.assertIsInstance(build.startDate, datetime.datetime)
        self.assertIsInstance(build.endDate, datetime.datetime)
        self.assertFalse(build.closed)
        self.assertFalse(build.inherited)
        self.assertTrue(self.client.delete_component_builds([build], component))

        # Categories
        category_dict = {
            'name': u'unittest_Category_{}'.format(today),
            'startDate': '2022-07-01T00:00:00-0800',
            'endDate': '2022-08-01T00:00:00-0800',
            'milestoneAssociation': False,
            'tentpoleRequired': False,
            'closed': False,
        }
        new_category = self.client.create_category_for_component(category_dict, component)
        self.assertIsInstance(new_category, radarclient.Category)
        categories = self.client.categories_for_component(component)
        category = _get_component_property_item(new_category, categories)
        self.assertEqual(category, new_category)
        self.assertIsInstance(category.startDate, datetime.datetime)
        self.assertIsInstance(category.endDate, datetime.datetime)
        self.assertFalse(category.tentpoleRequired)
        self.assertFalse(category.milestoneAssociation)
        self.assertFalse(category.closed)
        self.assertFalse(category.inherited)
        self.assertTrue(self.client.delete_component_categories([category], component))

        # Tentpoles
        tentpole_dict = {
            'name': u'unittest_Tentpole_{}'.format(today),
            'startDate': '2022-07-01T00:00:00-0800',
            'endDate': '2022-08-01T00:00:00-0800',
            'categoryAssociation': False,
            'eventAssociation': False,
            'milestoneAssociation': False,
            'closed': False
        }
        new_tentpole = self.client.create_tentpole_for_component(tentpole_dict, component)
        self.assertIsInstance(new_tentpole, radarclient.Tentpole)
        tentpoles = self.client.tentpoles_for_component(component)
        tentpole = _get_component_property_item(new_tentpole, tentpoles)
        self.assertEqual(tentpole, new_tentpole)
        self.assertIsInstance(tentpole.startDate, datetime.datetime)
        self.assertIsInstance(tentpole.endDate, datetime.datetime)
        self.assertFalse(tentpole.categoryAssociation)
        self.assertFalse(tentpole.eventAssociation)
        self.assertFalse(tentpole.milestoneAssociation)
        self.assertFalse(tentpole.closed)
        self.assertFalse(tentpole.inherited)
        self.assertTrue(self.client.delete_component_tentpoles([tentpole], component))

        # Keywords
        keyword_dict = {
            'name': u'unittest_Keyword_{}'.format(today),
            'description': 'Created by test_radarclient.py',
            'type': 'Normal',
            'copiedOnClone': False,
            'autoAttached': False,
            'closed': False,
        }
        new_keyword = self.client.create_keyword_for_component(keyword_dict, component)
        self.assertIsInstance(new_keyword, radarclient.Keyword)
        keywords = self.client.keywords_for_component(component)
        keyword = _get_component_property_item(new_keyword, keywords)
        self.assertEqual(keyword, new_keyword)
        self.assertFalse(keyword.copiedOnClone)
        self.assertFalse(keyword.autoAttached)
        self.assertFalse(keyword.closed)
        self.assertFalse(keyword.inherited)
        self.assertTrue(self.client.delete_component_keywords([keyword], component))

    def check_event(self, event, client):
        self.assertEqual(event.inherited, False)
        self.assertEqual(event.definedComponentId, 515346)
        self.assertEqual(event.milestoneAssociation, False)
        self.assertEqual(event.tentpoleRequired, False)
        self.assertIsInstance(event.startDate, datetime.datetime)
        self.assertIsInstance(event.endDate, datetime.datetime)
        self.assertEqual(event.id, 238659)
        self.assertEqual(event.name, 'Event One')

    @skip_unless_enabled
    def test_keywords_for_component(self):
        for default_component in TestConfiguration.default_components():
            self._test_keywords_for_component(default_component)

    def _test_keywords_for_component(self, component):
        data = component
        components = self.client.find_components(data)
        component = components[0]
        self.assertIsInstance(component, Component)

        # Check the closed/inherited arguments
        all_keywords = self.client.keywords_for_component(component, include_closed=True)
        open_keywords = self.client.keywords_for_component(component, include_closed=False)
        self.assertGreater (len(all_keywords), len(open_keywords)), "all_keywords ({}) should have more than open_keywords ({})".format(
            len(all_keywords),
            len(open_keywords)
        )
        open_local_keywords = self.client.keywords_for_component(component, include_closed=False, include_inherited=False)
        for kw in open_local_keywords:
            self.assertFalse(kw.closed), "{} is unexpectedly closed".format(kw)
            self.assertFalse(kw.inherited), "{} is unexpectedly inherited".format(kw)

        # Check that the component properties match definedComponentId
        all_keywords_with_comp = self.client.keywords_for_component(component, include_closed=True, additional_fields=['component'])
        for kw in all_keywords_with_comp:
            assert hasattr(kw, 'component'), "{} has no component property!".format(kw)
            self.assertEqual(kw.component.id, kw.definedComponentId), "{}'s component ({}) does not match definedComponentId {}".format(
                kw,
                kw.component,
                kw.definedComponentId
            )

    @skip_unless_enabled
    def test_event(self):
        for default_component in TestConfiguration.default_components():
            self._test_event(default_component)

    def _test_event(self, component):
        data = component
        client = self.authenticated_radar_client_spnego()
        components = client.find_components(data)
        component = components[0]
        self.assertIsInstance(component, Component)
        events = client.events_for_component(component)
        self.assertGreaterEqual(len(events), 4, 'event item count does not match: {}'.format(events))

        self.check_event(events[0], client)

    @skip_unless_enabled
    def test_change_radar_program_management_component_properties(self):
        for default_component in TestConfiguration.default_components():
            self._test_change_radar_program_management_component_properties(default_component)

    def _test_change_radar_program_management_component_properties(self, component):
        self.skip_if_not_marc()
        data = component
        components = self.client.find_components(data)
        component = components[0]

        radar = self.client.radar_for_id(11725080, additional_fields='event category tentpole'.split())

        self.assertIsInstance(radar.event, radarclient.model.Event)
        self.assertIsInstance(radar.event.component, radarclient.model.Component)
        self.assertEqual(radar.event.name, 'Event One', msg='Unexpected event in radar:11725080')

        self.assertIsInstance(radar.category, radarclient.model.Category)
        self.assertIsInstance(radar.category.component, radarclient.model.Component)
        self.assertEqual(radar.category.name, 'Category One')

        self.assertIsInstance(radar.tentpole, radarclient.model.Tentpole)
        self.assertIsInstance(radar.tentpole.component, radarclient.model.Component)
        self.assertEqual(radar.tentpole.name, 'Tentpole One')

        events = self.client.events_for_component(component)
        categories = self.client.categories_for_component(component)
        tentpoles = self.client.tentpoles_for_component(component)

        radar.event = events[1]
        radar.category = categories[1]
        radar.tentpole = tentpoles[1]
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        radar = self.client.radar_for_id(11725080, additional_fields='event category tentpole'.split())
        self.assertEqual(radar.event.name, 'Event Two')
        self.assertEqual(radar.category.name, 'Category Two')
        self.assertEqual(radar.tentpole.name, 'Tentpole Two')

        radar.event = None
        radar.category = None
        radar.tentpole = None
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        radar = self.client.radar_for_id(11725080, additional_fields='event category tentpole'.split())
        self.assertIsNone(radar.event)
        self.assertIsNone(radar.category)
        self.assertIsNone(radar.tentpole)

        radar.event = events[0]
        radar.category = categories[0]
        radar.tentpole = tentpoles[0]
        radar.commit_changes()
        self.client.clear_radar_cache()
        time.sleep(2)

        radar = self.client.radar_for_id(11725080, additional_fields='event category tentpole'.split())
        self.assertEqual(radar.event.name, 'Event One')
        self.assertEqual(radar.category.name, 'Category One')
        self.assertEqual(radar.tentpole.name, 'Tentpole One')

    @unittest.skip('Looping benchmark, enable when needed')
    @skip_unless_enabled
    def test_auth_loop(self):
        counter = 0
        rs = RunningStats()

        while True:
            counter += 1
            self.client.clear_radar_cache()
            t1 = datetime.datetime.now()
            try:
                radar = self.client.radar_for_id(14392303)  # noqa
            except Exception as e:
                print('Exception for request {}: {}'.format(counter, e))
                continue
            t2 = datetime.datetime.now()
            s = (t2 - t1).total_seconds()
            rs.push(s)
            print('request {} {:0.03f}s mean {:0.03f} stddev {:0.03f}'.format(counter, s, rs.mean(), rs.standard_deviation()))

    @skip_unless_enabled
    def test_simple_integer_value_converter(self):
        converter = radarclient.model.SimpleIntegerValueConverter

        # Test encoding to CSV
        self.assertEqual(5, converter.encode_csv_value(5), 'Value not encoded correctly')

        # Test decoding to CSV valid int
        self.assertEqual(5, converter.decode_csv_value('5'), 'Valid value not decoded correctly')

        # Test decoding empty string
        self.assertIsNone(converter.decode_csv_value(''), 'Empty string not decoded to None')

        # Test error thrown for invalid data
        with self.assertRaises(ValueError):
            converter.decode_csv_value('abc')

    @skip_unless_enabled
    def test_keyword_value_csv_converter(self):
        converter = radarclient.model.KeywordValueConverter()
        test_keyword = self.client.keywords_for_ids([196144])[0]

        # Test valid encode CSV
        self.assertEqual(converter.encode_csv_value(test_keyword), 'radarclient-python test | 196144')

        # Test valid decode CSV
        self.assertEqual(
            radarclient.model.Keyword({'name': 'radarclient-python test', 'id': 196144}),
            converter.decode_csv_value('radarclient-python test | 196144')
        )

        # Test empty string
        self.assertIsNone(converter.decode_csv_value(''))

    @skip_unless_enabled
    def test_keyword_list_value_csv_converter(self):
        keyword_list = self.client.keywords_for_ids([196144, 514505])
        converter = radarclient.model.KeywordListValueConverter()

        expected_encoded_value = 'radarclient-python test | 196144\nradarclient-python test 2 | 514505'
        # Test valid encode
        self.assertEqual(
            converter.encode_csv_value(keyword_list),
            expected_encoded_value
        )

        # Test valid decode
        decode_str = 'abc | 1\n123 | 2'
        expected_encoded_value = validation = [Keyword({'name': 'abc', 'id': 1}), Keyword({'name': '123', 'id': 2})]
        self.assertListEqual(converter.decode_csv_value(decode_str), expected_encoded_value)

        # Test encode none
        self.assertIsNone(converter.encode_csv_value([]))

        # Test decode empty string
        self.assertIsNone(converter.decode_csv_value(''))

    @skip_unless_enabled
    def test_find_radars_multithreaded_default_chunking_key(self):
        for default_component in TestConfiguration.default_components():
            self._test_find_radars_multithreaded_default_chunking_key(default_component)

    def _test_find_radars_multithreaded_default_chunking_key(self, component):
        query = {
            'all': [
                {
                    'component': component
                },
                {
                    'createdAt': {
                        'gte': '2021-06-01T00:00:00+0000',
                        'lt': '2021-08-01T00:00:00+0000'
                    }
                },
                {
                    'priority': {
                        'neq': 1
                    }
                },
            ]
        }

        m_start = time.time()
        gen = self.client.find_radars_multithreaded(query, 72, additional_fields=['ccList'])
        multithreaded_set = set(gen)
        m_end = time.time()

        c_start = time.time()
        conventional_find_set = set(self.client.find_radars(query, additional_fields=['ccList']))
        self.assertEqual(multithreaded_set, conventional_find_set, 'Radar sets not equal')
        c_end = time.time()

    @skip_unless_enabled
    def test_find_radars_multithreaded_return_queue_directly(self):
        for default_component in TestConfiguration.default_components():
            self._test_find_radars_multithreaded_return_queue_directly(default_component)

    def _test_find_radars_multithreaded_return_queue_directly(self, component):
        query = {
            'all': [
                {
                    'component': component
                },
                {
                    'createdAt': {
                        'gte': '2021-06-01T00:00:00+0000',
                        'lt': '2021-08-01T00:00:00+0000'
                    }
                },
                {
                    'priority': {
                        'neq': 1
                    }
                },
            ]
        }

        result_queue, exception_queue, thread_set = self.client.find_radars_multithreaded(
            query, 72, additional_fields=['ccList'], return_result_queue=True
        )
        sentinel = 'STOP'
        wait_for_multithreaded_completion_helper(result_queue, exception_queue, thread_set, 1, sentinel=sentinel)
        multithreaded_set = queue_to_set(result_queue, sentinel)
        self.assertNotEqual(len(multithreaded_set), 0, 'No radars were returned')

        conventional_find_set = set(self.client.find_radars(query, additional_fields=['ccList']))
        self.assertEqual(multithreaded_set, conventional_find_set, 'Radar sets not equal')

    @skip_unless_enabled
    def test_find_radars_multithreaded_non_default_chunking_key_full_dict(self):
        query = {'all': [{'priority': {'eq': 1}},
                            {'originatedOrModifiedBy': {'eq': {'date': {'gte': '2021-01-01T00:00:00-0000',
                                                                        'lte': '2022-01-01T00:00:00-0000'},
                                                                'modifier': {'id': 299156498}}}},
                            {'any': [{'keywordId': {'eq': 536965}},
                                    {'keywordId': {'eq': 1188290}}]}]}

        gen = self.client.find_radars_multithreaded(
            query, 12, additional_fields=['keywords'], chunking_key='originatedOrModifiedBy'
        )
        multithreaded_set = set(gen)
        print(len(multithreaded_set))

        conventional_find_set = set(self.client.find_radars(query, additional_fields=['keywords']))
        self.assertEqual(multithreaded_set, conventional_find_set, 'Radar sets not equal')

    @skip_unless_enabled
    def test_find_radars_multithreaded_bad_query(self):
        for default_component in TestConfiguration.default_components():
            self._test_find_radars_multithreaded_bad_query(default_component)

    def _test_find_radars_multithreaded_bad_query(self, component):
        bad_query = {
            'all': [
                {
                    'component': component
                },
                {
                    'createdAt': {
                        'gte': '2021-06-01T00:00:00+0000',
                        'lt': '2021-08-01T00:00:00+0000'
                    }
                },
                {
                    'classification': {
                        'eq': 3.14159
                    }
                },
            ]
        }

        with self.assertRaises(radarclient.UnsuccessfulResponseException):
            gen = self.client.find_radars_multithreaded(bad_query, 72)
            for _ in gen:
                pass

    @skip_unless_enabled
    def test_find_radars_multithreaded_return_results_directly(self):
        for default_component in TestConfiguration.default_components():
            self._test_find_radars_multithreaded_return_results_directly(default_component)

    def _test_find_radars_multithreaded_return_results_directly(self, component):
        query = {
            'all': [
                {
                    'component': component
                },
                {
                    'createdAt': {
                        'gte': '2021-06-01T00:00:00+0000',
                        'lt': '2021-08-01T00:00:00+0000'
                    }
                },
                {
                    'priority': {
                        'neq': 1
                    }
                },
            ]
        }

        multithreaded_res = self.client.find_radars_multithreaded(query, 72,
                                                                  return_find_results_directly=True)
        multithreaded_set = set(multithreaded_res)

        classic_res = self.client.find_radars(query, return_find_results_directly=True)
        classic_set = set(classic_res)

        self.assertEqual(multithreaded_set, classic_set)

    @staticmethod
    def multiprocess_queue_worker(radar_q, counter):
        radar = radar_q.get()
        while radar is not None:
            with counter.get_lock():
                counter.value += 1
            radar = radar_q.get()

        return

    @unittest.skipIf(sys.version_info[0] == 2, 'skipping this test on Python 2 because it seems to hang (deadlock?)')
    def test_find_radars_multithreaded_return_result_queue(self):
        for default_component in TestConfiguration.default_components():
            self._test_find_radars_multithreaded_return_result_queue(default_component)

    def _test_find_radars_multithreaded_return_result_queue(self, component):
        query = {
            'all': [
                {
                    'component': component
                },
                {
                    'createdAt': {
                        'gte': '2021-06-01T00:00:00+0000',
                        'lt': '2021-08-01T00:00:00+0000'
                    }
                },
                {
                    'priority': {
                        'neq': 1
                    }
                },
            ]
        }

        multithreaded_res_q, exp_q, thread_set = self.client.find_radars_multithreaded(
            query, 72, return_find_results_directly=True, return_result_queue=True
        )

        multi_radar_count = Value('i', 0)
        proc_count = 4
        proc_list = []
        for _ in range(proc_count):
            p = Process(
                target=self.multiprocess_queue_worker, args=(multithreaded_res_q, multi_radar_count)
            )
            proc_list.append(p)
            p.start()

        wait_for_multithreaded_completion_helper(multithreaded_res_q, exp_q, thread_set, proc_count)
        multithreaded_res_q.close()
        multithreaded_res_q.join_thread()

        for process in proc_list:
            process.join()
        classic_res = self.client.find_radars(query, return_find_results_directly=True)
        self.assertEqual(len(classic_res), multi_radar_count.value)

    @skip_unless_enabled
    def test_radars_multithreaded_radar_count(self):

        CBG_TO_LOOKUP = 244 # Cocoa
        START_DATE = "2023-05-01T00:00:00"
        END_DATE = "2023-06-01T00:00:00"
        ADDITIONAL_RADAR_FIELDS = [
            "component",
            "diagnosis",
            "event",
            "fixedInBuild",
            "id",
            "keywordNames",
            "lastModifiedAt",
            "milestone",
            "priority",
            "relatedProblems",
            "resolution",
            "state",
            "succinctSummaryRootCause",
            "title",
        ]

        def error_callback(radar_id, error):
                            logging.error(
                                "Error getting radar {}".format(radar_id),
                                extra={"radar_id": radar_id, "error": error},
                            )
                            print(type(error))

        for scheme in self.client.retry_policy.schemes:
            if scheme[2] == 429:
                print(scheme)

        radar_query = {
            "componentBundleGroupId": CBG_TO_LOOKUP,
            "createdAt": {
                'gte': START_DATE,
                'lt': END_DATE
            }
        }
        radar_ids = self.client.find_radar_ids(radar_query)
        logging.info("Got %d Radar IDs", len(radar_ids))

        first_100 = radar_ids[:100]

        radar_ids.append(1) # this should yield a RadarAccessDeniedResponseException
        first_100.append(1)

        problems = self.client.radars_for_ids(first_100,
                                            additional_fields=ADDITIONAL_RADAR_FIELDS,
                                            error_callback=error_callback)
        problems = list(problems)

        logging.info("Lookup of first 100 got %d Radar IDs", len(problems))
        self.assertEqual(len(problems), 100)

        problems = self.client.radars_for_ids_multithreaded(
                        problem_ids=radar_ids,
                        additional_fields=ADDITIONAL_RADAR_FIELDS,
                        error_callback=error_callback,
                        max_pull_thread_count=24
                    )
        problems = list(problems)

        logging.info("Lookup got %d Radar IDs", len(problems))
        self.assertEqual(len(problems), len(radar_ids) - 1)

    @skip_unless_enabled
    def test_retry_policy(self):
        request_data = {
            'id': 23498754823,
            'nonsense_key': 'nonsense_value'
        }

        retry_client = RadarClient(self.authentication_strategy_spnego(), self.system_identifier(),
                                   retry_policy=RetryPolicy())
        try:
            status, response = retry_client.build_and_send_json_request(
                ('problems', 'find'),
                request_data,
                method='POST'
            )
        except UnsuccessfulResponseException as u:
            self.assertEqual(u.code, 400)
            self.assertNotIsInstance(u, MaximumSendAttemptsExceededException)

        # Test with a custom scheme design
        design = [{
            'methods': [
                'POST'
            ],
            'endpoints': [
                'problems/find'
            ],
            'status_codes': [
                400,    # Bad Request
                429     # Too Many Attempts
            ],
            'delay_type': RetryPolicy.DELAY_TYPE_FIXED,
            'max_send_attempts': 3
        }]
        self.assertEqual(retry_client.sent_request_count, 1)

        retry_client = RadarClient(
            self.authentication_strategy_spnego(),
            self.system_identifier(),
            retry_policy=RetryPolicy(scheme_design=design)
        )
        self.assertEqual(len(retry_client.retry_policy.schemes), 2)
        try:
            status, response = retry_client.build_and_send_json_request(
                ('problems', 'find'),
                request_data,
                method='POST'
            )
        except UnsuccessfulResponseException as u:
            self.assertIn(u.code, [400, 429])
            self.assertIsInstance(u, MaximumSendAttemptsExceededException)
        self.assertEqual(retry_client.sent_request_count, 3)

        # Test with an empty 'endpoints' list
        no_ep_design = [{
            'methods': [
                'POST'
            ],
            'endpoints': [],
            'status_codes': [
                400,    # Bad Request
                429     # Too Many Attempts
            ],
            'delay_type': RetryPolicy.DELAY_TYPE_FIXED,
            'max_send_attempts': 3
        }]
        no_ep_retry_client = RadarClient(
            self.authentication_strategy_spnego(),
            self.system_identifier(),
            retry_policy=RetryPolicy(scheme_design=no_ep_design)
        )
        self.assertEqual(len(no_ep_retry_client.retry_policy.schemes), 2)
        try:
            status, response = no_ep_retry_client.build_and_send_json_request(
                ('problems', 'find'),
                request_data,
                method='POST'
            )
        except UnsuccessfulResponseException as u:
            self.assertIn(u.code, [400, 429])
            self.assertIsInstance(u, MaximumSendAttemptsExceededException)
        self.assertEqual(no_ep_retry_client.sent_request_count, 3)

        # Test that the multithreaded methods are properly deepcopying the RetryPolicy (was rdar://100174249)
        request_data = {'component': {'name': 'python-radarclient', 'version': '1.0', 'includeSubcomponents': True},
                        'createdAt': {'gte': '2022-01-01T08:00:00+0000',
                                      'lt': '2022-08-01T08:00:00+0000'},
                        'nonsense_key': 'nonsense_value'}
        try:
            _ = list(retry_client.find_radar_ids_multithreaded(request_data, chunk_hours=500, chunking_key='createdAt'))
        except UnsuccessfulResponseException as u:
            self.assertEqual(u.code, 400)
            self.assertIsInstance(u, MaximumSendAttemptsExceededException)

    @skip_unless_enabled
    def test_rate_limit_policy(self):

        # test endpoint regular expressions
        rate_limit_policy = RateLimitPolicy()

        self.assertEqual(rate_limit_policy._get_rate_limit_rule("POST", "/problems/find").rate_limit, 9)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("GET", "/problems/123").rate_limit, 10)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("GET", "/problems/123,456").rate_limit, 10)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("POST", "/problems/123/clone").rate_limit, 4)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("GET", "/problems/123/keywords").rate_limit, 15)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("DELETE", "/problems/123/related-problems/blocked-by/123").rate_limit, 3)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/componentTree").rate_limit, 6)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("POST", "/components/123/events").rate_limit, 2)
        self.assertEqual(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/events").rate_limit, 5)

        self.assertIsNone(rate_limit_policy._get_rate_limit_rule("GET", "/components"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("POST", "/components"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("POST", "/components/find"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/123"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/Foo/Bar"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/clone"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/componentTree"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/Foo/Bar/events/"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/categories"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/Foo/Bar/categories"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/component-root"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/123/events/555"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("GET", "/components/history/123"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("POST", "/problems/123/related-problems"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("PUT", "/problems/123/related-problems/blocking/456"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("POST", "/problems/keywords/add"))
        self.assertIsNotNone(rate_limit_policy._get_rate_limit_rule("PUT", "/problems/keywords/remove"))

        # 100 SWE components, any will do
        component_ids = [801480, 808171, 833157, 1499932, 925370, 1022969, 1235912, 1366126, 957877, 941619, 819090, 801491, 939057, 945329, 209667, 448966, 498949, 1087507, 84168, 547394, 547395, 91084, 301085, 458846, 665110, 236573, 677141, 417126, 377764, 181796, 615150, 653806, 226603, 467247, 441903, 137385, 302184, 84140, 391083, 611047, 230060, 463799, 362804, 140913, 292343, 84661, 219255, 441904, 467249, 467248, 457404, 849330, 1173136, 247302, 818953, 818954, 1095254, 1341074, 1610463, 637891, 365326, 697671, 933379, 652999, 1569113, 1185474, 177107, 442844, 829590, 948176, 1512503, 568365, 164965, 149610, 1610865, 146536, 149609, 1602099, 139500, 468265, 139501, 537464, 1252898, 663806, 939450, 843898, 113721, 406334, 1085929, 859190, 1085931, 102401, 1328020, 1085970, 723470, 463246, 1280986, 463245, 841024, 841025]

        retry_callback_1 = ThreadsafeRetryCallback()
        client_no_rate_limit = RadarClient(self.authentication_strategy_spnego(), self.system_identifier(), retry_policy=RetryPolicy(max_send_attempts=4, logging_callback=retry_callback_1))
        retry_callback_2 = ThreadsafeRetryCallback()
        rate_limit_callback_2 = ThreadsafeRateLimitCallback()
        client_rate_limit = RadarClient(self.authentication_strategy_spnego(), self.system_identifier(), retry_policy=RetryPolicy(max_send_attempts=4, logging_callback=retry_callback_2), rate_limit_policy=RateLimitPolicy(logging_callback=rate_limit_callback_2))

        start_time = time.time()
        start_retry_count = retry_callback_1.retry_count()
        components = Component._pseudo_get_by_ids(component_ids, client_no_rate_limit)
        end_time = time.time()
        retry_count = retry_callback_1.retry_count() - start_retry_count

        logger.info("Got %d components with single-threaded lookup in %.3fs with %d retries", len(components), (end_time - start_time), retry_count)
        time.sleep(1.0)

        start_time = time.time()
        start_retry_count = retry_callback_1.retry_count()
        manager = radarclient.SimpleThreadManager(component_ids, chunked_kwarg='component_id', max_thread_count=25)
        components = manager.get_threaded_results(
            client_no_rate_limit,
            'component_for_id',
            component_id=None,
        )
        self.assertRaises(MaximumSendAttemptsExceededException, list, components)
        retry_count = retry_callback_1.retry_count() - start_retry_count
        end_time = time.time()

        logger.info("Got exception with multi-threaded lookup in %.3fs with %d retries", (end_time - start_time), retry_count)
        time.sleep(1.0)

        start_time = time.time()
        start_retry_count = retry_callback_2.retry_count()
        start_rate_limit_wait_count = rate_limit_callback_2.rate_limit_wait_count()
        manager = radarclient.SimpleThreadManager(component_ids, chunked_kwarg='component_id', max_thread_count=25)
        components = manager.get_threaded_results(
            client_rate_limit,
            'component_for_id',
            component_id=None,
        )
        components = list(components)
        end_time = time.time()
        retry_count = retry_callback_2.retry_count() - start_retry_count
        rate_limit_wait_count = rate_limit_callback_2.rate_limit_wait_count() - start_rate_limit_wait_count

        logger.info("Got %d components with multi-threaded lookup in %.3fs with %d retries and %d waits", len(components), (end_time - start_time), retry_count, rate_limit_wait_count)
        self.assertGreaterEqual(rate_limit_wait_count, 20)          # Of the initial 25 threads, 21 will need to wait
        self.assertGreaterEqual(rate_limit_wait_count, retry_count) # There should be fewer retries than waits, otherwise we aren't waiting long enough
        time.sleep(1.0)

    @skip_unless_enabled
    def test_find_radar_ids_multithreaded(self):
        request_data = {'all': [{'component': {'eq': {'id': 514369, 'includeSubcomponents': True}}},
                                {'createdAt': {'gte': '2022-01-01T08:00:00+0000',
                                               'lt': '2022-08-01T08:00:00+0000'}}]}
        start_time = time.time()
        conventional_radar_ids = self.client.find_radar_ids(request_data)
        conventional_elapsed_time = round((time.time() - start_time),3)
        print("\nsingle-thread find completed in {}s".format(conventional_elapsed_time))

        start_time = time.time()
        multithreaded_radar_ids = set(self.client.find_radar_ids_multithreaded(request_data, chunk_hours=168,
                                                                               chunking_key='createdAt',
                                                                               limit=10000))
        multithreaded_elapsed_time = round((time.time() - start_time),3)
        print("multithreaded find completed in {}s".format(multithreaded_elapsed_time))

        conventional_set = set(conventional_radar_ids)
        self.assertEqual(conventional_set, multithreaded_radar_ids)

        # Test with queue directly
        start_time = time.time()
        result_q, exception_q, thread_set = self.client.find_radar_ids_multithreaded(
            request_data, chunk_hours=168, chunking_key='createdAt', return_result_queue=True
        )
        wait_for_multithreaded_completion_helper(result_q, exception_q, thread_set, 1)
        direct_set = queue_to_set(result_q)
        return_result_queue_elapsed_time = round((time.time() - start_time),3)
        print("multithreaded find with result_result_queue completed in {}s".format(return_result_queue_elapsed_time))

        self.assertEqual(conventional_set, direct_set)

    @skip_unless_enabled
    def test_radars_for_ids_multithreaded(self):
        idlist = [95813592, 95813702, 95788184, 97264015, 96523811, 95788186, 96634641, 95788190, 95788174, 95788192,
                  95788181, 95249784, 96172751, 96523804, 97111517, 95249117, 96956222, 95788199, 77499948, 97041376,
                  73723257, 96810790, 96810690, 93052650, 95799918, 95820373, 95820369, 95816854, 95816851, 95816848,
                  95816835, 95816832, 95799926, 95799922, 96234122, 92811822, 95799910, 95799907, 92812213, 92812208,
                  92811824, 92811778, 92811819, 92811797, 92811793, 96247001, 96018801, 95816729, 95816829, 95887515,
                  73539274, 90996783, 90996776, 88981510, 88981501, 86278791, 86278778, 84647073, 84647069, 84643048,
                  84643041, 84636684, 84636679, 84635733, 84635723, 84627500, 84627490, 84125437, 84125426, 81584927,
                  81584926, 81583634, 81583610, 81582022, 81582016, 80878486, 80878480, 80877850, 80877371, 80875520,
                  80542852, 80542844, 80540525, 80540521, 80531154, 80531137, 79941160, 79941154, 79786949, 79786940,
                  79042085, 79042079, 77404387, 77404382, 77403290, 77403288, 75763460, 75763455, 75761724, 75761718,
                  75757261, 75757256, 75755838, 75755832, 75548343, 75548326, 75245552, 75245547, 75244051, 75244047,
                  74768978, 74768972, 74767495, 74767492, 74764211, 74764206, 74733052, 74733050, 74298750, 74298746,
                  74282051, 74282049, 74280065, 74280062, 73729569, 73729565, 73728090, 73728086, 73723572, 73723566,
                  73722248, 73722199, 73697932, 73697930, 73697107, 73697105, 73691619, 73691615, 73688555, 73688552,
                  73670124, 73670118, 73543599, 73543591, 73539921, 73539920, 73539276, 95799899, 95799753, 95213600,
                  94658281, 95628310, 95625553, 95186353, 95613916, 95215727, 95124310, 95326074, 95249129, 87950261,
                  84690439, 90337146, 92699704, 92811662, 92534317, 92477296, 92174978, 91693367, 91693299, 91647131,
                  90995688, 90995925, 90995921, 90995915, 90995892, 90995890, 90995870, 90801007, 90983945, 90666047,
                  89190267, 86643343, 89605624, 89454880, 88712484, 88978611, 88979985, 88979980, 88979975, 88979951,
                  88979946, 88979926, 88727506, 88333316, 88092948, 88151945, 88031786, 86649846, 88104436, 88101602,
                  87233096, 85476013, 74261232, 86649341, 86649099, 86649008, 85092615, 86278078, 86278071, 86278058,
                  86278022, 86278017, 86277982, 83703056, 85473398, 85327496, 84976890, 83421164, 83618589, 83680085,
                  85044106, 82907319, 83919931, 84785588, 76460010, 78107908, 84340298, 84646697, 84646691, 84646687,
                  84646672, 84646668, 84646649, 84642822, 84642818, 84642815, 84642808, 84642807, 84642796, 84636335,
                  84636331, 84636328, 84636319, 84636316, 84636296, 84635262, 84635259, 84635248, 84635239, 84635235,
                  84635213, 84627098, 84627092, 84627088, 84627079, 84627076, 84627053, 84124987, 84124985, 84124982,
                  84124974, 84124970, 84124891, 83724959, 82984716, 83140229, 82551771, 82796881, 82186910, 82186814,
                  76586222, 81728205, 81638760, 81544575, 81584510, 81584507, 81584503, 81584498, 81584495, 81584488,
                  81583018, 81583016, 81583010, 81583000, 81582997, 81582979, 81581480, 81581477, 81581472, 81581464,
                  81581463, 81581449, 80931840, 80878261, 80878259, 80878252, 80878248, 80878244, 80878223, 80877205,
                  80877203, 80877197, 80877191, 80877190, 80877181, 80875336, 80875334, 80875329, 80875323, 80875321,
                  80875303, 80712661, 80648914, 80648850, 80648801, 80542526, 80542521, 80542517, 80542503, 80542502,
                  80542483, 80540206, 80540201, 80540198, 80540182, 80540180, 80540164, 80534253, 80534246, 80534244,
                  80534234, 80534231, 80534217, 80530808, 80530801, 80530800, 80530785, 80530782, 80530765, 80389405,
                  79940110, 79940107, 79940103, 79940095, 79940086, 79939993, 79905619, 79887094, 79875515, 79786580,
                  79786576, 79786570, 79786559, 79786557, 79786542, 79454056, 79354082, 79041821, 79041815, 79041810,
                  79041799, 79041796, 79041780, 79037432, 78892950, 78323743, 77480705, 77945934, 77873096, 76806993,
                  77444845, 77439891, 77404174, 77404171, 77404168, 77404157, 77404153, 77404145, 77403043, 77403041,
                  77403037, 77403029, 77403028, 77403021, 77092730, 76731663, 76979738, 76923340, 76764640, 76067168,
                  75191177, 76220329, 75760363, 75739842, 75763197, 75763193, 75763191, 75763184, 75763182, 75763170,
                  75761390, 75761384, 75761375, 75761367, 75761366, 75761344, 75756505, 75756500, 75756497, 75756490,
                  75756488, 75756481, 75755477, 75755473, 75755464, 75755456, 75755453, 75755434, 75653329, 75548039,
                  75548035, 75548031, 75548018, 75548016, 75548004, 75530150, 75324451, 74929093, 75269677, 75227162,
                  75245018, 75245015, 75245011, 75245008, 75245005, 75244997, 75243671, 75243670, 75243664, 75243654,
                  75243646, 75243630, 75085839, 75085689, 75199353, 75199351, 75195931, 75195926, 74883231, 74768653,
                  74768651, 74768646, 74768630, 74768629, 74768608, 74766814, 74766808, 74766804, 74766790, 74766789,
                  74766766, 74763800, 74763796, 74763793, 74763786, 74763783, 74763765, 74732816, 74732812, 74732811,
                  74732806, 74732801, 74732785, 74681386, 74609334, 74406468, 74406447, 74298471, 74298468, 74298467,
                  74298463, 74298462, 74298448, 74287143, 74287141, 74280979, 74281314, 74281307, 74281304, 74281296,
                  74281273, 74279785, 74279780, 74279773, 74279768, 74279767, 74279748, 73985124, 73985101, 73728651,
                  73728650, 73728648, 73728641, 73728640, 73728633, 73727794, 73723254, 73723250, 73723225, 73723224,
                  73723206, 73721398, 73721397, 73721396, 73721389, 73721385, 73721375, 73697461, 73697458, 73697455,
                  73697449, 73697444, 73697434, 73696564, 73696561, 73696559, 73696558, 73696556, 73696539, 73691324,
                  73691323, 73691320, 73691312, 73691311, 73691263, 73687925, 73687919, 73687913, 73687697, 73687696,
                  73687577, 73668808, 73668805, 73668803, 73668783, 73668781, 73668710, 73668200, 73668196, 73668191,
                  73668183, 73668182, 73668169, 73543438, 73543436, 73543435, 73543434, 73543433, 73543432, 73539819,
                  73539816, 73539814, 73539811, 73539810, 73539805, 73539180, 73539178, 73539177, 73539175, 73539174,
                  73539170, 73383379, 73009838]

        start_time = time.time()
        conventional_radars = self.client.radars_for_ids(idlist)
        conventional_elapsed_time = round((time.time() - start_time),3)
        print("\nsingle-thread retrieval completed in {}s".format(conventional_elapsed_time))

        start_time = time.time()
        multithreaded_radars = set(self.client.radars_for_ids_multithreaded(idlist))
        multithreaded_elapsed_time = round((time.time() - start_time),3)
        print("multithreaded retrieval completed in {}s".format(multithreaded_elapsed_time))

        conventional_set = set(conventional_radars)
        self.assertEqual(conventional_set, multithreaded_radars)

        # Test getting the result queue directly
        start_time = time.time()
        result_q, exception_q, thread_set = self.client.radars_for_ids_multithreaded(idlist, return_result_queue=True)
        wait_for_multithreaded_completion_helper(result_q, exception_q, thread_set, 1)
        direct_set = queue_to_set(result_q)
        return_result_queue_elapsed_time = round((time.time() - start_time),3)
        print("multithreaded retrieval with return_result_queue completed in {}s".format(return_result_queue_elapsed_time))

        self.assertEqual(conventional_set, direct_set)

    @skip_unless_enabled
    def test_combined_history(self):
        radar1 = self.client.radar_for_id(67874542)
        combined_history1 = radar1.combined_history()
        for mod_event in combined_history1:
            self.assertEqual(mod_event.changed_at, mod_event.radar_history_snapshot.lastModifiedAt)

        radar2 = self.client.radar_for_id(140987717)
        combined_history2 = radar2.combined_history(additional_snapshot_attributes=["workaround"], include_data_changes=True)
        for mod_event in combined_history2:
            self.assertEqual(mod_event.changed_at, mod_event.radar_history_snapshot.lastModifiedAt)
            assert hasattr(mod_event.radar_history_snapshot, "workaround")

        radar3 = self.client.radar_for_id(134949347)
        combined_history3 = radar3.combined_history(skip_diagnosis_history=True)
        for mod_event in combined_history3:
            self.assertEqual(mod_event.changed_at, mod_event.radar_history_snapshot.lastModifiedAt)

        self.client.clear_radar_cache()

    @skip_unless_enabled
    def test_combined_history_multithreaded(self):
        def _has_combined_history(radar):
            try:
                if radar._combined_history_events:
                    return True
            except:
                pass
            return False

        def _check_for_history(radars):
            processed_radars = []
            for radar in radars:
                self.assertTrue(_has_combined_history(radar), "rdar://{} has no _combined_history_events "
                                                              "property!".format(radar.id))
                del radar._combined_history_events
                processed_radars.append(radar)
            return processed_radars

        idlist = [95813592, 95813702, 95788184, 97264015, 96523811, 95788186, 96634641, 95788190, 95788174, 95788192,
                  95788181, 95249784, 96172751, 96523804, 97111517, 95249117, 96956222, 95788199, 77499948, 97041376,
                  73723257, 96810790, 96810690, 93052650, 95799918, 95820373, 95820369, 95816854, 95816851, 95816848,
                  95816835, 95816832, 95799926, 95799922, 96234122, 92811822, 95799910, 95799907, 92812213, 92812208,
                  92811824, 92811778, 92811819, 92811797, 92811793, 96247001, 96018801, 95816729, 95816829, 95887515,
                  73539274, 90996783, 90996776, 88981510, 88981501, 86278791, 86278778, 84647073, 84647069, 84643048,
                  84643041, 84636684, 84636679, 84635733, 84635723, 84627500, 84627490, 84125437, 84125426, 81584927,
                  81584926, 81583634, 81583610, 81582022, 81582016]

        start_time = time.time()
        radars = list(self.client.radars_for_ids_multithreaded(idlist))
        elapsed_time = round((time.time() - start_time),3)
        print("\nmultithreaded retrieval completed in {}s".format(elapsed_time))

        start_time = time.time()
        radars_with_history = self.client.combined_history_multithreaded(radars)
        local_radars = _check_for_history(radars_with_history)
        elapsed_time = round((time.time() - start_time), 3)
        print("combined_history_multithreaded() completed in {}s".format(elapsed_time))

        start_time = time.time()
        for radar in local_radars:
            _ = radar.combined_history()
        _check_for_history(local_radars)
        elapsed_time = round((time.time() - start_time), 3)
        print("serial combined_history() completed in {}s".format(elapsed_time))

        # Check return_result_queue
        start_time = time.time()
        result_q, exception_q, thread_set = self.client.combined_history_multithreaded(radars, return_result_queue=True)
        wait_for_multithreaded_completion_helper(result_q, exception_q, thread_set, 1)
        direct_set = queue_to_set(result_q)
        _check_for_history(direct_set)
        elapsed_time = round((time.time() - start_time), 3)
        print("multithreaded combined_history() with return_result_queue completed in {}s".format(elapsed_time))

    @skip_unless_enabled
    def test_workflows(self):
        component = self.client.component_for_id(1304996)   # python-radarclient-test bugs | version/with slash
        user_dsid = self.client.current_user().dsid
        today = time.time()

        # Create a new Workflow
        conditions = {
            "component": {
                "id": component.id,
                "includeSubcomponents": True
            }
        }
        actions = {
            "CC": {
                "insert": [
                    {
                       "id": user_dsid
                    }
                ]
            }
        }
        notifications = [
            {
                'notificationType': 'EMAIL',
                'attributes': {}
            }
        ]
        new_workflow = self.client.create_workflow(conditions, actions, notifications)
        self.assertIsInstance(new_workflow, Workflow)

        # Get Workflow by ID
        new_workflow_by_id = self.client.workflow_for_id(new_workflow.workflowId)
        # Wait for the 'status' to change from 'INDEXING' to 'ACTIVE'
        _cycle_count = 0
        _max_cycles = 30
        while _cycle_count < _max_cycles:
            _cycle_count += 1
            if new_workflow_by_id.status == 'INDEXING':
                time.sleep(1)
                new_workflow_by_id = self.client.workflow_for_id(new_workflow.workflowId)
        self.assertEqual(new_workflow_by_id.status, 'ACTIVE', "New Workflow is not 'ACTIVE'!")

        # Get all the user's Workflows
        current_user_workflows = self.client.workflows_for_current_user()
        self.assertNotEqual(len(current_user_workflows), 0, "No Workflows found for current user!")
        self.assertIn(
            new_workflow_by_id,
            current_user_workflows,
            "New Workflow '{}' not found in current user Workflows!".format(new_workflow_by_id.workflowId)
        )

        # Update Workflow with name and status, Get by IDs
        new_name = "python-radarclient_{}_unittest_WorkFlow_{}".format(user_dsid, today)
        new_status = "INACTIVE"
        updated_workflow = self.client.update_workflow(new_workflow_by_id, name=new_name, status=new_status)
        updated_workflow_by_ids = self.client.workflows_for_ids([updated_workflow.workflowId])[0]
        # Wait for the 'status' to change from 'INDEXING' to 'ACTIVE' or 'INACTIVE'
        _cycle_count = 0
        _max_cycles = 30
        while _cycle_count < _max_cycles:
            _cycle_count += 1
            if updated_workflow_by_ids.status == 'INDEXING':
                time.sleep(1)
                updated_workflow_by_ids = self.client.workflows_for_ids([updated_workflow.workflowId])[0]

        # assertEqual/assertNotEqual can't differentiate objects?
        # self.assertNotEqual(new_workflow_by_id, updated_workflow_by_ids, "Workflows still match!")
        self.assertEqual(updated_workflow_by_ids.name, new_name, "New name not found on updated Workflow!")
        self.assertEqual(updated_workflow_by_ids.status, new_status, "New status not found on updated Workflow!")

        # Find Workflows
        request_data = {
            'search': new_name
        }

        for is_final_attempt, attempt, delay_seconds in attempts_with_increasing_delay(6):
            try:
                found_workflows = self.client.find_workflows(request_data)
                self.assertEqual(len(found_workflows), 1,
                                "Expecting one matching Workflow, found {}".format(len(found_workflows)))
                break
            except AssertionError:
                if is_final_attempt:
                    raise

        self.assertEqual(updated_workflow_by_ids, found_workflows[0], "Workflows don't match!")

        # Delete Workflow
        self.assertTrue(self.client.delete_workflow(updated_workflow_by_ids))
        current_user_workflows = self.client.workflows_for_current_user()
        self.assertNotIn(
            new_workflow.workflowId,
            [workflow.workflowId for workflow in current_user_workflows],
            "Found deleted Workflow in current user's Workflows!"
        )

    @skip_unless_enabled
    def test_query_basic_suite(self):
        today = time.time()

        # Create a new Query
        search_attributes = {
            "all": [
                {
                    "component": {
                        "eq": {
                            "id": 514369,
                            "includeSubcomponents": False
                        }
                    }
                },
                {
                    "createdAt": {
                        "gte": "2022-01-01T00:00:00+0000",
                        "lt": "2023-01-01T00:00:00+0000",
                    }
                }
            ]
        }
        name = 'python-radarclient unittest_Query_{}'.format(today)
        description = "."
        new_query = self.client.create_query(name, search_attributes, description)
        self.assertIsInstance(new_query, Query)

        # Load the query from the API
        query_from_id = self.client.query_for_id(new_query.id)
        self.assertIsInstance(query_from_id, Query)
        self.assertEqual(query_from_id.name, new_query.name, "Query name mismatch!")
        self.assertEqual(query_from_id.type, new_query.type, "Query type mismatch!")

        # Find the Query
        request_data = {
            'ALL': {
                'ids': [query_from_id.id]
            }
        }

        for is_final_attempt, attempt, delay_seconds in attempts_with_increasing_delay(6):
            try:
                found_queries = self.client.find_queries(request_data)
                self.assertEqual(len(found_queries), 1, "Didn't find the Query!")
                break
            except AssertionError:
                if is_final_attempt:
                    raise

        found_query = found_queries[0]
        self.assertEqual(found_query.id, query_from_id.id)
        self.assertEqual(found_query.name, query_from_id.name, "Query name mismatch!")

        # Execute the new Query
        radars = self.client.radars_for_query(found_query.id)
        self.assertNotEqual(len(radars), 0, "No Radars found via Query!")
        original_ids = [radar.id for radar in radars]
        radar_ids = self.client.radar_ids_for_query(found_query.id)
        self.assertEqual(set(sorted(original_ids)), set(sorted(radar_ids)), "Radar ID sets don't match!")
        radar_count = self.client.radar_count_for_query(found_query.id)
        self.assertEqual(radar_count, len(radars), "Radar count mismatch!")

        # Execute the new Query while overriding PROBLEM_DEFAULT_FIELDS
        requested_fields = ['id', 'title', 'state', 'createdAt']
        self.client.clear_radar_cache()
        radars = self.client.radars_for_query(found_query.id, fields=requested_fields)
        for radar in radars:
            for attr in ['resolution', 'component', 'assignee', 'milestone', 'resolvedAt']:
                self.assertFalse(hasattr(radar, attr), "Radar object for {} has an unexpected attribute: {}".format(radar.id, attr))
            for attr in requested_fields:
                self.assertTrue(hasattr(radar, attr), "Radar object for {} is missing expected attribute: {}".format(radar.id, attr))

        # Delete the Query
        self.assertTrue(self.client.delete_query(found_query))

    @skip_unless_enabled
    def test_query_permissions_suite(self):
        design = [{
            'methods': ['GET', 'POST'],
            'endpoints': ['query'],
            'status_codes': [429],
            'delay_type': RetryPolicy.DELAY_TYPE_EXPONENTIAL_BACKOFF,
            'max_send_attempts': 3
        }]
        retry_client = RadarClient(
            self.authentication_strategy_spnego(),
            self.system_identifier(),
            retry_policy=RetryPolicy(scheme_design=design)
        )

        today = datetime.datetime.now().strftime("%Y%m%d")
        name = 'python-radarclient unittest_Query_{}'.format(today)

        for query in retry_client.find_queries({'name': name}):
            print('Deleting existing query {} with name "{}"'.format(query.id, name))
            retry_client.delete_query(query)

        # Create a new Query
        search_attributes = {
            "all": [
                {
                    "component": {
                        "eq": {
                            "id": 514369,
                            "includeSubcomponents": False
                        }
                    }
                },
                {
                    "createdAt": {
                        "gte": "2022-01-01T00:00:00+0000",
                        "lt": "2023-01-01T00:00:00+0000",
                    }
                }
            ]
        }
        description = "."
        try:
            new_query = retry_client.create_query(name, search_attributes, description)
        except UnsuccessfulResponseException as e:
            if e.code == 400 and 'is already created' in e.message:
                raise Exception('xxx')

        self.assertIsInstance(new_query, Query)

        # Add Person to Query
        curr_user_dsid = retry_client.current_user().dsid
        dsid_to_add = 299156498 if curr_user_dsid == 10152472 else 10152472 # Use Ben (10152472) or Marc (299156498), whoever user isn't
        user_to_add = retry_client.person_for_dsid(dsid_to_add)
        permission = Query.READ_AND_WRITE_PERMISSION
        new_query = retry_client.add_person_to_query(new_query, user_to_add, permission)
        query_from_id = retry_client.query_for_id(new_query.id)
        self.assertIn(user_to_add, [sub.subscriber for sub in query_from_id.subscribers],
                      "Added user not found in Query subscribers! Query ID: {}".format(query_from_id.id))

        # Change Query subscriber permissions
        new_permission = Query.READ_ONLY_PERMISSION
        query_from_id = retry_client.set_subscriber_permissions_for_query(query_from_id, [user_to_add], new_permission)
        query_from_id = retry_client.query_for_id(new_query.id)
        self.assertIn(user_to_add, [sub.subscriber for sub in query_from_id.subscribers],
                      "Added user not found in Query subscribers! Query ID: {}".format(query_from_id.id))
        added_user = next((sub for sub in query_from_id.subscribers if isinstance(sub.subscriber, Person) and sub.subscriber.dsid == dsid_to_add), None)
        self.assertEqual(added_user.permission, new_permission)

        # Remove Person from Query
        self.assertTrue(retry_client.remove_person_from_query(query_from_id, added_user.subscriber))
        query_from_id = retry_client.query_for_id(new_query.id)
        self.assertNotIn(user_to_add, [sub.subscriber for sub in query_from_id.subscribers],
                      "Removed user still found in Query subscribers! Query ID: {}".format(query_from_id.id))

        # Add group to Query
        work_group = retry_client.work_group_for_id(131276)
        access_group = retry_client.access_group_for_id(131277)
        for group in [work_group, access_group]:
            _ = retry_client.add_group_to_query(query_from_id, group, new_permission)
        query_from_id = retry_client.query_for_id(new_query.id)
        self.assertIn(work_group, [sub.subscriber for sub in query_from_id.subscribers],
                      "Added Work Group not found in Query subscribers! Query ID: {}".format(query_from_id.id))
        self.assertIn(access_group, [sub.subscriber for sub in query_from_id.subscribers],
                      "Added Access Group not found in Query subscribers! Query ID: {}".format(query_from_id.id))

        # Remove group from Query
        for group in [work_group, access_group]:
            _ = retry_client.remove_group_from_query(query_from_id, group)
        query_from_id = retry_client.query_for_id(new_query.id)
        self.assertNotIn(work_group, [sub.subscriber for sub in query_from_id.subscribers],
                      "Removed Work Group still found in Query subscribers! Query ID: {}".format(query_from_id.id))
        self.assertNotIn(access_group, [sub.subscriber for sub in query_from_id.subscribers],
                      "Removed Access Group still found in Query subscribers! Query ID: {}".format(query_from_id.id))

        # Change Everyone permissions on Query
        query_from_id = retry_client.set_everyone_permissions_for_query(query_from_id, Query.READ_ONLY_PERMISSION)
        query_from_id = retry_client.query_for_id(new_query.id)
        everyone_subcriber = next(
            (sub for sub in query_from_id.subscribers if isinstance(sub.subscriber, QuerySubscriberEveryone)),
            None
        )
        self.assertEqual(everyone_subcriber.permission, Query.READ_ONLY_PERMISSION,
                         "Everyone permission incorrect! Query ID: {}".format(query_from_id.id))

        # Delete the Query
        self.assertTrue(retry_client.delete_query(query_from_id))

    @skip_unless_enabled
    def test_radar_modify_job(self):
        request_dict = {
            'problemIDs': [93065929, 93064778, 93064532, 93062549, 8657654769092836481872],
            'diagnosis': 'Test mass modify in radarclient completed'
        }
        mod_job = ModifyRadarsJob(self.client, request_dict)
        mod_job.wait_until_done(status_callback=print)
        self.assertEqual('COMPLETED', mod_job.jobStatus)

    @skip_unless_enabled
    def test_radar_modify_job_with_timeout(self):
        end_statuses = {'CANCELED', 'COMPLETED'}
        request_dict = {
            'problemIDs': [93065929, 93064778, 93064532, 93062549, 95820373, 95820369, 95816854, 95816851,
                           95816848, 95816835, 95816832, 95799926, 95799922, 95799918, 95799910, 95799907,
                           92812213, 92812208, 92811824, 92811822, 92811819, 92811797, 92811793, 92811778],
            'diagnosis': 'Test mass modify in radarclient completed or possibly canceled'
        }
        mod_job = ModifyRadarsJob(self.client, request_dict)
        with self.assertRaises(APIJobTimeoutException):
            mod_job.wait_until_done(timeout=0, status_callback=print)
        attempts = 0
        while attempts < 5:
            attempts += 1
            mod_job.fetch_job_info()
            if mod_job.jobStatus in end_statuses:
                break
            print('attempt {}'.format(attempts))
            time.sleep(attempts * 1)

        self.assertIn(mod_job.jobStatus, end_statuses)

    @skip_unless_enabled
    def test_test_case_modify_job(self):
        request_dict = {
            'ids': [33961218, 33961290, 33961878, 33972506],
            'title': 'Modify Test Title Update {}'.format(time.time())
        }

        mod_job = ModifyTestCasesJob(self.client, request_dict)
        mod_job.wait_until_complete()
        self.assertEqual('COMPLETED', mod_job.jobStatus)

    @skip_unless_enabled
    def test_test_case_modify_job_cancel(self):
        request_dict = {
            'ids': [33961218, 33961290, 33961878, 33972506],
            'title': 'Modify Test Title Cancel {}'.format(time.time())
        }
        mod_job = ModifyTestCasesJob(self.client, request_dict)
        mod_job.cancel()
        self.assertEqual('CANCELLED', mod_job.jobStatus)

    @skip_unless_enabled
    def test_test_case_modify_job_with_timeout(self):
        request_dict = {
            'ids': [33961218, 33961290, 33961878, 33972506],
            'title': 'Modify Test Title Time Out {}'.format(time.time())
        }
        mod_job = ModifyTestCasesJob(self.client, request_dict)
        mod_job.wait_until_complete(time_out=0)

        self.assertIn(mod_job.jobStatus, ['CANCELLED', 'COMPLETED'])

    @skip_unless_enabled
    def test_test_suite_modify_job(self):
        request_dict = {
            'ids': [2273074, 2273078, 2273080, 2273082],
            'title': 'Modify suite title {}'.format(time.time())
        }

        mod_job = ModifyTestSuitesJob(self.client, request_dict)
        mod_job.wait_until_complete()
        self.assertEqual('COMPLETED', mod_job.jobStatus)

    @skip_unless_enabled
    def test_scheduled_test_modification(self):
        request_dict = {
            'ids': [7509460, 7514024, 7514025, 7514026],
            'title': 'Scheduled test modification test {}'.format(time.time())
        }

        mod_job = ModifyScheduledTestsJob(self.client, request_dict)
        mod_job.wait_until_complete()
        self.assertEqual('COMPLETED', mod_job.jobStatus)

    @skip_unless_enabled
    def test_scheduled_test_cases_modification(self):
        request_dict = {
            'ids': [352273740, 352273742, 352273744, 352273746],
            'title': 'Scheduled case title test {}'.format(time.time())
        }

        mod_job = ModifyScheduledTestCasesJob(self.client, request_dict)
        mod_job.wait_until_complete()
        self.assertEqual('COMPLETED', mod_job.jobStatus)

    @skip_unless_enabled
    def test_get_radarclient_with_appleconnect(self):
        sys_id = ClientSystemIdentifier('test', '1')
        client = RadarClient.radarclient_for_current_appleconnect_session(sys_id)
        self.assertIsInstance(client, RadarClient)

    @skip_unless_enabled
    def test_get_available_boards(self):
        """Get all available boards"""
        # Get all boards for the logged in user, which should not raise an error
        boards = self.client.available_boards()

        # Board with a component nobody has access to
        super_secret_board = [board for board in boards if board.id == 66090][0]

        # We should have access to the Board Title
        self.assertTrue(super_secret_board.title == "Super Secret Board")

        # The component should be inaccessible
        self.assertTrue(isinstance(super_secret_board.defaultComponent, ComponentInaccessible))

    @skip_unless_enabled
    def test_get_board(self):
        """Get the RadarClient Testing Board and validate the Title"""
        board_id = 65927
        board = self.client.board_for_id(board_id)
        self.assertEqual(board.title, "RadarClient Testing Board")

    @skip_unless_enabled
    def test_get_epics_for_board(self):
        """Get the RadarClient Testing Board and the number of epics"""
        board_id = 65927
        board = self.client.board_for_id(board_id)
        self.assertEqual(len(board.epics()), 1)

    @skip_unless_enabled
    def test_get_story_task(self):
        """Get the task for a Radar Board Story"""
        story = self.client.story_for_id(65927, 4411841)
        self.assertEqual(len(story.tasks), 1)
        self.assertEqual(story.tasks[0].title, "Example Subtask")
        self.assertEqual(story.tasks[0].related_story().title, "First Story")

    @skip_unless_enabled
    def test_create_board(self):
        """Create a Board in the Radar DB and then archive it"""
        now = datetime.datetime.now()
        board_access_list = [
            {
                "id": self.client.current_user().dsid,
                "roles": [
                    "board-admin"
                ]
            }
        ]
        state_columns = [
            {
                "maxState": "analyze-nominate",
                "title": "Defined"
            },
            {
                "maxState": "integrate",
                "title": "In Progress"
            },
            {
                "maxState": "verify",
                "title": "Complete"
            },
            {
                "maxState": "closed",
                "title": "Accepted"
            }
        ]
        title = "Radar Boards Integration Testing {}_{}_{}".format(now.month, now.day, now.year)
        description = "Radar Boards Integration Testing {}_{}_{}".format(now.month, now.day, now.year)
        component_id = 1517554

        # Create the Board with access only for the current user
        board = self.client.create_board(
            default_component_id=component_id,
            title=title, description=description,
            state_columns=state_columns,
            access_list=board_access_list)
        self.assertEqual(board.title, title, "Title should be {}".format(title))
        self.assertEqual(board.description, description, "Description should be {}".format(description))

        # Create a Backlog Story with 1 Story Point and Business value of 2 and then delete it
        story = board.create_backlog_story("IntegrationTestStory", story_points=1, business_value=2)
        self.assertEqual(story.title, "IntegrationTestStory", "Story title should be 'IntegrationTestStory'")
        self.assertEqual(story.storyPoints, 1, "StoryPoints should be 1")
        self.assertEqual(story.businessValue, 2, "BusinessValue should be 2")
        # Move the Story to the PRIORITIZED backlog with backlog_rank of 1
        self.assertTrue(story.add_to_prioritized_backlog(backlog_rank=1))

        # Create an Epic
        epic = board.create_epic("IntegrationTestEpic")
        self.assertEqual(epic.title, "IntegrationTestEpic",  "Epic title should be 'IntegrationTestStory'")

        # Relate the Story to the new epic
        self.assertEqual(story.relate_to_epic(epic), True)

        # Delete the Epic and Story
        self.assertEqual(story.delete(), True)
        self.assertEqual(epic.delete(), True)

        # Create a Sprint
        sprint = board.create_sprint(start_date="2023-03-06T00:00:01.000Z", end_date="2023-03-10T23:59:59.000Z", title="TestSprint")
        self.assertEqual(sprint.title, "TestSprint", "Sprint Title should be 'TestSprint")

        # Create a Sprint Story
        sprint_story = sprint.create_story("New Story", 5, 1)
        self.assertEqual(sprint_story.title, "New Story")
        self.assertEqual(sprint_story.storyPoints, 5)

        # Create a Radar and add it to the Sprint
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {"name": "python-radarclient", "version": "board-testing"},
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }
        radar = self.client.create_radar(data)
        sprint.add_story_for_radar_id(radar.id)

        # Start the Sprint now that it has a Story
        self.assertEqual(sprint.start(), True)

        # Check that the current user is a Board Admin
        self.assertTrue(board.current_user_is_board_admin, "Current user should be a Board Admin")

        # Archive the Board
        archived_board = board.archive()
        self.assertEqual(archived_board, True, "Board should be archived")

    @skip_unless_enabled
    def test_radar_related_epics(self):
        # rdar://104427122 (First Epic)
        radar = self.client.radar_for_id(104427122)
        boards = radar.related_radar_boards()
        epics = radar.related_radar_board_epics()
        stories = radar.related_radar_board_stories()
        self.assertEqual(boards[0].title, "RadarClient Testing Board", "Board title should be 'RadarClient Testing Board'")
        self.assertEqual(epics[0].title, "First Epic", "Epic title should be 'First Epic'")
        self.assertEqual(len(stories), 0, "No Stories should be returned")

    @skip_unless_enabled
    def test_related_stories(self):
        # rdar://105003876 (First Story)
        radar = self.client.radar_for_id(105003876)
        boards = radar.related_radar_boards()
        epics = radar.related_radar_board_epics()
        stories = radar.related_radar_board_stories()
        self.assertEqual(boards[0].title, "RadarClient Testing Board", "Board title should be 'RadarClient Testing Board'")
        self.assertEqual(stories[0].title, "First Story", "Story title should be 'First Story'")
        self.assertEqual(len(epics), 0, "No Epics should be returned")
        story = stories[0]
        events = story.events()
        self.assertIsInstance(events[0], RadarBoardSprintEvent)
        self.assertEqual(events[0].type, "story_added")

    @skip_unless_enabled
    def test_no_related_boards(self):
        # rdar://107183555 (Just a dummy bug, unrelated to a Radar Board)
        radar = self.client.radar_for_id(107183555)
        boards = radar.related_radar_boards()
        epics = radar.related_radar_board_epics()
        stories = radar.related_radar_board_stories()
        self.assertEqual(len(boards), 0, "No Boards should be returned")
        self.assertEqual(len(epics), 0, "No Epics should be returned")
        self.assertEqual(len(stories), 0, "No Stories should be returned")

    @skip_unless_enabled
    def test_radar_board_events(self):
        board = self.client.board_for_id(65927)
        sprint = board.active_sprint()
        events = sprint.events()
        self.assertEqual(len(events), 4, "Only 4 events should be present")

        # Get the event for Sprint being started
        sprint_start = events[0]
        self.assertEqual(sprint_start.type, "sprint_started")

        # Get the first Story on the Board
        event = events[1]
        self.assertEqual(event.item.title, "First Story")
        self.assertEqual(event.type, "story_added")

    @skip_unless_enabled
    def test_add_radar_to_sprint_as_story(self):
        now = datetime.datetime.now()
        board_access_list = [
            {
                "id": self.client.current_user().dsid,
                "roles": [
                    "board-admin"
                ]
            }
        ]
        state_columns = [
            {
                "maxState": "analyze-nominate",
                "title": "Defined"
            },
            {
                "maxState": "integrate",
                "title": "In Progress"
            },
            {
                "maxState": "verify",
                "title": "Complete"
            },
            {
                "maxState": "closed",
                "title": "Accepted"
            }
        ]
        title = "Radar Boards Integration Testing {}_{}_{}".format(now.month, now.day, now.year)
        description = "Radar Boards Integration Testing {}_{}_{}".format(now.month, now.day, now.year)
        component_id = 1517554

        # Create the Board with access only for the current user
        board = self.client.create_board(
            default_component_id=component_id,
            title=title, description=description,
            state_columns=state_columns,
            access_list=board_access_list)

        # Create a Sprint
        sprint = board.create_sprint(start_date="2023-03-06T00:00:01.000Z", end_date="2023-03-10T23:59:59.000Z",
                                     title="TestSprint")

        # Create a radar
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {"name": "python-radarclient", "version": "board-testing"},
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }
        radar = self.client.create_radar(data)

        # Add the Radar to the new board and request it as a Story object
        story = radar.add_to_radar_board_sprint(board_id=board.id, sprint_id=sprint.id)
        assert isinstance(story, RadarBoardStory)

        # Archive the board
        board.archive()

    @skip_unless_enabled
    def test_add_radar_to_radar_board_as_story(self):
        now = datetime.datetime.now()
        board_access_list = [
            {
                "id": self.client.current_user().dsid,
                "roles": [
                    "board-admin"
                ]
            }
        ]
        state_columns = [
            {
                "maxState": "analyze-nominate",
                "title": "Defined"
            },
            {
                "maxState": "integrate",
                "title": "In Progress"
            },
            {
                "maxState": "verify",
                "title": "Complete"
            },
            {
                "maxState": "closed",
                "title": "Accepted"
            }
        ]
        title = "Radar Boards Integration Testing {}_{}_{}".format(now.month, now.day, now.year)
        description = "Radar Boards Integration Testing {}_{}_{}".format(now.month, now.day, now.year)
        component_id = 1517554

        # Create the Board with access only for the current user
        board = self.client.create_board(
            default_component_id=component_id,
            title=title, description=description,
            state_columns=state_columns,
            access_list=board_access_list)

        # Create a radar
        data = {
            'title': u'create_radar test \u2192 bug',
            'component': {"name": "python-radarclient", "version": "board-testing"},
            'description': u'test \u2192 bug description',
            'classification': 'Other Bug',
            'reproducible': 'Not Applicable',
        }
        radar = self.client.create_radar(data)

        # Add the Radar to the new board and request it as a Story object
        story = radar.add_to_radar_board_as_story(board_id=board.id, return_story_object=True)
        assert isinstance(story, RadarBoardStory)

        # Archive the board
        board.archive()

    @skip_unless_enabled
    def test_cached_class_property_decorator(self):
        self.assertEqual(TestCachedClassPropertyClassC.ccp, ["TestCachedClassPropertyClassA", "TestCachedClassPropertyClassB"])
        self.assertEqual(TestCachedClassPropertyClassB.ccp, ["TestCachedClassPropertyClassA", "TestCachedClassPropertyClassB"])
        self.assertEqual(TestCachedClassPropertyClassA.ccp, ["TestCachedClassPropertyClassA"])
        self.assertEqual(TestCachedClassPropertyClassC.ccp, ["TestCachedClassPropertyClassA", "TestCachedClassPropertyClassB"])

    @skip_unless_enabled
    def test_get_all_test_categories_as_mapped_dictionary(self):
        all_categories = self.client.all_test_categories_map()
        cat = all_categories['APPLICATION_NAME'][21]
        self.assertEqual(cat, all_categories['APPLICATION_NAME'][cat.value])

    @skip_unless_enabled
    def test_get_all_test_categories(self):
        all_categories = self.client.all_test_categories()
        self.assertIn(TestCategory({'id': 7, 'value': 'Not Started', 'index': 1}), all_categories['TEST_STATUS'])

    @skip_unless_enabled
    def test_get_test_categories_for_type_as_mapped_dictionary(self):
        categories = self.client.test_categories_for_type_map('TEST_TYPE')
        cat = categories['QuickLook']
        self.assertEqual(cat, categories[cat.id])

    @skip_unless_enabled
    def test_get_test_categories_for_type_as_mapped_dictionary_invalid_type(self):
        categories = self.client.test_categories_for_type_map('not a real category type')
        self.assertDictEqual({}, categories)

    def run_test_of_get_category_ids_methods(self, category_type, get_id_method, cache_attribute):
        all_categories_for_type = self.client.test_categories_for_type(category_type)
        for category in all_categories_for_type:
            self.assertEqual(get_id_method(category.value), category.id)
            self.assertIsNotNone(getattr(self.client, cache_attribute))

    @skip_unless_enabled
    def test_get_id_for_scheduled_test_status(self):
        self.run_test_of_get_category_ids_methods('TEST_STATUS', self.client.id_for_scheduled_test_status,
                                                  '_scheduled_test_statuses')

    @skip_unless_enabled
    def test_get_id_for_test_category(self):
        self.run_test_of_get_category_ids_methods('TEST_TYPE', self.client.id_for_test_category, '_test_categories')

    @skip_unless_enabled
    def test_get_id_for_test_suite_status(self):
        self.run_test_of_get_category_ids_methods('SCRIPT_STATUS',
                                                  self.client.id_for_test_suite_status,
                                                  '_test_statuses')

    @skip_unless_enabled
    def test_get_id_for_test_track_name(self):
        self.run_test_of_get_category_ids_methods('TRACK', self.client.id_for_test_track_name, '_track_names')

    @skip_unless_enabled
    def test_get_id_for_text_complexity(self):
        self.run_test_of_get_category_ids_methods('TEST_LEVEL', self.client.id_for_test_complexity,
                                                  '_test_complexities')

    @skip_unless_enabled
    def test_get_id_for_business_process(self):
        self.run_test_of_get_category_ids_methods('BUSINESS_PROCESS', self.client.id_for_business_process,
                                                  '_business_processes')

    @skip_unless_enabled
    def test_get_id_for_scheduled_test_case_status(self):
        self.run_test_of_get_category_ids_methods('SCH_TEST_CASE_STATUS',
                                                  self.client.id_for_scheduled_test_case_status,
                                                  '_scheduled_test_case_statuses')

    @skip_unless_enabled
    def test_get_id_for_application_name(self):
        self.run_test_of_get_category_ids_methods('APPLICATION_NAME', self.client.id_for_application_name,
                                                  '_application_names')

    @skip_unless_enabled
    def test_get_id_for_test_cycle(self):
        self.run_test_of_get_category_ids_methods('SCHEDULED_TEST_NAME', self.client.id_for_test_cycle,
                                                  '_test_cycles')

    @skip_unless_enabled
    def test_get_id_for_test_geographies(self):
        self.run_test_of_get_category_ids_methods('GEOGRAPHY', self.client.id_for_test_geography,
                                                  '_test_geographies')

    def run_update_by_id_value_converter_test(self, value_converter_class, value, expected_id):
        test_decode_dict = {'value': 'Test Value', 'id': 'Test ID'}
        dict_decoded = value_converter_class.decode_radar_value(test_decode_dict)
        str_decoded = value_converter_class.decode_radar_value(test_decode_dict['value'])
        self.assertEqual(dict_decoded, str_decoded)

        fetched_id = value_converter_class.encode_radar_value(value, self.client)
        self.assertEqual(expected_id, fetched_id)

        with self.assertRaises(radarclient.exceptions.UpdateByIDLookUpError):
            value_converter_class.encode_radar_value('not a real thing', self.client)

    @skip_unless_enabled
    def test_test_geography_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.TestGeographyValueConverter, 'AMR', 26)

    @skip_unless_enabled
    def test_scheduled_test_status_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.ScheduledTestStatusValueConverter,
                                                   'In Progress', 8)

    @skip_unless_enabled
    def test_test_category_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.TestCategoryValueConverter, 'QuickLook', 4027418)

    @skip_unless_enabled
    def test_test_track_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.TestTrackValueConverter, 'SSO', 5)

    @skip_unless_enabled
    def test_business_process_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.BusinessProcessValueConverter, 'Agreement', 302)

    @skip_unless_enabled
    def test_scheduled_test_case_status_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.ScheduledTestCaseStatusValueConverter, 'No value',
                                                   10062017)

    @skip_unless_enabled
    def test_application_name_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.ApplicationNameValueConverter, 'GSX', 22)

    @skip_unless_enabled
    def test_test_cycle_value_converter(self):
        self.run_update_by_id_value_converter_test(radarclient.model.TestCycleValueConverter, 'UAT', 701790)

    def run_test_suite_ids_for_query_test(self, query_id):
        expected_ids = {2498464, 2498466, 2498468, 2498500, 2498502}

        fetched_ids = self.client.test_suite_ids_for_query(query_id)

        for test_id in fetched_ids:
            self.assertIn(test_id, expected_ids)

    @unittest.skip("These 'legacy' queries are known to fail and the Radar API team recommends re-crating the query in Radar 8. See 144189560")
    @skip_unless_enabled
    def test_test_suite_ids_for_query_built_in_tstt(self):
        query_id = 2672746
        self.run_test_suite_ids_for_query_test(query_id)

    @unittest.skip("These 'legacy' queries are known to fail and the Radar API team recommends re-crating the query in Radar 8. See 144189560")
    @skip_unless_enabled
    def test_test_suites_for_query_built_in_tstt(self):
        query_id = 2672746
        self.run_test_suites_for_query_test(query_id)

    @skip_unless_enabled
    def test_test_suite_ids_for_query_built_in_radar_8(self):
        query_id = 2805926
        self.run_test_suite_ids_for_query_test(query_id)

    def run_test_suites_for_query_test(self, query_id):
        test_ids = [2498464, 2498466, 2498468, 2498500, 2498502]
        expected_suites = set(TestSuite({'suiteId': test_id}) for test_id in test_ids)

        fetched_suites = set(self.client.test_suites_for_query(query_id))
        self.assertEqual(0, len(fetched_suites - expected_suites))

    @skip_unless_enabled
    def test_test_suites_for_query_built_in_radar_8(self):
        query_id = 2805926
        self.run_test_suites_for_query_test(query_id)

    def _run_suggestions_test(self, suggestions_method, search_string, limit, expected_object_type):
        """
        Run the basic suggestions item test and return the response for further testing if needed

        :param suggestions_method: function to be called for the test
        :param search_string: search string to use
        :param limit: the limit on number of responses
        :param expected_object_type: what the expected type of the items returned is

        :return: the return from the method
        """
        suggestions = suggestions_method(search_string, limit=limit)

        for item in suggestions:
            self.assertTrue(isinstance(item, expected_object_type))

        return suggestions

    @skip_unless_enabled
    def test_build_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.build_suggestions, 'Radar', limit, Build)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_person_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.person_suggestions, 'Phil', limit, Person)
        self.assertEqual(limit * 3, len(result))

    @skip_unless_enabled
    def test_component_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.component_suggestions, 'python', limit, Component)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_component_bundle_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.component_bundle_suggestions, 'rad', limit, ComponentBundle)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_component_bundle_group_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.component_bundle_group_suggestions, 'rad', limit,
                                            ComponentBundleGroup)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_keyword_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.keyword_suggestions, 'seed', limit, Keyword)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_milestone_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.milestone_suggestions, 'fut', limit, Milestone)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_event_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.event_suggestions, 'm3 ', limit, Event)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_category_suggestions(self):
        limit = 3
        result = self._run_suggestions_test(self.client.category_suggestions, 'rad', limit, Category)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_tentpole_suggestions(self):
        # As tentpoles come and go this test may need to be updated
        limit = 1
        result = self._run_suggestions_test(self.client.tentpole_suggestions, 'vis', limit, Tentpole)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_label_suggestions(self):
        limit = 1
        result = self._run_suggestions_test(self.client.label_suggestions, 'per', limit, Label)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_group_suggestions(self):
        self.skipTest('The API is not functional, '
                      'rdar://118335438 (Suggestions API For Groups Does not Return the Correct Information)')
        # Test may need tweaking to work once radar is resolved
        limit = 1
        suggestions = self.client.group_suggestions('gr', limit=limit)
        self.assertEqual(limit * 3, len(suggestions))

        counts = defaultdict(int)
        for suggestion in suggestions:
            counts[suggestion.__class__.__name__] += 1

        # Check for 1 dict as there is no DSGroup class
        self.assertEqual(1, counts['dict'])
        self.assertEqual(1, counts['WorkGroup'])
        self.assertEqual(1, counts['AccessGroup'])

    @skip_unless_enabled
    def test_board_suggestions(self):
        limit = 1
        result = self._run_suggestions_test(self.client.board_suggestions, 'rad', limit, RadarBoard)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_sprint_suggestions(self):
        limit = 1
        result = self._run_suggestions_test(self.client.sprint_suggestions, 'int', limit, RadarBoardSprint)
        self.assertEqual(limit, len(result))

    @skip_unless_enabled
    def test_add_and_remove_test_suite_label(self):
        test_suite_id = 1557189
        fields = ['label']
        test_suite = self.client.test_suite_for_id(test_suite_id, fields=fields)

        self.client.set_active_label_set(LabelSet({'id': 465973}))

        test_label = Label({'id': 2907133})
        test_suite.label = test_label
        test_suite.commit_changes(self.client, dry_run=True)
        test_suite.commit_changes(self.client)

        labeled_suite = self.client.test_suite_for_id(test_suite_id, fields=fields)
        self.assertEqual(labeled_suite.label, test_label)

        labeled_suite.label = None
        labeled_suite.commit_changes(self.client, dry_run=True)
        labeled_suite.commit_changes(self.client)

        label_removed_suite = self.client.test_suite_for_id(test_suite_id, fields=fields)
        self.assertIsNone(label_removed_suite.label)

    @skip_unless_enabled
    def test_update_actual_result_scheduled_test_case(self):
        sched_suite_id = 7490457
        sched_test = self.client.scheduled_test_for_id(sched_suite_id, additional_fields=['cases'])

        new_result = 'New Actual Result {}'.format(time.time())

        test_case = sched_test.cases[0]
        test_case.actualResults = new_result
        sched_test.commit_changes(self.client)

        sched_test = self.client.scheduled_test_for_id(sched_suite_id, additional_fields=['cases'])
        self.assertEqual(sched_test.cases[0].actualResults[-1]['actualResult'], new_result)

    def run_extend_known_fields_test(self, test_item, additional_fields=None, fields=None):
        local_fields = [] if additional_fields is None else additional_fields
        if fields is not None:
            local_fields += fields

        for field in local_fields:
            self.assertFalse(hasattr(test_item, field))

        test_item.extend_known_fields(self.client, additional_fields=additional_fields, fields=fields)
        self.assertEqual(len(test_item.change_records), 0)

        for field in local_fields:
            self.assertTrue(hasattr(test_item, field))

    @skip_unless_enabled
    def test_extend_known_fields_for_test_case_using_fields(self):
        test_id = 24158287
        test_case = self.client.test_suite_case_for_id(test_id, fields=['title'])
        self.run_extend_known_fields_test(test_case, fields=['expectedResult'])

    @skip_unless_enabled
    def test_extend_known_fields_for_test_case_using_additional_fields(self):
        test_id = 24158287
        test_case = self.client.test_suite_case_for_id(test_id, fields=['title'])
        self.run_extend_known_fields_test(test_case, additional_fields=['expectedResult'])

    @skip_unless_enabled
    def test_extend_known_fields_for_test_suite_using_fields(self):
        test_id = 1552271
        test_suite = self.client.test_suite_for_id(test_id, fields=['title'])
        self.run_extend_known_fields_test(test_suite, fields=['associatedTests'])

    @skip_unless_enabled
    def test_extend_known_fields_for_test_suite_using_additional_fields(self):
        test_id = 1552271
        test_suite = self.client.test_suite_for_id(test_id, fields=['title'])
        self.run_extend_known_fields_test(test_suite, additional_fields=['associatedTests'])

    @skip_unless_enabled
    def test_extend_known_fields_for_scheduled_case_using_fields(self):
        case_id = 149735749
        test_case = self.client.scheduled_test_case_for_id(case_id, fields=['title'])
        self.run_extend_known_fields_test(test_case, fields=['actualResults'])

    @skip_unless_enabled
    def test_extend_known_fields_for_scheduled_case_using_additional_fields(self):
        case_id = 149735749
        test_case = self.client.scheduled_test_case_for_id(case_id, fields=['title'])
        self.run_extend_known_fields_test(test_case, additional_fields=['actualResults'])

    def test_extend_known_fields_for_scheduled_test_using_fields(self):
        suite_id = 7500650
        test_suite = self.client.scheduled_test_for_id(suite_id, fields=['title'])
        self.run_extend_known_fields_test(test_suite, fields=['build'])

    def test_extend_known_fields_for_scheduled_test_using_additional_fields(self):
        suite_id = 7500650
        test_suite = self.client.scheduled_test_for_id(suite_id, fields=['title'])
        self.run_extend_known_fields_test(test_suite, additional_fields=['build'])

    @skip_unless_enabled
    def test_set_attributes_on_extension_for_test_objects(self):
        test_case_id = 24152704
        test_case = self.client.test_suite_case_for_id(test_case_id, fields=['title'])
        test_case.extend_known_fields(self.client, fields=['keywords', 'relatedProblems'])
        self.assertEqual(len(test_case._keywords_set), 2)
        self.assertEqual(len(test_case._related_problems_set), 6)

    @skip_unless_enabled
    def test_update_set_attributes_of_cases_in_suite(self):
        suite_id = 1878175
        test_suite = self.client.test_suite_for_id(suite_id, fields=['title', 'associatedTests'])
        test_suite.extend_fields_for_all_cases(self.client, fields=['relatedProblems', 'keywords'])
        self.assertEqual(len(test_suite.associatedTests[0]._related_problems_set), 6)
        self.assertEqual(len(test_suite.associatedTests[0]._keywords_set), 2)

    def test_api_endpoints_suite(self):
        endpoints = self.client.api_endpoints()
        self.assertGreater(len(endpoints), 0), "No API endpoints found!"
        self.assertIsInstance(endpoints[0], RadarAPIEndpoint), "Expected RadarAPIEndpoint, found {}".format(type(endpoints[0]))

        endpoint_ids = [endpoint.id for endpoint in endpoints]
        endpoint_names = [endpoint.name for endpoint in endpoints]
        self.assertEqual(len(endpoint_ids), len(endpoint_names)), "endpoint_names count != endpoint_ids count"

        endpoint_access = self.client.api_endpoint_access_for_names(endpoint_names)
        self.assertIsInstance(endpoint_access, RadarAPIEndpointAccessCheck), "Invalid response type: {}".format(type(endpoint_access))
        self.assertIsInstance(endpoint_access.permissions[0], RadarAPIEndpointPermission), "Invalid RadarAPIEndpointPermission type: {}".format(type(endpoint_access.permissions[0]))

        # This will get look through all the available API endpoints and specific URIs to find one that is:
        # 1. A 'GET' method
        # 2. With type 'RESTRICTED'
        # 3. With permission 'NOT REQUESTED'
        # 4. That doesn't require an id value, name, or payload
        # ...and attempt to access it. It should fail with the expected Exception type.
        found_inaccessible_test_method = False
        for endpoint_perms in endpoint_access.permissions:
            if not found_inaccessible_test_method and endpoint_perms.permission == "NOT REQUESTED":
                endpoint = endpoint_perms.endpoint
                if endpoint.type == 'RESTRICTED':
                    if endpoint.httpMethod == 'GET':
                        for uri in endpoint.uriList:
                            if found_inaccessible_test_method or 'id' in uri or 'name' in uri:
                                continue
                            uri_parts = uri.split('/')
                            uri_tuple = tuple(uri_parts[1:])
                            print("\nAbout to try requesting", endpoint.name, endpoint.httpMethod, uri)
                            try:
                                status, _ = self.client.build_and_send_request(uri_tuple)
                                self.assertNotEqual(status, '300'), "Unexpected status code: {}".format(status)
                            except Exception as e:
                                self.assertIsInstance(e, RadarAccessDeniedResponseException)
                                found_inaccessible_test_method = True
        self.assertTrue(found_inaccessible_test_method), "Unable to find a valid inaccessible endpoint to test with!"

    def test_radar_problem_summary(self):
        test_bug_id = 96172751
        radar = self.client.radar_for_id(test_bug_id)
        summary = radar.problem_summary()
        self.assertIsNotNone(summary)

    def test_problem_summary_multithreaded(self):
        test_bug_ids = [
            96172751, 101932591, 116372028, 125857738, 131551265, 131626750, 137222372, 138056966, 140864074,
            140864685, 140960492, 142640167, 143002044, 143499460, 143795820, 144640455, 145100448, 145230029,
            145938966, 146140521, 146403223, 146729279, 146737100, 146739674, 146796680, 146966022
        ]
        radars = self.client.radars_for_ids(test_bug_ids)
        radars = list(self.client.problem_summary_multithreaded(radars))
        for radar in radars:
            self.assertTrue(radar._problem_summary), "rdar://{} has no problem summary!".format(radar.id)

    def _test_delete_all_key_value_pairs_from_kv_store(self, kv_store):
        all_keys = kv_store.loaded_keys()
        for key_name in all_keys:
            kv_store.delete_key_value_pair_for_key(key_name)
            time.sleep(0.4)  # Delay to avoid 429 errors for deleting too fast (base is 3tps)
        self.assertEqual(len(kv_store.loaded_keys()), 0), "The KeyValueStore should be empty! {}".format(kv_store)
        time.sleep(3)  # Delay to allow Radar DB to propagate changes
        kv_store.reset()
        kv_store.load_pairs_for_keys()
        self.assertEqual(len(kv_store.loaded_keys()), 0), "The KeyValueStore should be empty! {}".format(kv_store)

    def _test_key_values_for_kv_store(self, kv_store):
        test_pairs = [
            ("test.key.3", "This is the third key, which has periods. in. it."),
            ("test:key-4", "This is the 4th key, which has a colon and dash."),
            ("test_key_1", "This is the value for test_key_1"),
            ("test_key_2", "This is the value for test_key_2"),
            ("test_key_dict", '{"test":"This is a top-level key in a stringified dictionary.","nested_dict":{"nested_key":"This is a nested key inside a nested, stringified, dictionary."}}'),
        ]
        self.assertIsInstance(kv_store, radarclient.model.KeyValueStore), "Invalid KeyValueStore type: {}".format(
            type(kv_store))
        # Cleanup existing key-value pairs on the test suite in case any were left over from a failed test
        if len(kv_store.loaded_keys()) > 0:
            self._test_delete_all_key_value_pairs_from_kv_store(kv_store)

        # Adding key-value pairs
        for test_key_value_tuple in test_pairs:
            key = test_key_value_tuple[0]
            value = test_key_value_tuple[1]
            kv_store.add_key_value_pair(key, value)
        time.sleep(3)  # Delay to allow Radar DB to propagate changes
        kv_store.load_pairs_for_keys()
        print()
        print(kv_store)
        self.assertEqual(len(kv_store.loaded_keys()), 5), "The KeyValueStore should have 5 pairs! {}".format(kv_store)
        for index, kv_pair in enumerate(sorted(kv_store.loaded_pairs(), key=lambda l:l.name)):
            (self.assertEqual(kv_pair.key, test_pairs[index][0]),
             "The KeyValuePair's key ({}) doesn't match ({})!".format(kv_pair.key, test_pairs[index][0]))
            (self.assertEqual(kv_pair.value, test_pairs[index][1]),
             "The KeyValuePair's value ({}) doesn't match ({})!".format(kv_pair.value, test_pairs[index][1]))

        # reset() and re-load()-ing
        kv_store.reset()
        for test_key_value_tuple in test_pairs:
            kv_store.load_pairs_for_keys([test_key_value_tuple[0]])
        self.assertEqual(len(kv_store.loaded_keys()), 5), "The KeyValueStore should have 5 pairs! {}".format(kv_store)

        # test loading stringified dictionary from value
        dict_str = kv_store.value_for_key('test_key_dict')
        dict_json = json.loads(dict_str)
        if isinstance(kv_store.source, Radar):
            print(json.dumps(dict_json, indent=4))

        # Testing delete() + update() via KeyValuePair methods also tests corresponding KeyValueStore methods
        for index, kv_pair in enumerate(kv_store.loaded_pairs()):
            if index == 4:
                kv_pair.delete()
                continue
            kv_pair.update(new_value=kv_pair.value + " [UPDATED]")
        time.sleep(3)  # Delay to allow Radar DB to propagate changes
        kv_store.reset()
        kv_store.load_pairs_for_keys()
        self.assertEqual(len(kv_store.loaded_keys()), 4), "The KeyValueStore should have 4 pairs! {}".format(kv_store)
        for value in kv_store.loaded_values():
            self.assertIn('[UPDATED]', value)

        # Clean up the test object's kv store before finishing
        self._test_delete_all_key_value_pairs_from_kv_store(kv_store)
        self.assertEqual(len(kv_store.loaded_keys()), 0), "The KeyValueStore should be empty! {}".format(kv_store)

    def test_radar_key_values(self):
        test_bug_id = 128500141
        radar = self.client.radar_for_id(test_bug_id, additional_fields=['keyValues'])
        kv_store = radar.key_values
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_component_id(self):
        component_id = TestConfiguration.value('default_component_id')['id']
        kv_store = self.client.key_values_for_component_id(component_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_access_group_id(self):
        access_group_id = 131277  # rdar://group/131277 (python-radarclient-test-access-group)
        kv_store = self.client.key_values_for_access_group_id(access_group_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_work_group_id(self):
        work_group_id = 131276  # rdar://group/131276 (python-radarclient-test-work-group)
        kv_store = self.client.key_values_for_work_group_id(work_group_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_test_suite_id(self):
        test_suite_id = 3046868  # rdar://ts/3046868 (Test Suite for Key-Value Support)
        kv_store = self.client.key_values_for_test_suite_id(test_suite_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_test_case_id(self):
        test_suite_id = 3046868  # rdar://ts/3046868 (Test Suite for Key-Value Support)
        test_case_id = 45275106  # rdar://tsc/45275106 (Sample Test Case)
        kv_store = self.client.key_values_for_test_case_id(test_case_id, test_suite_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_scheduled_test_id(self):
        scheduled_test_id = 25380628  # rdar://st/25380628 (Scheduled Test for Test Suite for Key-Value Support)
        kv_store = self.client.key_values_for_scheduled_test_id(scheduled_test_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_values_for_scheduled_test_case_id(self):
        scheduled_test_case_id = 697071110  # rdar://stc/697071110 (Sample Test Case)
        kv_store = self.client.key_values_for_scheduled_test_case_id(scheduled_test_case_id)
        self._test_key_values_for_kv_store(kv_store)

    def test_key_value_pair_exceptions(self):
        test_key = 'test_key_100'
        test_value = 'This is the value for test_key_100'
        test_bug_id = 128500141
        kv_store = self.client.key_values_for_radar_id(test_bug_id)
        kv_store.load_pairs_for_keys()

        # Cleanup existing key-value pairs on the test radar in case any were left over from a failed test
        if len(kv_store.loaded_pairs()) > 0:
            self._test_delete_all_key_value_pairs_from_kv_store(kv_store)
            time.sleep(3)
            del kv_store
            kv_store = self.client.key_values_for_radar_id(test_bug_id)
            kv_store.load_pairs_for_keys()

        # test Exception for non-existent key
        with self.assertRaises(KeyValuePairNotFoundException):
            kv_store.load_pairs_for_keys(['test_key_1'])

        kv_store.add_key_value_pair(test_key, test_value)
        time.sleep(3)
        kv = kv_store.key_value_pair_for_key(test_key)
        # test Exception for already-existing key
        with self.assertRaises(KeyValuePairAlreadyExistsException):
            kv_store.add_key_value_pair(test_key, test_value)
        kv.delete()

        # test Exception for unsupported class
        me = self.client.current_user()
        with self.assertRaises(KeyValuePairNotSupportedException):
            me.webservice_url_components_for_key_values()

        # Clean up test radar before finishing
        self._test_delete_all_key_value_pairs_from_kv_store(kv_store)

    def test_create_response_format_header(self):
        header = self.client.create_response_format_header('STANDARD')
        self.assertEqual(('X-Response-Format', 'STANDARD'), header)

    def test_create_response_format_header_invalid_value(self):
        with self.assertRaises(ValueError):
            self.client.create_response_format_header('INVALID')

    def test_create_response_format_header_lowercase(self):
        header = self.client.create_response_format_header('standard')
        self.assertEqual(('X-Response-Format', 'STANDARD'), header)

    def test_database_id_attribute_value_for_no_id_object(self):
        test_entry = DiagnosisEntry()
        self.assertIsNone(test_entry.database_id_attribute_value())


if __name__ == "__main__":
    logging.basicConfig(format='unit test logger: %(message)s')

    new_args = []
    for index, arg in enumerate(sys.argv):
        if arg == '--debug':
            library_logger.setLevel(logging.DEBUG)
            continue

        test_prefix = 'TestRadarClient.'
        if arg.startswith(test_prefix):
            test_names = arg[len(test_prefix):]
            test_names = [test_prefix + t for t in test_names.split(',')]
            new_args.extend(test_names)
            continue

        new_args.append(arg)
    sys.argv = new_args

    unittest.main(verbosity=1)
