from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import time
import logging


def validate_with_retry(fetch_function, assert_function):
    """
    Works around some race conditions with the radar API. Fetches an object using fetch_function which
    takes no arguments. Once fetched, it passes in the returned object to assert_function. If it fails the
    assert, it sleeps and then fetches again and checks again. If still failing after 3 attempts, it raises

    :param callable fetch_function: callable to be used to fetch an item from the radar API
    :param callable assert_function: callable that takes a single argument for the retrieved item and
        validates it

    :return: item retrieved, if successful
    :raises: if assert_function raises after 3 attempts
    """
    iterations = 0
    sleep_time = 0

    while iterations < 3:
        logging.debug('Sleeping for {} seconds'.format(sleep_time))
        time.sleep(sleep_time)
        iterations += 1
        logging.debug('Iteration {}'.format(iterations))

        item = fetch_function()
        logging.debug('item = {}'.format(item))
        try:
            assert_function(item)
            return item
        except AssertionError:
            if iterations == 3:
                raise
            pass
        sleep_time += 2
