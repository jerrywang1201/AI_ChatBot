import unittest
from radarclient import RadarGUI, RadarClient, ClientSystemIdentifier


class TestRadarGUI(unittest.TestCase):
    """
    This is just a way to easily test the methods one by one manually. The tests do not validate
    """

    def setUp(self):
        sys_id = ClientSystemIdentifier('RadarGUI_Test', '1')
        self.client = RadarClient.radarclient_for_current_appleconnect_session(sys_id)
        self.test_ids = [99093189, 99093070, 99093048]
        self.test_suite_ids = [2516648, 2517122, 2517114]

    def test_open_radar_ids_in_radar(self):
        RadarGUI.open_radar_ids_in_radar(self.test_ids)

    def test_open_radar_id_in_radar(self):
        RadarGUI.open_radar_id_in_radar(self.test_ids[0])

    def test_open_radars_in_radar(self):
        radars = self.client.radars_for_ids(self.test_ids)
        RadarGUI.open_radars_in_radar(radars)

    def test_open_radar_in_radar(self):
        radar = self.client.radar_for_id(self.test_ids[0])
        RadarGUI.open_radar_in_radar(radar)

    def test_open_test_suite_ids_in_radar(self):
        RadarGUI.open_test_suite_ids_in_radar(self.test_suite_ids)

    def test_open_test_suite_id_in_radar(self):
        RadarGUI.open_test_suite_id_in_radar(self.test_suite_ids[0])

    def test_open_test_suites_in_radar(self):
        test_suites = self.client.test_suites_for_ids(self.test_suite_ids)
        RadarGUI.open_test_suites_in_radar(test_suites)

    def test_open_test_suite_in_radar(self):
        test_suite = self.client.test_suite_for_id(self.test_suite_ids[0])
        RadarGUI.open_test_suite_in_radar(test_suite)

    def test_open_test_case_ids_in_radar(self):
        test_ids = [35752930, 35752932, 35752936]
        RadarGUI.open_test_case_ids_in_radar(test_ids)

    def test_open_test_case_id_in_radar(self):
        test_id = 35752930
        RadarGUI.open_test_case_id_in_radar(test_id)

    def test_open_test_cases_in_radar(self):
        test_ids = [35752930, 35752932, 35752936]
        test_cases = self.client.test_suite_cases_for_ids(test_ids)
        RadarGUI.open_test_cases_in_radar(test_cases)

    def test_open_test_case_in_radar(self):
        test_case = self.client.test_suite_case_for_id(35752930)
        RadarGUI.open_test_case_in_radar(test_case)

    def test_open_scheduled_test_ids_in_radar(self):
        test_ids = [7500643, 7500650, 7509429]
        RadarGUI.open_scheduled_test_ids_in_radar(test_ids)

    def test_open_scheduled_test_id_in_radar(self):
        test_id = 7500643
        RadarGUI.open_scheduled_test_id_in_radar(test_id)

    def test_open_scheduled_tests_in_radar(self):
        test_ids = [7500643, 7500650, 7509429]
        scheduled_tests = self.client.scheduled_tests_for_ids(test_ids)
        RadarGUI.open_scheduled_tests_in_radar(scheduled_tests)

    def test_open_scheduled_test_in_radar(self):
        scheduled_test = self.client.scheduled_test_for_id(7500643)
        RadarGUI.open_scheduled_test_in_radar(scheduled_test)

    def test_open_scheduled_test_case_ids_in_radar(self):
        test_ids = [149735480, 149735487, 149735488]
        RadarGUI.open_scheduled_test_case_ids_in_radar(test_ids)

    def test_open_scheduled_test_case_id_in_radar(self):
        test_id = 149735480
        RadarGUI.open_scheduled_test_case_id_in_radar(test_id)

    def test_open_scheduled_test_cases_in_radar(self):
        test_ids = [149735480, 149735487, 149735488]
        test_cases = self.client.scheduled_test_cases_for_ids(test_ids)
        RadarGUI.open_scheduled_test_cases_in_radar(test_cases)

    def test_open_scheduled_test_case_in_radar(self):
        test_id = 149735480
        test_case = self.client.scheduled_test_case_for_id(test_id)
        RadarGUI.open_scheduled_test_case_in_radar(test_case)


if __name__ == '__main__':
    unittest.main()
