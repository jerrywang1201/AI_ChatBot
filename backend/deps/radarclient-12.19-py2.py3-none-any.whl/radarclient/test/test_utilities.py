from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import

import unittest
from datetime import datetime, timedelta
from radarclient import utilities
from radarclient.model import UTC, ISO8601UTCDateValueConverter


class TestUtilities(unittest.TestCase):
    def test_chunk_query_by_created_at(self):

        test_query = {'state': 'Analyze', 'createdAt': {'lt': datetime.now(tz=UTC())}}
        with self.assertRaises(KeyError):
            chunk_generator = utilities.ChunkQueryDictGenerator(test_query, 3)
            chunk_generator.generator.next()

        # Pass in a string and datetime to validate conversion
        # Test with 'gt' and 'lte'
        test_query = {
            'state': 'Analyze',
            'createdAt': {
                'gt': '2020-01-01T00:00:00+0000',
                'lte': datetime(2020, 1, 3, 0, 0, 0, 0, tzinfo=UTC())
            }
        }

        expected = [
            {
                'state': 'Analyze',
                'createdAt': {
                    'gte': '2020-01-02T00:00:00+0000',
                    'lte': '2020-01-03T00:00:00+0000'
                }
            },
            {
                'state': 'Analyze',
                'createdAt': {
                    'gt': '2020-01-01T00:00:00+0000',
                    'lt': '2020-01-02T00:00:00+0000'
                }
            }
        ]
        self.assertEqual(expected, list(utilities.ChunkQueryDictGenerator(test_query, 24)))

        # Test with 'gte' and 'lt'
        test_query = {
            'state': 'Analyze',
            'createdAt': {
                'gte': '2020-01-01T00:00:00+0000',
                'lt': '2020-01-03T00:00:00+0000'
            }
        }

        expected = [
            {
                'state': 'Analyze',
                'createdAt': {
                    'gte': '2020-01-02T00:00:00+0000',
                    'lt': '2020-01-03T00:00:00+0000'
                }
            },
            {
                'state': 'Analyze',
                'createdAt': {
                    'gte': '2020-01-01T00:00:00+0000',
                    'lt': '2020-01-02T00:00:00+0000'
                }
            }
        ]
        self.assertEqual(expected, list(utilities.ChunkQueryDictGenerator(test_query, 24)))

        # Test with no 'lt' or 'lte' value and a chunk larger than the timespan
        test_datetime_end = datetime.now(tz=UTC())
        test_datetime = test_datetime_end - timedelta(hours=1)
        test_query = {
            'state': 'Analyze',
            'createdAt': {
                'gte': test_datetime
            }
        }

        expected = [{
            'state': 'Analyze',
            'createdAt': {
                'gte': ISO8601UTCDateValueConverter.encode_radar_value(test_datetime),
                'lt': ISO8601UTCDateValueConverter.encode_radar_value(test_datetime_end)
            }
        }]
        chunk_gen = utilities.ChunkQueryDictGenerator(test_query, 2)
        self.assertEqual(1, len(chunk_gen))
        self.assertEqual(expected, list(utilities.ChunkQueryDictGenerator(test_query, 2)))

    def test_chunk_query_with_other_datetime_key(self):
        test_query = {
            'state': 'Analyze',
            'lastModifiedAt': {
                'gte': '2020-01-01T00:00:00+0000',
                'lte': datetime(2020, 1, 3, 0, 0, 0, 0, tzinfo=UTC())
            }
        }

        expected = [
            {
                'state': 'Analyze',
                'lastModifiedAt': {
                    'gte': '2020-01-02T00:00:00+0000',
                    'lte': '2020-01-03T00:00:00+0000'
                }
            },
            {
                'state': 'Analyze',
                'lastModifiedAt': {
                    'gte': '2020-01-01T00:00:00+0000',
                    'lt': '2020-01-02T00:00:00+0000'
                }
            }
        ]

        self.assertEqual(
            expected, list(utilities.ChunkQueryDictGenerator(test_query, 24, chunking_value='lastModifiedAt'))
        )

    def test_chunk_query_with_competing_keys(self):
        """
        Make sure having a datetime key other than createdAt while also having createdAt behave as expected

        :return: None
        """
        test_query = {
            'state': 'Analyze',
            'lastModifiedAt': {
                'gte': '2020-01-01T00:00:00+0000',
                'lte': datetime(2020, 1, 3, 0, 0, 0, 0, tzinfo=UTC())
            },
            'createdAt': {
                'gte': '2019-01-01T00:00:00+0000',
                'lte': '2020-01-01T00:00:00+0000'
            }
        }

        expected = [
            {
                'state': 'Analyze',
                'lastModifiedAt': {
                    'gte': '2020-01-02T00:00:00+0000',
                    'lte': '2020-01-03T00:00:00+0000'
                },
                'createdAt': {
                    'gte': '2019-01-01T00:00:00+0000',
                    'lte': '2020-01-01T00:00:00+0000'
                }
            },
            {
                'state': 'Analyze',
                'lastModifiedAt': {
                    'gte': '2020-01-01T00:00:00+0000',
                    'lt': '2020-01-02T00:00:00+0000'
                },
                'createdAt': {
                    'gte': '2019-01-01T00:00:00+0000',
                    'lte': '2020-01-01T00:00:00+0000'
                }
            }
        ]

        self.assertEqual(
            expected, list(utilities.ChunkQueryDictGenerator(test_query, 24, chunking_value='lastModifiedAt'))
        )

    def test_response_code_is_success(self):

        def check_response_code(code, is_success):
            self.assertEqual(
                is_success, utilities.response_code_is_success(code),
                '{} returned incorrect success value'.format(code)
            )

        check_response_code(150, False)
        check_response_code(199, False)
        check_response_code(200, True)
        check_response_code(204, True)
        check_response_code(300, False)
        check_response_code(301, False)
        check_response_code(400, False)
        check_response_code(500, False)


if __name__ == '__main__':
    unittest.main()
