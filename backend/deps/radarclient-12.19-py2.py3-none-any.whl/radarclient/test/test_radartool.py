#!/usr/bin/env python

import unittest

from radarclient.radartool import KeychainPassword

ISOLATED_TESTS = 'test_keychain'
ISOLATED_TESTS = None


class TestRadartool(unittest.TestCase):

    def skip_unless_enabled(f):
        if not ISOLATED_TESTS or f.__name__ in ISOLATED_TESTS.split():
            return f
        return unittest.skip('test is not in isolated set')(f)

    @skip_unless_enabled
    def test_keychain(self):
        result = KeychainPassword.find_generic_username_and_password(label='AppleConnect2')
        self.assertIsNotNone(result)
        username, pw = result
        self.assertEquals(username, 'foo')
        self.assertEquals(pw, u'foo\--\u00E4--\u2192--')

# password: 0x666F6F5C2D2DC3A42D2DE286922D2D  "foo\134--\303\244--\342\206\222--"
# password: "abcabc"


if __name__ == "__main__":
    unittest.main()
