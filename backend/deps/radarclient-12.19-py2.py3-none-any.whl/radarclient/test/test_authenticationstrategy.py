import contextlib
import pathlib
import pickle
import secrets
import subprocess
import time
import unittest
from base64 import urlsafe_b64encode
from unittest import mock

from radarclient.authenticationstrategy import AuthenticationStrategyAppleConnect, _OTPGenerator
from radarclient.client import AuthenticatedRequestUrllib2, RadarEnvironment


@contextlib.contextmanager
def _run(args: list[str], output: str, return_code: int = 0, **kwargs):
    with mock.patch("subprocess.check_output") as patcher:
        patcher.return_value = output
        yield
        patcher.assert_any_call(args, stderr=subprocess.STDOUT, **kwargs)


class TestAuthenticationStrategyAppleConnect(unittest.TestCase):
    def setUp(self):
        self.mock_client_id = secrets.token_hex(15)
        empty = urlsafe_b64encode(b"{}").decode().strip("=")
        payload = urlsafe_b64encode(f'{{"exp":{int(time.time() + 300)}}}'.encode()).decode().strip("=")
        self.mock_jwt = f"{empty}.{payload}.{empty}"
        self.appleconnect_path = "/dev/null/appleconnect" # Use completely fake path to bypass user environment
        self._original_appleconnect_path = AuthenticationStrategyAppleConnect.APPLECONNECT_BINARY_PATH
        AuthenticationStrategyAppleConnect.APPLECONNECT_BINARY_PATH = self.appleconnect_path

    def tearDown(self):
        AuthenticationStrategyAppleConnect.APPLECONNECT_BINARY_PATH = self._original_appleconnect_path

    @mock.patch("subprocess.check_output", return_value="6.3 (2056)\n")
    def get_instance(self, mock_appleconnect: mock.MagicMock, **kwargs):
        """Returns an instance of AuthenticationStrategyAppleConnect with the first 'version' call mocked"""
        return AuthenticationStrategyAppleConnect(**kwargs)

    @contextlib.contextmanager
    def mock_appleconnect_radar_access_token(self):
        with _run(
            [
                self.appleconnect_path,
                "getToken",
                "--token-type=oauth",
                "--oauth-grant-type=pkce",
                "--oauth-client-ID=41rih2rtlg4zyax6eztzug6ftnhkun",
                "--interactivity-type=gui",
                "--oauth-resource=https://radar-webservices.apple.com",
            ],
            output=f"oauth-access-token: {self.mock_jwt}\n",
        ):
            yield self.mock_jwt

    @contextlib.contextmanager
    def mock_appleconnect_client_access_token(self):
        with _run(
            [
                self.appleconnect_path,
                "getToken",
                "--token-type=oauth",
                "--oauth-grant-type=pkce",
                f"--oauth-client-ID={self.mock_client_id}",
                "--interactivity-type=gui",
                "--oauth-resource=https://radar-webservices.apple.com",
            ],
            output=f"oauth-access-token: {self.mock_jwt}\n",
        ):
            yield self.mock_jwt

    @mock.patch("subprocess.check_output", return_value="6.3 (2056)\n")
    def test_available(self, mock_appleconnect: mock.MagicMock):
        self.assertTrue(AuthenticationStrategyAppleConnect.available())
        mock_appleconnect.assert_called_once_with([self.appleconnect_path, "version"])

    @mock.patch("subprocess.check_output", return_value="5.6 (2001)\n")
    def test_available_old_version(self, mock_appleconnect: mock.MagicMock):
        self.assertFalse(AuthenticationStrategyAppleConnect.available())
        mock_appleconnect.assert_called_once_with([self.appleconnect_path, "version"])

    def test_default_access_token(self):
        """Verify AuthenticationStrategyAppleConnect parses appleconnect output for default grant code"""
        auth_strategy = self.get_instance()
        with self.mock_appleconnect_radar_access_token() as mock_jwt:
            self.assertEqual(auth_strategy.generate_oauth_access_token(), mock_jwt)

    def test_client_access_token(self):
        """Verify AuthenticationStrategyAppleConnect parses appleconnect output for access token with custom client ID"""
        auth_strategy = self.get_instance(client_id=self.mock_client_id)
        with self.mock_appleconnect_client_access_token() as mock_jwt:
            self.assertEqual(auth_strategy.generate_oauth_access_token(), mock_jwt)

    @mock.patch("subprocess.check_output")
    def test_fallback(self, mock_appleconnect: mock.MagicMock):
        """Verify AuthenticationStrategyAppleConnect detects login error with custom client ID and falls back to default RWS client ID."""
        invalid_client_args = [
            self.appleconnect_path,
            "getToken",
            "--token-type=oauth",
            "--oauth-grant-type=pkce",
            f"--oauth-client-ID={self.mock_client_id}",
            "--interactivity-type=gui",
            "--oauth-resource=https://radar-webservices.apple.com",
        ]
        radar_grant_args = [
            self.appleconnect_path,
            "getToken",
            "--token-type=oauth",
            "--oauth-grant-type=pkce",
            "--oauth-client-ID=41rih2rtlg4zyax6eztzug6ftnhkun",
            "--interactivity-type=gui",
            "--oauth-resource=https://radar-webservices.apple.com",
        ]
        mock_appleconnect.side_effect = (
            # First call should return an error
            "Error: Your account does not have permission to access this application.\nError code: 12345\n",
            # Second call should return a grant code for the Radar client ID
            f"oauth-access-token: {self.mock_jwt}\n",
        )
        auth_strategy = self.get_instance(client_id=self.mock_client_id)
        self.assertEqual(auth_strategy.generate_oauth_access_token(), self.mock_jwt)
        mock_appleconnect.assert_has_calls(
            (
                # Called first with client ID
                mock.call(invalid_client_args, stderr=subprocess.STDOUT),
                # Called a second time with Radar client ID as fallback
                mock.call(radar_grant_args, stderr=subprocess.STDOUT),
            )
        )

    def test_configure_access_token(self):
        with self.mock_appleconnect_client_access_token() as mock_jwt:
            auth_strategy = self.get_instance(client_id=self.mock_client_id)
            request = AuthenticatedRequestUrllib2(auth_strategy, "https://radar-webservices.apple.com/")
            auth_strategy.configure_request_for_native_authentication(request)
            self.assertEqual(request._unittest_support_get_header("X-apple-oidc-access-token"), mock_jwt)

    def test_serialize(self):
        # with self.mock_appleconnect_client_access_token() as mock_jwt:
        auth_strategy = self.get_instance(client_id=self.mock_client_id)
        value = pickle.dumps(auth_strategy)
        self.assertIsNotNone(value)

    def test_account(self):
        with _run(
            [
                self.appleconnect_path,
                "getToken",
                "--token-type=oauth",
                "--oauth-grant-type=pkce",
                "--oauth-client-ID=41rih2rtlg4zyax6eztzug6ftnhkun",
                "--interactivity-type=gui",
                "--oauth-resource=https://radar-webservices.apple.com",
                "--account=jappleseed",
            ],
            output=f"oauth-access-token: {self.mock_jwt}\n",
        ):
            self.assertEqual(self.get_instance(account="jappleseed").generate_oauth_access_token(), self.mock_jwt)

    def test_keytab(self):
        with _run(
            [
                self.appleconnect_path,
                "getToken",
                "--token-type=oauth",
                "--oauth-grant-type=pkce",
                "--oauth-client-ID=41rih2rtlg4zyax6eztzug6ftnhkun",
                "--interactivity-type=gui",
                "--oauth-resource=https://radar-webservices.apple.com",
                "--account=jappleseed",
                "--keytab=auth.keytab",
            ],
            output=f"oauth-access-token: {self.mock_jwt}\n",
        ):
            self.assertEqual(self.get_instance(account="jappleseed", keytab="auth.keytab").generate_oauth_access_token(), self.mock_jwt)

    def test_use_identity(self):
        with _run(
            [
                self.appleconnect_path,
                "getToken",
                "--token-type=oauth",
                "--oauth-grant-type=pkce",
                "--oauth-client-ID=41rih2rtlg4zyax6eztzug6ftnhkun",
                "--interactivity-type=gui",
                "--oauth-resource=https://radar-webservices.apple.com",
                "--account=jappleseed",
                "--use-identity=delegated",
            ],
            output=f"oauth-access-token: {self.mock_jwt}\n",
        ):
            self.assertEqual(self.get_instance(account="jappleseed", use_identity="delegated").generate_oauth_access_token(), self.mock_jwt)

    def test_uat(self):
        with _run(
            [
                self.appleconnect_path,
                "getToken",
                "--token-type=oauth",
                "--oauth-grant-type=pkce",
                "--oauth-client-ID=hcjqu4f34vpvyxbbh1k26u1yqa1hdp",
                "--interactivity-type=gui",
                "--oauth-resource=https://rdr-rws-test2.corp.apple.com",
                "--environment=uat",
            ],
            output=f"oauth-access-token: {self.mock_jwt}\n",
        ):
            self.assertEqual(self.get_instance(radar_environment=RadarEnvironment("uat-alt")).generate_oauth_access_token(), self.mock_jwt)


class Test_OTPGenerator(unittest.TestCase):
    def test_htop(self):
        g = _OTPGenerator("atest234567atest")
        # Expected values generated using a validated alternate language implementation
        for counter, expected in enumerate(
            [
                "364498",
                "390115",
                "756546",
                "834220",
                "076753",
                "456179",
                "279738",
                "852354",
                "342005",
                "253522",
            ]
        ):
            assert g.hotp(counter) == expected

    def test_totp(self):
        g = _OTPGenerator("atest234567atest")
        totp_code = g.totp()
        assert isinstance(totp_code, str)
        assert len(totp_code) == _OTPGenerator.NUM_DIGITS
