# coding=utf-8
from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import datetime
import itertools
import sys
import os
import json
import pprint
import re
import bisect
from sys import warnoptions
import time
import warnings
import weakref
from collections import defaultdict
from copy import copy, deepcopy
from .utilities import response_code_is_success, RadarProtocolVersion, _convert_response_list_to_dict, logger
from .exceptions import (ObjectNotFoundException, UnsuccessfulResponseException, AttachmentLockedException,
                         DeprecatedMethodException, RadarAccessDeniedResponseException, UpdateByIDLookUpError,
                         ReorderDuplicatePlacementException, IncompatibleFieldsRequestException,
                         UnsuccessfulRadarJobException, KeyValuePairNotFoundException,
                         KeyValuePairAlreadyExistsException, KeyValuePairNotSupportedException)
from .decorators import cached_class_property, deprecated, deprecated_and_removed
import radarclient.compat as compat


class DictionaryBasedModel(object):
    """
    This is a base class for objects that are initialized by a dictionary. The dictionary keys are
    converted into properties on the instance. The values are run through value converters going in both
    directions.

    :meta private:
    """
    identifier_attrs = ()
    DEFAULT_PROPERTIES = []
    PROPERTY_KEYNAME_MAP = {}
    EXCLUDE_FROM_FIND = set()
    URL_COMPONENTS_FOR_FIND = None
    URL_COMPONENTS_FOR_GET_BY_ID = None
    GET_BY_ID_METHOD = None
    MAX_BATCH_SIZE = 15

    def __init__(self, dictionary_representation=None, *extra_constructor_args):
        if dictionary_representation is None:
            dictionary_representation = {}
        self.dictionary_representation_data = dictionary_representation
        self.parse_data()

    # API v2.2 changed many key names for several of the object classes based on DictionaryBasedModel.
    # This allows use of PROPERTY_KEYNAME_MAP dictionaries in the subclasses via keyname_map to map old names to new.
    def __getattr__(self, item):
        map = self.keyname_map
        attr = next((v for k, v in itertools.chain(map.items(), zip(map.values(), map.keys())) if k == item), None)
        if attr is None:
            raise AttributeError('{} is not an attribute'.format(item))
        return object.__getattribute__(self, attr)

    def __hash__(self):
        return hash(self.get_idents_str())

    def __eq__(self, other):
        return type(self) == type(other) and self.get_idents_str() == other.get_idents_str()

    def __ne__(self, other):
        return not self == other

    def database_id_attribute_value(self):
        """
        Returns the value of the attribute that is used as an ID in the database

        :return: Value of the ID attribute or ``None`` if this object does not have a unique database ID
        """
        # At the top level, this requires the first item in identifier_attrs to be the name of the ID attribute
        if len(self.identifier_attrs) == 0:
            return None
        else:
            return getattr(self, self.identifier_attrs[0])

    @classmethod
    def _instantiate_list_of_items(cls, item_list):
        return list(cls._make_generator_to_instantiate_items(item_list))

    @classmethod
    def _make_generator_to_instantiate_items(cls, item_list):
        return (cls(item) for item in item_list)

    @classmethod
    def _make_request_for_items_by_id(cls, client, url_suffix, additional_fields=None, fields=None,
                                      additional_headers=None, check_result=True):
        """
        Makes a request to get items by ID

        :param RadarClient client: client to use
        :param str|int url_suffix: last piece of the URL, usually the ID
        :param list[str] additional_fields: additional fields to request
        :param list[str] fields: A list of exclusive fields to get, if passed in, ``additional_fields`` is ignored
        :param list[tuple] additional_headers: list of tuples in format (header, value) to add to
            the request
        :param bool check_result: If True, checks the result for error, otherwise continues
            without checking

        :return: returns tuple of format (status code, data)
        """
        if additional_headers is None:
            additional_headers = []

        # This is able to be prettier in python3 below but need to maintain python2 support
        # url = client.webservice_url_for_path_components(
        #     *cls.URL_COMPONENTS_FOR_GET_BY_ID, url_tail
        # )
        url = client.webservice_url_for_path_components(
            *cls.URL_COMPONENTS_FOR_GET_BY_ID + (url_suffix,)
        )

        request = client.request_for_json_url(url)

        for header in additional_headers:
            request.add_header(*header)

        if fields is not None:
            # Make sure identifying attributes are retrieved always
            fields_set = set(fields)
            for id_attr in cls.identifier_attrs:
                fields_set.add(id_attr)

            client.configure_request_for_requested_fields(request, fields_set)
        else:
            client.configure_request_for_additional_fields(request, cls, additional_fields)
        req_status, req_data = client.send_request(request, check_response_code=check_result)
        return req_status, req_data

    @classmethod
    def _get_by_id(cls, item_id, client, processing_callable=None, additional_fields=None, fields=None,
                   additional_headers=None):
        """
        Finds a single item by ID

        :param int item_id: ID of item
        :param RadarClient client: client instance to use
        :param Callable[[Any], Any] processing_callable: callable that takes the data returned and
            processes it
        :param list[str] additional_fields: additional fields to fetch
        :param list[str] fields: A list of the exclusive fields to fetch

        :return: cls object
        :raises: IncompatibleFieldsRequestException if both ``fields`` and ``additional_fields`` are requested
        """
        if additional_fields is not None and fields is not None:
            raise IncompatibleFieldsRequestException('Cannot request both "additional_fields" and "fields"')

        if processing_callable is None:
            def processor(returned_item):
                if not isinstance(returned_item, dict):
                    raise ObjectNotFoundException(200, returned_item, 'Radar API did not return a dictionary')
                else:
                    return cls(returned_item)
        else:
            processor = processing_callable

        status, info = cls._make_request_for_items_by_id(
            client, item_id, additional_fields=additional_fields, fields=fields, additional_headers=additional_headers
        )
        # Some single-item response dictionaries return in a list.
        info = _convert_response_list_to_dict(info)

        if not response_code_is_success(status):
            raise client.exception_for_non_success_response(status, info)

        return processor(info)

    @classmethod
    def _pseudo_get_by_ids_error_checking(cls, item_id, item_data):
        """
        Checks for errors with _pseudo_get_by_ids

        :param int item_id: ID of item
        :param dict item_data: dictionary returned from API

        :return: True if there was an error, False otherwise
        """
        item_data = _convert_response_list_to_dict(item_data)   # API v2.2 (rdar://97676446)

        if 'message' in item_data:
            logger.error('Failed to get {} with ID {}. {}'.format(
                cls.__name__, item_id, item_data['message']))
            return True

        for id_attr in cls.identifier_attrs:
            if id_attr not in item_data:
                logger.error('Unknown error occurred fetching {} with ID {}. '
                      'returned item:{}'.format(cls.__name__, item_id, item_data))
                return True

        return False

    @classmethod
    def _process_pseudo_get_by_ids_result(cls, item_id, item_data, return_list):
        """
        Processes result from _pseudo_get_by_ids. It checks for errors. If there is no error,
        it instantiates an object of type cls and appends it to return_list

        :param int item_id: ID of item
        :param dict item_data: API returned dictionary
        :param list return_list: list to append instantiated objects to

        :return: list of cls objects
        """
        if not cls._pseudo_get_by_ids_error_checking(item_id, item_data):
            return_list.append(cls(item_data))

    @classmethod
    def _pseudo_get_by_ids(cls, id_list, client, processing_callable=None, additional_fields=None, fields=None,
                           additional_headers=None):
        """
        Not all endpoints in the API support multiple IDs at a time. This function looks to
        behave as though it did. If an item is not found, instead of raising an error,
        it will print it

        :param list[int] id_list: list of IDs to find
        :param RadarClient client: client instance to use for requests
        :param callable processing_callable: a callable that takes the item ID, the returned
            information, and a list and processes the return. If the item is valid, it appends it to
            the list, otherwise it prints an error
        :param list[str] additional_fields: list of additional fields to get
        :param list[str] fields: list of exclusive fields to get, if passed in, ``additional_fields`` is ignored

        :return: list of type cls
        """
        if processing_callable is None:
            processor = cls._process_pseudo_get_by_ids_result
        else:
            processor = processing_callable

        to_return = []
        for search_id in id_list:
            # check_result has to be True for retry to happen but we also don't want to raise the error to meet the
            # requirements of the contract
            try:
                status, ret_data = cls._make_request_for_items_by_id(
                    client, search_id, check_result=True, additional_fields=additional_fields, fields=fields,
                    additional_headers=additional_headers
                )
                processor(search_id, ret_data, to_return)
            except UnsuccessfulResponseException as ure:
                logger.exception(ure.message)

        return to_return

    @classmethod
    def _validate_get_by_ids_result(cls, result):
        """
        Checks to see if a result from _get_by_ids is an error and prints the error if needed

        :param dict result: result to check

        :return: True if there is an error, False otherwise
        """
        has_error = False
        if 'error' in result:
            logger.error('Error getting {} with {} {}: "{}"'.format(
                cls.__name__, cls.identifier_attrs[0], result.get(cls.identifier_attrs[0], '(unknown)'), result['error'])
            )
            has_error = True
        elif 'message' in result:
            logger.warning('Server warning message: {}'.format(result['message']))
            has_error = True

        return has_error

    @classmethod
    def _process_get_by_ids_results(cls, results):
        """
        This is the default processor for _get_by_ids. It takes the results and instantiates them
        as an object of type cls

        :param list[dict] results: list of results

        :return: list of cls objects
        """
        to_return = []
        for result in results:
            has_errors = cls._validate_get_by_ids_result(result)
            if not has_errors:
                to_return.append(cls(result))
        return to_return

    @classmethod
    def _get_by_ids(cls, id_list, client, processing_callable=None, additional_fields=None,
                    batch_size=15, additional_headers=None, fields=None):
        """
        Fetches a list of items from the Radar web API and will not raise an error if one or
        more items in the list are not found or raise an error

        :param list[int|str] id_list: list of IDs to fetch
        :param RadarClient client: client instance to use for requests
        :param callable processing_callable: A callable that takes the response from the Radar API and
            processes it. Any valid objects that are created are appended to the passed in list. Anything
            that hit an error should print information about the error
        :param list[str] additional_fields: A list of additional fields to load from the
            Radar Web API
        :param int batch_size: size of batches to use
        :param list[str] fields: list of exclusive fields to get, if passed in, ``additional_fields`` is ignored

        :return: return of processing_callable
        """
        if processing_callable is None:
            processor = cls._process_get_by_ids_results
        else:
            processor = processing_callable

        if batch_size > cls.MAX_BATCH_SIZE:
            logger.warning('Requested batch size, {}, is too big, '
                  'limiting to {}'.format(batch_size, cls.MAX_BATCH_SIZE))
            batch_size = cls.MAX_BATCH_SIZE

        # handle if list is a generator
        local_id_list = list(id_list)
        results = []
        for i in range(0, len(local_id_list), batch_size):
            batch_ids = [compat.unicode_string_type(item_id) for item_id in local_id_list[i:i + batch_size]]
            _, info = cls._make_request_for_items_by_id(
                client, ','.join(batch_ids), additional_fields=additional_fields, fields=fields,
                additional_headers=additional_headers
            )
            if isinstance(info, dict):
                results.append(info)
            else:
                results += info

        return processor(results)

    @classmethod
    def _find_ids(cls, query_data, client, id_attr, limit=None, additional_headers=None, processing_callable=None):
        """
        Convenience method for finding just IDs

        :param dict query_data: query dictionary
        :param RadarClient client: instance of client to use
        :param str id_attr: name of ID attribute for object
        :param int limit: maximum number to return

        :return: list of just the values for id_attr found by the search
        """
        results = cls._find(query_data, client, limit=limit,
                            exclusive_fields_for_first_search=[id_attr],
                            return_results_directly=True,
                            additional_headers=additional_headers,
                            processing_callable=processing_callable)
        return [getattr(result, id_attr) for result in results]

    @classmethod
    def _find_processor(cls, results, get_ids_method, return_results_directly):
        """
        Processes results from _find

        :param list[dict] results: list of dictionary results from API
        :param callable get_ids_method: a function that takes in a list of IDs and finds the
            items in the API with any other arguments set via partial. This is used for any of the
            two part searches such as TestSuite
        :param bool return_results_directly: if True, just instantiates the list as cls type

        :return: list of cls objects
        """
        if return_results_directly:
            to_return = cls._instantiate_list_of_items(results)
        else:
            ids = [result[cls.identifier_attrs[0]] for result in results]
            to_return = get_ids_method(ids)
        return to_return

    @classmethod
    def _replace_id_keys_with_values_for_compact_response(cls, results):
        to_return = []
        # Sometimes the value returned by the API is a list and not a dict
        # rdar://122811566 (Compact Format Returns a List, Not Dict, When there are no results)
        if isinstance(results, dict):
            field_map = results.get('fieldMapping')
            object_dict = results.get('objectDictionary')
            for result in results['result']:
                new_item = deepcopy(result)
                for field in field_map:
                    # Work around rdar://122649173 (fieldMapping is wrong for person types in compact response for find scheduled test)
                    if field_map[field] == 'person':
                        new_item_key = field[0:-2]
                    else:
                        new_item_key = field_map[field]
                    object_conversion = object_dict[field_map[field]]
                    conversion_key = new_item[field]
                    if conversion_key is not None:
                        new_item[new_item_key] = object_conversion[str(conversion_key)]
                    else:
                        new_item[new_item_key] = None
                    del new_item[field]
                to_return.append(new_item)
        return to_return

    @classmethod
    def _find_processor_for_compact_format(cls, results, get_ids_method, return_results_directly):
        to_return = []
        # Work around rdar://122811566 (Compact Format Returns a List, Not Dict, When there are no results)
        if not isinstance(results, list):
            # Need to actually instantiate items due to database ID names not being consistent
            # rdar://116066084 (Finding Scheduled Test Case and Getting by ID Return Differently Named Attributes for ID)
            instantiated_item_generator = cls._make_generator_to_instantiate_items(
                cls._replace_id_keys_with_values_for_compact_response(results)
            )
            if return_results_directly:
                to_return = list(instantiated_item_generator)
            else:
                id_response_gen = (item.database_id_attribute_value() for item in instantiated_item_generator)
                to_return = get_ids_method(id_response_gen)

        return to_return

    @classmethod
    def _find(cls, query_data, client, limit=None, processing_callable=None,
              additional_fields=None, exclusive_fields_for_first_search=None,
              return_results_directly=False, get_ids_method=None, additional_headers=None):
        """
        Runs a simple find against the radar API. Class must have a value for
        URL_COMPONENTS_FOR_FIND

        :param dict query_data: query dictionary
        :param RadarClient client: instance of client to use
        :param int limit: maximum number of items to return
        :param callable processing_callable: function that will process the returned results
        :param list[str] additional_fields: additional fields to fetch
        :param list[str] exclusive_fields_for_first_search: Used for searches that run a find
            and then get by ID. Can also be used to get only some of the supported IDs returned
        :param bool return_results_directly: If true, just returns whatever the processor
            provides after performing find
        :param callable get_ids_method: Method that will take a list of IDs and fetch matching
            objects from the radar API

        :return: return from processing_callable
        """
        if processing_callable is None:
            processor = cls._find_processor
        else:
            processor = processing_callable

        if return_results_directly and additional_fields is not None and \
                exclusive_fields_for_first_search is not None:
            raise ValueError('Cannot have return_results_directly be True with values for both '
                             'additional_fields and exclusive_fields_for_first_search')

        headers_to_add = []

        if return_results_directly and additional_fields is not None:
            requested_fields = set(cls.property_names) - cls.EXCLUDE_FROM_FIND
            requested_fields.update(additional_fields)
            headers_to_add.append(client.create_requested_fields_header(requested_fields))

        if exclusive_fields_for_first_search is not None:
            headers_to_add.append(client.create_requested_fields_header(exclusive_fields_for_first_search))

        if limit is not None:
            headers_to_add.append(client.create_limit_header(limit))

        if additional_headers is not None:
            headers_to_add += additional_headers

        _, info = client.build_and_send_json_request(cls.URL_COMPONENTS_FOR_FIND, query_data,
                                                     additional_headers=headers_to_add, method='POST')

        return processor(info, get_ids_method, return_results_directly)

    def get_idents(self):
        if len(self.identifier_attrs) == 0:
            raise NotImplementedError('Objects of class "{}" can\'t be hashed because their identifier_attrs are not defined.'.format(type(self)))
        return (str(self.__getattribute__(attr)) for attr in self.identifier_attrs)

    def get_idents_str(self, sep=''):
        return sep.join(self.get_idents())

    def parse_data(self):
        all_property_names = set(self.property_names + list(self.dictionary_representation_data.keys()))
        # The use of keyname_map is to remove the unused/irrelevant version of key name strings in scenarios
        # where they differ from API v2.1 and v2.2. The unused set of keys will be removed before the object is instantiated.
        keyname_map = self.keyname_map
        for old_key, new_key in keyname_map.items():
            if old_key in self.dictionary_representation_data:
                all_property_names.discard(new_key)
        for property_name in all_property_names:
            value = self.dictionary_representation_data.get(property_name, None)
            value = self.decode_property_value(property_name, value)
            self.apply_parsed_data(property_name, value)

    def apply_parsed_data(self, property_name, value):
        setattr(self, property_name, value)

    @classmethod
    def parse_webservice_data(cls, data_list, client, *extra_constructor_args):
        if isinstance(data_list, dict):
            data_list = [data_list]
        item_list = []
        for item_data in data_list:
            if 'status' in item_data:
                logger.error(u'Unable to load {} data: {}/{}'.format(cls.__name__, item_data['status'], item_data.get('message', '(No error message available)')))
                continue
            item_list.append(cls(item_data, client, *extra_constructor_args))
        return item_list

    def dictionary_representation(self):
        """
        Will return the defined properties of a DictionaryBasedModel subclass in dictionary form, and an alternative to
        referencing ``<class>.dictionary_representation_data``, which is typically the API response data used to instantiate the object.

        This is an implementation detail, and not meant to be referenced directly by clients.

        :meta private:
        """
        return {k: getattr(self, k) for k in self.property_names}

    @classmethod
    def value_converter_class_for_self(cls, variant=None):
        raise NotImplementedError()

    @classmethod
    def is_placeholder(cls):
        return False

    def radar_encoded_representation(self, variant=None):
        return self.value_converter_class_for_self(variant=variant).encode_radar_value(self)

    def decode_property_value(self, property_name, value):
        value_converter = self.value_converter_for_property_name(property_name)
        if value_converter:
            value = value_converter.decode_radar_value(value)
        return value

    def decode_user_friendly_property_value(self, property_name, value):
        value_converter = self.value_converter_for_property_name(property_name)
        if value_converter:
            value = value_converter.decode_user_friendly_value(value)
        return value

    def encode_user_friendly_property_value(self, property_name, value):
        value_converter = self.value_converter_for_property_name(property_name)
        if value_converter:
            value = value_converter.encode_user_friendly_value(value)
        return value

    def encode_property_value(self, property_name, value, *args):
        value_converter = self.value_converter_for_property_name(property_name)
        if value_converter:
            try:
                if len(args) > 0:
                    value = value_converter.encode_radar_value(value, args[0])
                else:
                    value = value_converter.encode_radar_value(value)
            except Exception as e:
                logger.error('value converter {} failed to convert value "{}": {}'.format(value_converter, value, e))
                raise
        return value

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        return u'<{} {}>'.format(type(self).__name__, self.dictionary_representation_data)

    @cached_class_property
    def property_names(cls):
        return DictionaryBasedModel.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        return DictionaryBasedModel.PROPERTY_KEYNAME_MAP

    @cached_class_property
    def property_value_converter_map(cls):
        # This maps property names to the value converter classes
        # that should be used to convert the corresponding value.
        return {
            'createdAt': ISO8601UTCDateValueConverter,
            'lastModifiedAt': ISO8601UTCDateValueConverter,
            'addedAt': ISO8601UTCDateValueConverter,
            'addedBy': CommentAuthorValueConverter,
        }

    def value_converter_for_property_name(self, property_name):
        return self.property_value_converter_map.get(property_name, None)

    def merge(self, merge_in):
        """
        Takes another object of the same type and updates the values of this object. Will add
        keys that don't exist currently and overwrite any that do exist. This is particularly
        useful for objects that have very disparate ``Find`` and ``get by ID`` endpoints such as
        :py:class:`~radarclient.model.ScheduledTest`

        :param merge_in: object to merge in. Must be of the same type as calling object

        :return: None
        :raises: ValueError if object don't represent the same thing

        :meta private:
        """
        if self != merge_in:
            raise ValueError('Cannot merge two objects that do not share identifier_attributes')
        self.dictionary_representation_data.update(merge_in.dictionary_representation_data)
        self.parse_data()

    @classmethod
    def merge_lists(cls, list_1, list_2, id_attr=None):
        """
        Merges items in two lists together to get all keys. This is particularly useful for
        objects that have ``find`` and ``get by ID`` endpoints that return different values such
        as :py:class:`ScheduledTest`. It does this using :py:meth:`merge`. If an item in
        ``list_1`` is also in ``list_2``, the item in ``list_1`` will be updated with the values
        from the item in ``list_2``. The lists must contain all the same type of object. See an
        example on :py:meth:`~radarclient.client.RadarClient.scheduled_tests_for_ids`

        :param list list_1: list to be merged in to
        :param list list_2: list to merge in from
        :param str id_attr: An attribute name used as to identify the merging items. Defaults to the ID attribute of
            the calling object if not specified

        :return: True if all items in ``list_1`` had a match in ``list_2``. Otherwise False

        :meta private:
        """
        to_return = True
        if not id_attr:
            id_attr = cls.identifier_attrs[0]
        merge_in_dict = {getattr(item, id_attr): item for item in list_2}
        for item in list_1:
            item_id = getattr(item, id_attr)
            if item_id in merge_in_dict:
                item.merge(merge_in_dict.pop(item_id))
            else:
                to_return = False

        return to_return

    def webservice_url_components_for_key_values(self):
        raise KeyValuePairNotSupportedException("There is no Key-Value Pair support for {}".format(type(self)))


class DotNotationDictionary(dict):
    """
    :meta private:
    """
    pass


class TSTTRelatedProblem(DictionaryBasedModel):
    """
    Tracks a relationship between a radar and any of the TSTT objects, TestSuite, TestCase,
    ScheduledTestCase, and ScheduledTest. This should not need to be instantiated directly.

    :param dict data: dictionary data for object
    :param DictionaryBasedTSTTModel tstt_object: Creates a weakref.proxy to the related TSTT item
    """
    identifier_attrs = ('id', 'tstt_object', 'relationType')

    DEFAULT_PROPERTIES = [
        'id',
        'relationType'
    ]

    TYPE_RELATED_TO = 'related-to'
    TYPE_BLOCKED_BY = 'blocked-by'

    @cached_class_property
    def property_names(cls):
        return super(TSTTRelatedProblem,
                     TSTTRelatedProblem).property_names + \
               TSTTRelatedProblem.DEFAULT_PROPERTIES

    def __init__(self, data=None, tstt_object=None):
        if tstt_object is not None:
            self.tstt_object = weakref.proxy(tstt_object)
        else:
            # noinspection PyTypeChecker
            self.tstt_object = None

        super(TSTTRelatedProblem, self).__init__(dictionary_representation=data)

        # pull the id out to top level to match previous behavior
        if data.get('id', None) is None:
            self.id = data['problem']['id']

    def associate_tstt_object(self, tstt_object):
        """
        Associates the related TSTT object as a weak reference. This is important for hashing to
        work correctly

        :param DictionaryBasedTSTTModel tstt_object: TSTT item to add

        :return: None
        :meta private:
        """
        self.tstt_object = weakref.proxy(tstt_object)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(TSTTRelatedProblem, cls).property_value_converter_map)
        map.update({
            'component': ComponentValueConverter,
        })
        return map

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        return u'<{} {} {} radar ID {}>'.format(
            self.__class__.__name__, self.tstt_object, self.relationType, self.id
        )

    def __hash__(self):
        return hash(
            (self.id,
             self.tstt_object.database_id_attribute_value(),
             type(self.tstt_object),
             self.relationType)
        )

    def __eq__(self, other):
        return (type(self) == type(other) and self.tstt_object == other.tstt_object and self.relationType ==
                other.relationType)


class DictionaryBasedTSTTModel(DictionaryBasedModel):
    """
    Parent class of TSTT objects that use change tracking for updates such as TestSuite,
    TestCase, ScheduledTest, and ScheduledTestCase

    :param dict data: data dictionary for item
    :meta private:
    """
    DEFAULT_PROPERTIES = []

    REPLACEMENT_KEYS = {}
    REVERSED_REPLACEMENT_KEYS = {v: k for k, v in REPLACEMENT_KEYS.items()}

    ENTITY_TYPE = None
    BASE_URL = None
    PROPERTY_NAME_FOR_KEYWORDS = 'keywords'
    PROPERTY_NAME_FOR_RELATED_PROBLEMS = 'relatedProblems'

    # Work around rdar://115851863 (Finding Scheduled Tests and Getting by ID Return the ID with Different Names) and
    # rdar://116066084 (Finding Scheduled Test Case and Getting by ID Return Differently Named Attributes for ID).
    # Definitions live in the associated classes
    FIND_ID_KEYS = ()
    GET_ID_KEYS = ()

    # Attributes that have their own change tracking that shouldn't have simple change record items created. Similar
    # to CollectionProperty items on Radar objects
    NON_SIMPLE_ATTRIBUTE_UPDATE_SET = {'attachments', 'pictures'}

    def __init__(self, data=None):
        for i in range(len(self.FIND_ID_KEYS)):
            find_key = self.FIND_ID_KEYS[i]
            get_key = self.GET_ID_KEYS[i]

            if find_key in data:
                data[get_key] = data[find_key]
            elif get_key in data:
                data[find_key] = data[get_key]

        self.change_records = defaultdict(list)
        self.is_being_instantiated = True
        super(DictionaryBasedTSTTModel, self).__init__(data)
        self.attachment_url_components = (self.ENTITY_TYPE, self.database_id_attribute_value(), 'attachments')
        self.pictures_url_components = (self.ENTITY_TYPE, self.database_id_attribute_value(), 'pictures')
        self.is_being_instantiated = False

        # Track keyword info to work around rdar://115739721 (Don't Raise an Error if Keyword to Add is Attached or
        # Keyword to Remove is not Attached to Radar Test Item)
        self.keywords = getattr(self, self.PROPERTY_NAME_FOR_KEYWORDS, [])
        self._keywords_set = set(self.keywords)

        # Track related problems even if not requested and work around
        # rdar://115739721 (Don't Raise an Error if Keyword to Add is Attached or Keyword to Remove is not Attached
        # to Radar Test Item)
        self.relatedProblems = getattr(self, self.PROPERTY_NAME_FOR_RELATED_PROBLEMS, [])
        self._related_problems_set = set()
        for related_problem in self.relatedProblems:
            # Associate the TSTT object as a weak reference for correct hashing
            related_problem.associate_tstt_object(self)
            self._related_problems_set.add(related_problem)

        # If attachments or pictures were included in the first batch, properly set them up without another API call
        self.attachments = []
        if 'attachments' in data and data['attachments'] is not None:
            for attachment in data['attachments']:
                self.attachments.append(TSTTAttachment(self, enclosure_data=attachment))
        self.pictures = []
        if 'pictures' in data and data['pictures'] is not None:
            for picture in data['pictures']:
                self.pictures.append(TSTTPicture(self, enclosure_data=picture))

        self.clear_change_records()

    @cached_class_property
    def property_names(cls):
        return super(DictionaryBasedTSTTModel,
                     DictionaryBasedTSTTModel).property_names + \
               DictionaryBasedTSTTModel.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        # Had to add this due to
        # rdar://115734641 (New Radar Test API Endpoint Return `priority` as a string instead of an int)
        m = dict(super(DictionaryBasedTSTTModel, cls).property_value_converter_map)
        m.update({
            'priority': RadarTestPriorityStringValueConverter,
            'keywords': KeywordListValueConverter,
            'component': ComponentValueConverter,
            'assignee': PersonValueConverter,
            'author': PersonValueConverter,
            'relatedProblems': TSTTRelatedProblemListValueConverter,
            'createdBy': PersonValueConverter,
            'lastModifiedBy': PersonValueConverter,
            'createdAt': ISO8601UTCDateValueConverter,
            'lastModifiedAt': ISO8601UTCDateValueConverter,
            'appName': ApplicationNameValueConverter,
            'applicationName': ApplicationNameValueConverter,
            'category': BusinessProcessValueConverter,
            'geography': TestGeographyValueConverter,
            'trackName': TestTrackValueConverter,
            'counts': DictionaryBasedModelValueConverter,
            'label': LabelValueConverter,
            'approvedBy': PersonValueConverter
        })
        return m

    def change_record_class_for_property(self, property):
        pass

    def clear_change_records(self):
        """
        Clears all queued changes. If you need the object to match the database, make a new call
        to fetch an accurate object

        :return: None
        """
        self.change_records.clear()

    def _add_change_record(self, change_record):
        self.change_records[type(change_record)].append(change_record)

    def extend_known_fields(self, client, additional_fields=None, fields=None):
        """
        Gets more values for the item without creating a new object.

        :param RadarClient client: a RadarClient to use to fetch the data
        :param iter[str] additional_fields: A list of fields to grab along with the defaults that would be returned
            if you were just requesting the item on its own
        :param iter[str] fields: A list of exclusive fields to get. It will not fetch anything other than what is
            passed in here

        .. note::
          This clears any change records so it should only be called right after instantiation.

        :return: None
        """
        full_item = getattr(client, self.GET_BY_ID_METHOD)(self.database_id_attribute_value(),
                                                           additional_fields=additional_fields,
                                                           fields=fields)

        if fields is None:
            for property_name in self.DEFAULT_PROPERTIES:
                attribute_value = getattr(full_item, property_name)
                setattr(self, property_name, attribute_value)
                self.dictionary_representation_data[property_name] = attribute_value
        if additional_fields is not None:
            for additional_field in additional_fields:
                attribute_value = getattr(full_item, additional_field)
                setattr(self, additional_field, attribute_value)
                self.dictionary_representation_data[additional_field] = attribute_value
        if fields is not None:
            for field in fields:
                attribute_value = getattr(full_item, field)
                setattr(self, field, attribute_value)
                self.dictionary_representation_data[field] = attribute_value

        self._keywords_set = set(self.keywords)
        self._related_problems_set = set(self.relatedProblems)

        self.clear_change_records()

    def load_attachments(self, client):
        """
        Loads attachments for item and sets ``self.attachments`` to the result

        :param RadarClient client: instance of radarclient to use

        :return: None
        """
        _, data = client.build_and_send_request(self.attachment_url_components)
        self.attachments = [TSTTAttachment(self, enclosure_data=item) for item in data]

    def load_attachments_and_pictures(self, client):
        """
        Convenience method that loads both pictures and attachments

        :param RadarClient client: instance of radarclient to use

        :return: None
        """
        self.load_pictures(client)
        self.load_attachments(client)

    def load_pictures(self, client):
        """
        Loads pictures for object and sets ``self.pictures`` to the result

        :param RadarClient client: instance of radarclient to use

        :return: None
        """
        _, data = client.build_and_send_request(self.pictures_url_components)
        self.pictures = [TSTTPicture(self, enclosure_data=item) for item in data]

    def _add_file(self, file_name, file_class, overwrite=False):
        new_file = file_class(self, file_name=file_name)
        self._add_change_record(AddFileTSTTChangeRecord(new_file, overwrite=overwrite))
        return new_file

    def _delete_file(self, file_obj):
        self._add_change_record(DeleteFileTSTTChangeRecord(file_obj))

    def add_attachment(self, file_name, overwrite=False):
        """
        Creates new attachment object that can be used to upload a file when changes are
        committed

        :param str file_name: Name of file once attached to radar
        :param bool overwrite: If True, will overwrite existing file, otherwise will not upload
            if file with the same name exists

        :rtype: TSTTAttachment

        Example::

            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel

            # For small files
            attachment = tstt_object.add_attachment('New File Name')
            attachment.set_upload_content('test 123'.encode())
            tstt_object.commit_changes(client)

            # For larger files
            attachment = tstt_object.add_attachment('New File Name')
            attachment.set_upload_file(open('/tmp/largefile.tgz', 'rb'))
            tstt_object.commit_changes(client)

        """
        new_attachment = self._add_file(file_name, TSTTAttachment, overwrite=overwrite)
        self.attachments = getattr(self, 'attachments', [])
        self.attachments.append(new_attachment)
        return new_attachment

    def delete_attachment(self, attachment):
        """
        Will delete the specified attachment on commit_changes

        :param TSTTAttachment attachment: attachment to delete

        :return: None

        Example::

            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel
            tstt_object.load_attachments(radar_client)
            tstt_object.delete_attachment(tstt_object.attachments[0])
            tstt_object.commit_changes(radar_client)

        """
        self._delete_file(attachment)

    def add_picture(self, file_name, overwrite=False):
        """
        Creates new picture object that can be used to upload a picture when changes are
        committed

        :param str file_name: Name of picture once attached to scheduled case
        :param bool overwrite: If True, will overwrite existing picture, otherwise will not upload
            if picture with the same name exists

        :rtype: TSTTPicture

        Example::

            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel

            # For small files
            picture = tstt_object.add_picture('New Picture.png')
            with open('/path/to/picture.png', 'rb') as fp:
                contents = fp.read()
            picture.set_upload_content(contents)
            tstt_object.commit_changes(client)

            # For larger files
            picture = tstt_object.add_picture('New Picture.png')
            picture.set_upload_file(open('/tmp/picture.png', 'rb'))
            tstt_object.commit_changes(client)

        """
        new_picture = self._add_file(file_name, TSTTPicture, overwrite=overwrite)
        self.pictures = getattr(self, 'pictures', [])
        self.pictures.append(new_picture)
        return new_picture

    def delete_picture(self, picture):
        """
        Will delete the specified picture when committing changes

        :param TSTTPicture picture: picture to be deleted

        :return: None

        Example::

            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel
            tstt_object.load_pictures(radar_client)
            tstt_object.delete_picture(tstt_object.pictures[0])
            tstt_object.commit_changes(radar_client)

        """
        self._delete_file(picture)

    def add_keywords(self, keywords):
        """
        Add multiple Keywords. If you will be using this method, it is highly recommended that you request ``keywords`` as
        part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to associate a keyword that is already associated. If
        you have the list, the addition of a keyword that is already associated will simply be ignored.

        :param iter[~radarclient.model.Keyword] keywords: iterable of Keyword objects to add

        :return: None
        """
        for keyword in keywords:
            if keyword not in self._keywords_set:
                self.keywords.append(keyword)
                self._keywords_set.add(keyword)
                self._add_change_record(RadarTestUpdateChangeRecord(
                    self, self.PROPERTY_NAME_FOR_KEYWORDS,
                    update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_KEYWORD,
                    action=RadarTestUpdateChangeRecord.ACTION_TYPE_INSERT,
                    new_value=[keyword]
                ))
            else:
                logger.info('{} was already in keyword list, will not add'.format(keyword))

    def add_keyword(self, keyword):
        """
        Add a Keyword. If you will be using this method, it is highly recommended that you request ``keywords`` as
        part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to associate a keyword that is already associated. If
        you have the list, the addition of a keyword that is already associated will simply be ignored.

        :param ~radarclient.model.Keyword keyword: keyword to add

        :return: None

        Example::

            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel
            keyword = radar_client.keywords_for_ids([52846])[0]
            tstt_object.add_keyword(keyword)
            tstt_object.commit_changes(radar_client)

        """
        # Need to add keywords to dictionary representation so change record gets created
        self.add_keywords([keyword])

    def add_keyword_by_id(self, keyword_id):
        """
        Add a keyword using just the ID. If you will be using this method, it is highly recommended that you request
        ``keywords`` as part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to associate a keyword that is already associated. If
        you have the list, the addition of a keyword that is already associated will simply be ignored.

        :param int keyword_id: ID of the keyword to be added

        :return: None
        """
        self.add_keywords_by_ids([keyword_id])

    def add_keywords_by_ids(self, keyword_ids):
        """
        Adds multiple keywords by ID. If you will be using this method, it is highly recommended that you request
        ``keywords`` as part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to associate a keyword that is already associated. If
        you have the list, the addition of a keyword that is already associated will simply be ignored.

        :param iter[int] keyword_ids: keyword IDs to associate

        :return: None
        """
        self.add_keywords((Keyword({'id': keyword_id}) for keyword_id in keyword_ids))

    def remove_keywords(self, keywords):
        """
        Removes Keywords. If you will be using this method, it is highly recommended that you request ``keywords`` as
        part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to remove a keyword that is not associated. If
        you have the list, the removal of a keyword that is not associated will simply be ignored.

        :param iter[~radarclient.model.Keyword] keywords: iterable of Keywords to add

        :return: None
        """
        for keyword in keywords:
            if keyword in self._keywords_set:
                self._keywords_set.remove(keyword)
                self.keywords.remove(keyword)
                self._add_change_record(RadarTestUpdateChangeRecord(
                    self, property_name=self.PROPERTY_NAME_FOR_KEYWORDS,
                    update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_KEYWORD,
                    action=RadarTestUpdateChangeRecord.ACTION_TYPE_REMOVE,
                    new_value=[keyword]
                ))
            else:
                logger.info('{} was not in keyword list, will not add change record'.format(keyword))

    def remove_keyword(self, keyword):
        """
        Removes a keyword. If you will be using this method, it is highly recommended that you request ``keywords`` as
        part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to remove a keyword that is not associated. If
        you have the list, the removal of a keyword that is not associated will simply be ignored.

        :param ~radarclient.model.Keyword keyword: Keyword to remove

        :returns: None

        Example::

            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel
            keyword = radar_client.keywords_for_ids([52846])[0]
            tstt_object.remove_keyword(keyword)
            tstt_object.commit_changes(radar_client)
        """
        self.remove_keywords([keyword])

    def remove_keywords_by_ids(self, keyword_ids):
        """
        Remove multiple keywords by ID. If you will be using this method, it is highly recommended that you request
        ``keywords`` as part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to remove a keyword that is not associated. If
        you have the list, the removal of a keyword that is not associated will simply be ignored.

        :param iter[int] keyword_ids: iterable of keyword IDs to remove

        :returns: None
        """
        self.remove_keywords((Keyword({'id': keyword_id}) for keyword_id in keyword_ids))

    def remove_keyword_by_id(self, keyword_id):
        """
        Remove a keyword by ID. If you will be using this method, it is highly recommended that you request
        ``keywords`` as part of ``additional_fields``. If you don't have the list of already associated keywords,
        you will receive an error from the server when trying to remove a keyword that is not associated. If
        you have the list, the removal of a keyword that is not associated will simply be ignored.

        :param int keyword_id: ID of keyword to remove

        :returns: None
        """
        self.remove_keywords_by_ids([keyword_id])

    def relate_radar_id(self, radar_id,
                        relation_type=TSTTRelatedProblem.TYPE_RELATED_TO):
        """
        Adds a relationship of ``relation_type`` for radar with ID ``radar_id`` to the object

        :param int radar_id: ID of radar to relate
        :param str relation_type: Type of relationship. Defaults to
            :py:const:`TSTTRelatedProblem.TYPE_RELATED_TO`. Can also be
            :py:const:`TSTTRelatedProblem.TYPE_BLOCKED_BY`

        :return: None

        Example::

            # tstt_object can by either a TestCase or ScheduledTestCase

            # Set radar 12345 as related to tstt_object
            tstt_object.relate_radar_id(12345)
            # Set tstt_object as blocked by radar 1
            tstt_object.relate_radar_id(1, TSTTRelatedProblem.TYPE_BLOCKED_BY)
            tstt_object.commit_changes(radar_client)

        """
        new_relationship = TSTTRelatedProblem(
            data={'id': radar_id, 'relationType': relation_type},
            tstt_object=self
        )

        if new_relationship not in self._related_problems_set:
            self._related_problems_set.add(new_relationship)
            self.relatedProblems.append(new_relationship)
            self._add_change_record(
                RadarTestUpdateChangeRecord(
                    self,
                    self.PROPERTY_NAME_FOR_RELATED_PROBLEMS,
                    update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_RELATED_PROBLEM,
                    action=RadarTestUpdateChangeRecord.ACTION_TYPE_INSERT,
                    new_value=[new_relationship])
            )
        else:
            logger.info('Relationship {} already exists. Not adding change log'.format(new_relationship))

    def relate_radar(self, radar, relation_type=TSTTRelatedProblem.TYPE_RELATED_TO):
        """
        Adds a relationship of ``relation_type`` for the radar. If planning to work with related problems,
        `relatedProblems` should be fetched when the object is created.

        :param Radar radar: Radar to be related
        :param str relation_type: Type of relationship. Defaults to
            :py:const:`TSTTRelatedProblem.TYPE_RELATED_TO`. Can also be
            :py:const:`TSTTRelatedProblem.TYPE_BLOCKED_BY`

        :return: None

        Example::

            # tstt_object can by either a TestCase or ScheduledTestCase
            radar_one = radar_client.radar_for_id(1)
            radar_two = radar_client.radar_for_id(12345

            # Set radar 12345 as related to tstt_object
            tstt_object.relate_radar(radar_two)
            # Set tstt_object as blocked by radar 1
            tstt_object.relate_radar_id(radar_one, TSTTRelatedProblem.TYPE_BLOCKED_BY)
            tstt_object.commit_changes(radar_client)

        """
        self.relate_radar_id(radar.id, relation_type=relation_type)

    def relate_radars_by_ids(self, radar_ids,
                             relation_type=TSTTRelatedProblem.TYPE_RELATED_TO):
        """
        Convenience function for :py:func:`relate_radar` to relate multiple radars by ID at the
        same time. If planning to work with related problems, `relatedProblems` should be fetched when the object is
        created.

        :param list[int] radar_ids: list of radar IDs to relate
        :param str relation_type: Type of relationship. Defaults to
            :py:const:`TSTTRelatedProblem.TYPE_RELATED_TO`. Can also be
            :py:const:`TSTTRelatedProblem.TYPE_BLOCKED_BY`

        :return: None
        """
        for radar_id in radar_ids:
            self.relate_radar_id(radar_id, relation_type=relation_type)

    def relate_radars(self, radars, relation_type=TSTTRelatedProblem.TYPE_RELATED_TO):
        """
        Convenience function for :py:func:`relate_radar` to relate multiple radars at a time. If planning to work with
        related problems, `relatedProblems` should be fetched when the object is created.

        :param list[Radar] radars: list of Radars to relate
        :param str relation_type: Type of relationship. Defaults to
            :py:const:`TSTTRelatedProblem.TYPE_RELATED_TO`. Can also be
            :py:const:`TSTTRelatedProblem.TYPE_BLOCKED_BY`

        :return: None
        """
        for radar in radars:
            self.relate_radar_id(radar.id, relation_type=relation_type)

    def remove_radar_relationships(self, relationship_list):
        """
        Removes multiple radar relationships from a TSTT object. If planning to work with related problems,
        `relatedProblems` should be fetched when the object is created.

        :param iter[~radarclient.model.TSTTRelatedProblem] relationship_list: list of relationships to be removed

        :return: None
        """
        for relationship in relationship_list:
            if relationship in self._related_problems_set:
                self._add_change_record(
                    RadarTestUpdateChangeRecord(
                        self,
                        self.PROPERTY_NAME_FOR_RELATED_PROBLEMS,
                        update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_RELATED_PROBLEM,
                        action=RadarTestUpdateChangeRecord.ACTION_TYPE_REMOVE,
                        new_value=[relationship])
                )
                self._related_problems_set.remove(relationship)
                self.relatedProblems.remove(relationship)

    def remove_radar_relationship(self, relationship):
        """
        Removes one radar relationship to the TSTT object. If planning to work with related problems,
        `relatedProblems` should be fetched when the object is created.

        :param ~radarclient.model.TSTTRelatedProblem relationship: relationship to remove

        :return: None

        Example::
            # tstt_object is any of the classes that inherit from DictionaryBasedTSTTModel that has relatedProblems
            # loaded
            tstt_object.remove_radar_relationship(tstt_object.relatedProblems[0])
            tstt_object.commit_changes(radar_client)

        """
        self.remove_radar_relationships([relationship])

    def remove_related_radar_by_id(self, radar_id, relation_type=TSTTRelatedProblem.TYPE_RELATED_TO):
        """
        Removes a related radar by radar ID. If planning to work with related problems,
        `relatedProblems` should be fetched when the object is created.

        :param int radar_id: ID of radar to be removed
        :param str relation_type: Type of relationship. Defaults to :py:const:`TSTTRelatedProblem.TYPE_RELATED_TO`.
            Can also be :py:const:`TSTTRelatedProblem.TYPE_BLOCKED_BY`

        :return: None
        """
        data = {'id': radar_id, 'relationType': relation_type}
        to_remove = TSTTRelatedProblem(data=data, tstt_object=self)
        self.remove_radar_relationship(to_remove)

    def remove_related_radar(self, radar, relation_type=TSTTRelatedProblem.TYPE_RELATED_TO):
        """
        Removes a related radar using a ~radarclient.model.Radar object. If planning to work with related problems,
        `relatedProblems` should be fetched when the object is created.

        :param ~radarclient.model.TSTTRelatedProblem radar: Radar object to remove
        :param str relation_type: Type of relationship. Defaults to :py:const:`TSTTRelatedProblem.TYPE_RELATED_TO`.
            Can also be :py:const:`TSTTRelatedProblem.TYPE_BLOCKED_BY`

        :return: None
        """
        self.remove_related_radar_by_id(radar.id, relation_type=relation_type)

    def commit_changes(self, client, dry_run=False, callback=lambda *args: None):
        """
        Commit the queued changes to the database or perform a dry run

        :param RadarClient client: client to use for making the changes
        :param bool dry_run: If True, will print out steps that will be taken without committing
        :param Callable[[int], str] callback: callback function that takes a string as an argument. Can be
            used for logging

        :return: None
        """
        for change_record_cls in self.change_records:
            change_record_cls.optimize_change_record_map(self.change_records)
        if len(self.change_records) > 0:
            callback('\nCommitting changes for {}'.format(self))
            TSTTChangeRecordCommitter.commit_change_records_for_tstt_item(self.change_records,
                                                                          client,
                                                                          dry_run=dry_run)
            callback('Committed changes for {}'.format(self))
        if not dry_run:
            self.clear_change_records()

    def __setattr__(self, key, value):
        if hasattr(self, 'dictionary_representation_data') and \
                key in self.dictionary_representation_data.keys() and \
                not self.is_being_instantiated and \
                not key in self.NON_SIMPLE_ATTRIBUTE_UPDATE_SET:
            change_record_class = self.change_record_class_for_property(key)
            self._add_change_record(change_record_class(self, key, new_value=value))
        super(DictionaryBasedTSTTModel, self).__setattr__(key, value)


class OtherRelatedItemSystem(DictionaryBasedModel):
    """
    Represents a system for ``OtherRelatedItem`` entries.

    OtherRelatedItemSystem objects have the following properties:

    - name
    - isGlobal
    - urlScheme

    Example::

        for system in radar_client.other_related_item_systems():
            print(system.name)

    """
    DEFAULT_PROPERTIES = [
        'name',
        'isGlobal',
        'urlScheme'
    ]

    @cached_class_property
    def property_names(cls):
        return super(OtherRelatedItemSystem, OtherRelatedItemSystem).property_names + \
               OtherRelatedItemSystem.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<OtherRelatedItemSystem "{}", url = {}, global = {}>'.format(self.name, self.urlScheme, self.isGlobal)


class TSTTSuite(DictionaryBasedTSTTModel):
    """
    Class to represent TestSuite and ScheduledTest objects

    :meta private:
    """
    DEFAULT_PROPERTIES = []

    @cached_class_property
    def property_names(cls):
        return super(TSTTSuite, TSTTSuite).property_names + TSTTSuite.DEFAULT_PROPERTIES

    def load_associated_case_attachments(self, client):
        """
        Loads attachment info for all cases in ``self.cases``

        :param RadarClient client: Instance of radarclient to use

        :return: None
        """
        for case in self.cases:
            case.load_attachments(client)

    def load_associated_case_pictures(self, client):
        """
        Loads picture info for all cases in ``self.cases``

        :param RadarClient client: instance of radarclient to use

        :return: None
        """
        for case in self.cases:
            case.load_pictures(client)

    def load_associated_case_attachments_and_pictures(self, client):
        """
        Load all attachment and picture info for associated test cases

        :param RadarClient client: instance of client to use

        :return: None
        """
        for case in self.cases:
            case.load_attachments_and_pictures(client)

    def extend_fields_for_all_cases(self, client, additional_fields=None, fields=None):
        """
        Helper function that will add fields to all cases in ``cases`` using :py:meth:`extend_known_fields`

        :param RadarClient client: a RadarClient to use to fetch the data
        :param iter[str] additional_fields: A list of fields to grab along with the defaults that would be returned
            if you were just requesting the item on its own
        :param iter[str] fields: A list of exclusive fields to get. It will not fetch anything other than what is
            passed in here

        .. note::
          This clears any change records, so it should only be called right after instantiation.

        :return: None
        """
        if additional_fields is not None:
            is_getting_related_problems = 'relatedProblems' in additional_fields
            is_getting_keywords = 'keywords' in additional_fields
        elif fields is not None:
            is_getting_related_problems = 'relatedProblems' in fields
            is_getting_keywords = 'keywords' in fields
        else:
            is_getting_related_problems = False
            is_getting_keywords = False

        case_ids = [case.database_id_attribute_value() for case in self.cases]
        if isinstance(self, TestSuite):
            case_list = client.test_suite_cases_for_ids(case_ids, additional_fields=additional_fields, fields=fields)
        else:
            case_list = client.scheduled_test_cases_for_ids(case_ids, additional_fields=additional_fields, fields=fields)

        self.merge_lists(self.cases, case_list, id_attr=case_list[0].identifier_attrs[0])

        # Work around set update issues as discussed https://a1391192.slack.com/archives/CJS717APK/p1739831151767979
        if is_getting_related_problems or is_getting_keywords:
            for case in self.cases:
                if is_getting_related_problems:
                    case._related_problems_set = set()
                    # Need to set the tstt object correctly for the relationship or it cannot be hashed
                    for relationship in case.relatedProblems:
                        relationship.tstt_object = self
                        case._related_problems_set.add(relationship)
                if is_getting_keywords:
                    case._keyword_set = set(case.keywords)

        # Clear change records from everything as noted in docstring
        self.clear_change_records()
        for case in self.cases:
            case.clear_change_records()


class OtherRelatedItem(DictionaryBasedModel):
    """
    An entry of the "other related item" list as returned by :py:attr:`radar.other_related_items.items() <Radar.other_related_items>`.

    OtherRelatedItem objects have the following properties:

    - id
    - system
    - title
    - url

    Example::

        # Read
        radar = self.client.radar_for_id(1234)
        for item in radar.other_related_items.items():
            print('Related item: system = {}, id = {}, title = {}'.format(item.system, item.id, item.title))

        # Add
        new_item = radarclient.OtherRelatedItem({'id': '5678', 'system': 'Espresso', 'title': 'foo bar baz'})
        radar.other_related_items.add(new_item)
        radar.commit_changes()

        # Remove
        goner = radarclient.OtherRelatedItem({'id': '1234', 'system': 'Foo Bar'})
        radar.other_related_items.delete(goner)
        radar.commit_changes()

    """
    DEFAULT_PROPERTIES = [
        'id',
        'system',
        'title',
        'url'
    ]

    def parse_data(self):
        super(OtherRelatedItem, self).parse_data()
        if isinstance(self.id, int):
            self.id = str(self.id)

    @cached_class_property
    def property_names(cls):
        return super(OtherRelatedItem, OtherRelatedItem).property_names + \
               OtherRelatedItem.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<OtherRelatedItem "{}", system = {}, title = {}>'.format(self.id, self.system, self.title)

    @classmethod
    def webservice_url_for_radar(cls, radar, **kwargs):
        return radar.webservice_url('other-related-items')

    def delete_webservice_url_for_radar(self, radar, **kwargs):
        return radar.webservice_url('other-related-items', self.system, self.id)

    @classmethod
    def change_record_class_for_add(cls):
        return AddOtherRelatedItemEntryRadarChangeRecord

    @classmethod
    def change_record_class_for_delete(cls):
        return DeleteOtherRelatedItemEntryRadarChangeRecord


class Query(DictionaryBasedModel):
    """
    Represents a saved Query for retrieving Radars, Test Suites, or Test Cases.

    A Query object can be obtained from :py:meth:`~radarclient.client.RadarClient.query_for_id`,
    :py:meth:`~radarclient.client.RadarClient.create_query`, :py:meth:`~radarclient.client.RadarClient.find_queries`,
    or :py:meth:`~radarclient.client.RadarClient.subscribed_queries`.

    More information available in the `Query API Docs`_.

    Query objects have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - type, :py:class:`str`
    - description, :py:class:`str`
    - isActive, :py:class:`bool`
    - isPublic, :py:class:`bool`
    - createdBy, :py:class:`Person`
    - createdAt, :py:class:`datetime.datetime`
    - lastModifiedBy, :py:class:`Person`
    - lastModifiedAt, :py:class:`datetime.datetime`
    - subscribers, :py:class:`list`
    - searchAttributes, :py:class:`dict`

    Example::

        report = radar_client.query_for_id(123)
        print('{} {}'.format(report.id, report.name))

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'createdAt',
        'createdBy',
        'description',
        'id',
        'isActive',
        'isFavorite',
        'isPublic',
        'lastModifiedAt',
        'lastModifiedBy',
        'name',
        'searchAttributes',
        'subscribers',
        'type',
    ]
    BASE_URL = 'query'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    READ_ONLY_PERMISSION = 'Read Only'
    READ_AND_WRITE_PERMISSION = 'Read & Write'
    OWNER_PERMISSION = 'Owner (Read & Write)'

    def __init__(self, dictionary_representation=None, *extra_constructor_args):
        super(Query, self).__init__(
            dictionary_representation=dictionary_representation, *extra_constructor_args
        )
        if not hasattr(self, 'subscribers'):
            self.subscribers = None

    @cached_class_property
    def property_names(cls):
        return super(Query, Query).property_names + Query.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<Query {} {}>'.format(self.id, self.name)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Query, cls).property_value_converter_map)
        map.update({
            'subscribers': QuerySubscriberListValueConverter,
            'createdBy': PersonValueConverter,
            'owner': PersonValueConverter,
            'lastModifiedBy': PersonValueConverter,
        })
        return map


class QuerySubscriber(DictionaryBasedModel):
    """
    Represents a Person or Group subscribed to a Query.

    QuerySubscriber objects have the following properties:

    - ``subscriber``, :py:class:`Person`, :py:class:`WorkGroup`, or :py:class:`AccessGroup`
    - ``type``, :py:class:`str`
    - ``permission``, :py:class:`str`
    """
    DEFAULT_PROPERTIES = [
        'subscriber',
        'type',
        'permission'
    ]

    def __init__(self, dictionary_representation=None, *extra_constructor_args):
        super(QuerySubscriber, self).__init__(
            dictionary_representation=dictionary_representation, *extra_constructor_args
        )

    @cached_class_property
    def property_names(cls):
        return super(QuerySubscriber, QuerySubscriber).property_names + Query.DEFAULT_PROPERTIES

    def __repr__(self):
        return u'<QuerySubscriber {} ("{}")>'.format(self.subscriber, self.permission)


class QuerySubscriberEveryone(DictionaryBasedModel):
    """
    Represents the 'type': 'Everyone' entry of the 'subscribers' property of a Query.

    This is auto-populated.

    :meta private:
    """
    DEFAULT_PROPERTIES = [
        'type',
        'permission'
    ]

    def __init__(self, dictionary_representation=None, *extra_constructor_args):
        super(QuerySubscriberEveryone, self).__init__(
            dictionary_representation=dictionary_representation, *extra_constructor_args
        )
        self.type = 'Everyone'

    def __repr__(self):
        return u'<Everyone "{}">'.format(self.permission)


class CommentAuthor(DictionaryBasedModel):
    """
    Represents a person known just by email and name, used in ``DiagnosisEntry`` and
    ``DescriptionEntry``. It's like a :py:class:`Person`, but with less information.

    CommentAuthor objects have the following properties:

    - email, :py:class:`str`
    - name, :py:class:`str`

    Example::

        radar = radar_client.radar_for_id(1234)
        diagnosis_items = radar.diagnosis.items()
        first_comment_author = diagnosis_items[0].addedBy
        print('{} {}'.format(first_comment_author.name, first_comment_author.email))

    """
    identifier_attrs = ('email',)
    DEFAULT_PROPERTIES = [
        'email',
        'name'
    ]

    @cached_class_property
    def property_names(cls):
        return super(CommentAuthor, CommentAuthor).property_names + \
               CommentAuthor.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<CommentAuthor {} {}>'.format(self.email, self.name)


class Person(DictionaryBasedModel):
    """
    Represents a Radar user account.

    Person objects can be loaded in several ways:

    1. As a property of another object, such as ``radar.assignee`` or ``keyword_association.addedBy``.
    2. From direct-retrieval methods such as :py:meth:`~radarclient.client.RadarClient.person_for_dsid`, \
    :py:meth:`~radarclient.client.RadarClient.find_people`, :py:meth:`~radarclient.client.RadarClient.current_user`, \
    :py:meth:`~radarclient.client.AppleDirectoryQuery.manager_dsids_for_dsids`, etc.

    Person objects always have the following properties:

    - dsid, :py:class:`int`
    - email, :py:class:`str`
    - firstName, :py:class:`str`
    - lastName, :py:class:`str`

    Person objects can also have several of the following properties, depending on the API:

    - chat, :py:class:`PersonChat` containing a :py:class:`PersonChatSlack` object
    - company, :py:class:`str`
    - department, :py:class:`str`
    - isActive, :py:class:`bool`
    - phone, :py:class:`str`
    - type, :py:class:`str`
    - isSystemAccount, :py:class:`bool`

    .. note::
        The ``type`` property can vary depending on the Radar API used. The `Person Documentation`_ lists the
        available values as ``External``, ``Contractor``, ``Employee``, and ``No Access``, but there are also ``Internal``,
        ``internal``, and ``external``. For example, ``radar.assignee`` will list ``type`` as ``Employee`` but the result of
        :py:meth:`~radarclient.client.RadarClient.person_for_dsid` for the same user will list ``type`` as ``Internal``.

    Example::

        radar = radar_client.radar_for_id(1234)
        current_assignee = radar.assignee
        print('{} {}'.format(current_assignee.firstName, current_assignee.lastName))

    """
    identifier_attrs = ('dsid',)
    DEFAULT_PROPERTIES = [
        'dsid',
        'email',
        'firstName',
        'lastName',
        'type'
    ]
    BASE_URL = 'people'
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    PROPERTY_KEYNAME_MAP = {'phone': 'phoneNumber'}

    @cached_class_property
    def property_names(cls):
        return super(Person, Person).property_names + Person.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Person, cls).property_value_converter_map)
        map.update({
            'chat': PersonChatValueConverter,
        })
        return map

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Person, Person).keyname_map)
        map.update(Person.PROPERTY_KEYNAME_MAP)
        return map

    def mention(self):
        """
        Used to generate the markdown string that triggers an @ Mention of said Person for use in a
        :py:class:`DiagnosisEntry`.

        For more information and example code, see :py:class:`DiagnosisEntry` and :py:class:`Mention`.
        """
        return '[{dsid}](adir://employees/{dsid})'.format(dsid=self.dsid)

    def __unicode__(self):
        return u'<Person {} {} {}>'.format(self.dsid, self.firstName, self.lastName)


class PersonChat(DictionaryBasedModel):
    """
    Represents the `optional` ``chat`` property of a :py:class:`Person`.

    A PersonChat object has the following property:

    - slack, :py:class:`PersonChatSlack`
    """
    DEFAULT_PROPERTIES = ['slack']

    @cached_class_property
    def property_names(cls):
        return super(PersonChat, PersonChat).property_names + PersonChat.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(PersonChat, cls).property_value_converter_map)
        map.update({
            'slack': PersonChatSlackValueConverter,
        })
        return map

    def __unicode__(self):
        return u'<PersonChat with Slack teamId {} and userId {}>'.format(
            self.slack.teamId,
            self.slack.userId
        )


class PersonChatSlack(DictionaryBasedModel):
    """
    Represents the ``slack`` property of a :py:class:`Person` object's ``chat`` property. It references the team
    and user information for a user's Slack account.

    A PersonChatSlack object has the following property:

    - teamId, :py:class:`str`
    - userId, :py:class:`str`
    """
    DEFAULT_PROPERTIES = ['teamId', 'userId']

    @cached_class_property
    def property_names(cls):
        return super(PersonChatSlack, PersonChatSlack).property_names + PersonChatSlack.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<PersonChatSlack with Slack teamId {} and userId {}>'.format(
            self.teamId,
            self.userId
        )


class WorkGroupRoles(DictionaryBasedModel):
    DEFAULT_PROPERTIES = [
        'builder',
        'integrator',
        'owner',
        'screener',
        'verifier'
    ]

    @cached_class_property
    def property_names(cls):
        return super(WorkGroupRoles, WorkGroupRoles).property_names + WorkGroupRoles.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        conversion_map = dict(super(WorkGroupRoles, cls).property_value_converter_map)
        conversion_map.update({
            'builder': PersonValueConverter,
            'integrator': PersonValueConverter,
            'owner': PersonValueConverter,
            'screener': PersonValueConverter,
            'verifier': PersonValueConverter
        })
        return conversion_map

    def __unicode__(self):
        return u'<WorkGroupRoles{}>'.format(
            ' '+', '.join('{}: {}'.format(role, getattr(self, role, '')) for role in self.DEFAULT_PROPERTIES if hasattr(self, role))
        )


class WorkGroupRole(WorkGroupRoles):
    pass


class RadarGroupMember(DictionaryBasedModel):
    DEFAULT_PROPERTIES = [
        'department',
        'lastModifiedAt',
        'lastModifiedBy',
        'person',
        'privilege'
    ]

    @cached_class_property
    def property_names(cls):
        return super(RadarGroupMember, RadarGroupMember).property_names + RadarGroupMember.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        conversion_map = dict(super(RadarGroupMember, cls).property_value_converter_map)
        # While lastModifiedBy is supposed to return a Person, it does not, <rdar://problem/69193203>
        conversion_map.update({
            'lastModifiedAt': ISO8601UTCDateValueConverter,
            'person': PersonValueConverter
        })
        return conversion_map

    def __unicode__(self):
        dept = getattr(self, 'department', "(unknown)")
        return u'<{} from department "{}">'.format(self.person, dept)


class RadarGroup(DictionaryBasedModel):
    """
    Main implementation of :py:class:`WorkGroup` and :py:class:`AccessGroup`. Should not be instantiated
    directly.

    :meta private:
    """
    identifier_attrs = (
        'id',
        'name',
    )
    DEFAULT_PROPERTIES = [
        'id',
        'description',
        'name',
        'roles'
    ]
    BASE_URL = 'groups'
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')

    @cached_class_property
    def property_names(cls):
        return super(RadarGroup, RadarGroup).property_names + RadarGroup.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        conversion_map = dict(super(RadarGroup, cls).property_value_converter_map)
        conversion_map.update({
            'roles': RadarGroupRoleValueConverter,
            'administrators': RadarGroupMemberListValueConverter,
            'members': RadarGroupMemberListValueConverter,
            'components': ComponentListValueConverter
        })
        return conversion_map

    def __unicode__(self):
        _id = ' {}'.format(getattr(self, 'id')) if hasattr(self, 'id') else ''
        return u'<{}{} "{}">'.format(self.__class__.__name__, _id, self.name)


class WorkGroup(RadarGroup):
    """
    Represents a work group.

    WorkGroup objects typically have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - description, :py:class:`str`
    - roles, a :py:class:`dict` representing the default :py:class:`~radarclient.model.Person` defined for each of the \
    ``owner``, ``screener``, ``integrator``, ``builder``, and ``verifier`` roles.

    """
    DEFAULT_PROPERTIES = []
    BASE_URL = 'groups/work-groups'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (BASE_URL,)

    def __init__(self, dictionary_representation):
        super(WorkGroup, self).__init__(dictionary_representation=dictionary_representation)

    @cached_class_property
    def property_names(cls):
        return super(WorkGroup, WorkGroup).property_names + WorkGroup.DEFAULT_PROPERTIES

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (self.name, 'key-values')


class AccessGroup(RadarGroup):
    """
    Represents an access group.

    AccessGroup objects typically have the following properties:

    From :py:meth:`~radarclient.client.RadarClient.access_group_for_id` or :py:meth:`~radarclient.client.RadarClient.find_radar_groups`:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - description, :py:class:`str`
    - roles, a :py:class:`dict` representing the default :py:class:`~radarclient.model.Person` defined for ``owner``

    From :py:meth:`~radarclient.client.RadarClient.access_groups_for_component_id`:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - description, :py:class:`str`
    - privilegeType, :py:class:`str`
    - inheritType, :py:class:`str`

    """
    DEFAULT_PROPERTIES = []
    BASE_URL = 'groups/access-groups'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (BASE_URL,)

    def __init__(self, dictionary_representation):
        # API v2.2 embeds most of the payload in a nested dict when using GET /components/{component-id}/accessgroups
        if 'accessGroup' in dictionary_representation:
            nested_object = dictionary_representation['accessGroup']
            assert isinstance(nested_object, dict)
            dictionary_representation.update(nested_object)
            del(dictionary_representation['accessGroup'])
        super(AccessGroup, self).__init__(dictionary_representation=dictionary_representation)

    @cached_class_property
    def property_names(cls):
        return super(AccessGroup, AccessGroup).property_names + AccessGroup.DEFAULT_PROPERTIES

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (self.name, 'key-values')


class Label(DictionaryBasedModel):
    """
    Represents a label that can be assigned to a Radar.

    Label objects have the following properties:

    - id
    - name
    - order
    - color

    Example::

        labels = radar_client.labels_by_name()
        label = labels['Some Label Name']
        radar = radar_client.radar_for_id(1234, additional_fields=['label'])
        radar.label = label
        radar.commit_changes()

        # To clear a Radar's label
        radar.label = None
        radar.commit_changes()

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'order',
        'color'
    ]
    BASE_URL = 'label-sets' # Also needs 'X-Filter-Labelset' header set to 'active' per API v2.2 spec
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)

    @cached_class_property
    def property_names(cls):
        return super(Label, Label).property_names + Label.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<Label {} {}>'.format(self.id, self.name)


class LabelSet(DictionaryBasedModel):
    """
    Represents a label set

    LabelSet objects have the following properties:

    - id
    - component
    - description
    - name

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'component',
        'description',
        'name'
    ]
    BASE_URL = 'label-sets'
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    SUBSCRIBE_ENDPOINT = 'subscribe'

    def __init__(self, dictionary_representation=None):
        super(LabelSet, self).__init__(dictionary_representation=dictionary_representation)
        if not hasattr(self, 'labels'):
            self.labels = None

    @cached_class_property
    def property_names(cls):
        return super(LabelSet, LabelSet).property_names + LabelSet.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        conversion_map = dict(super(LabelSet, cls).property_value_converter_map)
        conversion_map.update({
            'labels': LabelListValueConverter
        })
        return conversion_map

    def load_labels(self, client):
        """
        Load the labels associated with a label set in to ``self.labels``. This isn't needed if LabelSet
        was created via a call to :py:meth:`~radarclient.client.RadarClient.get_active_label_set`

        :param RadarClient client: client instance to use

        :return: None
        """
        _, info = client.build_and_send_request(('label-sets', self.id))
        self.labels = [Label(item) for item in info['labels']]

    def __unicode__(self):
        return u'<LabelSet {} {}>'.format(self.id, self.name)


class ScheduledTest(TSTTSuite):
    """
    Represents a Scheduled test

    ScheduledTest objects have the following properties:

    - id
    - suiteId
    - title
    - status
    - component
    - owner
    - lastModifiedAt
    - lastModifiedBy
    - createdAt
    - createdBy
    - scheduledStartDate
    - scheduledEndDate
    - priority
    - author
    - counts

    More info is available in the `Scheduled Test API Documentation`_.

    A basic example of updating scheduled test attributes is below.
    Attachments/Pictures can be manipulated with the functions below.

    Example::

        scheduled_test = client.scheduled_test_for_id(123)
        scheduled_test.title = 'New Updated Title'
        scheduled_test.status = 'In Progress'
        scheduled_test.commit_changes(client)

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'suiteId',
        'title',
        'owner',
        'scheduledStartDate',
        'scheduledEndDate',
        'lastModifiedAt',
        'priority',
        'status',
        'lastModifiedBy',
        'author',
        'counts',
        'createdAt',
        'createdBy'
    ]
    BASE_URL = 'tests/scheduledtests'
    ENTITY_TYPE = 'scheduled-tests'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (ENTITY_TYPE,)
    EXCLUDE_FROM_FIND = {'id'}
    GET_BY_ID_METHOD = 'scheduled_test_for_id'

    FIND_ID_KEYS = ('scheduledTestId', 'applicationName')
    GET_ID_KEYS = ('id', 'appName')

    def __init__(self, data):
        super(ScheduledTest, self).__init__(data=data)

    @cached_class_property
    def property_names(cls):
        return super(ScheduledTest, ScheduledTest).property_names + \
               ScheduledTest.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ScheduledTest, cls).property_value_converter_map)
        map.update({
            'owner': PersonValueConverter,
            'tester': PersonValueConverter,
            'currentTester': PersonValueConverter,
            'scheduledEndDate': ISO8601UTCDateValueConverter,
            'scheduledStartDate': ISO8601UTCDateValueConverter,
            'cases': ScheduledTestCaseListValueConverter,
            'testCycle': TestCycleValueConverter,
            'build': BuildValueConverter,
            'dateCompleted': ISO8601UTCDateValueConverter,
            'stcStatusCount': DictionaryBasedModelValueConverter
        })
        return map

    def change_record_class_for_property(self, property):
        return RadarTestUpdateChangeRecord

    def reorder_associated_case_by_id(self, test_case_id, new_position):
        """
        Move a case to a new location in the suite using the ID

        :param int test_case_id: The ID of the test case to move
        :param int new_position: The new position of the test case. Cannot have more than 1 test case moving to the same
            spot

        :return: None
        """
        self._add_change_record(
            ReorderScheduledTestCaseChangeRecord(
                self.database_id_attribute_value(), test_case_id, new_position,
                ScheduledTestCase.REORDERING_TYPE
            )
        )

    def reorder_associated_case(self, test_case, new_position):
        """
        Move a case to a new location in the suite using the ScheduledTestCase object

        :param ScheduledTestCase test_case: the test case to move
        :param int new_position: The new position of the test case. Cannot have more than 1 test case moving to the same
            spot

        :return: None
        """
        self.reorder_associated_case_by_id(test_case.database_id_attribute_value(), new_position)

    def modify_multiple_associated_scheduled_cases(self, change_dict, test_cases):
        """
        Adds change records to each of the specified test cases to commit when changes are committed

        :param dict change_dict: dict with the keys being the attribute names and the values being the new value to set
        :param list test_cases: list of :py:class:`ScheduledTestCase` objects to make the changes to

        :return: None

        Example::

            sched_test = radar_client.scheduled_test_for_id(1, additional_fields=['cases'])
            change_dict = {'priority': 1}
            sched_test.modify_multiple_associated_scheduled_cases(change_dict, sched_test.cases[0:3])
            sched_test.commit_changes(radar_client)

        """
        for test_case in test_cases:
            for attr in change_dict:
                setattr(test_case, attr, change_dict[attr])

    def remove_keywords_by_id_from_associated_test_cases(self, keyword_ids, cases):
        """
        Removes keywords by ID from the associated test cases passed in

        :param list(int) keyword_ids: list of keyword IDs to remove
        :param list(ScheduledTestCase) cases: list of ScheduledTestCases to remove keywords from

        :return: None
        """
        update_dict = {'removeKeywords': keyword_ids}
        self.modify_multiple_associated_scheduled_cases(update_dict, cases)

    def remove_keywords_from_associated_test_cases(self, keywords, cases):
        """
        Remove a list of Keywords from the passed in cases

        :param list(~radarclient.model.Keyword) keywords: list of Keyword objects to be removed
        :param list(ScheduledTestCase) cases: list of ScheduledTestCases to remove keywords from

        :return: None
        """
        self.remove_keywords_by_id_from_associated_test_cases(
            [keyword.id for keyword in keywords], cases
        )

    def remove_keyword_by_id_from_associated_test_cases(self, keyword_id, cases):
        """
        Convenience method for removing a single keyword by ID from associated cases

        :param int keyword_id: keyword ID to be removed
        :param list(ScheduledTestCase) cases: list of ScheduledTestCases to remove keywords from

        :return: None
        """
        self.remove_keywords_by_id_from_associated_test_cases([keyword_id], cases)

    def remove_keyword_from_associated_test_cases(self, keyword, cases):
        """
        Convenience function to remove a single keyword from scheduled test cases

        :param ~radarclient.model.Keyword keyword: Keyword to be removed
        :param list(ScheduledTestCase) cases: list of ScheduledTestCases to remove keywords from

        :return: None
        """
        self.remove_keywords_by_id_from_associated_test_cases([keyword.id], cases)

    def create_and_add_scheduled_test_case(self, request_data):
        """
        Create a scheduled test case and add it to a scheduled test suite

        :param dict request_data: Dictionary of request data matching the `Add Scheduled Case Docs`_

        :return: None

        Example::

            scheduled_test = client.scheduled_test_for_id(12345)
            request_dict = {
                'title': 'Added Test Case',
                'priority': 2
            }

            scheduled_test.create_and_add_scheduled_test_case(request_dict)
            scheduled_test.commit_changes(client)

        """
        self._add_change_record(CreateAndAddScheduledTestCase(compat.unicode_string_type(self), request_data, self.id))

    def commit_changes(self, client, dry_run=False, callback=lambda *args: None):
        cases = getattr(self, 'cases', [])

        for case in cases:
            case.commit_changes(client, dry_run=dry_run, callback=callback)
        super(ScheduledTest, self).commit_changes(client, dry_run=dry_run, callback=callback)

    def __unicode__(self):
        return u'<ScheduledTest id={} title={}>'.format(
            self.id, self.title
        )

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (self.id, 'key-values')


class ScheduledTestCase(DictionaryBasedTSTTModel):
    """
    Represents a scheduled test case

    Example::

        scheduled_test_id = 6429552
        st = client.scheduled_test_for_id(scheduled_test_id, additional_fields=['cases'])
        for case in st.cases:
            print('case {} tested by {}'.format(case.database_id_attribute_value(), case.tester))

        # Update a scheduled test cases attributes
        st.cases[0].title = 'New Updated Title'
        st.cases[0].commit_changes(client)

        # You could also run st.commit_changes(client) and it would include any changes to cases

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'order',
        'component',
        'createdAt',
        'lastModifiedAt',
        'priority',
        'counts',
        'reviewInTestSuite',
        'scheduledTestId',
        'status',
        'suiteId',
        'suiteTitle',
        'title',
        'createdBy',
        'lastModifiedBy',
        'tester',
        'expectedTimeInSeconds',
        'actualTimeInSeconds'
    ]
    EXCLUDE_FROM_FIND = {'scheduledTestTitle', 'caseId', 'expectedTimeInSeconds', 'actualTimeInSeconds',
                         'instructions', 'expectedResult', 'description', 'counts', 'relatedProblems', 'keywords',
                         'protectionMaskList', 'attachments', 'pictures', 'actualResults', 'history',
                         'relatedScheduledResources', 'suiteTitle', 'id'}
    BASE_URL = 'tests/scheduledcases'
    ENTITY_TYPE = 'scheduled-test-cases'
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (ScheduledTest.ENTITY_TYPE,)
    REORDERING_TYPE = 'SCHEDULED_TEST_CASE'
    GET_BY_ID_METHOD = 'scheduled_test_case_for_id'

    # These are kind of weird but it needs to be defined this way as of right now due to
    # rdar://116066084 (Finding Scheduled Test Case and Getting by ID Return Differently Named Attributes for ID)
    FIND_ID_KEYS = ('scheduledCaseId', 'scheduledTestCaseId')
    GET_ID_KEYS = ('id', 'id')

    def __init__(self, dictionary_representation=None):
        super(ScheduledTestCase, self).__init__(dictionary_representation)
        self.parent_case_keywords = None

    @cached_class_property
    def property_names(cls):
        return super(ScheduledTestCase, ScheduledTestCase).property_names + \
               ScheduledTestCase.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<ScheduledTestCase id={} title={}>'.format(self.id, self.title)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ScheduledTestCase, cls).property_value_converter_map)
        map.update({
            'tester': PersonValueConverter,
            'build': BuildValueConverter,
            'scheduledStartDate': ISO8601UTCDateValueConverter
        })
        return map

    def change_record_class_for_property(self, property):
        return RadarTestUpdateChangeRecord

    @deprecated(replacement=DictionaryBasedTSTTModel.remove_radar_relationship, version=12)
    def delete_relationship(self, relationship):
        """
        Deletes a radar relationship for a ScheduledTestCase

        :param TSTTRelatedProblem relationship: relation to be deleted

        :return: None

        Example::

            scheduled_test = radar_client.scheduled_test_for_id(123, additional_fields=['cases'])
            case = scheduled_test.cases[0]
            case.delete_relationship(case.relatedProblems[0])
            case.commit_changes(radar_client)

        """
        # noinspection PyTypeChecker,PyTypeChecker
        self._add_change_record(
            DeleteScheduledTestCaseRelatedProblemChangeRecord(
                self.scheduledTestID, relationship, self
            )
        )

    def load_parent_case_keywords(self, client):
        """
        Sets ``self.parent_case_keywords`` equal to the keywords on the TestCase this
        ScheduledTestCase came from

        :param RadarClient client: instance of client to use for the request

        :return: None
        """
        parent_case = client.test_suite_case_for_id(
            self.caseId, additional_fields=['keywords']
        )
        self.parent_case_keywords = parent_case.keywords

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (self.scheduledTestId, 'cases', self.id, 'key-values')


class ScheduledTestCaseRelatedProblem(DictionaryBasedModel):
    """
    .. deprecated:: 3.98
            Replaced with :py:class:`TSTTRelatedProblem`

    Represents a problem related to a scheduled test case.
    """
    DEFAULT_PROPERTIES = [
        'component',
        'id',
        'relationType',
        'state',
        'title'
    ]

    def __init__(self, data=None):
        warnings.warn('{} has been deprecated and replaced with the more general '
                      'TSTTRelatedProblem. It will be removed in a future release')
        super(ScheduledTestCaseRelatedProblem, self).__init__(dictionary_representation=data)

    @cached_class_property
    def property_names(cls):
        return super(ScheduledTestCaseRelatedProblem,
                     ScheduledTestCaseRelatedProblem).property_names + \
               ScheduledTestCaseRelatedProblem.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<ScheduledTestCaseRelatedProblem radar_id={} relationType={}>'.format(self.id, self.relationType)


class ScheduledTestData(DictionaryBasedModel):
    """
    .. deprecated:: 3.96
            Use :py:class:`ScheduledTest` instead

    ScheduledTestData objects have the following properties (of type unicode unless noted otherwise):

    - scheduledID
    - component (:py:class:`dict`)
    - owner (:py:class:`Person`)
    - title
    - status
    - priority
    - scheduledStartDate (:py:class:`datetime.datetime`)
    - scheduledEndDate (:py:class:`datetime.datetime`)
    - geography
    - lastModifiedAt (:py:class:`datetime.datetime`)
    - keywords (list of :py:class:`~radarclient.model.Keyword`)

    See the Radar web API documentation for a list of additional optional fields you can request
    with the ``additional_fields`` parameter to :py:meth:`~radarclient.client.RadarClient.scheduled_test_data_for_test_id`.

    """
    identifier_attrs = ('scheduledID',)
    DEFAULT_PROPERTIES = [
        'scheduledID',
        'status',
        'priority',
        'component',
        'owner',
        'title',
        'scheduledStartDate',
        'scheduledEndDate',
        'geography',
        'lastModifiedAt',
        'keywords'
    ]

    def __init__(self, dictionary_representation=None, *extra_constructor_args):
        warnings.warn('ScheduledTestData is deprecated and will be removed in a future release. '
                      'Please use ScheduledTest instead.')
        super(ScheduledTestData, self).__init__(
            dictionary_representation=dictionary_representation, *extra_constructor_args)

    @cached_class_property
    def property_names(cls):
        # optional_properties = 'cases suiteID status priority author currentTester testCycle testConfiguration masterData datesTrackToMilestone datesTrackToBuild build buildID complexity prerequisites testRestartInstructions blockedCaseCount failCaseCount naCaseCount noValueCaseCount passCaseCount totalCompletedCases totalCaseCount statusID statusIndex relatedProblems'.split()
        return super(ScheduledTestData, ScheduledTestData).property_names + \
               ScheduledTestData.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<ScheduledTestData {} status {}>'.format(self.scheduledID, self.status)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ScheduledTestData, cls).property_value_converter_map)
        map.update({
            'cases': TestCaseListValueConverter,
            'owner': PersonValueConverter,
            'author': PersonValueConverter,
            'currentTester': PersonValueConverter,
            'lastModifiedAt': ISO8601UTCDateValueConverter,
            'scheduledEndDate': ISO8601UTCDateValueConverter,
            'scheduledStartDate': ISO8601UTCDateValueConverter,
            'keywords': KeywordListValueConverter
        })
        return map


class TestCase(DictionaryBasedTSTTModel):
    """
    Represents a test case. Object can be used to queue changes similar to :py:class:`Radar` before
    committing the changes to the database

    TestCase objects have the following properties:

    - caseId
    - priority
    - expectedTimeInSeconds
    - expectedResults
    - instructions
    - data
    - description
    - title
    - keywords

    Example::

        # Find test case with ID 12345 and update the title, expectedTimeInSeconds, expectedResult, and add a
        # keyword
        test_case = radar_client.test_suite_case_for_id(12345)
        test_case.title = 'A New Title! A Better Title!'
        test_case.expectedTimeInSeconds = 600
        test_case.expectedResult = 'New and improved expected results'
        test_case.keyword = [radar_client.Keyword({'id': 196144, 'name': 'radarclient-python test'})]

        test_case.commit_changes(radar_client)

    """
    identifier_attrs = ('caseId',)
    DEFAULT_PROPERTIES = [
        'author',
        'counts',
        'caseId',
        'component',
        'createdAt',
        'lastModifiedAt',
        'createdBy',
        'lastModifiedBy',
        'priority',
        'title'
    ]
    EXCLUDE_FROM_FIND = {'expectedTimeInSeconds', 'data', 'instructions', 'description', 'expectedResults', 'counts',
                         'expectedResult', 'description', 'associatedSuites', 'keywords', 'relatedProblems',
                         'securityList', 'scheduledTests', 'attachments', 'pictures', 'relatedResources', 'security',
                         'protectionMaskList', 'history'}
    BASE_URL = 'tests/cases'
    ENTITY_TYPE = 'test-suites-cases'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    REORDERING_TYPE = 'TEST_CASE'
    GET_BY_ID_METHOD = 'test_suite_case_for_id'

    # Workaround <rdar://problem/66405284> Test Suite Case Endpoints Use Both
    # expectedResults and expectedResult
    REPLACEMENT_KEYS = {
        'expectedResults': 'expectedResult',
        'keyword': 'keywords'
    }
    REVERSED_REPLACEMENT_KEYS = {v: k for k, v in REPLACEMENT_KEYS.items()}

    CREATE_AND_ADD_VALID_FIELDS = {
        'data', 'expectedResult', 'expectedTimeInSeconds', 'instructions', 'description', 'componentId', 'authorId',
        'associatedSuite', 'priority', 'title', 'description'
    }

    @cached_class_property
    def property_names(cls):
        return super(TestCase, TestCase).property_names + TestCase.DEFAULT_PROPERTIES

    @staticmethod
    def _simple_integer_field_validator(key, value, can_be_none, min=None, max=None):
        """
        Validates an integer field in a test case creation dict meets requirements.

        :param str key: attribute key to be checked
        :param int value: value of the key
        :param bool can_be_none: if True, allows a None value, otherwise, does not allow
        :param int min: minimum expected value. No check performed if None
        :param int max: maximum expected value. No check performed if None

        :return: str|None None if valid or a string explaining why it is not valid
        """
        to_return = None
        if value is None:
            if not can_be_none:
                to_return = '{} is required to be something other than None'.format(key)
        elif type(value) is not int:
            to_return = '{} must be an int'.format(key)
        elif min is not None and value < min:
            to_return = '{} must be greater than or equal to {}'.format(key, min)
        elif max is not None and value > max:
            to_return = '{} must be less than or equal to {}'.format(key, max)

        return to_return

    @staticmethod
    def _simple_str_field_validator(key, value, can_be_none, max_length=None):
        """
        Validates a string field of in a test case creation dictionary

        :param str key: attribute name
        :param str value: value to be checked
        :param bool can_be_none: if True, allowed to be None, otherwise fails if None
        :param int max_length: Maximum permissable length for string

        :return: str|None None if valid or a string explaining why it is not valid
        """
        to_return = None
        if value is None:
            if not can_be_none:
                to_return = '{} is required to be something other than None'.format(key)
        elif type(value) is not compat.unicode_string_type:
            to_return = '{} must be a unicode string, not type {}'.format(key, type(value).__name__)
        elif max_length is not None and len(value) > max_length:
            to_return = '{} must be less than {} characters'.format(key, max_length)
        return to_return

    @staticmethod
    def validate_test_case_creation_dict(dict_to_add):
        """
        Validates a dictionary that will be used for test case creation meets minimum requirements

        :param dict dict_to_add: Dictionary to be used

        :return: list Returns an empty list if there are no issues, otherwise returns a list
            explaining what issues were found
        """
        required_fields = {'title', 'componentId'}
        key_set = set(dict_to_add.keys())
        missing_required = required_fields - key_set
        unexpected_keys = key_set - TestCase.CREATE_AND_ADD_VALID_FIELDS
        issues = []

        if len(missing_required) > 0:
            issues.append('Passed in dict is missing required values {}'.format(missing_required))
        if len(unexpected_keys) > 0:
            issues.append('Passed in dict has extra invalid keys, {}'.format(unexpected_keys))
        for field in sorted(key_set):
            value = dict_to_add.get(field)
            validation = None
            if field == 'data':
                validation = TestCase._simple_str_field_validator(
                    field, value, field not in required_fields, max_length=1000000)
            elif field == 'expectedResult':
                validation = TestCase._simple_str_field_validator(
                    field, value, field not in required_fields, max_length=4000)
            elif field == 'priority':
                validation = TestCase._simple_integer_field_validator(
                    field, value, field not in required_fields, min=1, max=6)
            elif field == 'summary':
                validation = TestCase._simple_str_field_validator(
                    field, value, field not in required_fields, max_length=4000)
            elif field == 'title':
                validation = TestCase._simple_str_field_validator(
                    field, value, field not in required_fields, max_length=240)

            if validation is not None:
                issues.append(validation)

        return issues

    @deprecated_and_removed(None, 12.0)
    def fix_up_self(self):
        """
        This works around two issues. The first is <rdar://problem/66405284> Test Suite Case
        Endpoints Use Both expectedResults and expectedResult. This will replace values
        attributes to match the expected default attributes. This also will create Keyword
        objects for any keyword dict info that is on this object

        .. note::
          This is not called by default as it could cause scripts to break.
          This also clears any change records so it should only be called right after instantiation.

        :return: None
        """
        # Making this no op for the new API
        pass

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(TestCase, cls).property_value_converter_map)
        map.update({
            'component': ComponentValueConverterEncodeOnly,
            'scheduledTests': ScheduledTestCaseListValueConverter
        })
        return map

    def change_record_class_for_property(self, property):
        return RadarTestUpdateChangeRecord

    def __unicode__(self):
        return u'<TestCase caseId: {} title: "{}">'.format(self.caseId, self.title)

    def webservice_url_components_for_key_values(self):
        pass


class TestSuite(TSTTSuite):
    """
    Represents a test suite. Object can be used to queue changes similar to :py:class:`Radar` before
    committing the changes to the database. Any changes made to TestCase objects in the cases
    attribute will also be updated on the commit_changes call.

    TestSuite objects have the following main properties:

    - suiteId
    - title
    - component
    - status
    - priority
    - author
    - category
    - isActive
    - isRegression
    - createdAt
    - lastModifiedAt
    - createdBy
    - lastModifiedBy
    - allTesterPending
    - counts

    Additional optional properties are documented in the `Test Suite API Documentation`_

    Example::

        test_suite = radar_client.test_suite_for_id(12345, additional_fields=['additionalTests', 'keywords'])
        # example test case ids already part of the suite are [123, 456, 789]
        middle_case_to_add = radar_client.test_suite_case_for_id(1337)
        case_to_append = radar_client.test_suite_case_for_id(42)

        # Change title of middle_case_to_add
        middle_case_to_add.title = "New Title"

        # Add middle_case_to_add in position 2 of test suite
        test_suite.add_test_case(middle_case_to_add case_number=2)

        # If commit_changes were run now, middle_case_to_add in radar would have its title changed
        # to New Title and it would be added to test_suite so that cases would now be
        # [123, 1337, 456, 789]

        # Queues adding case_to_append to test_suite such that cases will be
        # [123, 1337, 456, 789, 42] if commit_changes were to run
        test_suite.add_test_case(case_to_append)

        # Queues changing priority of case 123 to be 3 on commit_changes
        test_suite.cases[0].priority = 3

        # Queues moving case 123 to position 3. cases would be [1337, 456, 123, 789, 42]
        # if commit_changes were run now
        test_suite.reorder_associated_test_case(test_suite.cases[0], 3)

        # Queues up removing case 456 on commit
        test_suite.remove_associated_test_case(test_suite.cases[1])

        # Add a keyword. There is not currently a way to remove keywords in the API. If the
        # keyword is already present, it will leave it in place
        test_suite.add_keywords([radar_client.Keyword({'id': 1, 'name': 'test'})])

        # Print out of actions to be taken
        test_suite.commit_changes(radar_client, dry_run=True)

    .. note::
        If you requested ``associatedTests``, the cases that are part of that are pulled out in to a flat attribute
        called ``cases``. This matches the behavior of the previous TSTT API and also makes it easier to work with
        just the test cases that are part of the test suite
    """
    identifier_attrs = ('suiteId',)
    DEFAULT_PROPERTIES = [
        'suiteId',
        'title',
        'component',
        'status',
        'priority',
        'isActive',
        'isRegression',
        'createdAt',
        'lastModifiedAt',
        'author',
        'counts',
        'allTesterPending',
        'lastModifiedBy',
        'createdBy'
    ]
    EXCLUDE_FROM_FIND = {'changeId', 'assignee', 'allTesterPending', 'counts', 'associatedTests', 'diagnosisList',
                         'primaryData', 'prerequisites', 'relatedProblems', 'relatedSuite', 'securityList',
                         'security', 'scheduledTests', 'relatedResources', 'attachments', 'pictures',
                         'protectionMaskList', 'testTypes', 'label', 'ccList', 'history'}

    ENTITY_TYPE = 'test-suites'
    BASE_URL = 'tests/suites'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (ENTITY_TYPE,)
    REORDERING_TYPE = 'TEST_SUITE'
    GET_BY_ID_METHOD = 'test_suite_for_id'

    def __init__(self, dictionary_representation=None):
        # Work around rdar://116878945 (When Running a Query for Test Suites, the Suites are Returned with the ID `suiteID` instead of `suiteId)
        if 'suiteID' in dictionary_representation:
            dictionary_representation['suiteId'] = dictionary_representation.pop('suiteID')
        super(TestSuite, self).__init__(dictionary_representation)
        # Create a set to track all TestCase items in TestSuite
        self.case_set = set()
        # Create a cases attribute to mimic prior attribute available in previous UI
        self.cases = []

        # Work around rdar://124737413. Test cases at the top level are no longer being returned in order. This was
        # previously only an issue with sub-suites which is tracked by
        # rdar://121218110 (Cases in Sub Suites Not Returned in the Correct Order)
        if hasattr(self, 'associatedTests'):
            self.associatedTests.sort(key=lambda x: x._order)

            # Build a cases attribute to mimic prior API behavior
            for item in self.associatedTests:
                if isinstance(item, TestCase):
                    self.case_set.add(item)
                    self.cases.append(item)
                    setattr(item, 'suiteId', self.database_id_attribute_value())
                    item.clear_change_records()
                elif isinstance(item, TestSuite):
                    # Handle cases nested in sub-suites
                    for case in item.cases:
                        setattr(case, 'suiteId', item.database_id_attribute_value())
                        case.clear_change_records()
                        self.case_set.add(case)
                        self.cases.append(case)

    @cached_class_property
    def property_names(cls):
        return super(TestSuite, TestSuite).property_names + TestSuite.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(TestSuite, cls).property_value_converter_map)
        map.update({
            'associatedTests': AssociatedTestsListValueConverter,
            'scheduledTests': ScheduledTestListValueConverter
        })
        return map

    def change_record_class_for_property(self, property):
        return RadarTestUpdateChangeRecord

    def create_and_add_test_case(self, case_data, order=None):
        """
        Creates a test case and attaches it to the suite. If no ``componentId`` is included in ``case_data`` it will use
        the component ID of this ``TestSuite``

        :param dict case_data: case data dictionary per the `Create Test Suite Case Docs`_
        :param int order: The order the new case should be in the test suite. If not passed in, will add to the end
            of the suite

        :return: True if added to the change queue. False if not. Will also
            return a list of issues explaining the failure
        :rtype: (bool, list[str])
        """
        if case_data.get('componentId') is None:
            case_data['componentId'] = self.component.id
        associated_suite_dict = {'suiteId': self.suiteId}
        if order is not None:
            associated_suite_dict['order'] = order

        case_data['associatedSuite'] = associated_suite_dict
        issues = TestCase.validate_test_case_creation_dict(case_data)
        is_attached = True
        if len(issues) > 0:
            is_attached = False
        else:
            # This doesn't update the test case set because the test case won't exist until changes
            # are committed
            self._add_change_record(CreateAndAddTestCaseChangeRecord(
                compat.unicode_string_type(self), case_data)
            )
        return is_attached, issues

    def reorder_associated_case_by_id(self, test_case_id, new_position):
        """
        Move an associated test case using its ID

        :param int test_case_id: ID of the test case to move
        :param int new_position: The new position of the test case. Cannot have more than 1 item moving to the same spot

        :return: None
        """
        self._add_change_record(
            ReorderItemInTestSuiteChangeRecord(
                self.database_id_attribute_value(),
                test_case_id,
                new_position,
                TestCase.REORDERING_TYPE
            )
        )

    def reorder_associated_case(self, test_case, new_position, **kwargs):
        """
        Move a test case using a TestCase object

        :param TestCase test_case: TestCase object to be moved
        :param int new_position: The new position of the test case. Cannot have more than 1 item moving to the same spot
        :param kwargs: kept around to work as a replacement for reorder_associated_test_case
        :return:
        """
        self.reorder_associated_case_by_id(test_case.database_id_attribute_value(), new_position)

    def reorder_associated_suite_by_id(self, test_suite_id, new_position):
        """
        Move an associated test suite using its ID

        :param int test_suite_id: ID of the test suite to be moved
        :param int new_position: The new position of the test suite. Cannot have more than 1 item moving to the same spot

        :return: None
        """
        self._add_change_record(
            ReorderItemInTestSuiteChangeRecord(
                self.database_id_attribute_value(),
                test_suite_id,
                new_position,
                TestSuite.REORDERING_TYPE
            )
        )

    def reorder_associated_suite(self, test_suite, new_position):
        """
        Move an associated TestSuite

        :param TestSuite test_suite: TestSuite to be moved
        :param int new_position: The new position of the test suite. Cannot have more than 1 item moving to the same spot

        :return: None
        """
        self.reorder_associated_suite_by_id(test_suite.database_id_attribute_value(), new_position)

    @deprecated(reorder_associated_case, '12.0')
    def reorder_associated_test_case(self, test_case, case_number, sub_suite_pos=None):
        """
        Moves a test case that is already associated to a test suite to a new place in the order

        :param TestCase test_case: :py:class:`TestCase` object to reorder
        :param int case_number: Location to move the test case to in the suite
        :param int sub_suite_pos: Position case should be moved to within a sub-suite. This is only
            needed if you are changing case order of a sub suite as part of the parent suite
            which is unlikely. Mainly used for tstt_excel.py. If used, suiteID must be defined on
            the TestCase object

        :return: None

        Example::

            suite = radar_client.test_suite_for_id(123, additional_fields=['cases'])
            suite.reorder_associated_test_case(cases[0], 3)
            suite.commit_changes(radar_client)

        """
        self._add_change_record(
            ReorderAssociatedTestCaseChangeRecord(
                str(self), self.suiteId, test_case, case_number, sub_suite_pos=sub_suite_pos
            )
        )

    def remove_associated_test_case(self, test_case):
        """
        Removes a test case from a test suite

        :param TestCase test_case: :py:class:`TestCase` to be removed from the test suite
        :return: None

        Example::

            test_suite = radar_client.test_suite_for_id(123, additional_fields=['associatedTests'])
            test_suite.remove_associated_test_case(test_suite.cases[0])
            test_suite.commit_changes(radar_client)

        """
        self.remove_associated_test_case_by_id(test_case.caseId)

    def remove_associated_test_case_by_id(self, test_case_id):
        """
        Remove a test case by ID

        :param int test_case_id: The ID of the test case to be removed

        :return: None

        Example::
            # a suite that has a test case with the ID 4567
            test_suite = radar_client.test_suite_for_id(123, additional_fields=['associatedTests'])
            test_suite.remove_associated_test_case(4567)
            test_suite.commit_changes(radar_client)

        """
        self._add_change_record(RadarTestUpdateChangeRecord(
            self, 'associatedTestCases',
            update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_ASSOCIATED_CASE,
            action=RadarTestUpdateChangeRecord.ACTION_TYPE_REMOVE, new_value={'caseId': test_case_id}
        ))
        self.case_set.remove(TestCase({'caseId': test_case_id}))

    def add_test_case_by_id(self, test_case_id, case_number=0):
        """
        Add an existing test case with just the ID of the case

        :param int test_case_id: ID of the test case to add
        :param int case_number: What position the new case should be added in. Default is adding at the end of the
            list of cases

        :returns: None

        Example::

            # Add case 123 to suite 456 in the second spot
            suite = radar_client.test_suite_for_id(456)
            suite.add_test_case_by_id(123, case_number=2)

        """
        update_dict = {'caseId': test_case_id}
        if case_number > 0:
            update_dict['order'] = case_number

        self._add_change_record(RadarTestUpdateChangeRecord(
            self, 'associatedTestCases',
            update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_ASSOCIATED_CASE,
            action=RadarTestUpdateChangeRecord.ACTION_TYPE_INSERT,
            new_value=update_dict
        ))
        self.case_set.add(TestCase({'caseId': test_case_id}))

    def add_test_case(self, test_case, case_number=0):
        """
        Add a test case to a suite

        :param TestCase test_case: :py:class:`TestCase` object to add
        :param int case_number: What position the new case should be added in. Default is adding at the end of the
            list of cases

        :return: None

        Example::

            # Add case 123 to suite 456 in the second spot
            case = radar_client.test_suite_case_for_id(123)
            suite = radar_client.test_suite_for_id(456)
            suite.add_test_case(case, case_number=2)

        """
        self.add_test_case_by_id(test_case.caseId, case_number=case_number)

    def add_test_cases(self, case_list):
        """
        Add multiple :py:class:`TestCase` objects to the suite appending them to the end of the
        test suite.

        :param list[TestCase] case_list: list of :py:class:`TestCase` objects to append

        :return: None

        Example::

            query = {
                'title': {'like': '%test title%'},
                'priority': [3, 4],
                'component': {'name': 'test component', 'version': '1.0'}
            }
            cases = radar_client.find_test_suite_cases(query, return_results_directly=True)
            suite = radar_client.test_suite_for_id(123)
            suite.add_test_cases(cases)
            suite.commit_changes(radar_client)

        """
        for case in case_list:
            self.add_test_case(case)

    def add_test_suite_by_id(self, test_suite_id, order=0):
        update_dict = {'suiteId': test_suite_id}
        if order > 0:
            update_dict['order'] = order

        self._add_change_record(RadarTestUpdateChangeRecord(
            self, 'associatedSuites',
            update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_ASSOCIATED_SUITE,
            action=RadarTestUpdateChangeRecord.ACTION_TYPE_INSERT,
            new_value=update_dict
        ))

    def add_test_suite(self, test_suite, order=0):
        self.add_test_suite_by_id(test_suite.database_id_attribute_value(), order=order)

    def remove_test_suite_by_id(self, test_suite_id):
        self._add_change_record(RadarTestUpdateChangeRecord(
            self, 'associatedSuites',
            update_type=RadarTestUpdateChangeRecord.UPDATE_TYPE_ASSOCIATED_SUITE,
            action=RadarTestUpdateChangeRecord.ACTION_TYPE_REMOVE, new_value={'suiteId': test_suite_id}
        ))

    def remove_test_suite(self, test_suite):
        self.remove_test_suite_by_id(test_suite.database_id_attribute_value())

    @deprecated(add_test_case, 12.0)
    def add_existing_test_case(self, test_case, case_number=0, sub_suite_case_num=None):
        """
        Adds a test case that already exists. Must pass in a :py:class:`TestCase` object

        :param TestCase test_case: :py:class:`TestCase` object to add
        :param int case_number: Where the test case should be in the case order. If 0, test case
            is added to the end of the test suite. Default=0
        :param int sub_suite_case_num: Actual order of test case in the sub suite it is a part
            of. This is only needed if you are changing case order of a sub suite as part of the
            parent suite which is unlikely. Mainly used for tstt_excel.py. If used, suiteID must be
            defined on the TestCase object

        :return: None

        Example::

            # Add case 123 to suite 456 in the second spot
            case = radar_client.test_suite_case_for_id(123)
            suite = radar_client.test_suite_for_id(456)
            suite.add_existing_test_case(case, case_number=2)

        """
        append = True
        # Add a reordering change tracker if case_number is > 0
        if case_number > 0:
            self.reorder_associated_test_case(
                test_case, case_number, sub_suite_pos=sub_suite_case_num)
            append = False

        # Only use the test case suiteID if there is a sub_suite_case_num per
        # rdar://85476013 (add_existing_test_cases() method does not work)
        if sub_suite_case_num is None:
            add_to_suite_id = self.suiteID
        else:
            add_to_suite_id = test_case.suiteID
        self._add_change_record(
            AddExistingTestCaseChangeRecord(
                compat.unicode_string_type(self), add_to_suite_id,
                test_case, append=append
            )
        )
        self.case_set.add(test_case)

    @deprecated(add_test_cases, 12.0)
    def add_existing_test_cases(self, case_list):
        """
        Add multiple :py:class:`TestCase` objects to the suite appending them to the end of the
        test suite.

        :param list[TestCase] case_list: list of :py:class:`TestCase` objects to append

        :return: None

        Example::

            query = {
                'title': {'like': '%test title%'},
                'priority': [3, 4],
                'component': {'name': 'test component', 'version': '1.0'}
            }
            cases = radar_client.find_test_suite_cases(query, return_results_directly=True)
            suite = radar_client.test_suite_for_id(123)
            suite.add_existing_test_cases(cases)
            suite.commit_changes(radar_client)

        """
        for case in case_list:
            self.add_test_case(case)

    def commit_changes(self, client, dry_run=False, callback=lambda *args: None):
        for case in self.case_set:
            case.commit_changes(client, dry_run=dry_run, callback=callback)
        super(TestSuite, self).commit_changes(client, dry_run=dry_run, callback=callback)

    def __unicode__(self):
#         return u'<TestSuite title: "{}" component: {} | {}>'.format(self.title,
#                                                                     self.component['name'],
#                                                                     self.component['version'])
        return u'<TestSuite title: "{}" component: {}>'.format(self.title,
                                                                    self.component)

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (self.suiteId, 'key-values')


class TestCategory(DictionaryBasedModel):
    """
    Represents a test category

    Typical properties
        - id, :py:class:`int`
        - value, :py:class:`str`
    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = ['id', 'value']
    BASE_URL = 'tests/categories'

    @cached_class_property
    def property_names(cls):
        return super(TestCategory, TestCategory).property_names + TestCategory.DEFAULT_PROPERTIES


class Milestone(DictionaryBasedModel):
    """
    Represents a Milestone defined on a :py:class:`Component`.

    You should not need to instantiate objects of this class yourself. If you choose to, you can use `either`
    the ``dictionary_representation`` **OR** the ``id``, ``name``, & ``component`` parameters, but not both.

    Milestone objects can be loaded in three ways:

    1. As part of a :py:class:`Radar` object and returned from its ``milestone`` property. You must include\
    ``milestone`` in ``additional_fields`` when loading the Radar.
    2. From :py:meth:`~radarclient.client.RadarClient.milestones_for_component`.
    3. Returned by :py:meth:`~radarclient.client.RadarClient.create_milestone_for_component`.

    Milestone objects typically have the following properties:

        From a :py:class:`Radar` object:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - beginsAt, :py:class:`datetime.datetime`
        - endsAt, :py:class:`datetime.datetime`

        Using :py:meth:`~radarclient.client.RadarClient.milestones_for_component`:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - definedComponentId, :py:class:`int`
        - startDate, :py:class:`datetime.datetime`
        - endDate, :py:class:`datetime.datetime`
        - closed, :py:class:`bool`
        - protected, :py:class:`bool`
        - restricted, :py:class:`bool`
        - inheritanceType, :py:class:`bool`
        - tentpoleRequired, :py:class:`bool`
        - eventRequired, :py:class:`bool`
        - categoryRequired, :py:class:`bool`
        - protectedAccessGroups, a :py:class:`list` of :py:class:`AccessGroup` objects
        - restrictedAccessGroups,  a :py:class:`list` of :py:class:`AccessGroup` objects

    Example::

        # Example #1
        radar = client.radar_for_id(1234)
        component_query = {'name': 'python-radarclient', 'version': '1.0'}
        components = client.find_components(component_query)
        milestones = radar_client.milestones_for_component(components[0])
        radar.milestone = milestones[1]
        radar.commit_changes()

        # Example #2, instantiating a Milestone directly
        radar = client.radar_for_id(1234)
        milestone = Milestone(component=radar.component, name='test-milestone')
        radar.milestone = milestone
        radar.commit_changes()

    For information about determining a valid combination of Milestone, Event, Category, and Tentpole for a Radar, see
    :py:meth:`~radarclient.model.Radar.milestone_associations`.
    """
    identifier_attrs = ('id', 'name')
    DEFAULT_PROPERTIES = [
        'id',
        'name',
    ]

    PROPERTY_KEYNAME_MAP = {
        'beginsAt': 'startDate',
        'endsAt': 'endDate',
        'isClosed': 'closed',
        'isProtected': 'protected',
        'isRestricted': 'restricted',
        'isEventRequired': 'eventRequired',
        'isTentpoleRequired': 'tentpoleRequired',
        'isCategoryRequired': 'categoryRequired',
        'parentLevelComponentID': 'definedComponentId'
    }

    def __init__(self, dictionary_representation=None, id=None, name=None, component=None, *extra_constructor_args):
        self.id = id or ''
        self.name = name or ''
        self.component = component
        if dictionary_representation:
            # API v2.2 embeds most of the payload in a nested dictionary.
            if 'milestone' in dictionary_representation:
                nested_object = dictionary_representation['milestone']
                assert isinstance(nested_object, dict)
                dictionary_representation.update(nested_object)
                del(dictionary_representation['milestone'])
            super(Milestone, self).__init__(dictionary_representation, *extra_constructor_args)
            return

        super(Milestone, self).__init__({'id': id, 'name': name}, *extra_constructor_args)

    @cached_class_property
    def property_names(cls):
        return super(Milestone, Milestone).property_names + Milestone.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Milestone, cls).property_value_converter_map)
        map.update({
            'component': ComponentValueConverter,
            'beginsAt': ISO8601UTCDateValueConverter,   # Still needed for radar.milestone
            'endsAt': ISO8601UTCDateValueConverter,     # Still needed for radar.milestone
            'startDate': ISO8601UTCDateValueConverter,
            'endDate': ISO8601UTCDateValueConverter,
            'protectedAccessGroups': AccessGroupListValueConverter,
            'restrictedAccessGroups': AccessGroupListValueConverter,
        })
        return map

    def __unicode__(self):
        _id = ' {}'.format(getattr(self, 'id')) if hasattr(self, 'id') else ''
        _name = ' "{}"'.format(getattr(self, 'name')) if hasattr(self, 'name') else ''
        if self.component:
            _component = Component(self.component) if isinstance(self.component, dict) else self.component
            return u'<Milestone{}{}{}>'.format(_id, _name, ' from {}'.format(_component.__unicode__()))
        return u'<Milestone{}{}>'.format(_id, _name)

    def __eq__(self, other):
        if type(self) != type(other):
            return False
        if self.id and other.id:
            return self.id == other.id
        return self.component == other.component and self.name == other.name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        if self.id:
            return self.id
        return hash(self.component) ^ hash(self.name)

    @classmethod
    def value_converter_class_for_self(cls, variant=None):
        if variant == 'radar_property':
            return MilestoneAsRadarPropertyValueConverter
        else:
            raise Exception('Unable to convert milestone to unknown variant "{}" for'.format(variant))

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Milestone, cls).keyname_map)
        map.update(Milestone.PROPERTY_KEYNAME_MAP)
        return map


class MilestoneAssociations(DictionaryBasedModel):
    """
    Represents the the associated/available :py:class:`~Event`, :py:class:`~Category`, and :py:class:`~Tentpole` objects
    for a given :py:class:`~Milestone` when retrieved via :py:meth:`~radarclient.model.Radar.milestone_associations`, or
    for a given :py:class:`~Component` when retrieved via
    :py:meth:`~radarclient.client.RadarClient.milestone_associations_for_component_id`.

    MilestoneAssociations objects have the following properties:

    - events, the :py:class:`list` of associated :py:class:`~Event` objects.
    - categories, the :py:class:`list` of associated :py:class:`~Category` objects.
    - tentpoles, the :py:class:`list` of associated :py:class:`~Tentpole` objects.

    MilestoneAssociations objects can also have the following property:

    - milestone, the base :py:class:`~Milestone` where the associations are defined.

    For more information, see :py:meth:`~radarclient.model.Radar.milestone_associations` and
    :py:meth:`~radarclient.client.RadarClient.milestones_for_component`, and
    :py:meth:`~radarclient.client.RadarClient.milestone_associations_for_component_id`.
    """
    DEFAULT_PROPERTIES = [
        'categories',
        'events',
        'tentpoles',
    ]

    def __init__(self, dictionary_representation=None, milestone=None, categories=None, events=None, tentpoles=None,
                 component_id=None, *extra_constructor_args):
        self.milestone = milestone
        self.component_id = component_id
        self.categories = categories
        self.events = events
        self.tentpoles = tentpoles
        if dictionary_representation:
            super(MilestoneAssociations, self).__init__(dictionary_representation, *extra_constructor_args)
        else:
            super(MilestoneAssociations, self).__init__(
                {'categories': categories, 'events': events, 'tentpoles': tentpoles},
                *extra_constructor_args
            )
        # These Event, Category, and Tentpole objects are more limited than their typical versions, so we remove the
        # unused properties before returning.
        for object_list in [self.categories, self.events, self.tentpoles]:
            for _object in object_list:
                for _property in ['closed', 'component', 'definedComponentId', 'inherited', 'milestoneAssociation',
                                  'eventAssociation', 'categoryAssociation']:
                    if hasattr(_object, _property):
                        try:
                            delattr(_object, _property)
                        except AttributeError:
                            pass
        return

    @cached_class_property
    def property_names(cls):
        return super(MilestoneAssociations, MilestoneAssociations).property_names \
            + MilestoneAssociations.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(MilestoneAssociations, cls).property_value_converter_map)
        map.update({
            'categories': CategoryListValueConverter,
            'events': EventListValueConverter,
            'tentpoles': TentpoleListValueConverter,
        })
        return map

    def __unicode__(self):
        identifier = self.milestone or Component(id=self.component_id)
        to_return = u'<MilestoneAssociations for {}>'.format(identifier)
        if self.events:
            to_return = to_return + '\n    {}'.format('\n    '.join([evt.__unicode__() for evt in self.events]))
        if self.categories:
            to_return = to_return + '\n    {}'.format('\n    '.join([ctgy.__unicode__() for ctgy in self.categories]))
        if self.tentpoles:
            to_return = to_return + '\n    {}'.format('\n    '.join([tpl.__unicode__() for tpl in self.tentpoles]))
        return to_return


class ProgramManagementComponentProperty(DictionaryBasedModel):
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'startDate',
        'endDate',
        'closed',
        'milestoneAssociation',
        'definedComponentId',
        'inherited',
    ]
    PROPERTY_KEYNAME_MAP = {
        'beginsAt': 'startDate',
        'endsAt': 'endDate',
        'isClosed': 'closed',
        'hasMilestoneAssociation': 'milestoneAssociation',
        'isInherited': 'inherited',
        'parentLevelComponentID': 'definedComponentId'
    }

    def __init__(self, dictionary_representation=None, id=None, name=None, component=None, *extra_constructor_args):
        self.id = id or ''
        self.name = name or ''
        self.component = component
        if dictionary_representation:
            # API v2.2 embeds most of the payload in a nested dictionary.
            nested_objects_to_flatten = ['event', 'category', 'tentpole']
            for object_name in nested_objects_to_flatten:
                if object_name not in dictionary_representation:
                    continue
                nested_object = dictionary_representation[object_name]
                assert isinstance(nested_object, dict)
                dictionary_representation.update(nested_object)
                del(dictionary_representation[object_name])
            super(ProgramManagementComponentProperty, self).__init__(dictionary_representation, *extra_constructor_args)
            return

        super(ProgramManagementComponentProperty, self).__init__({'id': id, 'name': name}, *extra_constructor_args)

    @classmethod
    def parse_webservice_data(cls, data_list, component, client, *extra_constructor_args):
        if isinstance(data_list, dict):
            data_list = [data_list]
        item_list = []
        for item_data in data_list:
            name = getattr(item_data, 'name', None)
            if 'status' in item_data:
                logger.error(u'Unable to load {} data: {}/{}'.format(cls.__name__, item_data['status'], item_data.get('message', '(No error message available)')))
                continue
            item_list.append(cls(item_data, component, name, client, *extra_constructor_args))
        return item_list

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ProgramManagementComponentProperty, cls).property_value_converter_map)
        map.update({
            'component': ComponentValueConverter,
            'beginsAt': ISO8601UTCDateValueConverter,   # Still needed for radar.<property>
            'endsAt': ISO8601UTCDateValueConverter,     # Still needed for radar.<property>
            'startDate': ISO8601UTCDateValueConverter,
            'endDate': ISO8601UTCDateValueConverter,
            'milestones': MilestoneListValueConverter,
            'categories': CategoryListValueConverter,
            'events': EventListValueConverter,
        })
        return map

    def __unicode__(self):
        _class = type(self).__name__
        _id = ' {}'.format(self.id) if self.id else ''
        _name = ' "{}"'.format(self.name) if self.name else ''
        if hasattr(self, 'component') and self.component is not None:
            return u'<{}{}{}{}>'.format(_class, _id, _name, ' from {}'.format(self.component.__unicode__()))
        return u'<{}{}{}>'.format(_class, _id, _name)

    @cached_class_property
    def property_names(cls):
        return super(ProgramManagementComponentProperty,
                     ProgramManagementComponentProperty).property_names + \
               ProgramManagementComponentProperty.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(ProgramManagementComponentProperty, cls).keyname_map)
        map.update(ProgramManagementComponentProperty.PROPERTY_KEYNAME_MAP)
        return map


class Event(ProgramManagementComponentProperty):
    """
    Represents an Event defined on a :py:class:`Component`.

    You should not need to instantiate objects of this class yourself. If you choose to, you can use `either`
    the ``dictionary_representation`` **OR** the ``id``, ``name``, & ``component`` parameters, but not both.

    Event objects can be loaded in three ways:

    1. As part of a :py:class:`Radar` object and returned from its ``event`` property. You must include ``event`` in\
    ``additional_fields`` when loading the Radar.
    2. From :py:meth:`~radarclient.client.RadarClient.events_for_component`.
    3. Returned by :py:meth:`~radarclient.client.RadarClient.create_event_for_component`.

    Event objects typically have the following properties:

        From a :py:class:`Radar` object:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - beginsAt, :py:class:`datetime.datetime`
        - endsAt, :py:class:`datetime.datetime`

        Using :py:meth:`~radarclient.client.RadarClient.events_for_component`:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - definedComponentId, :py:class:`int`
        - startDate, :py:class:`datetime.datetime`
        - endDate, :py:class:`datetime.datetime`
        - milestoneAssociation, :py:class:`bool`
        - closed, :py:class:`bool`
        - inherited, :py:class:`bool`
        - tentpoleRequired, :py:class:`bool`
        - milestones, a :py:class:`list` of associated :py:class:`Milestone` objects

    **Usage Examples**

    To change a Radar's Event, you first need to load an :py:class:`Event` instance. Here are three options::

        # Option 1, load the Event from a Radar object
        radar = client.radar_for_id(1234, additional_fields=['event'])
        event = radar.event
        print(event)

        # Option 2, load the Event using RadarClient.events_for_component()
        component_query = {'name': 'python-radarclient', 'version': '1.0'}
        components = client.find_components(component_query)
        component = components[0]
        events = client.events_for_component(component)
        event = events[...] # Pick one of the events based on some criteria

        # Option 3, create an new Event for a Component
        request_data = {
            'name': u'NewMilestone',
            'startDate': '2022-07-01T00:00:00-0000',
            'endDate': '2022-08-01T00:00:00-0000',
            'tentpoleRequired': false,
        }
        component = radar_client.component_for_id(514369)
        event = radar_client.create_event_for_component(request_data, component)

    Now you can change the value::

        radar = client.radar_for_id(1234, additional_fields=['event'])
        radar.event = event
        radar.commit_changes()

    Clearing the event on a Radar instance::

        radar = client.radar_for_id(1234, additional_fields=['event'])
        radar.event = None
        radar.commit_changes()

    For information about determining a valid combination of Milestone, Event, Category, and Tentpole for a Radar, see
    :py:meth:`~radarclient.model.Radar.milestone_associations`.
    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = ['tentpoleRequired']
    PROPERTY_KEYNAME_MAP = {'isTentpoleRequired': 'tentpoleRequired'}

    @cached_class_property
    def property_names(cls):
        return super(Event, Event).property_names + Event.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Event, cls).keyname_map)
        map.update(Event.PROPERTY_KEYNAME_MAP)
        return map


class Category(ProgramManagementComponentProperty):
    """
    Represents a Category defined on a :py:class:`Component`.

    You should not need to instantiate objects of this class yourself. If you choose to, you can use `either`
    the ``dictionary_representation`` **OR** the ``id``, ``name``, & ``component`` parameters, but not both.

    Category objects can be loaded in three ways:

    1. As part of a :py:class:`Radar` object and returned from its ``category`` property. You must include ``category``\
    in ``additional_fields`` when loading the Radar.
    2. From :py:meth:`~radarclient.client.RadarClient.categories_for_component`.
    3. Returned by :py:meth:`~radarclient.client.RadarClient.create_category_for_component`.

    Category objects typically have the following properties:

        From a :py:class:`Radar` object:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - beginsAt, :py:class:`datetime.datetime`
        - endsAt, :py:class:`datetime.datetime`

        Using :py:meth:`~radarclient.client.RadarClient.categories_for_component`:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - definedComponentId, :py:class:`int`
        - startDate, :py:class:`datetime.datetime`
        - endDate, :py:class:`datetime.datetime`
        - milestoneAssociation, :py:class:`bool`
        - closed, :py:class:`bool`
        - inherited, :py:class:`bool`
        - tentpoleRequired, :py:class:`bool`
        - milestones, a :py:class:`list` of associated :py:class:`Milestone` objects

    This class is almost identical to :py:class:`Event`, see there for usage examples.

    For information about determining a valid combination of Milestone, Event, Category, and Tentpole for a Radar, see
    :py:meth:`~radarclient.model.Radar.milestone_associations`.
    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = ['tentpoleRequired']
    PROPERTY_KEYNAME_MAP = {'isTentpoleRequired': 'tentpoleRequired'}

    @cached_class_property
    def property_names(cls):
        return super(Category, Category).property_names + Category.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Category, cls).keyname_map)
        map.update(Category.PROPERTY_KEYNAME_MAP)
        return map


class Tentpole(ProgramManagementComponentProperty):
    """
    Represents a Tentpole defined on a :py:class:`Component`.

    You should not need to instantiate objects of this class yourself. If you choose to, you can use `either`
    the ``dictionary_representation`` **OR** the ``id``, ``name``, & ``component`` parameters, but not both.

    Tentpole objects can be loaded in three ways:

    1. As part of a :py:class:`Radar` object and returned from its ``tentpole`` property. You must include ``tentpole``\
    in ``additional_fields`` when loading the Radar.
    2. From :py:meth:`~radarclient.client.RadarClient.tentpoles_for_component`.
    3. Returned by :py:meth:`~radarclient.client.RadarClient.create_tentpole_for_component`.

    Tentpole objects typically have the following properties:

        From a :py:class:`Radar` object:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - beginsAt, :py:class:`datetime.datetime`
        - endsAt, :py:class:`datetime.datetime`

        Using :py:meth:`~radarclient.client.RadarClient.tentpoles_for_component`:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - definedComponentId, :py:class:`int`
        - startDate, :py:class:`datetime.datetime`
        - endDate, :py:class:`datetime.datetime`
        - milestoneAssociation, :py:class:`bool`
        - categoryAssociation, :py:class:`bool`
        - eventAssociation, :py:class:`bool`
        - closed, :py:class:`bool`
        - inherited, :py:class:`bool`
        - milestones, a :py:class:`list` of associated :py:class:`Milestone` objects
        - categories, a :py:class:`list` of associated :py:class:`Category` objects
        - events, a :py:class:`list` of associated :py:class:`Event` objects

    This class is almost identical to :py:class:`Event`, see there for usage examples.

    For information about determining a valid combination of Milestone, Event, Category, and Tentpole for a Radar, see
    :py:meth:`~radarclient.model.Radar.milestone_associations`.
    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'categoryAssociation',
        'eventAssociation',
    ]
    PROPERTY_KEYNAME_MAP = {
        'hasCategoryAssociation': 'categoryAssociation',
        'hasEventAssociation': 'eventAssociation'
    }

    @cached_class_property
    def property_names(cls):
        return super(Tentpole, Tentpole).property_names + Tentpole.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Tentpole, cls).keyname_map)
        map.update(Tentpole.PROPERTY_KEYNAME_MAP)
        return map


class Component(DictionaryBasedModel):
    """
    Represents a Component in the Radar database.

    :param dict dictionary_representation: Contains the properties used to instantiate the object
    :param int id: Component ID
    :param str name: Component Name
    :param str version: Component Version

    You should not need to instantiate objects of this class yourself. If you choose to, you can use `either`
    the ``dictionary_representation`` **OR** the ``id``, ``name``, & ``version`` parameters, but not both. The ``id``
    value is **mandatory** in either format.

    Component objects are typically loaded in one of the following ways:

    1. As part of a :py:class:`Radar` object and returned from its ``component`` property. **NOTE**: As an exception, \
    the ``component`` property of a :py:class:`Radar` is left in dictionary form for compatibility. See the :py:class:`Radar` \
    class for more information.
    2. From direct-retrieval methods such as :py:meth:`~radarclient.client.RadarClient.component_for_id`, \
    :py:meth:`~radarclient.client.RadarClient.components_for_ids`, :py:meth:`~radarclient.client.RadarClient.find_components`, \
    :py:meth:`~radarclient.client.RadarClient.components_for_name`, \
    :py:meth:`~radarclient.client.RadarClient.component_for_name_and_version`, etc.
    3. Returned by :py:meth:`~radarclient.client.RadarClient.create_component`.
    4. As instances of :py:class:`ComponentBundleMember` of a :py:class:`ComponentBundle` object.

    Component objects generated by the API `always` have the following properties, at a minimum:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - version, :py:class:`str`

    Component objects generated by the API often include additional properties, which you can read about more in the
    `Component API Docs`_. You can request these additional properties with the ``additional_fields`` parameter of
    :py:meth:`~radarclient.client.RadarClient.component_for_id`, :py:meth:`~radarclient.client.RadarClient.find_components`,
    and other direct-retrieval methods that return Component objects.

    Example::

        radar = radar_client.radar_for_id(12345678)
        dropbox_component = radar_client.component_for_name_and_version(name='python-radarclient-test bugs', version='1.0', additional_fields=['parent'])
        new_component = dropbox_component.parent
        radar.component = new_component
        radar.commit_changes()

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'version',
        'description',
        'isClosed',
        'isRestricted'
    ]
    PROPERTY_KEYNAME_MAP = {'subcomponents': 'subComponents'}
    BASE_URL = 'components'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (BASE_URL,)

    def __init__(self, dictionary_representation=None, name=None, version=None, id=None, *extra_constructor_args):
        if dictionary_representation:
            super(Component, self).__init__(dictionary_representation, *extra_constructor_args)
            return
        super(Component, self).__init__({'name': name, 'version': version, 'id': id}, *extra_constructor_args)

    @cached_class_property
    def property_names(cls):
        return super(Component, Component).property_names + Component.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Component, cls).property_value_converter_map)
        map.update({
            'parent': ComponentValueConverter,
            'subcomponents': ComponentListValueConverter,
            'subComponents': ComponentListValueConverter, # Needed for Get Component Tree in v2.2
            'owner': PersonValueConverter,
            'epm': PersonValueConverter,
            'screener': PersonValueConverter,
            'integrator': PersonValueConverter,
            'builder': PersonValueConverter,
            'verifier': PersonValueConverter,
            'followOnComponent': ComponentValueConverter,
            'workGroupObject': ComponentWorkGroupValueConverter
        })
        return map

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Component, cls).keyname_map)
        map.update(Component.PROPERTY_KEYNAME_MAP)
        return map

    def __unicode__(self):
        component_id = self.id if self.id is not None else '(no id)'
        if not self.name or not self.version:
            return u'<Component {}>'.format(component_id)
        return u'<Component {} "{} | {}">'.format(component_id, self.name, self.version)

    def __eq__(self, other):
        if type(self) != type(other):
            return False

        if self.id and other.id:
            return self.id == other.id
        return self.name == other.name and self.version == other.version

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        if self.id:
            return self.id
        return hash(self.name) ^ hash(self.version)

    @classmethod
    def value_converter_class_for_self(cls, variant=None):
        return ComponentValueConverter

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (self.id, 'key-values')


class ComponentInaccessible(DictionaryBasedModel):
    """
    Represents an **inaccessible** :py:class:`~Component` in a list or hierarchy. **This is specific to Radar API
    v2.2+.** For more information, see the `Get Component Tree API Docs`_.

    ComponentInaccessible objects have the following properties:

    - id, :py:class:`int`
    - name, ``None``
    - version, ``None``

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'version',
    ]
    PROPERTY_KEYNAME_MAP = {'subcomponents': 'subComponents'}

    @cached_class_property
    def property_names(cls):
        return super(ComponentInaccessible, ComponentInaccessible).property_names + \
               ComponentInaccessible.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ComponentInaccessible, cls).property_value_converter_map)
        map.update({
            'subcomponents': ComponentListValueConverter,
            'subComponents': ComponentListValueConverter, # Needed for Get Component Tree in v2.2
        })
        return map

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(ComponentInaccessible, cls).keyname_map)
        map.update(ComponentInaccessible.PROPERTY_KEYNAME_MAP)
        return map

    def __unicode__(self):
        return u'<ComponentInaccessible {}>'.format(self.id)


class ComponentBundle(DictionaryBasedModel):
    """
    Represents a Radar component bundle

    Component bundle objects have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - description, :py:class:`str`
    - components, :py:class:`list` of :py:class:`ComponentBundleMember` or \
    :py:class:`ComponentBundleMemberInaccessible` objects
    - admin, :py:class:`list` of :py:class:`Person` objects
    - owner, :py:class:`Person`
    - isActive, :py:class:`bool`
    - isPublic, :py:class:`bool`

    You can query for bundles with the :py:meth:`~radarclient.client.RadarClient.component_bundle_for_id`
    and :py:meth:`~radarclient.client.RadarClient.find_component_bundles` methods.

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'description',
        'components',
        'admin',
        'owner',
        'isActive',
        'isPublic'
    ]
    BASE_URL = 'component-bundles'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')

    @cached_class_property
    def property_names(cls):
        return super(ComponentBundle, ComponentBundle).property_names + \
               ComponentBundle.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ComponentBundle, cls).property_value_converter_map)
        map.update({
            'admin': PersonListValueConverter,
            'owner': PersonValueConverter,
            'components': ComponentBundleMemberListValueConverter,
        })
        return map

    def __unicode__(self):
        return u'<ComponentBundle {} {}>'.format(self.id, self.name)


class ComponentBundleMember(DictionaryBasedModel):
    """
    Represents an :py:class:`~Component` in the list accessible through the ``components`` property of a
    :py:class:`ComponentBundle` instance.

    ComponentBundleMember objects have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - version, :py:class:`str`
    - isComponentTreeIncluded, :py:class:`bool`: whether or not this component's subcomponents are included by \
    design
    - subcomponents, :py:class:`list`: An empty list unless the ``include_component_children`` parameter was set \
    to ``True`` when loading the component bundle, and the ``isComponentTreeIncluded`` is also ``True``.

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'version',
        'isComponentTreeIncluded',
        'subcomponents'
    ]

    @cached_class_property
    def property_names(cls):
        return super(ComponentBundleMember, ComponentBundleMember).property_names + \
               ComponentBundleMember.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ComponentBundleMember, cls).property_value_converter_map)
        map.update({
            'subcomponents': ComponentBundleMemberListValueConverter,
        })
        return map

    def __unicode__(self):
        return u'<ComponentBundleMember {} "{} | {}">'.format(self.id, self.name, self.version)


class ComponentBundleMemberInaccessible(ComponentInaccessible):
    """
    Represents an **inaccessible** :py:class:`~Component` in the list from the ``components`` property of a
    :py:class:`ComponentBundle` instance. **This is specific to Radar API v2.2+.** For more information, see the
    `Component Bundle API Docs`_.

    ComponentBundleMemberInaccessible objects have the following properties:

    - id, :py:class:`int`
    - name, None
    - version, None

    """
    @cached_class_property
    def property_names(cls):
        return super(ComponentBundleMemberInaccessible, ComponentBundleMemberInaccessible).property_names + \
               ComponentBundleMemberInaccessible.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<ComponentBundleMemberInaccessible {}>'.format(self.id)


class ComponentBundleGroup(DictionaryBasedModel):
    """
    Represents a Radar component bundle group.

    Component bundle group objects have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str`
    - admins, :py:class:`list` of :py:class:`Person` objects with administrator access
    - owner, :py:class:`Person`
    - isActive, :py:class:`bool`
    - isPublic, :py:class:`bool`
    - memberBundles, :py:class:`list` of :py:class:`~radarclient.model.ComponentBundleGroupMemberBundle` instances
    - memberGroups, :py:class:`list` of :py:class:`~radarclient.model.ComponentBundleGroupMemberGroup` instances

    You can get bundle group objects with :py:meth:`~radarclient.client.RadarClient.component_bundle_group_for_id`
    or search for them via :py:meth:`~radarclient.client.RadarClient.find_component_bundle_groups`.

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'admins',
        'memberBundles',
        'memberGroups',
        'description',
        'id',
        'isActive',
        'isPublic',
        'name',
        'owner'
    ]
    # Need this as a workaround to rdar://97278429
    PROPERTY_KEYNAME_MAP = {'admin': 'admins'}
    BASE_URL = 'component-bundle-groups'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')

    @cached_class_property
    def property_names(cls):
        return super(ComponentBundleGroup, ComponentBundleGroup).property_names + \
               ComponentBundleGroup.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(ComponentBundleGroup, cls).keyname_map)
        map.update(ComponentBundleGroup.PROPERTY_KEYNAME_MAP)
        return map

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(ComponentBundleGroup, cls).property_value_converter_map)
        map.update({
            'admins': PersonListValueConverter,
            'owner': PersonValueConverter,
            'memberBundles': ComponentBundleGroupMemberBundleListValueConverter,
            'memberGroups': ComponentBundleGroupMemberGroupListValueConverter,
        })
        return map

    def __unicode__(self):
        return u'<ComponentBundleGroup {} "{}">'.format(self.id, self.name)


class ComponentBundleGroupMember(DictionaryBasedModel):
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'description',
    ]

    @cached_class_property
    def property_names(cls):
        return super(ComponentBundleGroupMember, ComponentBundleGroupMember).property_names + \
               ComponentBundleGroupMember.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<ComponentBundleGroupMember {} "{}">'.format(self.id, self.name)


class ComponentBundleGroupMemberBundle(ComponentBundleGroupMember):
    """
    Represents an item in the list accessible through the ``memberBundles`` property of a
    :py:class:`ComponentBundleGroup` instance.

    Instances have the following properties:

    - id
    - name
    - description

    """
    def __unicode__(self):
        return u'<ComponentBundleGroupMemberBundle {} "{}">'.format(self.id, self.name)


class ComponentBundleGroupMemberGroup(ComponentBundleGroupMember):
    """
    Represents an item in the list accessible through the ``memberGroups`` property of a
    :py:class:`ComponentBundleGroup` instance.

    Instances have the following properties:

    - id
    - name
    - description

    """
    def __unicode__(self):
        return u'<ComponentBundleGroupMemberGroup {} "{}">'.format(self.id, self.name)


class DescriptionEntry(DictionaryBasedModel):
    """
    An entry of the **Description** :py:class:`CollectionProperty` as returned by :py:attr:`radar.description.items() <Radar.description>`.

    Each DescriptionEntry on an existing :py:class:`Radar` object loaded from the Radar API has the following properties:

    - text, :py:class:`str`
    - addedBy, a :py:class:`CommentAuthor` instance
    - addedByPerson, a :py:class:`Person` instance
    - addedAt, a :py:class:`datetime.datetime` instance

    Example::

        radar = radar_client.radar_for_id(1234)

        # read description
        description_entries = radar.description.items()
        # print latest entry
        print(description_entries[-1].text)

    **Creating New Entries:**

    :param str text: The text for the new entry.

    Example::

        # add new item to description
        entry = radarclient.DescriptionEntry()
        entry.text = u'foo bar baz'
        radar.description.add(entry)
        radar.commit_changes()

        # more compact
        radar.description.add(DescriptionEntry(text="foo bar baz"))

    """
    DEFAULT_PROPERTIES = [
        'text',
        'addedBy',
        'addedAt'
    ]

    def __init__(self, dictionary_representation=None, text=None, *extra_constructor_args):
        if dictionary_representation:
            super(DescriptionEntry, self).__init__(dictionary_representation, *extra_constructor_args)
            return
        super(DescriptionEntry, self).__init__({'text': text}, *extra_constructor_args)

    @cached_class_property
    def property_names(cls):
        return super(DescriptionEntry, DescriptionEntry).property_names + \
               DescriptionEntry.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(DescriptionEntry, cls).property_value_converter_map)
        map.update({
            'addedByPerson': PersonValueConverter
        })
        return map

    def __unicode__(self):
        return u'<DescriptionEntry {} by {} ({})>\n{}'.format(self.addedAt, self.addedBy.name, self.addedBy.email, self.text)

    @classmethod
    def webservice_url_for_radar(cls, radar, **kwargs):
        return radar.webservice_url('description')

    @classmethod
    def change_record_class_for_add(cls):
        return AddDescriptionEntryRadarChangeRecord


class DiagnosisEntry(DictionaryBasedModel):
    """
    An entry of the **Diagnosis** :py:class:`CollectionProperty` as returned by :py:attr:`radar.diagnosis.items() <Radar.diagnosis>`.

    .. note::
        Radar 8 uses the term "Discussion" instead of "Diagnosis". Earlier Radar app versions used the term "Diagnosis",
        which is still the term used by the API & in the API documentation.

    Each DiagnosisEntry on an existing :py:class:`Radar` object loaded from the Radar API has the following properties:

    - text, :py:class:`str`, the entry's text
    - addedBy, a :py:class:`CommentAuthor` instance
    - addedByPerson, a :py:class:`Person` instance
    - addedAt, a :py:class:`datetime.datetime` instance

    Example::

        radar = radar_client.radar_for_id(1234)

        # read diagnosis, all items
        diagnosis_items = radar.diagnosis.items()

        # read diagnosis, only user-provided
        diagnosis_items = radar.diagnosis.items(type='user')
        # print latest entry
        print(diagnosis_items[-1].text)

        # read diagnosis, only history
        diagnosis_items = radar.diagnosis.items(type='history')

    For more information about `parsing` the diagnosis history of a Radar, see :py:meth:`~radarclient.model.Radar.combined_history`.

    **Creating New Entries:**

    :param str text: The text for the new entry.
    :param bool suppress_mentions: [optional] If ``True``, will `not` parse the ``text`` for potential @ Mention
        instances and simply pass in the unaltered string instead. Defaults to ``False``. See more below about @
        Mentions support.

    Example::

        # add new item to diagnosis
        entry = radarclient.DiagnosisEntry()
        entry.text = u'foo bar baz'
        radar.diagnosis.add(entry)
        radar.commit_changes()

        # more compact
        radar.diagnosis.add(DiagnosisEntry(text="foo bar baz"))
        radar.commit_changes()

    **@ Mentions**

    Radar now supports tagging users in the Diagnosis (Discussion).† This can be utilized by embedding the output
    of the :py:meth:`Person.mention` method in the ``text`` of a new DiagnosisEntry.

        **†** `This functionality is limited to tagging Person accounts in the Diagnosis (Discussion), as of March 2025.
        Support for the Description and/or tagging other object types (such as an AD group) could potentially be
        added by the Radar API team in the future, and would require an update to this library for local support.`

    Example::

        # 1. Get the radar
        # 2. Get the full Component object for the radar's current component (to access its 'epm' property)
        # 3. Get the Person object matching that component's designated EPM.
        radar = radar_client.radar_for_id(123456789)
        full_component = radar_client.component_for_id(radar.component['id'])
        dri = full_component.epm

        # 4. Create a new DiagnosisEntry tagging the DRI
        entry = radarclient.DiagnosisEntry()
        entry.text = f"Tagging our EPM {dri.mention()} so this bug is included in the BRB currently in progress!"
        radar.commit_changes()

    For more information about `reading` @ Mention data from an existing Radar, see :py:class:`Mention`.

    """
    MENTIONS_REGEX = r'\[([0-9]+)\]\(adir://employees/\1\)'
    DEFAULT_PROPERTIES = [
        'addedAt',
        'addedBy',
        'addedByPerson',
        'text'
    ]

    def __init__(self, dictionary_representation=None, text=None, suppress_mentions=False, *extra_constructor_args):
        if dictionary_representation:
            super(DiagnosisEntry, self).__init__(dictionary_representation, *extra_constructor_args)
            return
        super(DiagnosisEntry, self).__init__({'text': text}, *extra_constructor_args)
        self.suppress_mentions = suppress_mentions
        self.mention_strings = []

    @cached_class_property
    def property_names(cls):
        return super(DiagnosisEntry, DiagnosisEntry).property_names + DiagnosisEntry.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(DiagnosisEntry, cls).property_value_converter_map)
        map.update({
            'addedByPerson': PersonValueConverter
        })
        return map

    def __unicode__(self):
        return u'<DiagnosisEntry {} by {} ({})>\n{}'.format(self.addedAt, self.addedBy.name, self.addedBy.email, self.text)

    @classmethod
    def webservice_url_for_radar(cls, radar, **kwargs):
        type = kwargs.get('type', 'all')
        return radar.webservice_url('diagnosis', type)

    @classmethod
    def change_record_class_for_add(cls):
        return AddDiagnosisEntryRadarChangeRecord


class Mention(DictionaryBasedModel):
    """
    Represents an element of the `mentions` list property of a :py:class:`Radar` object, specifically when using
    ``additional_fields=['mentions']`` in the retrieval method for said Radar. It is related to tagging users in
    the Diagnosis (Discussion) via the @ Mention functionality.

    You should not need to instantiate this class yourself. It is provided for clients intending to implement the
    `displaying` of @ Mentions in Diagnosis (Discussion) entries.

    Mention objects typically have the following properties:

    - ``clientMetadata`` (:py:class:`dict`), a field to store any client metadata*
    - ``context`` (:py:class:`str`), either ``DISCUSSION`` or ``DESCRIPTION``†
    - ``details.person`` (:py:class:`Person`)
    - ``entityId`` (:py:class:`int`), the DSID of the subject :py:class:`Person`
    - ``entityType`` (:py:class:`str`), currently limited to ``Person``†
    - ``mentionedTimestamp`` (:py:class:`datetime.datetime`), corresponding to the ``addedAt`` value of the :py:class:`DiagnosisEntry` containing the @ Mention

    For more information, see :py:class:`DiagnosisEntry` and :py:meth:`Person.mention`.

        ***** `The 'clientMetadata' property doesn't appear to be utilized, as of March 2025.`

        **†** `This functionality is limited to tagging Person accounts in the Diagnosis (Discussion), as of March 2025.
        Support for the Description and/or tagging other object types (such as an AD group) could potentially be
        added by the Radar API team in the future, and would require an update to this library for local support.`

    """
    DEFAULT_PROPERTIES = [
        'clientMetadata',
        'context',
        'details',
        'entityId',
        'entityType',
        'mentionedTimeStamp'
    ]

    @cached_class_property
    def property_names(cls):
        return super(Mention, Mention).property_names + Mention.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Mention, cls).property_value_converter_map)
        map.update({
            'clientMetadata': DotNotationDictionaryValueConverter,
            'details': MentionDetailsValueConverter,
            'mentionedTimeStamp': ISO8601UTCDateValueConverter
        })
        return map

    def __unicode__(self):
        return u'<Mention for {} at {}>'.format(self.details, self.mentionedTimeStamp.strftime('%Y-%m-%dT%H:%M:%S%z'))


class MentionDetails(DictionaryBasedModel):
    """
    Used for the nested 'details' property of a :py:class:`Mention` object.

    :meta private:
    """
    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(MentionDetails, cls).property_value_converter_map)
        map.update({
            'person': PersonValueConverter,
        })
        return map

    def __unicode__(self):
        if self.person:
            return self.person.__unicode__()
        return 'None'


class Keyword(DictionaryBasedModel):
    """
    Represents a Keyword in Radar.

    Keyword objects can be loaded in multiple ways:

    1. As part of a :py:class:`Radar` object by including ``keywords`` in ``additional_fields`` or calling :py:meth:`Radar.keywords`.
    2. From direct-retrieval methods such as :py:meth:`~radarclient.client.RadarClient.keywords_for_component`, \
    :py:meth:`~radarclient.client.RadarClient.find_keywords`, :py:meth:`~radarclient.client.RadarClient.keywords_for_ids`, \
    or :py:meth:`~radarclient.client.RadarClient.keywords_for_name`.

    Keyword objects loaded from :py:class:`Radar` objects `always` have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str`, the user-visible keyword name

    Keyword objects loaded from direct-retrieval methods can `also` include some of the following additional properties:

    - autoAttached / isAutoAttached, :py:class:`bool`, indicates whether the keyword is automatically attached to Radars filed to the defining component
    - closed / isClosed, :py:class:`bool`, indicates whether the keyword is closed
    - copiedOnClone / isCopiedOnClone, :py:class:`bool`, indicates whether the keyword is copied when a problem it is attached to is cloned
    - component, the defining :py:class:`Component`
    - definedComponentId, :py:class:`int`, provided by the API response and used to determine the ``component`` above`
    - description, :py:class:`str`, the keyword description
    - inherited, :py:class:`bool`, indicates whether or not the keyword was inherited from a parent Component
    - source, :py:class:`str`, the keyword source type (Public, Personal) or a shared keyword set name
    - type, :py:class:`str`, the keyword type. Valid values are: ``Normal``, ``Personal``, ``Shared``, ``Global``, ``Restricted``, ``Restricted Remove``

    .. note::
        Some of the properties shown above are listed with two variants, with an ``is`` prefix and without.
        The reason for this is that there are multiple API calls that return these objects, and the server
        API is inconsistent.

        At the Python level, we let you use either variant when accessing the property
        on the Keyword object. However when specifying the property name in the ``additional_fields``
        parameter of :py:meth:`~radarclient.client.RadarClient.find_keywords`, :py:meth:`~radarclient.client.RadarClient.keywords_for_ids`, \
        or :py:meth:`~radarclient.client.RadarClient.keywords_for_name`, you have to use the variant with the ``is`` prefix.

    Example::

        # load a keyword if its ID is known
        keyword = radar_client.keywords_for_ids([196144], additional_fields=['component']])[0]
        print('{}: {} ({}/{})'.format(keyword.id, keyword.name, keyword.component.name, keyword.component.version))

        # get keywords associated to a Radar
        radar = radar_client.radar_for_id(1234)
        for kw in radar.keywords():
            print('{}: {}'.format(kw.id, kw.name))

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = ['id', 'name']
    PROPERTY_KEYNAME_MAP = {
        'isClosed': 'closed',
        'isCopiedOnClone': 'copiedOnClone',
        'isAutoAttached': 'autoAttached',
    }
    BASE_URL = 'keywords'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)
    URL_COMPONENTS_FOR_FIND = (BASE_URL, 'find')
    MAX_BATCH_SIZE = 200  # Approximately the max # of 7-digit keyword IDs that fit into a single 2048-character URL

    def __init__(self, dictionary_representation=None, component=None, *extra_constructor_args):
        self.id = None
        # API v2.2 embeds most of the payload in a nested dictionary.
        if 'keyword' in dictionary_representation:
            nested_object = dictionary_representation['keyword']
            assert isinstance(nested_object, dict)
            dictionary_representation.update(nested_object)
            del(dictionary_representation['keyword'])
        super(Keyword, self).__init__(dictionary_representation, *extra_constructor_args)
        if component:
            self.component = component
        return

    @cached_class_property
    def property_names(cls):
        return super(Keyword, Keyword).property_names + Keyword.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Keyword, cls).property_value_converter_map)
        map.update({
            'component': ComponentValueConverter,
        })
        return map

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Keyword, cls).keyname_map)
        map.update(Keyword.PROPERTY_KEYNAME_MAP)
        return map

    def __unicode__(self):
        return u'<Keyword {} "{}">'.format(self.id, self.name)


class KeywordAssociation(DictionaryBasedModel):
    """
    An object that captures information about the association of a keyword to a Radar. It has the following properties:

    - keyword, :py:class:`Keyword`, the keyword instance
    - addedBy, :py:class:`Person`, the user that assigned the keyword to the bug
    - addedAt, :py:class:`datetime.datetime`, the time at which the keyword was assigned to the bug

    Example::

        radar = radar_client.radar_for_id(1234)
        for ka in radar.keyword_associations():
            print('Keyword {}/{} assigned by {} at {}'.format(ka.keyword.id, ka.keyword.name, ka.addedBy, ka.addedAt))

    """
    DEFAULT_PROPERTIES = [
        'keyword',
        'addedBy',
        'addedAt'
    ]

    @cached_class_property
    def property_names(cls):
        return super(KeywordAssociation, KeywordAssociation).property_names + \
               KeywordAssociation.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(KeywordAssociation, cls).property_value_converter_map)
        map.update({
            'keyword': KeywordValueConverter,
            'addedBy': PersonValueConverter,
        })
        return map


class CCMembership(DictionaryBasedModel):
    """
    An object that captures information about a person's CC subscription to a Radar,
    as returned by :py:attr:`radar.cc_memberships.items() <Radar.cc_memberships>`.

    Each entry has the following properties:

    - person, :py:class:`Person`, the person instance
    - isProblemVisible, :py:class:`bool`, whether the person is able to view the problem and receive CC notifications

    Example::

        radar = radar_client.radar_for_id(1234)
        for cc in radar.cc_memberships.items():
            print('CC {} can{} view the problem'.format(cc.person.email, '' if cc.isProblemVisible else 'not'))

    """
    DEFAULT_PROPERTIES = [
        'person',
        'isProblemVisible'
    ]

    @cached_class_property
    def property_names(cls):
        return super(CCMembership, CCMembership).property_names + CCMembership.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(CCMembership, cls).property_value_converter_map)
        map.update({
            'person': PersonValueConverter,
        })
        return map

    @classmethod
    def value_converter_class_for_self(cls, variant=None):
        return CCMembershipValueConverter

    @classmethod
    def webservice_url_for_radar(cls, radar, **kwargs):
        return radar.webservice_url('cc-list')

    def update_webservice_url_for_radar(self, radar, **kwargs):
        return radar.webservice_url('cc-list', self.person.dsid)

    @classmethod
    def change_record_class_for_add(cls):
        return AddCCMembershipRadarChangeRecord

    @classmethod
    def change_record_class_for_delete(cls):
        return DeleteCCMembershipRadarChangeRecord

    def __unicode__(self):
        return u'<CCMembership person {} isProblemVisible {}>'.format(self.person, self.isProblemVisible)


class RadarEnclosureTransferDelegate(object):
    """
    This is an abstract base class from which you can derive
    a custom transfer delegate for the Enclosure (Attachments/Pictures) API.

    Transfer delegates participate in the enclosure upload
    or download process. They receive upload/download progress updates
    and can optionally make some policy decisions.

    To use a transfer delegate, subclass this class and
    override one or more methods, and then create an instance
    of the class and set that instance as the ``transfer_delegate``
    property on the appropriate Enclosure subclass instance.

    The system will call your override methods during various
    points in the transfer process. See the documentation for
    the methods you can override below.

    Here's an example for deriving a delegate class, this one
    logs the progress to a file or stdout::

        class ProgressLoggingTransferDelegate(radarclient.RadarEnclosureTransferDelegate):

            def __init__(self, file_handle=sys.stdout, should_close=False):
                self.file_handle = file_handle
                self.should_close = should_close

            def did_start_transfer(self, enclosure):
                self.log_with_timestamp(f'Started transfer of "{enclosure.fileName}"')

            def did_end_transfer(self, enclosure, status):
                self.log_with_timestamp(f'Completed transfer of "{enclosure.fileName}" with status {status}')
                if self.should_close:
                    self.file_handle.close()

            def update_transfer_progress(self, enclosure, bytes_transferred, bytes_total):
                percentage = float(bytes_transferred) / float(bytes_total) * 100
                self.log_with_timestamp(f'Transfer of "{enclosure.fileName}" {percentage:.1f}% complete')

            def log_with_timestamp(self, message):
                timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                print('{} {}'.format(timestamp, message), file=self.file_handle)


    Here's an example of how to use it::

        radar = client.radar_for_id(1234)

        path = '/files/to/attach/really_big_file.dat'
        attachment = radar.new_attachment(os.path.basename(path))
        attachment.overwrite_existing_file = True
        attachment.set_upload_file(open(path, mode='rb'))

        log_file = open('/tmp/logfile.txt', 'w')
        attachment.transfer_delegate = ProgressLoggingTransferDelegate(log_file, should_close=True)

        radar.attachments.add(attachment)

        radar.commit_changes()

    This will produce the following output in ``/tmp/logfile.txt``::

        2020-11-19 15:53:45 Started transfer of "really_big_file.dat"
        2020-11-19 15:53:45 Transfer of "really_big_file.dat" 0.3% complete
        2020-11-19 15:53:45 Transfer of "really_big_file.dat" 0.7% complete
        2020-11-19 15:53:45 Transfer of "really_big_file.dat" 1.0% complete
        [...]
        2020-11-19 15:53:46 Transfer of "really_big_file.dat" 99.9% complete
        2020-11-19 15:53:46 Transfer of "really_big_file.dat" 100.0% complete
        2020-11-19 15:53:48 Completed transfer of "really_big_file.dat" with status TRANSFER_RESULT_SUCCESS

    """

    DUPLICATE_POLICY_RAISE_EXCEPTION = 'DUPLICATE_POLICY_RAISE_EXCEPTION'
    DUPLICATE_POLICY_IGNORE = 'DUPLICATE_POLICY_IGNORE'

    TRANSFER_RESULT_SUCCESS = 'TRANSFER_RESULT_SUCCESS'
    TRANSFER_RESULT_FAILED = 'TRANSFER_RESULT_FAILED'

    def __init__(self):
        pass

    def did_start_transfer(self, enclosure):
        """
        This method gets called when the transfer starts.

        :param RadarEnclosure enclosure: The enclosure that this particular call is about.

        :return: None

        """

        pass

    def did_end_transfer(self, enclosure, status):
        """
        This method gets called when the transfer ends.

        :param RadarEnclosure enclosure: The enclosure that this particular call is about.
        :param str status: One of ``RadarEnclosureTransferDelegate.TRANSFER_RESULT_SUCCESS`` or ``RadarEnclosureTransferDelegate.TRANSFER_RESULT_FAILED``, indicating success or failure.

        :return: None

        """
        pass

    def policy_for_duplicate_upload(self, enclosure):
        """
        This method gets called when an upload fails because the item already exists and the
        :py:class:`overwrite_existing_file <RadarEnclosure>` property was set to False.

        You can choose to raise an exception or to silently ignore the failure by returning
        the appropriate value from this method.

        :param RadarEnclosure enclosure: The enclosure that this particular call is about.
        :return: One of ``RadarEnclosureTransferDelegate.DUPLICATE_POLICY_RAISE_EXCEPTION`` or ``RadarEnclosureTransferDelegate.DUPLICATE_POLICY_IGNORE``

        """
        return self.DUPLICATE_POLICY_RAISE_EXCEPTION

    def update_transfer_progress(self, enclosure, bytes_transferred, bytes_total):
        """
        This method gets called with progress updates during the transfer.

        :param RadarEnclosure enclosure: The enclosure that this particular call is about.
        :param int bytes_transferred: The number of bytes transferred at the time of this method call
        :param int bytes_total: The total number of bytes to be transferred

        :return: None

        """
        pass

    @classmethod
    def default_delegate(cls):
        return cls()


class EnclosureBase(DictionaryBasedModel):
    DEFAULT_PROPERTIES = []

    class ReadProgressReportingFileWrapper(object):

        def __init__(self, enclosure, target_file):
            self.enclosure = weakref.ref(enclosure)
            self.target_file = target_file
            self.bytes_read = 0

        def read(self, size=-1):
            buffer = self.target_file.read(size)
            self.bytes_read += len(buffer)
            bytes_total = self.enclosure().transfer_file_size()
            self.enclosure().transfer_delegate.update_transfer_progress(
                self.enclosure(), self.bytes_read, bytes_total
            )
            return buffer

        def __len__(self):
            return int(self.enclosure().fileSize)

        def __repr__(self):
            target_file_name = getattr(self.target_file, 'name', '(file path/name unknown)')
            enclosure_name = self.enclosure().fileName
            return '<{} wrapping file handle "{}" for enclosure "{}">'.format(type(self).__name__, target_file_name, enclosure_name)

    @cached_class_property
    def property_names(cls):
        return super(EnclosureBase, EnclosureBase).property_names + \
               EnclosureBase.DEFAULT_PROPERTIES

    def __init__(self, enclosure_data=None,
                 transfer_delegate=RadarEnclosureTransferDelegate.default_delegate()):
        if enclosure_data is None:
            enclosure_data = {}
        self.upload_content = None
        self.upload_file = None
        self.upload_file_close_callback = None
        self.fileSize = None
        self.download_file = None
        self.overwrite_existing_file = False
        self.transfer_delegate = transfer_delegate
        super(EnclosureBase, self).__init__(enclosure_data)

    def __del__(self):
        if self.upload_file is not None and self.upload_file_close_callback is not None:
            self.upload_file_close_callback(self.upload_file.target_file)

    def content_url(self, client=None):
        pass

    def content(self, client=None):
        """
        Fetches and returns the actual enclosure file content.

        This method loads the content into memory and is therefore only suitable for small files.
        Use :py:meth:`write_to_file` to stream larger files to a destination file handle in chunks.

        Example::

            radar = radar_client.radar_for_id(1234)

            # get the actual enclosure data
            picture = radar.pictures.items()[0]
            with open('/tmp/foo', 'wb') as f:
                f.write(picture.content())

            attachment = radar.attachments.items()[0]
            with open('/tmp/foo', 'wb') as f:
                f.write(attachment.content())

        """
        if self.upload_content:
            return self.upload_content
        elif self.upload_file:
            return self.upload_file
        try:
            content_url = self.content_url(client=client)
            request = client.request_for_url(content_url)
            self.configure_download_request(request)
            request.add_header('Accept', 'application/octet-stream')

            response = request.send()
            return response.data()
        except UnsuccessfulResponseException as exc_ure:
            err_status = exc_ure.code
            if err_status == 400 and hasattr(self, 'locked') and self.locked:
                err_reason = exc_ure.reason
                err_message = ('{} -- this attachment has been locked by the Radar infrastructure and '
                               'cannot be downloaded or altered').format(exc_ure.message)
                raise AttachmentLockedException(err_status, err_reason, err_message)
            else:
                raise exc_ure

    def content_download_file(self, continue_at=0, client=None):
        try:
            # The API servers currently don't support byte-range requests: radar:26411950
            continue_at = 0
            content_url = self.content_url(client=client)
            request = client.request_for_url(content_url)
            self.configure_download_request(request)
            request.add_header('Accept', 'application/octet-stream')
            if continue_at:
                request.add_header('Range', 'bytes={}-'.format(continue_at))
            response = request.send()
            response_file = response.file()
            if response_file:
                self.download_file = self.ReadProgressReportingFileWrapper(self, response_file)
            return self.download_file
        except UnsuccessfulResponseException as exc_ure:
            err_status = exc_ure.code
            if err_status == 400 and hasattr(self, 'locked') and self.locked:
                err_reason = exc_ure.reason
                err_message = ('{} -- this attachment has been locked by the Radar infrastructure and '
                               'cannot be downloaded or altered').format(exc_ure.message)
                raise AttachmentLockedException(err_status, err_reason, err_message)
            else:
                raise exc_ure

    def set_upload_content(self, data):
        """
        Sets the content for a new enclosure that is about to be attached to a Radar.

        This method loads the content into memory and is therefore only suitable for small files.
        Use :py:meth:`set_upload_file` for larger files.

        See examples at :py:meth:`Radar.new_picture` and :py:meth:`Radar.new_attachment`.
        """
        if hasattr(data, 'read'):
            raise TypeError("'read' attribute found on data object. Use set_upload_file for "
                            "file-like objects.")

        self.upload_content = data
        self.fileSize = len(data)

    def set_upload_file(self, file_obj, content_length=None, close_callback=lambda f: f.close()):
        """
        Sets the file-like object for a new enclosure that is about to be attached to a Radar.
        Unlike :py:meth:`set_upload_content`, this variant avoids reading the
        enclosure content into memory and should therefore be suitable for large enclosures.

        :param file file_obj: A file-like object from which to read the enclosure content.
        :param callable close_callback: An optional handler that gets called when the file handle is no longer needed. It gets passed the file-like object. Defaults to a handler that calls :py:meth:`~file.close` on the object.
        :param int content_length: An optional content length value. You must supply this if the file-like object has no :py:meth:`~file.fileno` attribute and the size can therefore not be determined with an :py:func:`~os.fstat` call.

        See examples at :py:meth:`Radar.new_picture` and :py:meth:`Radar.new_attachment`.

        """
        if not hasattr(file_obj, 'read'):
            raise TypeError("no 'read' attribute on file_obj.")

        if content_length is None:
            if not hasattr(file_obj, 'fileno'):
                raise TypeError("no 'fileno' attribute on file_obj and content_length not given.")

            self.fileSize = os.fstat(file_obj.fileno()).st_size
        else:
            self.fileSize = int(content_length)

        self.upload_file = self.ReadProgressReportingFileWrapper(self, file_obj)
        self.upload_file_close_callback = close_callback

    def write_to_file(self, target_file, continue_at=0, client=None):
        """
        Downloads the enclosure and writes it to the given file handle. This
        is suitable for large file downloads.

        :param file target_file: A file-like object to which to write the enclosure content.

        Example::

            radar = radar_client.radar_for_id(1234)

            attachment = radar.attachments.items()[0]
            with open('/tmp/radar-download-{}'.format(attachment.fileName), 'wb') as f:
                attachment.write_to_file(f)

        """
        if 'b' not in target_file.mode:
            raise Exception(
                'File handle {} was not opened in binary mode, please add "b" to the mode flags '
                'when opening the file'.format(
                    target_file))

        # The API servers currently don't support byte-range requests: radar:26411950
        continue_at = 0
        download_file = self.content_download_file(continue_at=continue_at, client=client)
        if continue_at:
            target_file.seek(0, os.SEEK_END)
        self.transfer_delegate.did_start_transfer(self)
        while True:
            chunk = download_file.read(128 * 1024)
            if not chunk:
                break
            target_file.write(chunk)
        self.transfer_delegate.did_end_transfer(
            self, RadarEnclosureTransferDelegate.TRANSFER_RESULT_SUCCESS
        )

    def configure_download_request(self, request):
        request.is_file_download_request = True

    def transfer_file_size(self):
        if self.fileSize is None:
            return None
        return int(self.fileSize)

    def __eq__(self, other):
        type_match = type(self) == type(other)
        radar_match = self.radar.id == other.radar.id
        filename_match = self.fileName == other.fileName
        return type_match and radar_match and filename_match

    def __ne__(self, other):
        return not (self == other)


class TSTTEnclosureBase(EnclosureBase):
    """
    Base enclosure class for TSTT family objects. Should not be instantiated on its own

    :meta private:
    """
    DEFAULT_PROPERTIES = [
        'addedAt',
        'addedBy',
        'fileName'
    ]
    identifier_attrs = ('_original_file_name', 'parent')

    def __init__(self, parent, file_name=None, enclosure_data=None):
        self.is_instantiating = True
        super(TSTTEnclosureBase, self).__init__(enclosure_data=enclosure_data)
        self.parent = parent
        if self.fileName is None:
            if file_name is None:
                raise ValueError('file_name must be provided if not creating object through API')
            else:
                self.fileName = file_name
        self._original_file_name = self.fileName
        self.content_url_components = None
        self.is_instantiating = False

    @cached_class_property
    def property_names(cls):
        return super(TSTTEnclosureBase, TSTTEnclosureBase).property_names + \
               TSTTEnclosureBase.DEFAULT_PROPERTIES

    def content_url(self, client=None):
        return client.webservice_url_for_path_components(*self.content_url_components)

    def content(self, client=None):
        """
        Fetches and returns the actual enclosure file content.

        This method loads the content into memory and is therefore only suitable for
        small files.
        Use :py:meth:`write_to_file` to stream larger files to a destination file handle
        in chunks.

        Example::

            tstt_object.load_attachments_and_pictures(radar_client)

            picture = tstt_object.pictures[0]
            with open('/tmp/pic', 'wb') as f:
                f.write(picture.content())

            attachment = tstt_object.attachments[0]
            with open('/tmp/attachment', 'wb') as f:
                f.write(attachment.content())

        """
        return super(TSTTEnclosureBase, self).content(client=client)

    def set_upload_content(self, data):
        """
        Sets the content for a new enclosure that is about to be attached to a TSTT object.

        See :py:meth:`~TestSuite.add_attachment` for the appropriate object type for examples

        """
        return super(TSTTEnclosureBase, self).set_upload_content(data)

    def set_upload_file(self, file_obj, content_length=None, close_callback=lambda f: f.close()):
        """
        Sets the file-like object for a new enclosure that is about to be attached to a Radar.
        Unlike :py:meth:`set_upload_content`, this variant avoids reading the
        enclosure content into memory and should therefore be suitable for large enclosures.

        :param file file_obj: A file-like object from which to read the enclosure content.
        :param callable close_callback: An optional handler that gets called when the file handle is no longer needed. It gets passed the file-like object. Defaults to a handler that calls :py:meth:`~file.close` on the object.
        :param int content_length: An optional content length value. You must supply this if the file-like object has no :py:meth:`~file.fileno` attribute and the size can therefore not be determined with an :py:func:`~os.fstat` call.

        See :py:meth:`~TestSuite.add_attachment` or :py:meth:`~TestSuite.add_picture` for the
        appropriate object type for examples

        """
        return super(TSTTEnclosureBase, self).set_upload_file(
            file_obj, content_length=content_length, close_callback=close_callback
        )

    def write_to_file(self, target_file, continue_at=0, client=None):
        """
        Downloads the enclosure and writes it to the given file handle. This
        is suitable for large file downloads.

        :param file target_file: A file-like object to which to write the enclosure content.
        :param int continue_at: Continue writing at this position
        :param RadarClient client: instance to use for downloading the file

        Example::

            tstt_object.load_attachments(radar_client)
            attachment = tstt_object.attachments[0]
            with open('/tmp/test_attachment', 'wb') as f:
                attachment.write_to_file(f, client=radar_client)

        """
        return super(TSTTEnclosureBase, self).write_to_file(
            target_file, continue_at=continue_at, client=client
        )

    def __setattr__(self, key, value):
        if hasattr(self, 'fileName') and key == 'fileName' and not self.is_instantiating:
            self.parent._add_change_record(ModifyFileTSTTChangeRecord(self, value))
        super(TSTTEnclosureBase, self).__setattr__(key, value)


class TSTTAttachment(TSTTEnclosureBase):
    """
    Represents a file attachment on a TSTT object.
    """
    DEFAULT_PROPERTIES = [
        'createdAt',
        'encodeType',
        'fileId',
        'fileSize',
        'lastModifiedAt',
        'privileges'
    ]
    identifier_attrs = ('fileId',)
    ENDPOINT_KEY = 'attachments'

    def __init__(self, parent, file_name=None, enclosure_data=None):
        super(TSTTAttachment, self).__init__(
            parent, file_name=file_name, enclosure_data=enclosure_data
        )
        self.content_url_components = parent.attachment_url_components + (self.fileName,)

    def __unicode__(self):
        return u'<TSTTAttachment "{}">'.format(self.fileName)

    @cached_class_property
    def property_names(cls):
        return super(TSTTAttachment, TSTTAttachment).property_names + \
               TSTTAttachment.DEFAULT_PROPERTIES


class TSTTPicture(TSTTEnclosureBase):
    """
    Represents a picture type attachment of a TSTT object
    """
    DEFAULT_PROPERTIES = []

    def __init__(self, parent, file_name=None, enclosure_data=None):
        super(TSTTPicture, self).__init__(
            parent, file_name=file_name, enclosure_data=enclosure_data)
        self.content_url_components = parent.pictures_url_components + (self._original_file_name,)

    @cached_class_property
    def property_names(cls):
        return super(TSTTPicture, TSTTPicture).property_names + \
               TSTTPicture.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<TSTTPicture "{}">'.format(self.fileName)


class RadarEnclosureBase(EnclosureBase):
    """
    Abstract base class for some Radar enclosure classes. You don't instantiate this directly
    but some of its methods are part of the API.

    :meta private:
    """
    DEFAULT_PROPERTIES = [
        'fileSize',
        'fileName'
    ]

    def __init__(self, enclosure_data=None, transfer_delegate=RadarEnclosureTransferDelegate.default_delegate()):
        if enclosure_data is None:
            enclosure_data = {}
        self.radar = None
        super(RadarEnclosureBase, self).__init__(enclosure_data)

    def set_parent_radar(self, radar):
        self.radar = radar

    def content_download_file(self, continue_at=0, client=None):
        if client is not None:
            client_to_use = client
        else:
            client_to_use = self.radar.client
        return super(RadarEnclosureBase, self).content_download_file(continue_at=continue_at,
                                                                     client=client_to_use)

    def write_to_file(self, target_file, continue_at=0, client=None):
        if client is not None:
            client_to_use = client
        else:
            client_to_use = self.radar.client
        super(RadarEnclosureBase, self).write_to_file(target_file, continue_at=continue_at,
                                                      client=client_to_use)

    @cached_class_property
    def property_names(cls):
        return super(RadarEnclosureBase, RadarEnclosureBase).property_names + \
               RadarEnclosureBase.DEFAULT_PROPERTIES


class RadarArchiveEnclosure(RadarEnclosureBase):
    """
    :meta private:
    """

    def set_parent_radar(self, radar):
        super(RadarArchiveEnclosure, self).set_parent_radar(radar)
        if not self.fileName:
            self.fileName = os.path.basename(self.content_url())

    def content_url(self, client=None):
        return self.radar.webservice_url('{}/{}-attachments.zip'.format(self.base_path(), self.radar.id))

    def configure_download_request(self, request):
        super(RadarArchiveEnclosure, self).configure_download_request(request)
        request.add_header('X-Download-All', 'true')

    def base_path(self):
        raise Exception('abstract method')


class RadarAttachmentArchiveEnclosure(RadarArchiveEnclosure):
    """
    :meta private:
    """

    def base_path(self):
        return 'attachments'


class RadarPictureArchiveEnclosure(RadarArchiveEnclosure):
    """
    :meta private:
    """

    def base_path(self):
        return 'pictures'


class RadarEnclosure(RadarEnclosureBase):
    """
    Represents a Radar screenshot or file attachment. It has the following properties:

    - fileSize, :py:class:`int`, the file size in bytes
    - fileName, :py:class:`str`, the filename
    - addedBy, :py:class:`Person`, the user that added the enclosure to the bug
    - addedAt, :py:class:`datetime.datetime`, the time at which the enclosure was added to the bug
    - transfer_delegate, :py:class:`RadarEnclosureTransferDelegate`, optional transfer delegate, see that class for details
    - upload_should_reset_read_by_assignee, :py:class:`bool`, lets you choose if uploading a file should reset the Radar's read flag
    - overwrite_existing_file, :py:class:`bool`, lets you choose if uploading a file that exists should overwrite the file or fail

    You should not need to use this class directly, instead you use one of its subclasses
    :py:class:`Picture` or :py:class:`Attachment`.

    Example::

        radar = radar_client.radar_for_id(1234)

        # list all pictures for a Radar
        for picture in radar.pictures.items():
            print('Picture: {} ({} bytes)'.format(picture.fileName, picture.fileSize))

        # list all attachments for a Radar
        for attachment in radar.attachments.items():
            print('Attachment: {} ({} bytes)'.format(attachment.fileName, attachment.fileSize))

    On upload of an enclosure the Radar's "Read by Assignee" flag is cleared, marking the
    Radar as unread. If you want to prevent that, you can set the
    upload_should_reset_read_by_assignee property to false:

    Example::

        radar = radar_client.radar_for_id(1234)
        attachment = radar.new_attachment('enclosure test.txt')
        attachment.set_upload_content('foo bar\\n'.encode())
        attachment.upload_should_reset_read_by_assignee = False
        radar.attachments.add(attachment)
        radar.commit_changes()

    Overwrite an existing attachment by setting the
    overwrite_existing_file property to True:

    Example::

        radar = radar_client.radar_for_id(1234)
        attachment = radar.new_attachment('enclosure test.txt')
        attachment.set_upload_content('foo bar\\n'.encode())
        attachment.overwrite_existing_file = True
        radar.attachments.add(attachment)
        radar.commit_changes()

    """
    DEFAULT_PROPERTIES = [
        'addedAt',
        'addedBy'
    ]

    def __init__(self, *args, **kwargs):
        self.upload_should_reset_read_by_assignee = True
        super(RadarEnclosure, self).__init__(*args, **kwargs)

    @cached_class_property
    def property_names(cls):
        return super(RadarEnclosure, RadarEnclosure).property_names + \
               RadarEnclosure.DEFAULT_PROPERTIES

    def content(self, client=None):
        if client is not None:
            client_to_use = client
        else:
            client_to_use = self.radar.client
        return super(RadarEnclosure, self).content(client=client_to_use)

    def content_download_file(self, continue_at=0, client=None):
        if client is not None:
            client_to_use = client
        else:
            client_to_use = self.radar.client
        return super(RadarEnclosure, self).content_download_file(continue_at=continue_at,
                                                                 client=client_to_use)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarEnclosure, cls).property_value_converter_map)
        map.update({
            'addedBy': PersonValueConverter,
            'privileges': DotNotationDictionaryValueConverter,
        })
        return map

    def __eq__(self, other):
        type_match = type(self) == type(other)
        radar_match = self.radar.id == other.radar.id
        filename_match = self.fileName == other.fileName
        return type_match and radar_match and filename_match

    def __ne__(self, other):
        return not (self == other)

    @classmethod
    def change_record_class_for_add(cls):
        return AddEnclosureRadarChangeRecord

    @classmethod
    def change_record_class_for_delete(cls):
        return DeleteEnclosureRadarChangeRecord


class Picture(RadarEnclosure):
    """
    Objects of this type represent a picture on a Radar, usually accessed through
    :py:attr:`radar.pictures.items() <Radar.pictures>`. This class has a sibling class: :py:class:`Attachment`.

    Instantiating new picture attachments for a :py:class:`Radar` can be done via :py:meth:`~radarclient.model.Radar.new_picture`.

    See :py:class:`RadarEnclosure` for examples and class methods.
    """
    def __unicode__(self):
        return u'<Picture "{}">'.format(self.fileName)

    def content_url(self, client=None):
        return self.webservice_url_for_radar(self.radar) + '/' + compat.urllib_url_quote(
            self.fileName.encode('utf8'))

    @classmethod
    def webservice_url_for_radar(cls, radar):
        return radar.webservice_url('pictures')


class Attachment(RadarEnclosure):
    """
    Objects of this type represent an attachment on a Radar, usually accessed through
    :py:attr:`radar.attachments.items() <Radar.attachments>`. This class has a sibling class (:py:class:`Picture`) and
    a subclass (:py:class:`AttachmentLink`).

    Instantiating `new` file attachments for a :py:class:`Radar` can be done via :py:meth:`Radar.new_attachment`.
    Downloading attachments into memory or local storage is documented in the :py:class:`RadarEnclosure` class.

    An Attachment has all the same properties as a :py:class:`RadarEnclosure` with three additional, optional properties:

    - ``locked``, :py:class:`bool`. If ``True``, the file cannot be downloaded or modified. See more below. \
    Defaults to ``False``.
    - ``links``, an optional list of :py:class:`AttachmentLink` objects, each one representing another Radar the file \
    is virtually attached ("linked") to. Defaults to an empty list.
    - ``sourceFile``, if this Attachment is actually a :py:class:`LinkedAttachment`, this property is an \
    :py:class:`AttachmentLink` object referencing the attachment's source Radar. Defaults to ``None``.

    An Attachment cannot be both a :py:class:`LinkedAttachment` (virtually attached from a different Radar) **and**
    linked to additional Radars. Hence, an Attachment can not have both its ``links`` and ``sourceFile`` properties
    defined simultaneously.

    **Locked Attachments**

    An Attachment that is **locked** has been restricted by the Radar infrastructure, typically for security reasons.
    Sometimes, locked attachments are later unlocked by the Radar infrastructure.

    .. warning::
        Locked Attachments **cannot be downloaded, renamed, or overwritten**. Attempts to do so will raise an
        :py:class:`~radarclient.exceptions.AttachmentLockedException`. However, they `can` be deleted.

    See :py:class:`RadarEnclosure`, :py:class:`LinkedAttachment`, and :py:class:`AttachmentLink` for additional
    details, examples, and class methods.

    """
    def __init__(self, enclosure_data=None):
        if enclosure_data is None:
            enclosure_data = {}
        self.locked = True if enclosure_data.get('archiveStatus') == 'ARCHIVED' else False
        super(Attachment, self).__init__(enclosure_data)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Attachment, cls).property_value_converter_map)
        map.update({
            'links': AttachmentLinkSourceListValueConverter,
            'sourceFile': AttachmentLinkValueConverter,
        })
        return map

    def __unicode__(self):
        return u'<Attachment "{}">'.format(self.fileName)

    def content_url(self, client=None):
        components = [compat.urllib_url_quote(i) for i in self.fileName.encode('utf8').split(b'/')]
        path = '/'.join(components)
        return self.webservice_url_for_radar(self.radar) + '/' + path

    def configure_download_request(self, request):
        super(Attachment, self).configure_download_request(request)
        if self.fileId:
            request.add_header('X-Attachment-File-Key', compat.urllib_url_quote(compat.file_output_representation_for_unicode_string(self.fileId)))
            request.add_header('X-File-Size', str(self.fileSize))
            if hasattr(self, 'encodeType') and self.encodeType:
                request.add_header('X-Encoding-Key', self.encodeType)

    @classmethod
    def webservice_url_for_radar(cls, radar):
        return radar.webservice_url('attachments')


class LinkedAttachment(Attachment):
    """
    A custom class representing a virtual attachment, linked from and actually stored on another Radar.

    A LinkedAttachment has all the same properties as an :py:class:`Attachment` with some additional properties:

    - ``source_radar_id``
    - ``sourceFile``, an instance of :py:class:`AttachmentLink` referencing the attachment's source Radar.

    See :py:class:`Attachment`, :py:class:`RadarEnclosure`, and :py:class:`AttachmentLink` for additional details,
    examples, and class methods.

    """
    def __init__(self, enclosure_data=None):
        if enclosure_data is None:
            enclosure_data = {}
        super(LinkedAttachment, self).__init__(enclosure_data)
        self.source_radar_id = self.sourceFile.linked_radar_id

    def __unicode__(self):
        return u'<LinkedAttachment "{}" from rdar://{}>'.format(self.fileName, self.source_radar_id)


class NamedBuild(DictionaryBasedModel):
    """
    Represents a build that has a name, used for a Radar's ``buildInfo`` collection property.

    Build objects have the following properties:

    - name

    Note that you can use a :py:class:`Build` instance where a :py:class:`NamedBuild` instance
    is expected, but you can't swap them the other way around. Currently for example that
    means you can pass an item returned from the ``foundInBuild`` collection property into the one
    for ``buildInfo``, but not the other way around.

    Example::

        radar = radar_client.radar_for_id(1234, additional_fields=['buildInfo'])
        builds = radar.buildInfo.items()
        for build in builds:
            print('BuildInfo "{}"'.format(build.name))
        radar.buildInfo.add(radarclient.NamedBuild({'name': 'Foobar19A409'}))
        radar.commit_changes()

    """
    identifier_attrs = ('name',)
    DEFAULT_PROPERTIES = ['name']

    @cached_class_property
    def property_names(cls):
        return super(NamedBuild, NamedBuild).property_names + NamedBuild.DEFAULT_PROPERTIES

    def __unicode__(self):
        return u'<Build {}>'.format(self.name)

    def radar_update_value(self, protocol_version):
        assert protocol_version
        if protocol_version >= RadarProtocolVersion('2.1'):
            # Based on discussions with the Radar API team. The key here
            # is indeed "id", but buildInfo remains a free-form text field
            # not objects that can be identified with an ID. However, the server
            # still expects the free form string wrapped in this structure with
            # an ID key.
            return {'id': str(self.name)}
        else:
            return self.name

    @classmethod
    def change_record_class_for_add(cls):
        return AddBuildRadarChangeRecord

    @classmethod
    def change_record_class_for_delete(cls):
        return DeleteBuildRadarChangeRecord


class Build(NamedBuild):
    """
    Represents a build that is identified with an identifier, used in a Radar's build-related collection properties.

    You should not need to instantiate objects of this class yourself.

    Build objects typically have the following properties:

        From a :py:class:`Radar` object:

        - id, :py:class:`int`
        - name, :py:class:`str`

        Using :py:meth:`~radarclient.client.RadarClient.builds_for_component`:

        - id, :py:class:`int`
        - name, :py:class:`str`
        - component, the defining :py:class:`Component`
        - definedComponentId, :py:class:`int`
        - startDate, :py:class:`datetime.datetime`
        - endDate, :py:class:`datetime.datetime`
        - closed, :py:class:`bool`
        - inherited, :py:class:`bool`

    Example::

        radar = radar_client.radar_for_id(1234, additional_fields=['fixedInBuild'])
        component = radar_client.component_for_id(514369)
        builds = radar_client.builds_for_component(component)
        build_foo, = [b for b in builds if b.name == 'Foo19A409']
        build_bar, = [b for b in builds if b.name == 'Bar19A409']

        builds = radar.fixedInBuild.items()
        for build in builds:
            print('Fixed in build: "{}"'.format(build.name))
        radar.fixedInBuild.add(build_foo)
        radar.fixedInBuild.delete(build_bar)
        radar.commit_changes()

    """
    identifier_attrs = ('id',)
    DEFAULT_PROPERTIES = [
        'id',
        'startDate',
        'endDate',
        'closed',
        'inherited'
    ]
    PROPERTY_KEYNAME_MAP = {
        'beginsAt': 'startDate',
        'endsAt': 'endDate',
        'isClosed': 'closed'
    }

    def __init__(self, dictionary_representation=None, component=None, *extra_constructor_args):
        self.id = None
        # API v2.2 embeds most of the payload in a nested dictionary.
        if 'build' in dictionary_representation:
            nested_object = dictionary_representation['build']
            assert isinstance(nested_object, dict)
            dictionary_representation.update(nested_object)
            del(dictionary_representation['build'])
        super(Build, self).__init__(dictionary_representation, *extra_constructor_args)
        return

    @cached_class_property
    def property_names(cls):
        return super(Build, Build).property_names + Build.DEFAULT_PROPERTIES

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(Build, cls).keyname_map)
        map.update(Build.PROPERTY_KEYNAME_MAP)
        return map

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Build, cls).property_value_converter_map)
        map.update({
            'startDate': ISO8601UTCDateValueConverter,
            'endDate': ISO8601UTCDateValueConverter,
        })
        return map

    def __unicode__(self):
        return u'<Build {} {}>'.format(self.id, self.name)

    def radar_update_value(self, protocol_version):
        assert protocol_version
        if protocol_version >= RadarProtocolVersion('2.1'):
            return {'id': str(self.id)}
        else:
            return self.id


class RadarPlaceholder(DictionaryBasedModel):
    """
    Represents a placeholder for a Radar instance in cases where nothing but the Radar's ID is known.

    This is returned by :py:meth:`~radarclient.client.RadarClient.create_radar` if the bug was filed into a dropbox
    component to which the current user does not have access.

    There is a single property named ``id`` that lets you get the ID of the newly created Radar.

    To distinguish placeholders from regular instances without having to perform class checks
    you can query the ``is_placeholder`` method. It will return ``True`` for placeholders and
    ``False`` for full Radar objects.

    """

    @classmethod
    def is_placeholder(cls):
        return True


class Radar(DictionaryBasedModel):
    """
    Represents a single Radar (Problem).

    You should not need to instantiate objects of this class yourself. You can get :py:class:`Radar` instances
    for existing bugs through :py:meth:`~radarclient.client.RadarClient.radars_for_ids` or :py:meth:`~radarclient.client.RadarClient.find_radars`. You
    can create new Radars with :py:meth:`~radarclient.client.RadarClient.create_radar`.

    Most Radar Web API properties are directly mapped to properties on instances of this class.
    Some collection-type properties such as description or diagnosis entries are wrapped in other
    classes documented here.

    For backwards-compatibility reasons, the value of the ``component`` property on a Radar
    instance is a dictionary instead of a :py:class:`Component`.  That property started out as a
    raw dictionary and it was later changed so that the property could be *set* to both
    a raw dictionary but also to an instance of the :py:class:`Component` class. That class
    was introduced to properly model a component.

    As of version 1.1 of the Radar server API (version 3.23 of this library), which was introduced in early 2019,
    the following build-related attributes changed from having simple scalar values to multi-valued lists:

    - buildInfo
    - fixedInBuild
    - foundInBuild
    - mustBeFixedInBuild
    - verifiedInBuild

    That means that like other multi-valued attributes, they are now backed by a :py:class:`CollectionProperty`
    with an item class of :py:class:`NamedBuild` for ``buildInfo`` and :py:class:`Build` for the other four.
    See the documentation for those two classes for some usage examples.

    """
    identifier_attrs = ('id',)
    build_attrs = {'buildInfo': NamedBuild, 'fixedInBuild': Build, 'foundInBuild': Build, 'mustBeFixedInBuild': Build, 'verifiedInBuild': Build}
    BASE_URL = 'problems'
    BASE_URL_COMPONENTS_FOR_KEY_VALUES = (BASE_URL,)

    PROBLEM_DEFAULT_FIELDS = {
        'assignee',
        'assigneeLastModifiedAt',
        'category',
        'classification',
        'component',
        'configurationSummary',
        'counts',
        'createdAt',
        'dri',
        'duplicateOfProblemID',
        'fingerprint',
        'fixOrder',
        'hasReleaseNotes',
        'hasSourceChanges',
        'hasWorkaround',
        'id',
        'isExternallyViewable',
        'isReadByAssignee',
        'lastModifiedAt',
        'milestone',
        'originator',
        'priority',
        'reproducible',
        'resolution',
        'state',
        'substate',
        'tentpole',
        'title',
    }

    def __init__(self, problem_data, client, requested_fields, relationship_parser=None):
        # relationship_parser added for rdar://117783608 (Instantiating RadarRunnerSession fails during parsing of
        # related radars
        self.client = client
        self.reset_keyword_associations()
        self.reset_milestone_associations()
        super(Radar, self).__init__(problem_data)

        self.requested_fields = requested_fields

        # These collection properties could be pre-populated by the Radar data
        self.description = CollectionProperty('description', self, DescriptionEntry, problem_data.get('description'))
        """
        A :py:class:`CollectionProperty` attribute that provides access to the Radar's description entries.

        See the :py:class:`DescriptionEntry` class for more information and usage examples.
        """

        self.diagnosis = CollectionProperty('diagnosis', self, DiagnosisEntry, problem_data.get('diagnosis'))
        """
        A :py:class:`CollectionProperty` attribute that provides access to the Radar's diagnosis entries.

        See the :py:class:`DiagnosisEntry` class for more information and usage examples.
        """

        self.attachments = AttachmentCollectionProperty('attachments', self, Attachment, problem_data.get('attachments'))
        """
        A :py:class:`CollectionProperty` subclass attribute that provides access to the Radar's attachments.

        See the :py:class:`Attachment` and :py:class:`LinkedAttachment` classes for more information and usage examples.
        """

        self.pictures = CollectionProperty('pictures', self, Picture, problem_data.get('pictures'))
        """
        A :py:class:`CollectionProperty` attribute that provides access to the Radar's pictures.

        See the :py:class:`Picture` class for more information and usage examples.
        """

        self.other_related_items = CollectionProperty('other_related_items', self, OtherRelatedItem, problem_data.get('otherRelatedItems'))
        """
        A :py:class:`CollectionProperty` attribute that provides access to the Radar's other related items entries.

        See the :py:class:`OtherRelatedItem` class for more information and usage examples.
        """

        # These collection properties must be pre-populated by the Radar data if they are used later on
        for key, item_class in self.build_attrs.items():
            value = None
            if key in requested_fields:
                assert hasattr(self, 'builds'), '"builds" entry requested but not found in problem response data'
                assert key in self.builds, '"{}" entry requested but not found in problem response data "builds" subdictionary'.format(key)
                value = self.builds[key]
            setattr(self, key, CollectionProperty(key, self, item_class, value))

        if hasattr(self, 'builds'):
            del self.builds

        # These collection properties can't be pre-populated by the Radar data
        self.cc_memberships = CollectionProperty('cc_memberships', self, CCMembership)
        """
        A :py:class:`CollectionProperty` attribute that provides access to the Radar's CC subscriptions.

        See the :py:class:`CCMembership` class for more information and usage examples.
        """

        for key in [key for key in requested_fields if not hasattr(self, key)]:
            setattr(self, key, None)
            self.dictionary_representation_data[key] = None

        self.added_relationships = []
        related_problems_data = problem_data.get('relatedProblems')
        if relationship_parser is None:
            self._parse_related_problems_data(related_problems_data)
        else:
            relationship_parser(self, related_problems_data)

        if not (problem_data.get('id')):
            raise Exception('Input data for radar lacks id: {}'.format(problem_data))

        key_value_data = problem_data.get('keyValues')
        self.key_values = KeyValueStore(self.client, self, key_value_data)
        """
        A built-in :py:class:`KeyValueStore` attribute, equivalent to
        :py:meth:`~radarclient.client.RadarClient.key_values_for_radar_id`, used for retrieving, updating, creating,
        and deleting key-value pairs associated with the Radar. Each is represented by a :py:class:`KeyValuePair`.

        **By default, no key-value pairs will be loaded automatically.** :py:class:`~radarclient.model.KeyValuePair`
        objects can be loaded into the Radar's :py:class:`~radarclient.model.KeyValueStore` via
        :py:meth:`~radarclient.model.KeyValueStore.load_pairs_for_keys`.
        Alternatively, the Radar's :py:class:`KeyValueStore` can be pre-populated with **all** its key-value pairs by
        adding ``additional_fields=['keyValues']`` to the various Radar-retrieval methods. However, this may incur a
        performance and/or memory hit if there are many key-value pairs [unrelated to those that are needed] already
        associated with the Radar.

        Example::

            # 1. Accessing a specific key-value pair by key/name (no preloading needed):
            radar = radar_client.radar_for_id(123456789)
            test_dri = radar.key_values.value_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri)

            # 2a. Preloading all available key-value pairs:
            radar = radar_client.radar_for_id(123456789, additional_fields=['keyValues'])
            for key_name in radar.key_values.loaded_keys():
                print(key_name)

            # 2b. Loading specific key-value pairs:
            radar = radar_client.radar_for_id(123456789)
            radar.key_values.load_pairs_for_keys(['swe.amt.audio_qa.test_dri', 'swe.amt.audio_qa.aqs'])
            for kv_pair in radar.key_values.loaded_pairs():
                print(kv_pair)

            # 3. Adding a new key-value pair:
            radar = radar_client.radar_for_id(123456789)
            radar.key_values.add_key_value_pair(
                key_name='swe.amt.audio_qa.test_results_url',
                value='https://aqatestautomation.apple.com/results/index.html?radar_id=123456789'
            )

            # 4a. Updating the value of an existing key-value pair:
            radar = radar_client.radar_for_id(123456789)
            radar.key_values.update_value_for_key(
                key_name='swe.amt.audio_qa.test_config',
                value='D34/21A210c'
            )

            # 4b. Updating the value of an existing key-value pair via its KeyValuePair object:
            radar = radar_client.radar_for_id(123456789)
            test_dri_kv_pair = radar.key_values.key_value_pair_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri_kv_pair.addedBy)
            test_dri_kv_pair.update('John Q. Tester')

            # 5a. Deleting a key-value pair:
            radar = radar_client.radar_for_id(123456789)
            radar.key_values.delete_key_value_pair_for_key('swe.amt.audio_qa.test_dri')

            # 5b. Deleting the value of an existing key-value pair via its KeyValuePair object:
            radar = radar_client.radar_for_id(123456789)
            test_dri_kv_pair = radar.key_values.key_value_pair_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri_kv_pair.addedBy)
            test_dri_kv_pair.delete()

        For more information about the available methods, see :py:class:`~radarclient.model.KeyValueStore`.
        """

        # start capturing property updates
        self.change_records = []

    @classmethod
    def default_radar_property_value_converter_map(cls):
        map = dict(super(Radar, cls).property_value_converter_map)
        map.update({
            'assignee': PersonValueConverter,
            'originator': PersonValueConverter,
            'resolvedBy': PersonValueConverter,
            'dri': PersonValueConverter,
            'epm': PersonValueConverter,
            'milestone': MilestoneAsRadarPropertyValueConverter,
            'component': ComponentValueConverterEncodeOnly,

            'label': LabelValueConverter,

            'lastModifiedAt': ISO8601UTCDateValueConverter,
            'assigneeLastModifiedAt': ISO8601UTCDateValueConverter,
            'resolvedAt': ISO8601UTCDateValueConverter,
            'closedAt': ISO8601UTCDateValueConverter,

            'dateNeededCurrent': ISO8601DateOnlyValueConverter,
            'dateNeededOriginal': ISO8601DateOnlyValueConverter,
            'targetCompletionCurrent': ISO8601DateOnlyValueConverter,
            'targetCompletionOriginal': ISO8601DateOnlyValueConverter,
            'targetStartDate': ISO8601DateOnlyValueConverter,
            'keywords': KeywordAssociationListValueConverter,

            'event': EventValueConverter,
            'category': CategoryValueConverter,
            'tentpole': TentpoleValueConverter,

            'priority': SimpleIntegerValueConverter,
            'resolverID': SimpleIntegerValueConverter,
            'originatorID': SimpleIntegerValueConverter,
            'labelID': SimpleIntegerValueConverter,
            'fixOrder': SimpleIntegerValueConverter,
            'duplicateOfProblemID': SimpleIntegerValueConverter,
            'driID': SimpleIntegerValueConverter,
            'componentID': SimpleIntegerValueConverter,
            'assigneeID': SimpleIntegerValueConverter,
            'counts': DotNotationDictionaryValueConverter,
            'mentions': MentionListValueConverter
        })
        return map

    @cached_class_property
    def property_value_converter_map(cls):
        map = cls.default_radar_property_value_converter_map()
        return map

    def __unicode__(self):
        title_str = u' {}'.format(self.title) if hasattr(self, 'title') else ''
        return u'<rdar://problem/{}>{}'.format(self.id, title_str)

    def __setattr__(self, key, value):
        if hasattr(self, 'change_records') and hasattr(self, 'dictionary_representation_data') and key in list(self.dictionary_representation_data.keys()):
            change_record_class = self.change_record_class_for_property(key)
            self.add_change_record(change_record_class(self, key))
        super(Radar, self).__setattr__(key, value)

    def __lt__(self, other):
        return self.id < other.id

    @classmethod
    def property_change_record_map(cls):
        # This maps property names to their custom change record classes
        return {
            'milestone': MilestoneRadarChangeRecord,
        }

    def change_record_class_for_property(self, property_name):
        return self.property_change_record_map().get(property_name, SimplePropertyRadarChangeRecord)

    def add_change_record(self, record):
        if not hasattr(self, 'change_records'):
            return
        self.change_records.append(record)

    def clear_change_records(self):
        del(self.change_records[:])

    def reset_cached_data_on_change_records(self):
        for record in self.change_records:
            record.reset_cached_data(self)

    def commit_changes(self, dry_run=False):
        """
        Commits queued changes to the Radar database.

        :param bool dry_run: If ``True``, doesn't actually send the changes to the server, just prints them.

        Example::

            radar = radar_client.radar_for_id(1234)
            new_priority = 1
            radar.priority = new_priority
            radar.title = "new title"
            radar.commit_changes()

        """

        change_record_map = {}
        for change_record in self.change_records:
            record_class = type(change_record)
            change_record_map.setdefault(record_class, []).append(change_record)

        for record_class in list(change_record_map.keys()):
            record_class.optimize_change_record_map(change_record_map, protocol_version=self.client.protocol_version)

        for record_class, records in sorted(list(change_record_map.items()), key=lambda x: x[0].execution_priority(), reverse=True):
            record_class.commit_change_records_for_radar(records, self, dry_run=dry_run)

        self.reset_cached_data_on_change_records()
        self.clear_change_records()

    def apply_parsed_data(self, property_name, value):
        if property_name == 'keywords':
            assert isinstance(value, list)
            self.loaded_keyword_associations = value
        else:
            super(Radar, self).apply_parsed_data(property_name, value)

    def encode_user_friendly_property_value(self, property_name, value):
        if property_name == 'keywords':
            return KeywordListValueConverter.encode_user_friendly_value(value)
        else:
            return super(Radar, self).encode_user_friendly_property_value(property_name, value)

    def webservice_url(self, *args):
        args = [arg for arg in args if arg is not None]
        return self.client.webservice_url_for_path_components('problems', str(self.id), *args)

    def webservice_url_keywords(self):
        return self.webservice_url('keywords')

    def webservice_url_relationships(self):
        return self.webservice_url('related-problems')

    def webservice_url_attachment_archive(self):
        return self.webservice_url('attachments/{}-attachments.zip'.format(self.id))

    def webservice_url_components_for_key_values(self):
        return self.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (str(self.id), 'key-values')

    def combined_history(self, **kwargs):
        """
        A combination of a Radar's Problem History and Diagnosis History restructured into a single, chronological
        :py:class:`list` of uniform :py:class:`RadarHistoryModificationEvent` objects tracking modifications made to the
        Radar over time. It also includes a :py:class:`RadarHistorySnapshot` for each modification event.

        .. note::
            The source information needed for a Radar's combined history can be pre-loaded by adding
            ``additional_fields=['history', 'diagnosisHistory']`` to any method used to retrieve the Radar. This is
            typically `much` faster than waiting for combined_history() to load the historical data via separate API
            requests. Also, if utilizing Express Mode (see below) you only need to include ``additional_fields=['history']``.
            Finally, additional time savings can be had if the ``RadarHistorySnapshot`` objects aren't needed, by setting
            ``skip_snapshots`` to ``True``.

        :param bool skip_diagnosis_history: aka "Express Mode". Setting to ``True`` will skip the Diagnosis History and
            use only the Problem History object. Faster, but the history is limited to 11 specific attributes (see below).
        :param bool skip_snapshots: Will skip assembling the ``RadarHistorySnapshot`` objects. This can save processing
            time and memory for bugs that have very long histories, lots of related problems, diagnosis comments, etc.
        :param list[str] additional_snapshot_attributes: Similar to ``additional_fields`` for a Radar request, a list of
            extra attributes and/or actions to include in the :py:class:`RadarHistorySnapshot` objects. Does not apply
            in Express Mode.
        :param bool include_data_changes: By default change events with the ``data`` change_type are omitted. Set to
            ``True`` to include. Does not apply in Express Mode.

        Example::

            radar = radar_client.radar_for_id(1234)
            for modification_event in radar.combined_history():
                print(modification_event)
                print(modification_event.radar_history_snapshot)

        **Express Mode**

        The Diagnosis History is used to track changes to the `majority` of a Radar's attributes. However, the Problem
        History tracks a few specific, commonly-used attributes and can be pre-loaded separately (see above). If the
        scope of your combined_history usage can be limited to these attributes, you can use the
        ``skip_diagnosis_history=True`` argument and save on API response & processing time. If you are pre-loading
        historical data, for Express Mode you only need to include ``additional_fields=['history']``.

        As of API v2.2, the 11 attributes included in Express Mode (``skip_diagnosis_history=True``) are:

        - ``assignee``
        - ``category`` (name only)
        - ``component``
        - ``event`` (name only)
        - ``fixOrder``
        - ``isReadByAssignee``
        - ``lastModifiedAt``
        - ``milestone``
        - ``priority``
        - ``state``
        - ``tentpole`` (name only)

        Example::

            # Use Express Mode for faster API turnaround
            radar = radar_client.radar_for_id(1234)
            for modification_event in radar.combined_history(skip_diagnosis_history=True):
                print(modification_event)
                print(modification_event.radar_history_snapshot)

        By default, Diagnosis History changes with an change_type of ``data`` are omitted, but can be included by passing in an
        argument of ``include_data_changes=True``. These ``data`` change events typically include:

        - Attachment additions or deletions. The API response only includes `how many` attachments were attached or deleted at that time, not filenames. As such, it's mostly just noise, especially for Radars with lots of automated processing, for example by iTriage.
        - Changes to a Radar's Resolution denoted in string form. These are both inaccurate and extraneous; the proper from/to syntax is included with the correct ``resolution`` attribute elsewhere.
        - Scheduled Test Relationship additions or deletions. These appear to be valid, and are only available this way.

        Example::

            # include the change events for the 'data' change_type (attribute)
            radar = radar_client.radar_for_id(1234)
            for modification_event in radar.combined_history(include_data_changes=True):
                print(modification_event)
                print(modification_event.radar_history_snapshot)

        Finally, the ``additional_snapshot_attributes`` argument accepts a list of attributes (change_type values) to add to
        what is automatically included in the radar_history_snapshot data. See the :py:class:`RadarHistorySnapshot` class for more information.

        For more information, see :py:class:`RadarHistoryModificationEvent` and :py:class:`RadarHistorySnapshot`.

        """
        if not hasattr(self, '_combined_history') or not hasattr(self, '_combined_history_events'):
            max_attempts = 3
            attempts = 0
            exception = None
            while attempts < max_attempts:
                attempts += 1
                try:
                    self._combined_history = RadarHistory('combined_history', self, RadarHistoryModificationEvent)
                    self._combined_history_events = self._combined_history.events(**kwargs)
                    return self._combined_history_events
                except Exception as e:
                    exception = e
                    time.sleep(0.3)
            raise exception
        return self._combined_history_events

    def new_picture(self, filename):
        """
        Creates a new :py:class:`Picture` instance. You can then add content to it and
        schedule it for addition with ``radar.pictures.add()``, or schedule it for deletion
        with ``radar.pictures.delete()``.

        :param str filename: The filename for the new picture.

        Example::

            # addition
            radar = radar_client.radar_for_id(1234)
            picture = radar.new_picture('Mt. Fuji.jpg')
            with open('/Library/Desktop Pictures/Mt. Fuji.jpg', 'rb') as f:
                picture.set_upload_content(f.read())
            radar.pictures.add(picture)
            radar.commit_changes()

            # deletion
            radar = radar_client.radar_for_id(1234)
            picture = radar.new_picture('Mt. Fuji.jpg')
            radar.pictures.delete(picture)
            radar.commit_changes()

        """

        enclosure = Picture()
        enclosure.set_parent_radar(self)
        enclosure.fileName = filename
        return enclosure

    def new_attachment(self, filename):
        """
        Creates a new :py:class:`Attachment` instance. You can then add content to it and
        schedule it for addition with ``radar.attachments.add()``, or schedule it for deletion
        with ``radar.attachments.delete()``.

        :param str filename: The filename for the new attachment.

        Example::

            # addition
            radar = radar_client.radar_for_id(1234)
            attachment = radar.new_attachment('enclosure test.txt')
            attachment.set_upload_content('foo bar\\n'.encode())
            radar.attachments.add(attachment)
            radar.commit_changes()

            # addition - large file
            radar = radar_client.radar_for_id(1234)
            attachment = radar.new_attachment('large_file.tgz')
            attachment.set_upload_file(open('/tmp/largefile.tgz', 'rb'))
            radar.attachments.add(attachment)
            radar.commit_changes()

            # deletion
            radar = radar_client.radar_for_id(1234)
            attachment = radar.new_attachment('enclosure test.txt')
            radar.attachments.delete(attachment)
            radar.commit_changes()

        """
        enclosure = Attachment()
        enclosure.set_parent_radar(self)
        enclosure.fileName = filename
        return enclosure

    def attachment_archive_download_enclosure(self):
        """
        Returns an artificial enclosure that lets you download all attachments
        for the receiver as a zip archive.

        Example::

            radar = radar_client.radar_for_id(1234)
            archive_enclosure = radar.attachment_archive_download_enclosure()
            output_path = os.path.join('/tmp', archive_enclosure.fileName)
            with open(output_path, 'wb') as f:
                archive_enclosure.write_to_file(f)

        """
        enclosure = RadarAttachmentArchiveEnclosure()
        enclosure.set_parent_radar(self)
        return enclosure

    def picture_archive_download_enclosure(self):
        """
        Returns an artificial enclosure that lets you download all pictures
        for the receiver as a zip archive.

        Example::

            radar = radar_client.radar_for_id(1234)
            archive_enclosure = radar.picture_archive_download_enclosure()
            output_path = os.path.join('/tmp', archive_enclosure.fileName)
            with open(output_path, 'wb') as f:
                archive_enclosure.write_to_file(f)

        """
        enclosure = RadarPictureArchiveEnclosure()
        enclosure.set_parent_radar(self)
        return enclosure

    def _parse_related_problems_data(self, related_problems_data):
        """
        Pareses the dictionary returned by the radar API for relatedProblems

        :param related_problems_data: the dictionary returned by the API

        :return: None
        """
        if related_problems_data is None:
            self.loaded_relationships = None
        else:
            self.loaded_relationships = []

            for relationship_info in related_problems_data:
                relationship = Relationship(
                    relationship_info['relationType'],
                    self,
                    related_radar_id=relationship_info['problem']['id']
                )
                self.loaded_relationships.append(relationship)

    def _load_relationships(self):
        """
        Populates loaded_relationships with all relationships if loaded_relationships is None. Does not
        load Radar objects for the Relationships.

        :return: None
        """
        if self.loaded_relationships is not None:
            return
        request_header = self.client.create_requested_fields_header(['relatedProblems'])
        _, data = self.client.build_and_send_request(
            ('problems', self.id), additional_headers=[request_header]
        )

        self._parse_related_problems_data(data['relatedProblems'])

    def relationships(self, types=None, load_related_radars=True, error_callback=None):
        """
        Returns a list of :py:class:`Relationship` instances. For more information and examples, see that class.

        .. note::
            If you are planning to work with the related problems of a radar, it is recommended that you
            pass `relatedProblems` as an additional field when you first get the radar in question. This
            saves 1-2 seconds per radar as it removes the need for a second API call

        :param list types: A list of relationship types, if present the returned list is filtered to relationships whose type is in the list
        :param bool load_related_radars: If ``True`` (the default), the returned :py:class:`Relationship` instances have their ``related_radar``
                                         field populated. Passing ``False`` results in a performance improvement because the related radar isn't loaded.
        :param callable error_callback: An optional callable that gets called when there is an error
            loading a related radar per documentation on :py:meth:`~radarclient.client.RadarClient.radars_for_ids`
        :rtype: list[Relationship]
        """

        self._load_relationships()

        relationships = []
        if self.loaded_relationships is not None:
            relationships.extend(self.loaded_relationships)
        relationships.extend(self.added_relationships)
        to_return = [i for i in relationships if not types or i.type in types]

        if load_related_radars:
            related_radar_ids = [relation.related_radar_id for relation in to_return if
                                 relation.related_radar is None]
            additional_fields = list(set(self.requested_fields) - Radar.PROBLEM_DEFAULT_FIELDS)
            related_radars = self.client.radars_for_ids(
                related_radar_ids, additional_fields=additional_fields, error_callback=error_callback
            )
            related_radar_map = {radar.id: radar for radar in related_radars}

            for relationship in to_return:
                if relationship.related_radar is None:
                    if relationship.related_radar_id in related_radar_map:
                        relationship.related_radar = related_radar_map[relationship.related_radar_id]
                    elif not error_callback:
                        logger.error(u'Unable to load related radar {}'.format(relationship.related_radar_id))

        return to_return

    def all_relationships(self, delegate=None, _preceding=None, error_callback=None):
        """
        Returns a generator that produces a list of relationship chains. This lets you traverse
        the the entire relationship graph of a given Radar.

        :param object delegate: A delegate object that currently gets called for progress information and relationship traversal decisionmaking
        :param func error_callback: An error handling callback for
            :py:meth:`~radarclient.client.RadarClient.radars_for_ids`. The default will handle no access errors and
            cease traversing the chain at that point and will log an error

        The delegate object can implement any of these methods::

            class RelationshipTraversalDelegate(object):

                def should_follow_relationship(self, relationship):
                    return True / False

                def traversal_progress(self, processed_radar_count, total_radar_count):
                    pass

        Example::

            radar = radar_client.radar_for_id(1234)
            for relationship_chain in radar.all_relationships():
                print('relationship chain:')
                for relationship in relationship_chain:
                    print('from {} to {} type {}'.format(relationship.radar.id, relationship.related_radar.id, relationship.type))

        Example with delegate::

            class RadarStateTraversalDelegate:

                def __init__(self, accepted_states):
                    self.accepted_states = accepted_states

                def should_follow_relationship(self, relationship):
                    return relationship.related_radar.state in self.accepted_states

            delegate = RadarStateTraversalDelegate(['Analyze', 'Integrate'])

            radar = radar_client.radar_for_id(1234)
            for relationship_chain in radar.all_relationships(delegate=delegate):
                print('relationship chain:')
                for relationship in relationship_chain:
                    print('from {} to {} type {}'.format(relationship.radar.id, relationship.related_radar.id, relationship.type))

        """
        if _preceding is None:
            _preceding = []

        def _local_error_callback(radar_id, error):
            if isinstance(error, RadarAccessDeniedResponseException):
                logger.error(error)
            else:
                raise error

        if error_callback is None:
            error_callback = _local_error_callback

        for i in self.relationships(error_callback=error_callback):
            if _preceding:
                if _preceding[-1].radar.id == i.related_radar_id:
                    continue

            if delegate and callable(getattr(delegate, 'should_follow_relationship', None)):
                should_follow = delegate.should_follow_relationship(i)
                if not should_follow:
                    continue

            yield _preceding + [i]
            if i.related_radar_id in (i.radar.id for i in _preceding + [i]):
                continue
            if not i.related_radar:
                continue
            for j in i.related_radar.all_relationships(delegate=delegate, _preceding=_preceding + [i],
                                                       error_callback=error_callback):
                yield j

    def all_unique_relationships(self):
        """
        Like :py:meth:`Radar.all_relationships`, but each relationship is listed only once,
        i.e. inverse relationships of previously seen relationships are filtered out.

        """
        seen = set()
        for relationship_chain in self.all_relationships():
            relationship = relationship_chain[-1]
            inverse = relationship.inverse_relationship()
            if (relationship in seen) or (inverse in seen):
                continue
            seen.update([relationship, inverse])
            yield relationship_chain

    def related_radars(self, types=None):
        """
        Returns a list of related Radars.

        :param list types: An array of strings with the requested relationship types. Defaults to None, which returns all relationship types.

        Example::

            radar = radar_client.radar_for_id(1234)
            for related in radar.related_radars([Relationship.TYPE_CLONED_TO]):
                print('Radar {} cloned to {}'.format(radar.id, related.id))

        """
        return [i.related_radar for i in self.relationships(types) if i.related_radar]

    def ultimate_original(self, additional_fields=None, error_callback=None):
        """
        Climbs the dupe chain for a radar to find the ultimate original. If radar is not a dupe, returns
        ``self``. If an error_callback was provided and the current user does not have access to one of the
        Radars in the dupe chain, or the Radar fails to load for other reasons, this method returns None.

        :param list[str] additional_fields: A list of additional fields to load from the Radar Web API for
            the returned :py:class:`Radar`. Even if radar is not a dupe, the returned object will contain
            the requested fields.

        :param callable error_callback: An optional callable that gets called when there is an error
            loading a related radar.

        :rtype: :py:class:`Radar` or None
        :raise UnsuccessfulResponseException: if the current user does not have access to a radar
            in the dupe chain or there is an issue loading a related radar for a different reason AND
            no error_callback is passed in. If an error callback was passed in, the method returns None
            instead.
        """
        if error_callback is None:
            def _error_callback(failed_id, error):
                raise error
            error_callback = _error_callback

        if self.resolution != 'Duplicate':
            if additional_fields is not None:
                original = self.client.radar_for_id(self.id, additional_fields=additional_fields,
                                                    error_callback=error_callback)
            else:
                original = self
        else:
            url_components = ('problem', 'tree')
            # Docs say depth can be <= 1000 but the API raises an error for anything >= 10
            # rdar://104701336 (Problem Tree Depth Errors at depth more than 10)
            req_data = {'ids': [self.id], 'relationType': Relationship.TYPE_DUPLICATE_OF, 'depth': 10}
            status, data = self.client.build_and_send_json_request(url_components, req_data, method='POST')

            current_dict = data[0]
            while current_dict.get('relatedProblems') is not None:
                current_dict = current_dict['relatedProblems'][0]['problem']

            original = self.client.radar_for_id(current_dict['id'], additional_fields=additional_fields,
                                                error_callback=error_callback)

            # Guard against a dupe that is more than 10 layers deep
            if original is not None and original.resolution == 'Duplicate':
                original = original.ultimate_original(additional_fields=additional_fields,
                                                      error_callback=error_callback)
        return original

    def reset_relationships(self):
        self.loaded_relationships = None
        self.added_relationships = []

    def add_relationship(self, relationship):
        """
        Relates the receiver to another Radar.

        :param Relationship relationship: The relationship instance that captures the information to be stored to the Radar database.

        Example::

            radar = radar_client.radar_for_id(1234)
            radar2 = radar_client.radar_for_id(5678)
            relationship = Relationship(Relationship.TYPE_PARENT_OF, radar, radar2)
            radar.add_relationship(relationship)
            radar.commit_changes()

        Note that you can't add relationships of type TYPE_ORIGINAL_OF, TYPE_DUPLICATE_OF, TYPE_CLONE_OF, or TYPE_CLONED_TO
        this way.

        To mark a Radar as a duplicate of another one, use the ``duplicateOfProblemID`` property::

            radar = radar_client.radar_for_id(1234)
            original_radar_id = 5678
            radar.state = 'Verify'
            radar.resolution = 'Duplicate'
            radar.duplicateOfProblemID = original_radar_id
            radar.commit_changes()

        To clone a Radar, use the :py:meth:`~radarclient.client.RadarClient.clone_radar` method.

        """
        self.add_change_record(AddRelationshipRadarChangeRecord(self, relationship))
        self.added_relationships.append(relationship)

    def delete_relationship(self, relationship):
        """
        Unrelates the receiver from another Radar.

        :param Relationship relationship: The relationship instance that captures the information to be removed from the Radar database.

        Example::

            radar = radar_client.radar_for_id(1234)
            relationship = radar.relationships([Relationship.TYPE_PARENT_OF])[0]
            radar.delete_relationship(relationship)
            radar.commit_changes()

        """
        if self.loaded_relationships and relationship not in self.loaded_relationships:
            logger.warning(u'Radar {} does not have relationship {}'.format(self, relationship))
            return

        self._load_relationships()
        if self.loaded_relationships:
            self.loaded_relationships.remove(relationship)
        self.add_change_record(DeleteRelationshipRadarChangeRecord(self, relationship))

    def milestone_associations(self, milestone_override=None):
        """
        Returns the associated/available :py:class:`~Event`, :py:class:`~Category`, and :py:class:`~Tentpole` objects
        for the :py:class:`~Milestone` currently assigned to the radar, in the form of an
        :py:class:`~MilestoneAssociations` object.

        :param ~radarclient.model.Milestone milestone_override: [optional] Any milestone available in the radar's
            current component. The available milestones can be retrieved via
            :py:meth:`~radarclient.client.RadarClient.milestones_for_component`.

        For more information, see the `Fetch Milestone Associations API Docs`_.

        .. rubric:: Determining Milestone, Event, Category, and Tentpole

        Determining a valid combination of Milestone, Event, Category, and Tentpole for a radar actually involves using
        several different API endpoints (accessed via separate radarclient methods), some of them potentially multiple
        times.

        1. If the current radar does not have a milestone assigned (or you wish to use a different milestone), start \
        with :py:meth:`~radarclient.client.RadarClient.milestones_for_component` to determine the available \
        milestones for a component, and choose the appropriate Milestone. If necessary, save the updated Milestone via \
        :py:meth:`~commit_changes`.
        2. Use :py:meth:`~milestone_associations()` to determine the associated/available Events, Categories, and \
        Tentpoles associated with the radar's current Milestone, then assign the associated Event and Category.
        3. For `each` Tentpole associated with the chosen Milestone, you still need to make sure it's allowed with the \
        chosen Event and Category, via \
        :py:meth:`~radarclient.client.RadarClient.tentpoles_for_component` with ``include_associations=True``.
        4. Assign the Tentpole, and finally save everything via  :py:meth:`~commit_changes`.

        Example::

            # 1. Determine the available Milestones
            radar = radar_for_id(123456789)
            milestones = radar_client.milestones_for_component(radar.component)
            radar.milestone = milestones[1]
            radar.commit_changes()

            # 2. Find the associated Events, Categories, and tentpoles
            assoc = radar.milestone_associations()
            print(assoc)

            # 3. Assign an Event and Category
            radar.event = assoc.events[1]
            radar.category = assoc.categories[3]

            # 4. Assign a valid Tentpole
            tentpoles = radar_client.tentpoles_for_component(radar.component)
            print(tentpoles)
            # 4a. Choose the 2nd tentpole in the list, aka tentpoles[1], and make sure it's associated
            if tentpoles[1] in assoc.tentpoles:
                # 4b. Make sure the chosen Tentpole is allowed with the chosen Event and Category
                if radar.event in tentpoles[1].events and radar.category in tentpoles[1].categories:
                    radar.tentpole = tentpoles[1]
                    radar.commit_changes()

        """
        self.fetch_milestone_associations(milestone_override)
        return self.fetched_milestone_associations

    def fetch_milestone_associations(self, milestone_override):
        if self.fetched_milestone_associations is not None:
            return

        request_data = {}
        if milestone_override:
            milestone = milestone_override
            assert isinstance(milestone_override, Milestone), 'milestone_override must be a Milestone object'
            request_data['milestoneId'] = milestone_override.id
        elif self.milestone:
            milestone = self.milestone
            request_data['milestoneId'] = milestone.id
        else:
            milestone = None

        url = ('problems', self.id, 'fetchMilestoneAssociations')
        status, response = self.client.build_and_send_json_request(url, request_data, method='POST')
        if response_code_is_success(status):
            self.fetched_milestone_associations = MilestoneAssociations(response, milestone=milestone)

    def reset_milestone_associations(self):
        self.fetched_milestone_associations = None

    def keyword_associations(self):
        """
        Returns a list of :py:class:`KeywordAssociation` instances representing keywords assigned
        to the receiver. See that class for more information and examples.

        """
        self.load_keyword_associations()
        return self.loaded_keyword_associations + self.added_keyword_associations

    def keywords(self):
        """
        Returns a list of :py:class:`Keyword` instances for keywords assigned
        to the receiver. See that class for more information and examples.

        """
        return [association.keyword for association in self.keyword_associations()]

    def load_keyword_associations(self):
        if self.loaded_keyword_associations is not None:
            return

        url = self.webservice_url_keywords()
        request = self.client.request_for_json_url(url)

        status, data_list = self.client.send_request(request)
        if status == 404:
            data_list = []

        self.loaded_keyword_associations = []
        for data in data_list:
            keyword_association = KeywordAssociation(data)
            self.loaded_keyword_associations.append(keyword_association)

    def reset_keyword_associations(self):
        self.loaded_keyword_associations = None
        self.added_keyword_associations = []

    def add_keyword(self, keyword):
        """
        Adds a keyword to a Radar.

        :param ~radarclient.model.Keyword keyword: The keyword to be added

        Example::

            keyword = self.client.keywords_for_ids([52846])[0]
            radar = self.client.radar_for_id(12595023)
            radar.add_keyword(keyword)
            radar.commit_changes()

        """

        association = KeywordAssociation({})
        association.keyword = keyword
        self.add_change_record(AddKeywordRadarChangeRecord(self, association))
        self.added_keyword_associations.append(association)

    def remove_keyword(self, keyword):
        """
        Removes a keyword from a Radar.

        :param ~radarclient.model.Keyword keyword: The keyword to be removed

        Example::

            keyword = self.client.keywords_for_ids([52846])[0]
            radar = self.client.radar_for_id(12595023)
            radar.remove_keyword(keyword)
            radar.commit_changes()

        """

        association = KeywordAssociation({})
        association.keyword = keyword
        self.add_change_record(RemoveKeywordRadarChangeRecord(self, association))

    def add_cc(self, person):
        """
        Adds a cced person to a Radar.

        :param Person person: The person to be added

        Example::

            person = self.client.find_people(False, email="example@apple.com")[0]
            radar = self.client.radar_for_id(12595023)
            radar.add_cc(person)
            radar.commit_changes()

        """

        membership = CCMembership({})
        membership.person = person
        self.cc_memberships.add(membership)

    def delete_cc(self, person):
        """
        Deletes a cced person from a Radar.

        :param Person person: The person to be deleted

        Example::

            person = self.client.find_people(False, email="example@apple.com")[0]
            radar = self.client.radar_for_id(12595023)
            radar.delete_cc(person)
            radar.commit_changes()

        """

        membership = CCMembership({})
        membership.person = person
        self.cc_memberships.delete(membership)

    def clone_target_milestone(self, target_milestone, reason=None, dry_run=False):
        """
        The Target Milestones APIs were deprecated in Radar API v2.2 and are no longer available.
        """
        message = "The Target Milestones APIs were deprecated in Radar API v2.2 and are no longer available."
        raise DeprecatedMethodException(message)

    def webservice_url_add_person_to_security_list(self, person_dsid):
        return self.webservice_url('security-list/person', person_dsid)

    def webservice_url_add_group_to_security_list(self, group_name, group_type):
        return self.webservice_url('security-list', group_type, group_name)

    def add_person_to_security_list(self, person):
        """
        Adds a person to the security list for a radar

        :param Person person: The person to be added
        :return: bool
        """
        url = self.webservice_url_add_person_to_security_list(person.dsid)
        request = self.client.request_for_json_url(url, method='PUT')
        status, _ = self.client.send_request(request)

        return response_code_is_success(status)

    def add_group_to_security_list(self, group_name, group_type='access-group'):
        """
        Adds a group to the security list for a radar

        :param str group_name: The radar group to be added
        :param str group_type: The type of the group to add. One of ['access-groups', 'work-groups']
        :return: bool
        """
        url = self.webservice_url_add_group_to_security_list(group_name, group_type)
        request = self.client.request_for_json_url(url, method='PUT')
        status, _ = self.client.send_request(request)

        return response_code_is_success(status)

    def add_to_radar_board_sprint(self, board_id, sprint_id):
        """
        A convenience wrapper to add a :py:class:`Radar` object directly to a :py:class:`RadarBoardSprint` as a :py:class:`RadarBoardStory`

        :param int board_id: ID of the :py:class:`RadarBoard` to add the Radar to as a :py:class:`RadarBoardStory`
        :param int sprint_id: ID of the :py:class:`RadarBoardSprint` to add the Radar to as a :py:class:`RadarBoardStory`
        :returns: A :py:class:`RadarBoardStory` object
        :rtype: RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulRadarJobException`
        """
        status, response = self.client.build_and_send_json_request(url_components=(
            RadarBoard.BASE_URL,
            board_id,
            RadarBoardSprint.BASE_URL,
            sprint_id,
            RadarBoardStory.BASE_URL),
            request_data=[{"problemId": self.id}]
        )

        # Radar API can Return a list of Stories - in this case we requested and will only return one
        return RadarBoardStory(response[0], client=self.client)

    def add_to_radar_board_as_story(self, board_id, return_story_object=False, should_clear_cache=False):
        """
        A convenience wrapper to add a :py:class:`Radar` object directly to a :py:class:`RadarBoard` as a :py:class:`RadarBoardStory`

        The endpoints for this method are restricted, you may need to request access to the ``Create Jobs`` and ``Get Jobs`` API

        .. note::
            - Using `return_story_object` is a best effort approach to return the story object if the import was successful but it is not guaranteed to work
            - Users should add error handling logic around this function to handle the case where the import fails
            - Using the should_clear_cache option will clear the cache only if the agileAttributes field is being requested to get most recent data

        :param int board_id: ID of the :py:class:`RadarBoard` to add the Radar to as a :py:class:`RadarBoardStory`
        :param bool return_story_object: If a :py:class:`RadarBoardStory` should be returned instead of a :py:class:`RadarBoardJob`
        :param bool should_clear_cache: If clearing the cache is permitted - defaults to false
        :rtype: RadarBoardJob or RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulRadarJobException`
        """

        # Default behaviour to not break exiting clients
        if not return_story_object:
            return self.client.board_for_id(board_id).add_story_for_radar_id(self.id)

        # New behaviour to return story object if the import was successful
        # Add the Story to the board
        job = self.client.board_for_id(board_id).add_story_for_radar_id(self.id)

        # Clear the radar cache if the agileAttributes field is being requested to get most recent data and we have permission
        if "agileAttributes" in self.requested_fields and should_clear_cache:
            self.client.clear_radar_cache()

        # Reload the job status
        job = self.client.radar_board_job_for_id(board_id, job.jobId)

        # If the job is complete, return the Story object
        if job.is_successful():
            # Make sure to get the right story for this board as a Radar can exist on multiple boards
            stories = self.related_radar_board_stories()
            return [story for story in stories if story.boardId == board_id][0]
        raise UnsuccessfulRadarJobException

    def add_to_radar_board_as_epic(self, board_id, return_epic_object=False, should_clear_cache=False):
        """
        A convenience wrapper to add a :py:class:`Radar` object directly to a :py:class:`RadarBoard` as an :py:class:`RadarBoardEpic`

        The endpoints for this method are restricted, you may need to request access to the ``Create Jobs`` and ``Get Jobs`` API

        .. note::
            - Using `return_epic_object` is a best effort approach to return the epic object if the import was successful but it is not guaranteed to work
            - Users should add error handling logic around this function to handle the case where the import fails
            - Using the should_clear_cache option will clear the cache only if the agileAttributes field is being requested to get most recent data

        :param int board_id: ID of the :py:class:`RadarBoard` to add the Radar to as an :py:class:`RadarBoardEpic`
        :param bool return_epic_object: If a :py:class:`RadarBoardEpic` should be returned instead of a :py:class:`RadarBoardJob`
        :param bool should_clear_cache: If clearing the cache is permitted - defaults to false
        :rtype: RadarBoardJob or RadarBoardEpic
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulRadarJobException`
        """

        # Default behaviour to not break exiting clients
        if not return_epic_object:
            self.client.board_for_id(board_id).add_epic_for_radar_id(self.id)

        # New behaviour to return Epic object if the import was successful
        # Add the Epic to the board
        job = self.client.board_for_id(board_id).add_epic_for_radar_id(self.id)

        # Clear the radar cache if the agileAttributes field is being requested to get most recent data and we have permission
        if "agileAttributes" in self.requested_fields and should_clear_cache:
            self.client.clear_radar_cache()

        # Reload the job status
        job = self.client.radar_board_job_for_id(board_id, job.jobId)

        # If the job is complete, return the Epic object
        if job.is_successful():
            # Make sure to get the right epic for this board, as a Radar can exist on multiple boards
            epics = self.related_radar_board_epics()
            return [epic for epic in epics if epic.boardId == board_id][0]
        raise UnsuccessfulRadarJobException

    def related_radar_board_stories(self):
        """
        Find any :py:class:`RadarBoardStory` objects associated with the :py:class:`Radar`

        A single Radar can be associated with multiple Radar Boards.

        :returns: A list of :py:class:`RadarBoardStory` objects or an empty list
        :rtype: list[RadarBoardStory]
        """
        if "agileAttributes" in self.requested_fields:
            agile_attributes = self.agileAttributes
        else:
            agile_attributes = self.client.radar_for_id(self.id, additional_fields=["agileAttributes"]).agileAttributes
        if agile_attributes:
            story_list = []
            boards_list = agile_attributes.get("boards")
            if boards_list is not None:
                for board in boards_list:
                    if board.get("story"):
                        story_list.append(self.client.story_for_id(board_id=board.get("id"), story_id=board.get("story").get("id")))
                return story_list
        return []

    def related_radar_board_epics(self):
        """
        Find any :py:class:`RadarBoardEpic` objects associated with the :py:class:`Radar`

        A single Radar can be associated with multiple Radar Boards.

        :returns: A list of :py:class:`RadarBoardEpic` objects or an empty list
        :rtype: list[RadarBoardEpic]
        """
        if "agileAttributes" in self.requested_fields:
            agile_attributes = self.agileAttributes
        else:
            agile_attributes = self.client.radar_for_id(self.id, additional_fields=["agileAttributes"]).agileAttributes
        if agile_attributes:
            epic_list = []
            boards_list = agile_attributes.get("boards")
            if boards_list is not None:
                for board in boards_list:
                    if board.get("epic"):
                        epic_list.append(self.client.epic_for_id(board_id=board.get("id"), epic_id=board.get("epic").get("id")))
                return epic_list
        return []

    def related_radar_boards(self):
        """
        Find any active :py:class:`RadarBoard` objects associated with the :py:class:`Radar`

        A single Radar can be associated with multiple Radar Boards.

        Does not return archived boards

        :returns: A list of :py:class:`RadarBoards` objects or an empty list
        :rtype: list[RadarBoard]
        """
        if "agileAttributes" in self.requested_fields:
            agile_attributes = self.agileAttributes
        else:
            agile_attributes = self.client.radar_for_id(self.id, additional_fields=["agileAttributes"]).agileAttributes
        if agile_attributes:
            boards_list = agile_attributes.get("boards")
            if boards_list is not None:
                return [self.client.board_for_id(board.get("id")) for board in boards_list if board.get("state") != "archived"]
        return []

    def link_all_attachments_from_radar_id(self, source_radar_id):
        """
        Link all the attachments from a specific source Radar to the current Radar. Takes effect with
        :py:meth:`~Radar.commit_changes`.

        :param int source_radar_id: The ``id`` of the source Radar.

        For more information, see :py:class:`LinkedAttachment` and
        :py:meth:`~Radar.unlink_all_attachments_from_radar_id`.
        """
        self.add_change_record(LinkAllAttachmentsRadarChangeRecord(self, source_radar_id, 'link'))

    def unlink_all_attachments_from_radar_id(self, source_radar_id):
        """
        Unlink (remove) all the attachments on the current Radar that are linked from a specific source Radar. Takes
        effect with :py:meth:`~Radar.commit_changes`.

        :param int source_radar_id: The ``id`` of the source Radar.

        For more information, see :py:class:`LinkedAttachment` and :py:meth:`~Radar.link_all_attachments_from_radar_id`.
        """
        self.add_change_record(LinkAllAttachmentsRadarChangeRecord(self, source_radar_id, 'unlink'))

    def problem_summary(self):
        """
        Uses the experimental* AI/ML-based Get Problem Summary API to summarize the Radar.
        Equivalent to the **Insights** > **Summary** feature in Radar.app.

        :returns: (:py:class:`str`) The summary text.

        `* As of March 2025, this feature is still considered "beta" by the Radar team.`

        .. warning::
            Usage of this feature implies acknowledgement of and agreement to the following Terms of Use from Apple Legal.

        **General**

        Radar Problem Summary is an experimental feature. Please be advised that this feature:

            1. May occasionally generate problem summaries that include words or phrases that are unrepresentative of the content of the problem.
            2. May occasionally generate words or phrases that are found to be harmful or offensive.

        **Terms of Use**

            1. By opting into the use of this feature, you acknowledge that this feature can produce summaries that are unrepresentative of the content of the problem, and will treat these summaries with appropriate care when choosing how to approach using it to understand problems in Radar.
            2. By opting into the use of this feature, you acknowledge that this feature can produce words or phrases that may be considered harmful or offensive, and your participation in the use of this feature is voluntary. Improvements to reduce the possibility of harmful words or phrases will be made as and when incidents are identified that require a response, but are constrained by the capabilities of the system. If you find that harmful or offensive content is counterproductive to your work, your recourse is to opt out of the feature—neither the Radar team nor Apple Inc. are liable for any harm voluntary use of this feature may produce.
            3. Outputs must not be co-mingled on a non-temporary basis with any Apple proprietary or classified material (beyond what is required for evaluation).
            4. Outputs must not be distributed to parties external to Apple.
            5. Outputs from the summarization must not be used for creating:
                1. Models that are used in production workflows.
                2. Services that are used in production workflows.
                3. Code that is integrated into Apple's code base.
                4. Documentation considered a system-of-record, source-of-truth, or official announcement, including but not limited to: advertising copy, legal memos, internal product documentation.
            6. Any exceptions to the use of Outputs above (3-5) must be reviewed and approved by legal, more specifically, the appropriate product and privacy counsel for the team building the feature. This includes integration of Outputs into any Apple production workflow. Please contact the legal team as early as possible during feature development to allow for significant mitigations to be implemented as needed.
            7. Apple stores information about who has opted in to the use of this feature. This information may be associated with your Apple Connect credentials. The Radar team and other teams at Apple may use this information to develop and improve Radar Problem Summary and underlying machine learning models. Apple will retain this data in perpetuity.

        """
        if not hasattr(self, '_problem_summary'):
            self._problem_summary = None
            url = self.webservice_url('summary')
            request = self.client.request_for_url(url, method='GET')
            status, response = self.client.send_request(request)
            if response_code_is_success(status):
                self._problem_summary = response.get('summary')
        return self._problem_summary


class BaseChangeRecord(object):

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    @classmethod
    def optimize_change_record_map(cls, change_record_map, protocol_version=None):
        pass

    @classmethod
    def execution_priority(cls):
        # record classes with higher priority execute before ones with lower priority
        return 0

    @classmethod
    def print_dry_run_output(cls, message):
        if 'RADARCLIENT_SUPPRESS_DRY_RUN_OUTPUT' in os.environ:
            return
        print(message)


class RadarChangeRecord(BaseChangeRecord):

    @classmethod
    def commit_change_records_for_radar(cls, records, radar, dry_run=False):
        for change_record in records:
            change_record.commit_change(dry_run=dry_run)

    def reset_cached_data(self, radar):
        pass


class TSTTChangeRecordCommitter(object):

    @staticmethod
    def commit_change_records_for_tstt_item(record_map, client, dry_run=False):
        for record_class, records in sorted(list(record_map.items()),
                                            key=lambda x: x[0].execution_priority()):
            record_class.commit_change_records_for_tstt_item(records, client, dry_run=dry_run)


class BaseFileTSTTChangeRecord(BaseChangeRecord):
    # Execution priority should be 0 to avoid a test case being removed from a test suite and
    # thus causing an error on upload
    exec_priority = 1

    def __init__(self, tstt_enclosure):
        self.tstt_enclosure = tstt_enclosure

    @classmethod
    def execution_priority(cls):
        """
        Method kept around to maintain compatibility with other change records.
        :return:
        """
        return cls.exec_priority


class AddFileTSTTChangeRecord(BaseFileTSTTChangeRecord):
    exec_priority = 1

    def __init__(self, tstt_enclosure, overwrite=True):
        super(AddFileTSTTChangeRecord, self).__init__(tstt_enclosure)
        self.overwrite = overwrite

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        for record in records:
            enclosure = record.tstt_enclosure
            if dry_run:
                if record.overwrite:
                    overwrite_string = 'Will overwrite file if it exists'
                else:
                    overwrite_string = 'Will not overwrite file if it exists'
                cls.print_dry_run_output('Will upload file "{}" to {}. {}\n'.format(enclosure.fileName,
                                                               enclosure.parent, overwrite_string))
            else:
                url = enclosure.content_url(client=client)
                if enclosure.upload_content is not None:
                    data = enclosure.upload_content
                elif enclosure.upload_file:
                    data = enclosure.upload_file
                else:
                    raise Exception(
                        'Neither upload_content nor upload_file were set for {}'.format(enclosure)
                    )

                request = client.request_for_url(url, data=data, method="PUT")
                if record.overwrite:
                    request.add_header('X-Override-File', True)

                request.add_header('Content-Length', str(enclosure.fileSize))
                # Workaround <rdar://problem/67723767> Unable to upload attachments via python
                # radar api (Non-200 response code 500: Upload Paused due to broken stream)
                request.add_header('Content-Type', 'application/octet-stream')

                try:
                    enclosure.transfer_delegate.did_start_transfer(enclosure)
                    client.send_request(request)
                    enclosure.transfer_delegate.did_end_transfer(
                        enclosure, RadarEnclosureTransferDelegate.TRANSFER_RESULT_SUCCESS)
                except UnsuccessfulResponseException as e:
                    enclosure.transfer_delegate.did_end_transfer(
                        enclosure, RadarEnclosureTransferDelegate.TRANSFER_RESULT_FAILED
                    )
                    should_ignore = False
                    if e.code == 400 and 'already exists in the bundle' in e.reason:
                        policy = enclosure.transfer_delegate.policy_for_duplicate_upload(enclosure)
                        should_ignore = policy == RadarEnclosureTransferDelegate.DUPLICATE_POLICY_IGNORE
                    if not should_ignore:
                        raise e


class DeleteFileTSTTChangeRecord(BaseFileTSTTChangeRecord):
    exec_priority = 1

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        for record in records:
            enclosure = record.tstt_enclosure
            if dry_run:
                cls.print_dry_run_output('Will delete "{}" from {}\n'.format(enclosure.fileName, enclosure.parent))
            else:
                url = enclosure.content_url(client=client)
                request = client.request_for_url(url, method='DELETE')
                client.send_request(request)


class ModifyFileTSTTChangeRecord(BaseFileTSTTChangeRecord):
    exec_priority = 1

    def __init__(self, tstt_enclosure, new_name):
        super(ModifyFileTSTTChangeRecord, self).__init__(tstt_enclosure)
        self.new_name = new_name

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        for record in records:
            enclosure = record.tstt_enclosure
            if dry_run:
                cls.print_dry_run_output('Changing file "{}" to "{}" on {}'.format(
                    enclosure._original_file_name, record.new_name, enclosure.parent)
                )
            else:
                url = enclosure.content_url(client)
                request_json = json.dumps({'path': record.new_name})
                request = client.request_for_json_url(url, json_string=request_json, method='POST')
                client.send_request(request)


class RadarTestUpdateChangeRecord(BaseChangeRecord):
    """
    Change record for Radar Test update APIs

    :meta private:
    """
    ACTION_TYPE_INSERT = 'insert'
    ACTION_TYPE_REMOVE = 'remove'

    UPDATE_TYPE_KEYWORD = 'keyword'
    UPDATE_TYPE_RELATED_PROBLEM = 'related_problem'
    UPDATE_TYPE_ASSOCIATED_CASE = 'associated_case'
    UPDATE_TYPE_ASSOCIATED_SUITE = 'associated_suite'
    VALID_UPDATE_TYPES = {None, UPDATE_TYPE_KEYWORD, UPDATE_TYPE_RELATED_PROBLEM, UPDATE_TYPE_ASSOCIATED_CASE,
                          UPDATE_TYPE_ASSOCIATED_SUITE}

    PROPERTY_NAME_REMAPPING_MAP = {
        'component': 'componentId',
        'author': 'authorId',
        'geography': 'geographyId',
        'applicationName': 'applicationId',
        'category': 'categoryId',
        'trackName': 'trackId',
        'build': 'buildId',
        'actualResults': 'actualResult',
        'tester': 'testerId',
        'currentTester': 'testerId',
        'testCycle': 'testCycleId',
        'assignee': 'assigneeId',
        'owner': 'ownerId'
    }

    def __init__(self, change_object, property_name, update_type=None, action=None, new_value=None):
        self.change_object = change_object
        if update_type is not None and action is None:
            raise ValueError('If update_type is not None, action must be a valid action')

        if update_type not in self.VALID_UPDATE_TYPES:
            raise ValueError('{} is not a valid argument for update_type'.format(update_type))

        self.action = action
        self.update_type = update_type

        self.property_name = property_name

        if self.update_type is None:
            self.old_value = getattr(change_object, property_name, None)
        else:
            self.old_value = None

        self.new_value = new_value

        item_id = change_object.database_id_attribute_value()
        self.url_components = (change_object.BASE_URL,) + (item_id,)

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        change_dict = cls.build_change_dict(records, client)

        if dry_run:
            cls.print_dry_run_output('Changes to be made to {}'.format(records[0].change_object))
            for record in records:
                cls.print_dry_run_output(record)
        else:
            client.build_and_send_json_request(records[0].url_components, change_dict, method='PUT')

    @classmethod
    def build_change_dict(cls, records, client):
        change_dict = {}

        for record in records:
            property_name_for_update = cls.PROPERTY_NAME_REMAPPING_MAP.get(record.property_name, record.property_name)
            if record.update_type is None:
                encoded_value = record.change_object.encode_property_value(record.property_name, record.new_value,
                                                                           client)
                # special case for label which is updated in a bit of a weird way considering the data structure
                if record.property_name == 'label':
                    if record.new_value is None:
                        label_dict = {cls.ACTION_TYPE_REMOVE: record.old_value.database_id_attribute_value()}
                    else:
                        label_dict = {cls.ACTION_TYPE_INSERT: encoded_value}
                    change_dict[property_name_for_update] = label_dict
                else:
                    change_dict[property_name_for_update] = encoded_value
            elif record.update_type == cls.UPDATE_TYPE_KEYWORD:
                change_dict.setdefault('keywords', {}).setdefault(record.action, []).append(
                    record.change_object.encode_property_value(record.property_name, record.new_value)[0])
                # Using index because keywords are normally encoded as lists
            elif record.update_type == cls.UPDATE_TYPE_RELATED_PROBLEM:
                change_dict.setdefault('relatedProblems', {}).setdefault(record.action, []).append(
                    record.change_object.encode_property_value(record.property_name, record.new_value)[0])
            elif record.update_type in {cls.UPDATE_TYPE_ASSOCIATED_CASE, cls.UPDATE_TYPE_ASSOCIATED_SUITE}:
                change_dict.setdefault(record.property_name, {}).setdefault(record.action, []).append(record.new_value)
            else:
                # Due to checks in __init__ this should only happen if we forget to update this when new types are added
                raise ValueError('{} is not a valid argument for update_type'.format(record.update_type))

        return change_dict

    def __unicode__(self):
        if self.update_type is None:
            return u'<Property change for {}: property "{}", old value "{}", new value "{}">'.format(
                self.change_object,
                self.property_name,
                self.old_value,
                self.new_value
            )
        else:
            return 'Will {} {} {}'.format(self.action, self.new_value, self.change_object)

    def __eq__(self, other):
        return type(self) == type(other) and \
            self.update_type == other.update_type and \
            self.action == other.action and \
            self.property_name == other.property_name and \
            self.old_value == other.old_value and \
            self.new_value == other.new_value and \
            self.radar_encoded_new_value == other.radar_encoded_new_value and \
            self.change_object == other.change_object

    def __ne__(self, other):
        return not self.__eq__(other)

    @classmethod
    def execution_priority(cls):
        """
        Method kept around to maintain compatibility with other change records.
        :return:
        """
        return 0


class BaseTestCaseInSuiteChangeRecord(BaseChangeRecord):
    """
    Base for change records for test cases in suites

    :meta private:
    """
    exec_priority = 0

    def __init__(self, suite_str):
        self.suite_str = suite_str

    @classmethod
    def execution_priority(cls):
        """
        Method kept around to maintain compatibility with other change records.
        :return:
        """
        return cls.exec_priority


class CreateAndAddTestCaseBaseChangeRecord(BaseTestCaseInSuiteChangeRecord):
    exec_priority = 2

    def __init__(self, suite_str, case_data):
        super(CreateAndAddTestCaseBaseChangeRecord, self).__init__(suite_str)
        self.case_data = case_data


class CreateAndAddTestCaseChangeRecord(CreateAndAddTestCaseBaseChangeRecord):
    exec_priority = 2

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        suite_str = records[0].suite_str
        for record in records:
            if dry_run:
                cls.print_dry_run_output('Will create new test case on suite {} with the below info\n{}\n'
                      .format(suite_str, pprint.pformat(record.case_data)))
            else:
                client.create_test_suite_case(record.case_data, fetch_full_object=False)


class CreateAndAddScheduledTestCase(CreateAndAddTestCaseBaseChangeRecord):
    exec_priority = 2

    def __init__(self, suite_str, case_data, scheduled_suite_id):
        super(CreateAndAddScheduledTestCase, self).__init__(suite_str, case_data)
        self.scheduled_suite_id = scheduled_suite_id

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        suite_str = records[0].suite_str
        for record in records:
            if dry_run:
                cls.print_dry_run_output('Will create new scheduled test case on scheduled suite {} with the below info\n{}\n'
                      .format(suite_str, pprint.pformat(record.case_data)))
            else:
                client.create_scheduled_test_case(record.scheduled_suite_id, record.case_data, fetch_full_object=False)


class AddExistingTestCaseChangeRecord(BaseTestCaseInSuiteChangeRecord):
    exec_priority = 1

    def __init__(self, suite_str, suite_id, test_case, append=True):
        super(AddExistingTestCaseChangeRecord, self).__init__(suite_str)
        self.suite_id = suite_id
        self.test_case = test_case
        self.append = append

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        suite_additions = defaultdict(list)
        for record in records:
            suite_additions[record.suite_id].append((record.test_case, record.append))
        if dry_run:
            for suite in suite_additions:
                cls.print_dry_run_output('Will add the below test cases to suite with ID {}'.format(suite))
                for update_tuple in suite_additions[suite]:
                    cls.print_dry_run_output(update_tuple[0])
                cls.print_dry_run_output('')
        else:
            for suite_id in suite_additions:
                case_ids = [tup[0].caseID for tup in suite_additions[suite_id]]
                request_data = {'suiteID': suite_id, 'testCaseIDs': case_ids}

                client.build_and_send_json_request(
                    (TestSuite.BASE_URL, 'testcases'), request_data, method='POST'
                )

                # This weird update works around <rdar://problem/66362208> Bulk Add Test Cases Does
                # Not Do So In Order
                updated_suite = None
                num_cases = 0
                for update_tuple in suite_additions[suite_id]:
                    will_append = update_tuple[1]
                    if will_append:
                        if updated_suite is None:
                            updated_suite = client.test_suite_for_id(
                                suite_id, additional_fields=['cases']
                            )
                            num_cases = len(updated_suite.cases)

                        client._reorder_test_suite_case_by_id(
                            suite_id, update_tuple[0].caseID, num_cases
                        )


class RemoveExistingTestCaseChangeRecordByID(BaseTestCaseInSuiteChangeRecord):
    """
    Removes an existing test case from a test suite. This should always be the last thing that
    runs so that other actions like reordering and insertion happen first

    :meta private:
    """
    exec_priority = 50

    def __init__(self, suite_str, suite_id, test_case):
        super(RemoveExistingTestCaseChangeRecordByID, self).__init__(suite_str)
        self.suite_id = suite_id
        self.test_case = test_case

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        suite_str = records[0].suite_str
        if dry_run:
            for record in records:
                cls.print_dry_run_output('Will remove test case {} from {}'.format(record.test_case, suite_str))
        else:
            # Speed up processing by iterating over the cases just once and then removing by case
            # number in reverse order so that the other case numbers don't change
            suite_id = records[0].suite_id
            suite = client.test_suite_for_id(suite_id, additional_fields=['cases'])
            case_number = len(suite.cases)

            to_remove_set = set()
            for record in records:
                to_remove_set.add(record.test_case.caseID)
            case_numbers_to_remove = []

            while case_number > 0 and len(to_remove_set) > 0:
                suite_case_at_number = suite.cases[case_number - 1]
                if suite_case_at_number.caseID in to_remove_set:
                    case_numbers_to_remove.append(case_number)
                    to_remove_set.remove(suite_case_at_number.caseID)

                case_number -= 1

            for case_num in case_numbers_to_remove:
                client.build_and_send_request(
                    (TestSuite.BASE_URL, suite_id, 'cases', case_num), method='DELETE'
                )


class ReorderItemInRadarTestSuiteChangeRecord(BaseChangeRecord):
    exec_priority = 10
    BASE_URL = None

    def __init__(self, suite_id, item_id, new_position, item_type):
        self.suite_id = suite_id
        self.item_id = item_id
        self.new_position = new_position
        self.item_type = item_type

    @classmethod
    def build_pruned_records(cls, records):
        moving_item_ids = set()
        pruned_records = []
        new_locations = set()
        # Used to determine if the pruned_records will need to be sorted which is needed on versions of python older
        # than 3.10
        need_sort_for_older_python = False

        # sorting method for records in pruned_records used in bisect.insort for 3.10 and newer and as part of a call
        # to sort in older python versions
        def pruned_records_sort(rec):
            return -rec.new_position

        # Work on reversed set so that the latest reorder request for an item is used, in case of duplicates
        for record in reversed(records):
            if record.new_position in new_locations:
                raise ReorderDuplicatePlacementException('Cannot have more than 1 item moving to the same place')
            else:
                new_locations.add(record.new_position)

            if record.item_id not in moving_item_ids:
                if not need_sort_for_older_python:
                    # key was not added until python3.10. If older version than 3.10 is in use, the code will revert
                    # to simply sorting the list with the same logic at the end
                    try:
                        bisect.insort(pruned_records, record, key=pruned_records_sort)
                    except TypeError:
                        logger.exception('Failed to use bisect.insort with key argument')
                        need_sort_for_older_python = True
                        pruned_records.append(record)
                else:
                    pruned_records.append(record)
                moving_item_ids.add(record.item_id)
            else:
                logger.debug('Not doing {} since item had a later reorder request'.format(record))

        # Here is where the sorting happens on python versions older than 3.10 which doesn't need it because it does
        # bisect.insort
        if need_sort_for_older_python:
            pruned_records.sort(key=pruned_records_sort)

        return pruned_records, moving_item_ids

    @staticmethod
    def _get_list_of_items_for_current_order(suite_id, client):
        raise NotImplementedError('Must implement in child class')

    @staticmethod
    def _build_item_dict(item, current_order):
        return {
            'id': item.database_id_attribute_value(),
            'type': item.REORDERING_TYPE,
            'currentOrder': current_order
        }

    @classmethod
    def _build_stub_object_of_correct_type(cls, item_type, ident):
        if item_type == ScheduledTestCase.REORDERING_TYPE:
            return ScheduledTestCase({ScheduledTestCase.identifier_attrs[0]: ident})
        elif item_type == TestCase.REORDERING_TYPE:
            return TestCase({TestCase.identifier_attrs[0]: ident})
        elif item_type == TestSuite.REORDERING_TYPE:
            return TestSuite({TestSuite.identifier_attrs[0]: ident})
        else:
            raise ValueError('{} is not a valid type'.format(item_type))

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        if dry_run:
            try:
                recs, _ = cls.build_pruned_records(records)
                for rec in recs:
                    cls.print_dry_run_output(rec)
            except ReorderDuplicatePlacementException as ex:
                cls.print_dry_run_output('Reordering will fail with exception "{}"'.format(ex))
        else:
            # Send up all items as part of reorder so that a user wanted an item in position 4 will end up with it in
            # position 4 without having to worry about all the other items shifting.
            current_items = cls._get_list_of_items_for_current_order(records[0].suite_id, client)
            pruned_records, moving_item_ids = cls.build_pruned_records(records)
            items_in_new_order = []
            order = 1
            item_index = 0
            pending_reorder_record = pruned_records[-1]

            url_components = (cls.BASE_URL, records[0].suite_id, 'reorder')

            while len(pruned_records) > 0 and item_index < len(current_items):
                current_item = current_items[item_index]

                if pending_reorder_record is not None and pending_reorder_record.new_position == order:
                    items_in_new_order.append(cls._build_stub_object_of_correct_type(
                        pending_reorder_record.item_type, pending_reorder_record.item_id
                    ))
                    order += 1

                    pruned_records.pop()
                    if len(pruned_records) > 0:
                        pending_reorder_record = pruned_records[-1]
                    else:
                        pending_reorder_record = None
                elif current_item.database_id_attribute_value() not in moving_item_ids:
                    items_in_new_order.append(current_item)
                    order += 1
                    item_index += 1
                else:
                    item_index += 1

            while len(pruned_records) > 0:
                rec = pruned_records.pop()
                items_in_new_order.append(cls._build_stub_object_of_correct_type(rec.item_type, rec.item_id))

            # Need to do multiple reorders to make sure things end up exactly where expected
            current_index = 0
            while current_index < len(items_in_new_order):
                up_to_date_items = cls._get_list_of_items_for_current_order(records[0].suite_id, client)
                new_loc = current_index + 1

                current_loc = up_to_date_items.index(items_in_new_order[current_index]) + 1
                sub_items = [cls._build_item_dict(items_in_new_order[current_index], current_loc)]

                current_index += 1
                while (current_index < len(items_in_new_order) and current_loc < len(up_to_date_items) and
                       items_in_new_order[current_index] == up_to_date_items[current_loc]):
                    sub_items.append(cls._build_item_dict(items_in_new_order[current_index], current_loc + 1))
                    current_index += 1
                    current_loc += 1

                request_dict = {
                    'reorder': {
                        'items': sub_items,
                        'newOrder': new_loc
                    }
                }

                client.build_and_send_json_request(url_components, request_dict, method='PUT')

    @classmethod
    def execution_priority(cls):
        """
        Method kept around to maintain compatibility with other change records.
        :return:
        """
        return cls.exec_priority

    def __unicode__(self):
        return u'<Reorder change for suite {}. Move {} with ID {} to position {}>'.format(
            self.suite_id, self.item_type, self.item_id, self.new_position
        )


class ReorderScheduledTestCaseChangeRecord(ReorderItemInRadarTestSuiteChangeRecord):
    exec_priority = 10
    BASE_URL = ScheduledTest.BASE_URL

    @staticmethod
    def _get_list_of_items_for_current_order(suite_id, client):
        return client.scheduled_test_for_id(suite_id, fields=['cases']).cases


class ReorderItemInTestSuiteChangeRecord(ReorderItemInRadarTestSuiteChangeRecord):
    exec_priority = 10
    BASE_URL = TestSuite.BASE_URL

    @staticmethod
    def _get_list_of_items_for_current_order(suite_id, client):
        return client.test_suite_for_id(suite_id, fields=['associatedTests']).associatedTests


class ReorderAssociatedTestCaseChangeRecord(BaseTestCaseInSuiteChangeRecord):
    exec_priority = 5

    def __init__(self, suite_str, suite_id, test_case, new_case_number, sub_suite_pos=None):
        super(ReorderAssociatedTestCaseChangeRecord, self).__init__(suite_str)
        self.suite_id = suite_id
        self.test_case = test_case
        self.new_case_number = new_case_number
        self.sub_suite_pos = sub_suite_pos
        if sub_suite_pos is not None:
            try:
                self.sub_suite_id = test_case.suiteID
            except AttributeError:
                raise AttributeError('If sub_suite_pos is passed in, test_case instance must have '
                                     'a value for suiteID')

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        for record in records:
            if dry_run:
                sub_info = ''
                if record.sub_suite_pos is not None:
                    sub_info = ' (Position {} in sub-suite with ID {})'.format(
                        record.sub_suite_pos, record.sub_suite_id)
                cls.print_dry_run_output('Will move test case {} to position {} in {}{}\n'.format(
                    record.test_case, record.new_case_number, record.suite_str, sub_info)
                )
            else:
                if record.sub_suite_pos is not None:
                    client._reorder_test_suite_case_by_id(record.sub_suite_id,
                                                          record.test_case.caseID,
                                                          record.sub_suite_pos)
                else:
                    client._reorder_test_suite_case_by_id(record.suite_id,
                                                          record.test_case.caseID,
                                                          record.new_case_number)


class CollectionPropertyModificationRadarChangeRecord(RadarChangeRecord):

    def __init__(self, collection_property, collection_item):
        assert collection_property
        assert collection_item
        self.collection_property = collection_property
        self.collection_item = collection_item

    def reset_cached_data(self, radar):
        self.collection_property.reset()


class SimplePropertyRadarChangeRecord(RadarChangeRecord):

    def __init__(self, radar, property_name, new_value=None):
        self.property_name = property_name
        self.radar = radar
        self.old_value = getattr(radar, property_name, None)
        self.new_value = new_value

    def __unicode__(self):
        return u'<Property change for Radar {}: property "{}", old value "{}", current value "{}">'.format(self.radar, self.property_name, self.old_value, getattr(self.radar, self.property_name))

    @classmethod
    def commit_change_records_for_radar(cls, records, radar, dry_run=False):
        change_json_code = cls.change_json_for_records(records, radar)
        if not change_json_code:
            return

        if dry_run:
            cls.print_dry_run_output(change_json_code)
            return

        url = radar.webservice_url()
        request = radar.client.request_for_json_url(url, json_string=change_json_code)
        status, result_data = radar.client.send_request(request)
        if status != 200:
            logger.error(u'Non-200 result status for property change {}: {} {}'.format(change_json_code, status, result_data))

    @classmethod
    def change_json_for_records(cls, records, radar):
        protocol_version = radar.client.protocol_version
        changes = {}
        property_name_remapping_map = {
            'component': 'componentID',
            'label': 'labelID',
            'dri': 'driID',
            'assignee': 'assigneeID',
            'resolvedBy': 'resolverID',
            'originator': 'originatorID',
            'epm': 'epmID',
        }
        for change_record in records:
            property_name = change_record.property_name
            property_name_json = property_name_remapping_map.get(property_name, property_name)
            if change_record.new_value:
                changes[property_name_json] = change_record.new_value
            else:
                changes[property_name_json] = radar.encode_property_value(property_name, getattr(radar, property_name, None))
#        logger.debug('changes for JSON conversion: {}'.format(changes))
        change_json = json.dumps(changes)
        return change_json

    @classmethod
    def optimize_change_record_map(cls, change_record_map, protocol_version=None):
        # If this is a subclass of SimplePropertyRadarChangeRecord, move the
        # change records over into a combined set so that we still get a single
        # update in the history.
        if issubclass(cls, SimplePropertyRadarChangeRecord) and cls != SimplePropertyRadarChangeRecord:
            change_record_map.setdefault(SimplePropertyRadarChangeRecord, []).extend(change_record_map[cls])
            del change_record_map[cls]

    @classmethod
    def execution_priority(cls):
        return 1


class MilestoneRadarChangeRecord(SimplePropertyRadarChangeRecord):

    def reset_cached_data(self, radar):
        radar.reset_milestone_associations()


class AddEnclosureRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        url = self.collection_item.content_url()
        if self.collection_item.upload_content:
            data = self.collection_item.upload_content
        elif self.collection_item.upload_file:
            data = self.collection_item.upload_file
        else:
            raise Exception('Upload_content/upload_file not set for enclosure ({}/{}). Check for zero-length file.'.format(self.collection_item.upload_content, self.collection_item.upload_file))

        if dry_run:
            self.print_dry_run_output(u'Uploading enclosure: {} bytes to {}'.format(self.collection_item.fileSize, url))
            return

        request = self.collection_property.radar.client.request_for_url(url, data=data, method='PUT')
        request.add_header('Content-Length', str(self.collection_item.fileSize))
        request.add_header('Content-Type', 'application/octet-stream')
        if not self.collection_item.upload_should_reset_read_by_assignee:
            request.add_header('X-Reset-Read-By-Assignee', 'true')

        if self.collection_item.overwrite_existing_file:
            request.add_header('X-Override-File', 'true')

        try:
            self.collection_item.transfer_delegate.did_start_transfer(self.collection_item)
            self.collection_property.radar.client.send_request(request)
            self.collection_item.transfer_delegate.did_end_transfer(self.collection_item, RadarEnclosureTransferDelegate.TRANSFER_RESULT_SUCCESS)
        except UnsuccessfulResponseException as e:
            self.collection_item.transfer_delegate.did_end_transfer(self.collection_item, RadarEnclosureTransferDelegate.TRANSFER_RESULT_FAILED)
            should_ignore = False
            if e.code == 400 and 'already exists in the bundle' in e.reason:
                policy = self.collection_item.transfer_delegate.policy_for_duplicate_upload(self.collection_item)
                should_ignore = policy == RadarEnclosureTransferDelegate.DUPLICATE_POLICY_IGNORE
            if not should_ignore:
                raise e


class DeleteEnclosureRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        url = self.collection_item.content_url()

        if dry_run:
            self.print_dry_run_output(u'Deleting enclosure: {}'.format(url))
            return

        request = self.collection_property.radar.client.request_for_url(url, method='DELETE')
        self.collection_property.radar.client.send_request(request)


class AttachmentLinkBaseRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    @classmethod
    def link_method(cls):
        raise NotImplementedError()

    def commit_change(self, dry_run=False):
        if self.collection_item.type == AttachmentLink.ATTACHMENT_TYPE_SOURCE:
            target_radar_id = self.collection_item.linked_radar_id or self.collection_item.linked_radar.id
            source_radar_id = self.collection_item.attachment.radar.id
        elif self.collection_item.type == AttachmentLink.ATTACHMENT_TYPE_LINKED:
            target_radar_id = self.collection_item.attachment.radar.id
            source_radar_id = self.collection_item.linked_radar_id or self.collection_item.linked_radar.id
        assert target_radar_id and source_radar_id, "Unable to identify the source and target Radar IDs!"
        assert self.link_method() in ['link', 'unlink'], "Unknown link_method: {}".format(self.link_method())
        url_components = ('problems', target_radar_id, 'attachments', self.link_method())
        url = self.collection_property.radar.client.webservice_url_for_path_components(*url_components)
        json_data = {
            'attachments': [self.collection_item.attachment.fileName],
            'sourceEntityId': source_radar_id,
            'sourceEntityType': 'problem'
        }
        if dry_run:
            print('url:', url)
            pprint.pprint(json_data)
            return

        request = self.collection_property.radar.client.request_for_json_url(url, json_string=json.dumps(json_data))
        self.collection_property.radar.client.send_request(request)


class LinkAttachmentRadarChangeRecord(AttachmentLinkBaseRadarChangeRecord):

    @classmethod
    def link_method(cls):
        return 'link'


class UnlinkAttachmentRadarChangeRecord(AttachmentLinkBaseRadarChangeRecord):

    @classmethod
    def link_method(cls):
        return 'unlink'


class LinkAllAttachmentsRadarChangeRecord(RadarChangeRecord):

    def __init__(self, radar, source_radar_id, link_method):
        self.radar = radar
        self.source_radar_id = source_radar_id
        self.link_method = link_method

    def commit_change(self, dry_run=False):
        url = self.radar.webservice_url('attachments', self.link_method)
        json_data = {
            'attachments': [],
            'sourceEntityId': self.source_radar_id,
            'sourceEntityType': 'problem'
        }
        if dry_run:
            print('url:', url)
            pprint.pprint(json_data)
            return

        request = self.radar.client.request_for_json_url(url, json_string=json.dumps(json_data))
        request.add_header('X-{}-All'.format(self.link_method.capitalize()), 'true')
        self.radar.client.send_request(request)
        self.radar.attachments.reset()


class AddDescriptionOrDiagnosisEntryRadarChangeRecordBase(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        json = self.json_code()
        url = self.collection_item.webservice_url_for_radar(self.collection_property.radar, type=None)
        if dry_run:
            self.print_dry_run_output(json)
            return

        request = self.collection_property.radar.client.request_for_json_url(url, json_string=json)
        self.collection_property.radar.client.send_request(request)

    def json_code(self):
        data = {'text': self.collection_item.text}
        return json.dumps(data)

    def __unicode__(self):
        return u'<Add {} entry change for Radar {}: {}>'.format(self.radar_property_name(), self.collection_property.radar, self.collection_item)

    @classmethod
    def radar_property_name(cls):
        raise NotImplementedError()

    @classmethod
    def optimize_change_record_map(cls, change_record_map, protocol_version=None):
        # If there is a diagnosis/description change record and
        # also at least one property change record, convert the first
        # diagnosis/description change record into a property change
        # record so that the history shows only one entry.
        if SimplePropertyRadarChangeRecord not in list(change_record_map.keys()):
            return

        # Due to rdar://147959301, if any new DiagnosisEntry includes an @ Mention and there is also a pending
        # change record for a new DescriptionEntry, the Update Problem request will fail.
        if (AddDiagnosisEntryRadarChangeRecord in list(change_record_map.keys())
                and AddDescriptionEntryRadarChangeRecord in list(change_record_map.keys())):
            return

        simple_property_change_records = change_record_map[SimplePropertyRadarChangeRecord]

        add_description_or_diagnosis_change_records = change_record_map[cls]
        first_add_description_or_diagnosis_record = add_description_or_diagnosis_change_records.pop(0)
        if not add_description_or_diagnosis_change_records:
            # No diagnosis/description change records left,
            # remove the record type from the map completely
            del change_record_map[cls]

        property_change_record = SimplePropertyRadarChangeRecord(
            first_add_description_or_diagnosis_record.collection_property.radar,
            cls.radar_property_name(),
            first_add_description_or_diagnosis_record.collection_item.text)
        simple_property_change_records.append(property_change_record)

        # Additional custom logic for DiagnosisEntry changes with @ Mentions
        if isinstance(first_add_description_or_diagnosis_record, AddDiagnosisEntryRadarChangeRecord):
            cr_collection_item = first_add_description_or_diagnosis_record.collection_item
            cr_collection_item.mention_strings = re.findall(DiagnosisEntry.MENTIONS_REGEX, cr_collection_item.text)
            if cr_collection_item.mention_strings and not cr_collection_item.suppress_mentions:
                addl_property_change_record = SimplePropertyRadarChangeRecord(
                    first_add_description_or_diagnosis_record.collection_property.radar,
                    'mentions',
                    first_add_description_or_diagnosis_record.mentions_json()
                )
                simple_property_change_records.append(addl_property_change_record)


class AddDescriptionEntryRadarChangeRecord(AddDescriptionOrDiagnosisEntryRadarChangeRecordBase):

    @classmethod
    def radar_property_name(cls):
        return 'description'


class AddDiagnosisEntryRadarChangeRecord(AddDescriptionOrDiagnosisEntryRadarChangeRecordBase):

    @classmethod
    def radar_property_name(cls):
        return 'diagnosis'

    def json_code_with_mentions(self):
        json_data = {
            'diagnosis': self.collection_item.text,
            'mentions': self.mentions_json()
        }
        return json.dumps(json_data)

    def mentions_json(self):
        mentions_data = {'person': []}
        for identifier in self.collection_item.mention_strings:
            mentions_data['person'].append({
                'dsid': int(identifier),
                'context': 'DISCUSSION'
            })
        return mentions_data

    def commit_change(self, dry_run=False):
        self.collection_item.mention_strings = re.findall(DiagnosisEntry.MENTIONS_REGEX, self.collection_item.text)
        if len(self.collection_item.mention_strings) > 0 and not self.collection_item.suppress_mentions:
            # Custom logic for adding a DiagnosisEntry with @ Mentions
            json_string = self.json_code_with_mentions()
            if dry_run:
                self.print_dry_run_output(json_string)
                return
            url = self.collection_property.radar.webservice_url()
            request = self.collection_property.radar.client.request_for_json_url(url, json_string=json_string)
            self.collection_property.radar.client.send_request(request)
        else:
            # Fall back to the standard Add Diagnosis Entry API mechanism.
            super(AddDiagnosisEntryRadarChangeRecord, self).commit_change(dry_run)


class AddRelationshipRadarChangeRecord(RadarChangeRecord):

    def __init__(self, radar, relationship):
        self.relationship = relationship
        self.radar = radar

    def commit_change(self, dry_run=False):
        url = self.relationship.webservice_url()
        method = 'PUT'
        if dry_run:
            self.print_dry_run_output(u'Making a {} request to {}'.format(method, url))
            return

        request = self.radar.client.request_for_url(url, method=method)
        # rdar://86643343 (Client should not throw an error for response code 304 (Not Modified))
        try:
            self.radar.client.send_request(request)
        except UnsuccessfulResponseException as ure:
            if ure.code == 304:
                logger.debug('Relationship already exists. No modification made')
            else:
                raise

        self.radar.reset_relationships()


class DeleteRelationshipRadarChangeRecord(RadarChangeRecord):

    def __init__(self, radar, relationship):
        self.relationship = relationship
        self.radar = radar

    def commit_change(self, dry_run=False):
        url = self.relationship.webservice_url()
        method = 'DELETE'
        if dry_run:
            self.print_dry_run_output(u'Making a {} request to {}'.format(method, url))
            return

        request = self.radar.client.request_for_url(url, method=method)
        self.radar.client.send_request(request)
        self.radar.reset_relationships()


class DeleteTSTTRelatedProblemBaseChangeRecord(BaseChangeRecord):
    execution_priority = 0

    def __init__(self, url_components, relationship, tstt_item):
        self.url_components = url_components
        self.relationship = relationship
        self.tstt_item = weakref.proxy(tstt_item)

    @classmethod
    def commit_change_records_for_tstt_item(cls, records, client, dry_run=False):
        for record in records:
            if dry_run:
                cls.print_dry_run_output('Will delete {} from {}'.format(record.relationship, record.tstt_item))
            else:
                url = client.webservice_url_for_path_components(*record.url_components)
                request = client.request_for_url(url, method='DELETE')
                client.send_request(request)
        if dry_run:
            cls.print_dry_run_output('')


class DeleteScheduledTestCaseRelatedProblemChangeRecord(DeleteTSTTRelatedProblemBaseChangeRecord):
    execution_priority = 0

    def __init__(self, scheduled_test_id, relationship, test_case):
        super(DeleteScheduledTestCaseRelatedProblemChangeRecord, self).__init__(
            ('scheduled-tests', scheduled_test_id, 'cases', test_case.caseID,
            'related-problem', relationship.relationType, relationship.id),
            relationship,
            test_case
        )


class AddOtherRelatedItemEntryRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        json = self.json_code()
        url = self.collection_item.webservice_url_for_radar(self.collection_property.radar, type=None)
        if dry_run:
            self.print_dry_run_output(u'Making a request to {}'.format(url))
            return

        request = self.collection_property.radar.client.request_for_json_url(url, json_string=json)
        self.collection_property.radar.client.send_request(request)

    def json_code(self):
        data = [{'id': compat.unicode_string_type(self.collection_item.id), 'system': self.collection_item.system, 'title': self.collection_item.title}]
        return json.dumps(data)


class DeleteOtherRelatedItemEntryRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        url = self.collection_item.delete_webservice_url_for_radar(self.collection_property.radar, type=None)
        if dry_run:
            self.print_dry_run_output(u'Making a DELETE request to {}'.format(url))
            return

        request = self.collection_property.radar.client.request_for_url(url, method='DELETE')
        self.collection_property.radar.client.send_request(request)


class AddKeywordRadarChangeRecord(RadarChangeRecord):

    def __init__(self, radar, keyword_association):
        self.radar = radar
        self.keyword_association = keyword_association

    def commit_change(self, dry_run=False):
        url = '/'.join([self.radar.webservice_url_keywords(), str(self.keyword_association.keyword.id)])

        if dry_run:
            self.print_dry_run_output(u'Adding keyword {} to {}: PUT request to {}'.format(self.keyword_association.keyword, self.radar, url))
            return

        request = self.radar.client.request_for_url(url, method='PUT')
        try:
            self.radar.client.send_request(request)
        except UnsuccessfulResponseException as e:
            # If a keyword is already attached, treat it as success
            if e.code != 409:
                raise

    def reset_cached_data(self, radar):
        self.radar.reset_keyword_associations()


class RemoveKeywordRadarChangeRecord(RadarChangeRecord):

    def __init__(self, radar, keyword_association):
        self.radar = radar
        self.keyword_association = keyword_association

    def commit_change(self, dry_run=False):
        url = '/'.join([self.radar.webservice_url_keywords(), str(self.keyword_association.keyword.id)])

        if dry_run:
            self.print_dry_run_output(u'Removing keyword {} from {}: DELETE request to {}'.format(self.keyword_association.keyword, self.radar, url))
            return

        request = self.radar.client.request_for_url(url, method='DELETE')
        self.radar.client.send_request(request)

    def reset_cached_data(self, radar):
        self.radar.reset_keyword_associations()


class AddCCMembershipRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        url = self.collection_item.update_webservice_url_for_radar(self.collection_property.radar)

        if dry_run:
            self.print_dry_run_output(u'Adding cced person {} to {}: PUT request to {}'.format(self.collection_item.person.email, self.collection_property.radar, url))
            return

        request = self.collection_property.radar.client.request_for_url(url, method='PUT')
        try:
            self.collection_property.radar.client.send_request(request)
        except UnsuccessfulResponseException as e:
            # Don't error out if person is already on the CC list
            if e.code != 409:
                raise


class DeleteCCMembershipRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    def commit_change(self, dry_run=False):
        url = self.collection_item.update_webservice_url_for_radar(self.collection_property.radar)

        if dry_run:
            self.print_dry_run_output(u'Removing cced person {} from {}: DELETE request to {}'.format(self.collection_item.person.email, self.collection_property.radar, url))
            return

        request = self.collection_property.radar.client.request_for_url(url, method='DELETE')
        self.collection_property.radar.client.send_request(request)


class AddOrDeleteBuildRadarChangeRecord(CollectionPropertyModificationRadarChangeRecord):

    @classmethod
    def optimize_change_record_map(cls, change_record_map, protocol_version=None):
        # Translate a set of insert/remove changes for the various build fields
        # into a single SimplePropertyChange operation where the value
        # is a complex dictionary with the collection of all operations
        # according to the API

        add_or_delete_records = []
        items_to_remove_from_map = []
        for record_class, records in change_record_map.items():
            if not issubclass(record_class, cls):
                continue
            add_or_delete_records.extend(records)
            items_to_remove_from_map.append(record_class)
        assert add_or_delete_records, 'Unexpected empty add/delete build record list'

        for key in items_to_remove_from_map:
            del change_record_map[key]

        # Try to find an existing simple property change record
        builds_changes = None # The "value" dictionary that contains all the insert/delete descriptions
        property_change_records = change_record_map.setdefault(SimplePropertyRadarChangeRecord, [])
        records = [r for r in property_change_records if r.property_name == 'builds']
        if records:
            assert len(records) == 1, 'More than 1 ({}) simple property change records for property "builds"'.format(len(records))
            builds_changes = records[0].new_value
        else:
            builds_changes = {}
            radar = add_or_delete_records[0].collection_property.radar
            property_change_records.append(SimplePropertyRadarChangeRecord(radar, 'builds', builds_changes))

        for record in add_or_delete_records:
            radar_update_value = record.collection_item.radar_update_value(protocol_version=protocol_version)
            builds_changes.setdefault(record.collection_property.property_name, {}).setdefault(record.operation_name(), []).append(radar_update_value)


class AddBuildRadarChangeRecord(AddOrDeleteBuildRadarChangeRecord):

    @classmethod
    def operation_name(cls):
        return 'insert'


class DeleteBuildRadarChangeRecord(AddOrDeleteBuildRadarChangeRecord):

    @classmethod
    def operation_name(cls):
        return 'remove'


class AbstractValueConverter(object):
    """
    A value converter converts between the value as received from
    and sent to the Radar Web API in JSON and Python's representation.
    An example is an ISO date string as stored in Radar, which the converter
    converts to a Python datetime instance, and back to an ISO string.

    It also converts from a user-friendly value notation that the radartool
    command line frontend, and possibly others in the future, use.

    :meta private:
    """

    @classmethod
    def encode_radar_value(cls, value, *args):
        return value

    @classmethod
    def decode_radar_value(cls, value):
        return value

    @classmethod
    def decode_user_friendly_value(cls, value):
        return cls.decode_radar_value(value)

    @classmethod
    def encode_user_friendly_value(cls, value):
        return cls.encode_radar_value(value)

    @classmethod
    def encode_csv_value(cls, value):
        return value

    @classmethod
    def decode_csv_value(cls, value):
        to_return = value
        if value == '':
            to_return = None
        return to_return


class BuildValueConverter(AbstractValueConverter):
    @classmethod
    def decode_radar_value(cls, value):
        if value is not None:
            return Build(value)
        else:
            return None

    @classmethod
    def encode_radar_value(cls, value, *args):
        if value is not None:
            return value.id
        else:
            return None


class DotNotationDictionaryValueConverter(AbstractValueConverter):
    """
    Convert something not updatable by the user to be accessible via dot notation and as a dictionary. Current
    version only goes 1 level deep. This is mainly used to remain compatible with `counts` in `Radar` objects

    :meta private:
    """

    @classmethod
    def decode_radar_value(cls, value):
        if value is None:
            return value
        to_return = None
        if not isinstance(value, dict):
            logger.warning('value {} is not a dict'.format(value))
            to_return = value
        else:
            to_return = DotNotationDictionary(value)
            for key, value in to_return.items():
                to_return.__setattr__(key, value)

        return to_return


class UpdateByIDValueConverter(AbstractValueConverter):
    """
    A value converter the supports fields that require an ID when updating but are returned as simple strings. These
    IDs are fetched by calling an end point through Radar. It also handles the fact that sometimes they aren't
    returned as simple string but they should be. See
    rdar://116060703 (Requesting geography for /tests/suites/{test-suite-id} returns LookUpAttributes object)
    rdar://116060126 (/tests/scheduledtests/{scheduledtest-id} Docs Show Wrong Return Type for Many Items)

    :meta private:
    """
    ID_MAPPING_METHOD = None # name of method for mapping like "id_for_test_geography"
    ITEM_NAME = None # Name of the item for exception purposes like "Test Geography"

    @classmethod
    def decode_radar_value(cls, value):
        # Work around various issues where the return type is different depending on endpoint
        # rdar://116123679 (/tests/suites/{test-suite-id} attributes returned as LookUpAttributes objects but /tests/suites/find returns them as string values)
        # rdar://116123581 (/tests/scheduledtests/{scheduledtest-id} attributes returned as LookUpAttributes Objects but /tests/scheduledtests/find returns them as strings)
        if isinstance(value, dict):
            return value['value']
        else:
            return value

    @classmethod
    def encode_radar_value(cls, value, *args):
        client = args[0]
        try:
            return getattr(client, cls.ID_MAPPING_METHOD)(value)
        except KeyError:
            raise UpdateByIDLookUpError('No matching {} ID found for {}'.format(cls.ITEM_NAME, value))


class TestGeographyValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_test_geography'
    ITEM_NAME = 'Test Geography'


class ScheduledTestStatusValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_scheduled_test_status'
    ITEM_NAME = 'Scheduled Test Status'


class TestCategoryValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_test_category'
    ITEM_NAME = 'Test Category'


class TestTrackValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_test_track_name'
    ITEM_NAME = 'Test Track'


class BusinessProcessValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_business_process'
    ITEM_NAME = 'Business Process'


class ScheduledTestCaseStatusValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_scheduled_test_case_status'
    ITEM_NAME = 'Scheduled Test Case Status'


class ApplicationNameValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_application_name'
    ITEM_NAME = 'Application Name'


class TestCycleValueConverter(UpdateByIDValueConverter):
    ID_MAPPING_METHOD = 'id_for_test_cycle'
    ITEM_NAME = 'Test Cycle'


class DictionaryBasedModelValueConverter(AbstractValueConverter):
    @classmethod
    def decode_radar_value(cls, value):
        to_return = None
        if value is not None:
            to_return = DictionaryBasedModel(value)
        return to_return


class SimpleIntegerValueConverter(AbstractValueConverter):

    @classmethod
    def decode_csv_value(cls, value):
        to_return = None
        if value != '':
            to_return = int(value)
        return to_return

    @classmethod
    def decode_user_friendly_value(cls, value):
        if value is not None:
            value = int(value)
        return value


class KeywordAssociationValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, keyword_association_data):
        return KeywordAssociation(keyword_association_data)

    @classmethod
    def encode_radar_value(cls, keyword_association, *args):
        raise Exception('Encoding of keyword associations is not supported')


class KeywordValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, keyword_data):
        if isinstance(keyword_data, dict):
            return Keyword(keyword_data)
        else:
            return Keyword({'name': keyword_data})

    @classmethod
    def encode_radar_value(cls, keyword, *args):
        """
        Encodes a :py:class:`~radarclient.model.Keyword` object to a valid radar API string

        :param ~radarclient.model.Keyword keyword: Keyword to encode

        :return: valid string for Radar API representing the keyword as ID
        """
        return getattr(keyword, 'id', keyword.name)

    @classmethod
    def encode_user_friendly_value(cls, value):
        return value.name

    @classmethod
    def encode_csv_value(cls, value):
        to_return = None
        if value is not None:
            to_return = '{} | {}'.format(value.name, value.id)
        return to_return

    @classmethod
    def decode_csv_value(cls, value):
        to_return = None
        if value != '':
            spl = value.split('|')
            to_return = Keyword({'name': spl[0].strip(), 'id': int(spl[1])})
        return to_return


class CCMembershipValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, cc_membership_data):
        return CCMembership(cc_membership_data)

    @classmethod
    def encode_radar_value(cls, cc_membership, *args):
        raise Exception('Encoding of cc memberships is not supported')


class ListValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, data):
        item_converter_class = cls.list_item_value_converter_class()
        if data is None:
            # Radar API may send us None when it should send us an empty list.
            data = []
        elif not isinstance(data, list):
            # Radar API may send us a single object when it should send us a list containing that object
            data = [data]
        return [item_converter_class.decode_radar_value(item_data) for item_data in data]

    @classmethod
    def encode_radar_value(cls, items, *args):
        item_converter_class = cls.list_item_value_converter_class()
        return [item_converter_class.encode_radar_value(item) for item in items]

    @classmethod
    def encode_user_friendly_value(cls, items):
        item_converter_class = cls.list_item_value_converter_class()
        return [item_converter_class.encode_user_friendly_value(item) for item in items]

    @classmethod
    def encode_csv_value(cls, items):
        to_return = None
        if len(items) > 0:
            item_converter_class = cls.list_item_value_converter_class()
            to_join = [item_converter_class.encode_csv_value(item) for item in items]
            to_return = '\n'.join(to_join)
        return to_return

    @classmethod
    def decode_csv_value(cls, data_string):
        to_return = None
        if data_string != '':
            item_converter_class = cls.list_item_value_converter_class()
            split_vals = data_string.split('\n')
            to_return = [item_converter_class.decode_csv_value(val) for val in split_vals]
        return to_return


class RadarTestPriorityStringValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, value):
        # This also works around
        # rdar://115846857 (priority for Scheduled Test Cases Returned as Object When Fetched as Part of Scheduled Test)
        if isinstance(value, dict):
            return int(value['value'])
        elif value is not None:
            return int(value)
        else:
            return None

    @classmethod
    def encode_radar_value(cls, value, *args):
        return int(value)


class KeywordListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return KeywordValueConverter


class KeywordAssociationListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return KeywordAssociationValueConverter


class AssociatedTestsListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return AssociatedTestsValueConverter


class TestCaseListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return TestCaseValueConverter


class ScheduledTestListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ScheduledTestValueConverter


class ScheduledTestCaseListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ScheduledTestCaseValueConverter


class ScheduledTestCaseValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, case_data):
        return ScheduledTestCase(case_data)

    @classmethod
    def encode_radar_value(cls, case, *args):
        return case.database_id_attribute_value()


class ScheduledTestValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, value):
        # In some areas, the build is returned as just an integer. Convert to a dictionary so that it can be
        # processed as a Build
        if isinstance(value.get('build'), compat.string_types):
            value['build'] = {NamedBuild.identifier_attrs[0]: value['build']}
        if isinstance(value.get('owner'), int):
            value['owner'] = {Person.identifier_attrs[0]: value['owner']}
        return ScheduledTest(value)

    @classmethod
    def encode_radar_value(cls, scheduled_test, *args):
        return scheduled_test.database_id_attribute_value()


class LabelValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, label_data):
        if isinstance(label_data, compat.string_types):
            # Labels returned by shared report execution are just strings with the name, the remaining information is missing.
            # Create a dummy dictionary in that case.
            label_data = {'name': label_data, 'id': None, 'color': None, 'order': None}
        return Label(label_data) if label_data else None

    @classmethod
    def encode_radar_value(cls, label, *args):
        return label.id if label else None

    @classmethod
    def encode_user_friendly_value(cls, value):
        return value.name if value else None


class AssociatedTestsValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        def keyword_extractor(keyword_list):
            # If a user does not have access to a related item, keywords is None. The below handles that.
            # See https://a1391192.slack.com/archives/CJS717APK/p1715687838101779
            to_return = None
            if keyword_list is not None:
                to_return = []
                for keyword in keyword_list:
                    to_return.append(keyword['keyword'])

            return to_return

        if item_data['type'] == 'SUITE':
            merged_items = deepcopy(item_data['suite'])
            merged_items['associatedTests'] = item_data['associatedTests']
            merged_items['keywords'] = keyword_extractor(item_data['keywords'])
            merged_items['_order'] = item_data['order']
            return TestSuite(merged_items)
        else:
            merged_items = deepcopy(item_data['case'])
            merged_items['_order'] = item_data['order']
            merged_items['keywords'] = keyword_extractor(item_data['keywords'])
            return TestCase(merged_items)

    @classmethod
    def encode_radar_value(cls, item, *args):
        item.database_id_attribute_value()


class TestCaseValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, case_data):
        return TestCase(case_data)

    @classmethod
    def encode_radar_value(cls, case, *args):
        return case.caseID


class TSTTRelatedProblemConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, value):
        return TSTTRelatedProblem(data=value)

    @classmethod
    def encode_radar_value(cls, value, *args):
        return {'problemId': value.id, 'relationType': value.relationType}


class TSTTRelatedProblemListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return TSTTRelatedProblemConverter


class ScheduledTestCaseRelatedProblemValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, data):
        return ScheduledTestCaseRelatedProblem(data)

    # @classmethod
    # def encode_radar_value(cls, case):
    #     return case.caseID


class ScheduledTestCaseRelatedProblemListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ScheduledTestCaseRelatedProblemValueConverter


class ComponentValueConverterEncodeOnly(AbstractValueConverter):
    """
    This preserves the dictionary form on the decode side. This is used to ensure backwards compatibility
    for the "component" property on Radar instances. That property started out as a raw dictionary and it
    was initially not mapped in the property value converter map of the Radar class. That was later
    changed so that the property could be *set* to both a raw dictionary but also to an instance of the
    Component class. That class was introduced to properly model a component.

    :meta private:
    """

    @classmethod
    def encode_radar_value(cls, component, *args):
        if isinstance(component, dict):
            if 'id' in component:
                try:
                    return int(component['id']) # Try converting str to int, workaround for rdar://98842951
                except:
                    raise Exception("Invalid 'id' type in Component dictionary: {}".format(type(component['id'])))
            else:
                return component
        elif isinstance(component, Component):
            if hasattr(component, 'id'):
                try:
                    return int(component.id)    # Try converting str to int, workaround for rdar://98842951
                except:
                    raise Exception("Invalid 'id' type in Component object: {}".format(type(component.id)))
            raise Exception("Component object has no 'id' property")
        else:
            raise Exception('Invalid type "{}" for component value'.format(type(component)))


class ComponentValueConverter(ComponentValueConverterEncodeOnly):

    @classmethod
    def decode_radar_value(cls, component_data):
        if component_data is None:
            return component_data
        # API v2.2 includes inaccessible components in hierarchies by default.
        if 'id' in component_data:
            if component_data['id'] is not None and not all([component_data.get('name'), component_data.get('version')]):
                return ComponentInaccessible(component_data)
        return Component(component_data)


class RadarBoardComponentValueConverter(ComponentValueConverterEncodeOnly):

    @classmethod
    def decode_radar_value(cls, component_data):
        if component_data is None:
            return component_data
        if component_data.get('id') and not component_data.get('name') and not component_data.get('version'):
            return ComponentInaccessible(component_data)
        return Component(component_data)


class ComponentBundleValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, component_bundle_data):
        return ComponentBundle(component_bundle_data)

    @classmethod
    def encode_radar_value(cls, component_bundle, *args):
        """
        Encodes a component bundle in to a valid ``dict`` for the Radar API

        :param ComponentBundle component_bundle: component bundle to encode

        :return: Valid ``dict`` representation of ``component_bundle``
        """
        return {'name': component_bundle.name, 'id': component_bundle.id}


class ComponentBundleMemberValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, component_bundle_item_data):
        # API v2.2 includes inaccessible components in bundles by default.
        if component_bundle_item_data['name'] is None and component_bundle_item_data['version'] is None:
            return ComponentBundleMemberInaccessible(component_bundle_item_data)
        return ComponentBundleMember(component_bundle_item_data)

    @classmethod
    def encode_radar_value(cls, component_bundle_item, *args):
        return {'name': component_bundle_item.name, 'id': component_bundle_item.id}


class RadarGroupMemberValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, value):
        return None if value is None else RadarGroupMember(value)


class RadarGroupMemberListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return RadarGroupMemberValueConverter


class RadarGroupRoleValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, value):
        return None if value is None else WorkGroupRoles(value)


class ComponentBundleGroupMemberBundleValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, component_bundle_group_member_data):
        return ComponentBundleGroupMemberBundle(component_bundle_group_member_data)

    @classmethod
    def encode_radar_value(cls, component_bundle_group_member, *args):
        return {'name': component_bundle_group_member.name, 'id': component_bundle_group_member.id}


class ComponentBundleGroupMemberGroupValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, component_bundle_group_member_data):
        return ComponentBundleGroupMemberGroup(component_bundle_group_member_data)

    @classmethod
    def encode_radar_value(cls, component_bundle_group_member, *args):
        return {'name': component_bundle_group_member.name, 'id': component_bundle_group_member.id}


class ProgramManagementComponentPropertyValueConverter(AbstractValueConverter):

    @classmethod
    def encode_radar_value(cls, item, *args):
        data = {}
        if item:
            if item.id:
                data['id'] = item.id
            if item.name:
                data['name'] = item.name
        return data if data else None


class EventValueConverter(ProgramManagementComponentPropertyValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return Event(item_data) if item_data else None


class CategoryValueConverter(ProgramManagementComponentPropertyValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return Category(item_data) if item_data else None


class TentpoleValueConverter(ProgramManagementComponentPropertyValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return Tentpole(item_data) if item_data else None


class MilestoneAsRadarPropertyValueConverter(AbstractValueConverter):
    """
    This value converter is for the radar.milestone property.

    :meta private:
    """

    @classmethod
    def decode_radar_value(cls, milestone_data):
        return Milestone(milestone_data) if milestone_data else None

    @classmethod
    def encode_radar_value(cls, milestone, *args):
        if isinstance(milestone, Milestone):
            if milestone.id is not None:
                return {'id': milestone.id}
            else:
                return {'name': milestone.name}
        return milestone

    @classmethod
    def decode_user_friendly_value(cls, value):
        try:
            value = int(value)
            return Milestone({'id': value})
        except ValueError:
            pass

        # TODO: handle other convenience formats, for example "<component name>:<component version>:<milestone name>"
        # We'll need to figure out how to plumb a client instance in here

        raise Exception('Invalid milestone value "{}", must be a Milestone ID'.format(value))


class ComponentListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ComponentValueConverter


class ComponentBundleListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ComponentBundleValueConverter


class ComponentBundleMemberListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ComponentBundleMemberValueConverter


class ComponentBundleGroupMemberBundleListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ComponentBundleGroupMemberBundleValueConverter


class ComponentBundleGroupMemberGroupListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return ComponentBundleGroupMemberGroupValueConverter


class LabelListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return LabelValueConverter


class MilestoneListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return MilestoneAsRadarPropertyValueConverter


class CategoryListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return CategoryValueConverter


class EventListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return EventValueConverter


class TentpoleListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return TentpoleValueConverter


class AccessGroupValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, group_data):
        if group_data is None:
            return None
        return AccessGroup(group_data)


class AccessGroupListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return LabelValueConverter


class ComponentWorkGroupValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, work_group_obj_data):
        role_keys = ['builder', 'integrator', 'owner', 'screener', 'verifier']
        if 'roles' not in work_group_obj_data and any(key in work_group_obj_data for key in role_keys):
            work_group_roles = {key: work_group_obj_data[key] for key in role_keys if key in work_group_obj_data}
            new_work_group_obj_data = {
                'description': work_group_obj_data['description'],
                'id': work_group_obj_data['id'],
                'name': work_group_obj_data['name'],
                'roles': work_group_roles
            }
            return WorkGroup(new_work_group_obj_data)
        return WorkGroup(work_group_obj_data)


class RadarBoardStateColumnConverter(AbstractValueConverter):
    @classmethod
    def decode_radar_value(cls, column_data):
        if column_data is None:
            return None
        return RadarBoardStateColumn(column_data)

    @classmethod
    def encode_radar_value(cls, column, *args):
        if column is not None:
            if column.id is not None:
                return int(column.id)
        return None


class PersonValueConverter(AbstractValueConverter):
    """
    This converts from the person dictionaries as returned by the find person query and others to Person
    objects.

    :meta private:
    """

    @classmethod
    def decode_radar_value(cls, person_data):
        if person_data is None:
            return None
        return Person(person_data)

    @classmethod
    def encode_radar_value(cls, person, *args):
        if person is not None:
            if person.dsid is not None:
                return int(person.dsid)
        return None

    @classmethod
    def decode_user_friendly_value(cls, value):
        return Person({'dsid': value})


class PersonListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return PersonValueConverter


class PersonChatValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return PersonChat(item_data) if item_data else None


class PersonChatSlackValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return PersonChatSlack(item_data) if item_data else None


class MentionValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return Mention(item_data) if item_data else None


class MentionListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return MentionValueConverter


class MentionDetailsValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return MentionDetails(item_data) if item_data is not None else None


class QuerySubscriberListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return QuerySubscriberValueConverter


class QuerySubscriberValueConverter(AbstractValueConverter):
    @classmethod
    def decode_radar_value(cls, subscriber_data):
        subscriber_type = subscriber_data.get('type', None)
        permission = subscriber_data.get('permission', None)
        sub_type_obj = subscriber_data
        if subscriber_type is not None:
            if 'subscriber' in subscriber_data:
                subscriber_info = subscriber_data['subscriber']
                if subscriber_type in ['Person', 'person']:
                    sub_type_obj = Person(subscriber_info)
                elif subscriber_type in ['Access Group', 'access-group']:
                    sub_type_obj = AccessGroup(subscriber_info)
                elif subscriber_type in ['Work Group', 'work-group']:
                    sub_type_obj = WorkGroup(subscriber_info)
            elif subscriber_type == 'Everyone':
                sub_type_obj = QuerySubscriberEveryone(subscriber_data)
        subscriber_dict_repr = {
            'subscriber': sub_type_obj,
            'type': subscriber_type,
            'permission': permission,
        }
        return QuerySubscriber(subscriber_dict_repr)


class CommentAuthorValueConverter(AbstractValueConverter):
    """
    This converts from the person dictionaries as returned by the description/diagnosis list queries
    to the CommentAuthor objects.

    :meta private:
    """

    @classmethod
    def decode_radar_value(cls, person_data):
        if isinstance(person_data, compat.string_types):
            person_data = {'email': None, 'name': person_data}
        return CommentAuthor(person_data)

    @classmethod
    def encode_radar_value(cls, author, *args):
        return {'email': author.email, 'name': author.name}


class AttachmentLinkValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return AttachmentLink(item_data, type=AttachmentLink.ATTACHMENT_TYPE_LINKED) if item_data else None


class AttachmentLinkSourceValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return AttachmentLink(item_data, type=AttachmentLink.ATTACHMENT_TYPE_SOURCE) if item_data else None


class AttachmentLinkSourceListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return AttachmentLinkSourceValueConverter


class ISO8601DateOnlyValueConverter(AbstractValueConverter):
    """
    Convert between Python ``date`` objects and the date string
    representation used in the raw Radar API requests.

    This variant uses only the date part and does not use the time of day.
    """

    @classmethod
    def decode_radar_value(cls, iso8601_date_string):
        if iso8601_date_string is None:
            return None

        components = re.findall(r'^(\d{4})-(\d{2})-(\d{2})$', iso8601_date_string)
        if not components:
            raise Exception('Invalid date value "{}"'.format(iso8601_date_string))

        year, month, day = components[0]
        return datetime.date(int(year), int(month), int(day))

    @classmethod
    def encode_radar_value(cls, date_value, *args):
        """
        Converts a ``date`` object in to a properly formatted string for the Radar API

        :param datetime.date date_value: date

        :return: properly formated str representation of the date object for the Radar API
        """
        if date_value is None:
            return None
        if isinstance(date_value, datetime.datetime):
            date_value = date_value.date()
        return date_value.isoformat()


class UTC(datetime.tzinfo):
    """
    UTC time zone class reference implementation from the Python "datetime" module documentation
    """

    def utcoffset(self, dt):
        return datetime.timedelta(0)

    def tzname(self, dt):
        return "UTC"

    def dst(self, dt):
        return datetime.timedelta(0)


class LocalTimeZone(datetime.tzinfo):
    """
    :meta private:
    """

    def utcoffset(self, dt):
        offset_seconds = time.altzone if self.does_dst_apply() else time.timezone
        return datetime.timedelta(seconds=-offset_seconds)

    def tzname(self, dt):
        return time.tzname[time.daylight]

    def dst(self, dt):
        return datetime.timedelta(seconds=time.altzone - time.timezone)

    def does_dst_apply(self):
        return time.daylight and time.localtime().tm_isdst

# In general value converters are an implementation detail
# not to be exposed to API clients, but we'll expose this one because
# it's often useful.
class ISO8601UTCDateValueConverter(AbstractValueConverter):
    """
    Convert between Python ``datetime`` objects and the date string
    representation used in the raw Radar API requests.

    This variant supports date including time of day.
    """

    utc = UTC()

    local = LocalTimeZone()

    @classmethod
    def decode_radar_value(cls, iso8601_date_string):
        if iso8601_date_string is None:
            return None
        dt = datetime.datetime.strptime(iso8601_date_string[:19], '%Y-%m-%dT%H:%M:%S')
        dt = dt.replace(tzinfo=cls.utc)
        return dt

    @classmethod
    def encode_radar_value(cls, datetime_value, *args):
        """
        Converts a tz aware ``datetime`` object in to a properly formatted string for the Radar API

        :param datetime.datetime datetime_value: tz aware datetime

        :return: properly formated str representation of the datetime object for the Radar API
        :raises: if ``datetime_value`` is not timezone aware
        """
        if datetime_value:
            if not datetime_value.tzinfo:
                raise Exception('datetime values must have a timezone')
            return datetime.datetime.strftime(datetime_value, '%Y-%m-%dT%H:%M:%S%z')
        else:
            return None


class CamelCase(object):
    """
    Convert between fooBarBaz (used by Radar) and foo_bar_baz (used by Python) names.

    :meta private:
    """
    @classmethod
    def encode(cls, underscore_value):
        # underscore -> camel case
        return re.sub(r'(\w)_(\w)', lambda match: match.group(1) + match.group(2).upper(), underscore_value)

    @classmethod
    def decode(cls, camelcase_value):
        # camel case -> underscore
        return re.sub(r'([a-z])([A-Z])', lambda match: match.group(1) + '_' + match.group(2).lower(), camelcase_value)


class Relationship(object):
    """
    Represents a relationship to another Radar.

    :param str type: the relationship type, see below
    :param radarclient.model.Radar radar: the radar instance
    :param radarclient.model.Radar related_radar: the related radar instance
    :param int related_radar_id: the related radar id, in case the actual radar instance is unavailable, which can happen if permissions don't allow it to be loaded.

    Instances of this class have the following properties, corresponding to the parameters above:

    - type, :py:class:`str`, the type
    - radar, :py:class:`Radar`, the radar instance
    - related_radar, :py:class:`Radar`, the related radar instance
    - related_radar_id, :py:class:`int`, the related radar id

    The ``type`` property is one of

    - Relationship.TYPE_RELATED_TO
    - Relationship.TYPE_ORIGINAL_OF
    - Relationship.TYPE_DUPLICATE_OF
    - Relationship.TYPE_CLONE_OF
    - Relationship.TYPE_CLONED_TO
    - Relationship.TYPE_BLOCKED_BY
    - Relationship.TYPE_BLOCKING
    - Relationship.TYPE_PARENT_OF
    - Relationship.TYPE_SUBTASK_OF
    - Relationship.TYPE_CAUSE_OF
    - Relationship.TYPE_CAUSED_BY

    Example::

        radar = radar_client.radar_for_id(1234)

        # get all relationships
        for r in radar.relationships():
            print('from {} to {} type {}'.format(r.radar.id, r.related_radar.id, r.type))

        # get relationships of a certain type
        for r in radar.relationships([Relationship.TYPE_CLONED_TO]):
            print('cloned from {} to {}'.format(r.radar.id, r.related_radar.id))

    """

    TYPE_RELATED_TO = 'related-to'
    TYPE_ORIGINAL_OF = 'original-of'
    TYPE_DUPLICATE_OF = 'duplicate-of'
    TYPE_CLONE_OF = 'clone-of'
    TYPE_CLONED_TO = 'cloned-to'
    TYPE_BLOCKED_BY = 'blocked-by'
    TYPE_BLOCKING = 'blocking'
    TYPE_PARENT_OF = 'parent-of'
    TYPE_SUBTASK_OF = 'subtask-of'
    TYPE_CAUSE_OF = 'cause-of'
    TYPE_CAUSED_BY = 'caused-by'

    inverse_map = {
        TYPE_RELATED_TO: TYPE_RELATED_TO,
        TYPE_ORIGINAL_OF: TYPE_DUPLICATE_OF,
        TYPE_CLONE_OF: TYPE_CLONED_TO,
        TYPE_BLOCKING: TYPE_BLOCKED_BY,
        TYPE_PARENT_OF: TYPE_SUBTASK_OF,
        TYPE_CAUSE_OF: TYPE_CAUSED_BY,
    }
    inverse_map.update({v: k for k, v in list(inverse_map.items())})

    def __init__(self, type, radar, related_radar=None, related_radar_id=None):
        self.type = type
        self.radar = radar
        self.related_radar = related_radar
        self.related_radar_id = related_radar.id if related_radar else related_radar_id

    def inverse_relationship(self):
        """
        Returns a :py:class:`Relationship` instance with the ``radar`` and ``related_radar``
        values reversed, and the ``type`` field set to the inverse relationship type.
        """

        return Relationship(self.inverse_map[self.type], self.related_radar, self.radar)

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        return u'<Relationship {} -{}-> {}>'.format(self.radar.id, self.type, self.related_radar_id)

    def __eq__(self, other):
        match = self.radar.id == other.radar.id
        match = match and self.related_radar_id == other.related_radar_id
        match = match and self.type == other.type
        return match

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(self.radar.id) ^ hash(self.type) ^ hash(self.related_radar_id)

    def webservice_url(self):
        return self.radar.webservice_url_relationships() + '/' + self.type + '/' + str(self.related_radar_id)


class AttachmentLink(DictionaryBasedModel):
    """
    A custom class representing a link between an :py:class:`Attachment` (the source attachment file) on a Radar, and a
    :py:class:`LinkedAttachment` (the virtual, or "linked" version) on a second Radar.

    :param Attachment attachment: The relevant :py:class:`Attachment` or :py:class:`LinkedAttachment`
    :param str type: The link type, see below
    :param radarclient.model.Radar radar: the radar instance
    :param radarclient.model.Radar linked_radar: the linked radar instance
    :param int linked_radar_id: The ``id`` of the linked Radar, in case the actual radar instance is unavailable,
        which can happen if permissions don't allow it to be loaded, or the AttachmentLink object was loaded from the
        API as either the ``links`` or ``sourceFile`` property of the Attachment object.

    AttachmentLink objects have the following properties:

    - ``type``, :py:class:`str` (see below)
    - ``radar``, :py:class:`Radar` representing the parent :py:class:`Attachment`'s Radar, whether for the source or the linked attachment.
    - ``linked_radar``, :py:class:`Radar` representing the Radar on the other end of the link, whether for the source or the linked attachment.
    - ``linked_radar_id``, if the linked Radar instance isn't loaded or available.

    AttachmentLink objects can have the following additional properties (when fetched from the Radar API):

    - ``createdAt``, :py:class:`datetime.datetime`
    - ``createdBy``, :py:class:`Person`

    The ``type`` is one of:

    - AttachmentLink.ATTACHMENT_TYPE_SOURCE (``source``)
    - AttachmentLink.ATTACHMENT_TYPE_LINKED (``linked``)

    For examples and more information, see :py:attr:`Radar.attachments.link() <AttachmentCollectionProperty.link>`,
    :py:attr:`Radar.attachments.unlink() <AttachmentCollectionProperty.unlink>`,
    :py:meth:`Radar.link_all_attachments_from_radar_id`, and :py:meth:`Radar.unlink_all_attachments_from_radar_id`.

    """
    ATTACHMENT_TYPE_SOURCE = 'source'
    ATTACHMENT_TYPE_LINKED = 'linked'

    def __init__(self, link_data=None, attachment=None, type=None, radar=None, linked_radar=None, linked_radar_id=None):
        self.attachment = attachment
        assert link_data or (attachment and type and (linked_radar or linked_radar_id)), \
            "Missing information for AttachmentLink instantiation"
        self.type = type
        self.radar = attachment.radar if attachment else radar
        self.linked_radar_id = linked_radar.id if linked_radar else linked_radar_id
        if link_data:
            self.linked_radar_id = link_data.get("entityId")
            super(AttachmentLink, self).__init__(link_data)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(AttachmentLink, cls).property_value_converter_map)
        map.update({
            'createdBy': PersonValueConverter,
        })
        return map

    def __unicode__(self):
        filename = self.attachment.fileName
        if self.type == self.ATTACHMENT_TYPE_SOURCE:
            return u'<AttachmentLink to rdar://{} for {}>'.format(self.linked_radar_id, filename)
        elif self.type == self.ATTACHMENT_TYPE_LINKED:
            return u'<AttachmentLink from rdar://{} for {}>'.format(self.linked_radar_id, filename)
        return u'<AttachmentLink for {}>'.format(filename)


class CollectionProperty(object):
    """
    This class is used for some properties on a :py:class:`Radar` instance that represent
    collections of items instead of simple values. You don't instantiate it directly.

    Currently, the following Radar properties are instances of ``CollectionProperty`` (or a subclass thereof):

    - ``radar.diagnosis`` - instances of :py:class:`DiagnosisEntry`
    - ``radar.description`` - instances of :py:class:`DescriptionEntry`
    - ``radar.pictures`` - instances of :py:class:`Picture`
    - ``radar.attachments`` - instances of :py:class:`Attachment` or :py:class:`LinkedAttachment`
    - ``radar.other_related_items`` - instances of :py:class:`OtherRelatedItem`
    - ``radar.buildInfo`` - instances of :py:class:`NamedBuild`
    - ``radar.fixedInBuild`` - instances of :py:class:`Build`
    - ``radar.foundInBuild`` - instances of :py:class:`Build`
    - ``radar.mustBeFixedInBuild`` - instances of :py:class:`Build`
    - ``radar.verifiedInBuild`` - instances of :py:class:`Build`

    Changes (additions, deletions) to the collection are not sent to the Radar database
    immediately, instead they are queued and executed on a call to :py:meth:`Radar.commit_changes`.

    Additionally, some collections like ``radar.diagnosis`` (:py:class:`DiagnosisEntry`) or ``radar.description``
    (:py:class:`DescriptionEntry`) don't allow deletion, only addition, consistent with how Radar works.

    For usage examples, see the corresponding item classes.
    """

    def _apply_loaded_item_data(self, item_data_list):
        self.loaded_items = []
        for item_data in item_data_list:
            item = self.item_class(item_data)
            if callable(getattr(item, 'set_parent_radar', None)):
                item.set_parent_radar(self.radar)
            self.loaded_items.append(item)

    def __init__(self, property_name, radar, item_class, collection_data=None):
        self.item_class = item_class
        self.property_name = property_name
        self.radar = radar
        self.reset()
        if collection_data is not None:
            self._apply_loaded_item_data(collection_data)

    def reset(self):
        self.loaded_items_request_configuration = {}
        self.loaded_items = None
        self.added_items = []

    def load_items(self, **kwargs):
        if self.loaded_items is not None and self.loaded_items_request_configuration == kwargs:
            return

        if not hasattr(self.item_class, 'webservice_url_for_radar'):
            raise Exception('CollectionProperty item class "{}" does not support loading data separately. Please preload it by adding the appropriate additional_fields list entry when you request the parent object.'.format(self.item_class.__name__))

        radar = self.radar
        url = self.item_class.webservice_url_for_radar(radar, **kwargs)

        self.loaded_items_request_configuration = kwargs

        request = radar.client.request_for_json_url(url)
        status, item_data_list = radar.client.send_request(request)

        if status == 404:
            item_data_list = []
        self._apply_loaded_item_data(item_data_list)

    def add(self, item):
        """
        Add a new item to the collection. As noted above, additions are not immediately
        sent to the Radar database, but the :py:meth:`items` method will return them
        before the call to :py:meth:`Radar.commit_changes`.

        See :py:meth:`Radar.new_picture`, :py:meth:`Radar.new_attachment`, :py:class:`DescriptionEntry`,
        and :py:class:`DiagnosisEntry` for examples.
        """
        self.check_item_type(item)

        change_record_class = self.item_class.change_record_class_for_add()
        self.check_change_record_class(change_record_class)
        self.radar.add_change_record(change_record_class(self, item))
        self.added_items.append(item)

    def check_item_type(self, item):
        if not isinstance(item, self.item_class):
            raise Exception('Item "{}" (type {}) is not of expected type "{}"'.format(item, type(item).__name__, self.item_class.__name__))

    def check_change_record_class(self, change_record_class):
        # We need to be sure that the change record class knows how to deal with a CollectionProperty and is compatible with our constructor call
        assert issubclass(change_record_class,
                          CollectionPropertyModificationRadarChangeRecord), 'Change record classes for collection property modifications must be of type {}, {} is not.'.format(
            CollectionPropertyModificationRadarChangeRecord.__name__, change_record_class.__name__)

    def summary(self):
        return u'\n'.join([compat.unicode_string_type(i) for i in self.items()])

    def delete(self, item):
        """
        Delete an item from the collection. As noted above, deletions are not immediately
        sent to the Radar database, and the :py:meth:`items` method will still return deleted
        items until the call to :py:meth:`Radar.commit_changes`.

        See :py:meth:`Radar.new_picture` and :py:meth:`Radar.new_attachment` for examples.

        """
        self.check_item_type(item)
        change_record_class = self.item_class.change_record_class_for_delete()
        self.check_change_record_class(change_record_class)
        self.radar.add_change_record(change_record_class(self, item))

    def items(self, **kwargs):
        """
        Return the collection's items.

        """
        self.load_items(**kwargs)
        return self.loaded_items + self.added_items

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        return u'<CollectionProperty {}>'.format(self.property_name)


class AttachmentCollectionProperty(CollectionProperty):
    """
    This :py:class:`CollectionProperty` subclass is specific for the :py:class:`Attachment` class, which has unique
    functionality specific to supporting instances of :py:class:`LinkedAttachment`, and the linking/unlinking of those
    files between Radars. As with the parent class, you don't instantiate it directly.

    For more information, see the classes linked above, plus :py:meth:`link` and :py:meth:`unlink` below.
    """
    def _apply_loaded_item_data(self, item_data_list):
        self.loaded_items = []
        for item_data in item_data_list:
            if item_data.get('sourceFile'):
                item = LinkedAttachment(item_data)
            else:
                item = Attachment(item_data)
            if callable(getattr(item, 'set_parent_radar', None)):
                item.set_parent_radar(self.radar)
                all_links = [l for l in item.links + [item.sourceFile] if l]
                for link in all_links:
                    link.attachment = item
                    link.radar = self.radar
            self.loaded_items.append(item)

    def __init__(self, property_name, radar, item_class, collection_data=None):
        assert item_class == Attachment, "Invalid item class ({}) for AttachmentCollectionProperty!".format(item_class)
        super(AttachmentCollectionProperty, self).__init__(property_name, radar, item_class, collection_data)

    def link(self, item):
        """
        Links an :py:class:`Attachment` to another Radar or creates a new :py:class:`LinkedAttachment` linked from its
        source Radar, by creating a new :py:class:`AttachmentLink` object. **NOTE**: The change will not take effect
        until calling :py:meth:`Radar.commit_changes`.

        Example::

            # Linking from an existing attachment (the source Radar)
            source_radar = radar_client.radar_for_id(123456789)
            # Find the right attachment
            valid_attachment = None
            for attachment in source_radar.attachments.items():
                if attachment.fileName == "crashlog.txt":
                    valid_attachment = attachment
                    break
            # This radar needs the linked attachment
            target_radar = radar_client.radar_for_id(111222333)
            # Creating the link
            new_link = AttachmentLink(attachment=valid_attachment, type=AttachmentLink.ATTACHMENT_TYPE_SOURCE,
                                      radar=source_radar, linked_radar=target_radar)
            source_radar.attachments.link(new_link)
            source_radar.commit_changes()

            # Linking from the to-be-linked/destination Radar
            target_radar = radar_client.radar_for_id(111222333)
            # Creating the eventual LinkedAttachment
            new_attachment = target_radar.new_attachment("crashlog.txt")
            source_radar_id = 123456789
            # Creating the link
            new_link = AttachmentLink(attachment=new_attachment, type=AttachmentLink.ATTACHMENT_TYPE_LINKED,
                                      target_radar=target_radar, linked_radar_id=source_radar_id)
            target_radar.attachments.link(new_link)
            target_radar.commit_changes()

        """
        assert isinstance(item, AttachmentLink)
        self.radar.add_change_record(LinkAttachmentRadarChangeRecord(self, item))

    def unlink(self, item):
        """
        Unlinks an :py:class:`Attachment` from a linked Radar or a :py:class:`LinkedAttachment` from its source Radar,
        using a reference to the existing Attachment's :py:class:`AttachmentLink`. **NOTE**:The change will not take
        effect until calling :py:meth:`Radar.commit_changes`.

        .. note::
            Unlinking a :py:class:`LinkedAttachment` does not delete the original :py:class:`Attachment` on its source
            Radar.

        Example::

            # Unlinking from the attachment's linked Radar (not the source Radar)
            radar = radar_client.radar_for_id(111222333)
            # Finding the linked attachment and getting its AttachmentLink instance
            existing_attachment_link = None
            for attachment in radar.attachments.items():
                if isinstance(attachment, LinkedAttachment):
                    if attachment.fileName == "crashlog.txt":
                        existing_attachment_link = attachment.sourceFile
            # Unlinking the attachment
            if existing_attachment_link:
                radar.attachments.unlink(existing_attachment_link)
                radar.commit_changes()

            # Unlinking from the attachment's source Radar
            radar = radar_client.radar_for_id(123456789)
            # Finding the attachment that has links to other Radars
            existing_attachment_links = []
            for attachment in radar.attachments.items():
                if attachment.fileName == "crashlog.txt":
                    if attachment.links:
                        existing_attachment_links.extend(attachment.links)
            # Unlinking the attachment
            for link in existing_attachment_links:
                radar.attachments.unlink(link)
            radar.commit_changes()

        """
        assert isinstance(item, AttachmentLink)
        self.radar.add_change_record(UnlinkAttachmentRadarChangeRecord(self, item))

    def delete(self, item):
        """
        This method overrides the parent delete() specifically for LinkedAttachment, so client users
        can simply call radar.attachments.delete(attachment) for a LinkedAttachment and it will unlink seamlessly.

        TODO: This should utilize a LinkedAttachment.change_record_class_for_delete() override instead.

        :meta private:
        """
        if isinstance(item, LinkedAttachment):
            change_record_class = UnlinkAttachmentRadarChangeRecord
            self.check_change_record_class(change_record_class)
            self.radar.add_change_record(change_record_class(self, item.sourceFile))
        else:
            super(AttachmentCollectionProperty, self).delete(item)


class WorkflowActions(DictionaryBasedModel):
    pass


class WorkflowConditions(DictionaryBasedModel):
    pass


class WorkflowNotification(DictionaryBasedModel):

    DEFAULT_PROPERTIES = [
        'attributes',
        'notificationType',
        'scope'
    ]

    @cached_class_property
    def property_names(cls):
        return super(WorkflowNotification, WorkflowNotification).property_names + WorkflowNotification.DEFAULT_PROPERTIES


class WorkflowActionsValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, actions_data):
        return WorkflowActions(actions_data)

    @classmethod
    def encode_radar_value(cls, actions, *args):
        pass


class WorkflowConditionsValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, conditions_data):
        return WorkflowConditions(conditions_data)

    @classmethod
    def encode_radar_value(cls, conditions, *args):
        pass


class WorkflowNotificationValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, notifications_data):
        return WorkflowNotification(notifications_data)

    @classmethod
    def encode_radar_value(cls, notifications, *args):
        pass


class WorkflowNotificationListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return WorkflowNotificationValueConverter


class Workflow(DictionaryBasedModel):
    """
    Represents a Workflow object. These objects are returned as representations of a subscription when
    calling :py:meth:`~radarclient.client.RadarClient.workflows_for_current_user`, :py:meth:`~radarclient.client.RadarClient.find_workflows`,
    or :py:meth:`~radarclient.client.RadarClient.workflow_for_id`.

    .. note::
        Workflows are user-specific. The various APIs can only access Workflows created by the current authenticated user.

    More information available in the `Radar API Docs (Workflow APIs)`_.

    Workflow objects have the following properties:

    - actions
    - conditions
    - indexedDate
    - lastModifiedDate
    - lastModifiedPerson
    - lastModifiedPersonId
    - name
    - notifications
    - status
    - subscriberId
    - tags
    - tokenObjects
    - workflowConditionType
    - workflowId
    """
    identifier_attrs = ('workflowId',)
    DEFAULT_PROPERTIES = [
        'actions',
        'conditions',
        'indexedDate',
        'lastModifiedDate',
        'lastModifiedPerson',
        'lastModifiedPersonId',
        'name',
        'notifications',
        'status',
        'subscriberId',
        'tags',
        'tokenObjects',
        'workflowConditionType',
        'workflowId',
    ]
    BASE_URL = 'workflow/problem'
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)

    def __init__(self, dictionary_representation=None, *extra_constructor_args):
        super(Workflow, self).__init__(
            dictionary_representation=dictionary_representation, *extra_constructor_args
        )

    @classmethod
    def _find(cls, request_data, client):
        workflows = []
        next_page = None
        while True:
            query_params = ''
            if next_page:
                query_params = '?page_to_fetch={}'.format(next_page)
            _, results = client.build_and_send_json_request((cls.BASE_URL, 'find', query_params), request_data, method='POST')
            workflows.extend(Workflow(item) for item in results['workflows'])
            next_page = results['nextPage']
            if not next_page:
                break
        return workflows

    @cached_class_property
    def property_names(cls):
        return super(Workflow, Workflow).property_names + Workflow.DEFAULT_PROPERTIES

    def __unicode__(self):
        status = self.status or None
        name = ' "{}" '.format(self.name) if self.name else ' '
        return u'<Workflow {}{}{}>'.format(self.workflowId, name, status)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(Workflow, cls).property_value_converter_map)
        map.update({
            'indexedDate': ISO8601UTCDateValueConverter,
            'lastModifiedDate': ISO8601UTCDateValueConverter,
            'lastModifiedPerson': PersonValueConverter,
            'notifications': WorkflowNotificationListValueConverter,
            'conditions': WorkflowConditionsValueConverter,
            'actions': WorkflowActionsValueConverter
        })
        return map


class RadarHistory(object):
    """
    This class is used for the ``combined_history(**kwargs)`` method of the :py:class:`Radar` class. It represents changes
    made to a Radar over time that are normally tracked separately in a Radar's Problem History and Diagnosis History
    (via the ChangedField object). You don't instantiate it directly.

    :meta private:
    """

    def __init__(self, property_name, radar, item_class):
        self.item_class = item_class
        self.property_name = property_name
        self.radar = radar
        self.reset()

    def reset(self):
        self.loaded_items = None

    def load_items(self, **kwargs):
        if self.loaded_items is not None:
            return

        radar = self.radar
        radar_id = radar.id

        include_data_changes = kwargs.get('include_data_changes', False)
        additional_snapshot_attributes = kwargs.get('additional_snapshot_attributes', [])
        skip_diagnosis_history = kwargs.get('skip_diagnosis_history', False)
        skip_snapshots = kwargs.get('skip_snapshots', False)

        raw_problem_history = self._get_problem_history(radar_id) if not hasattr(radar, 'history') else getattr(radar, 'history')
        processed_prob_history = self._process_problem_history(raw_problem_history, radar)

        if skip_diagnosis_history:
            processed_change_history = []
        else:
            raw_change_history = self._get_change_history(radar_id) if not hasattr(radar, 'diagnosisHistory') else getattr(radar, 'diagnosisHistory')
            processed_change_history = self._process_change_history(raw_change_history['history'], include_data_changes)

        self.loaded_items = self._build_combined_history(processed_prob_history, processed_change_history, radar,
                                                         additional_snapshot_attributes, skip_diagnosis_history,
                                                         skip_snapshots)

    def summary(self):
        return u'\n'.join([compat.unicode_string_type(i) for i in self.events()])

    def events(self, **kwargs):
        """
        Equivalent to the items() method of the CollectionProperty class.

        :meta private:
        """
        self.load_items(**kwargs)
        return self.loaded_items

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        return u'<RadarHistory {}>'.format(self.property_name)

    def _get_problem_history(self, radar_id):
        problem_history_url = self.radar.client.webservice_url_for_path_components('problems', radar_id, 'history')
        request = self.radar.client.request_for_json_url(problem_history_url)
        response_status, response_data = self.radar.client.send_request(request, True)
        if not response_status == 200:
            raise Exception("Failure to obtain Problem History: {}\n{}".format(response_status, response_data))
        return response_data

    def _get_change_history(self, radar_id):
        changed_fields_url = self.radar.client.webservice_url_for_path_components('problems', 'history', radar_id)
        request = self.radar.client.request_for_json_url(changed_fields_url)
        response_status, response_data = self.radar.client.send_request(request, True)
        if not response_status == 200:
            raise Exception("Failure to obtain Change History: {}\n{}".format(response_status, response_data))
        return response_data[0]['history']

    def _process_problem_history(self, problem_history, radar):
        """
        Takes the list of ProblemHistory objects and reformats each into the new change event dictionary.
        Includes the radar object because the value for radar.createdAt will be used by the per-event
        processing function.

        :meta private:
        """
        createdAt = radar.createdAt
        processed_problem_history = []
        for problem_history_object in problem_history:
            new_event = self._reformat_problem_history_event(problem_history_object, radar)
            if new_event:
                processed_problem_history.append(new_event)
        return processed_problem_history

    def _reformat_problem_history_event(self, problem_history_object, radar):
        """
        Processes a single ProblemHistory object into the new change event dictionary.
        The radar object is included because the first ProblemHistory object (which should include a value
        for 'changedAt' matching the time of the Radar's creation) needs to be treated as a change event
        for the component and assignee, from 'None' to their initial values.
        The first change event will be altered again later to add the initial title, reproducible, and
        classification values to its snapshot. These attributes, along with component, assignee, and
        description are the only attributes set at the time of creation.

        :meta private:
        """
        new_change_event = {}
        changed_attributes = []

        problem_history_attribute_comparison_map = {
            'assignee' : ('changedAt', 'whenReassignedDate'),
            'category_name' : ('previousCategory', 'changedCategory'),
            'component' : ('previousComponentID', 'changedComponentID'),
            'event_name' : ('previousEvent', 'changedEvent'),
            'fixOrder' : ('previousFixOrder', 'changedFixOrder'),
            'milestone' : ('previousMilestone', 'changedMilestone'),
            'priority' : ('previousPriority', 'changedPriority'),
            'state' : ('previousState', 'changedState'),
            'tentpole_name' : ('previousTentpole', 'changedTentpole')
        }

        if problem_history_object['changedAt'] == datetime.datetime.strftime(radar.createdAt, '%Y-%m-%dT%H:%M:%S%z'):
            # This is the initial ProblemHistory object from the Radar's creation.
            changed_attributes.append({ 'assignee' : { 'from' : None, 'to' : problem_history_object['assignee'] } })
            changed_attributes.append({ 'component' : { 'from' : None, 'to' : problem_history_object['component'] } })
        else:
            for attribute, values in problem_history_attribute_comparison_map.items():
                """
                Iterates through the attributes in problem_history_attribute_comparison_map using the specified
                values to determine what has changed. Includes special handling for assignee & component, and
                any previous assignee & component values will be back-referenced later.

                :meta private:
                """
                previous_value = problem_history_object[values[0]]
                changed_value = problem_history_object[values[1]]
                if attribute == 'assignee':
                    if previous_value == changed_value:
                        changed_attributes.append({ attribute : { 'from' : RadarHistoryValuePlaceholderPreviousAssignee(), 'to' : problem_history_object['assignee'] } })
                elif previous_value != changed_value:
                    if attribute == 'component':
                        previous_value = RadarHistoryValuePlaceholderPreviousComponent()
                        changed_value = problem_history_object['component']
                    changed_attributes.append({ attribute : { 'from' : previous_value, 'to' : changed_value } })

        if changed_attributes:
            new_change_event = {
                'changed_at' : problem_history_object['changedAt'],
                'changed_by' : problem_history_object['changedBy'],
                'changes' : changed_attributes
            }
            return RadarHistoryModificationEvent(new_change_event)
        else:
            return

    def _process_change_history(self, change_history, include_data_changes):
        """
        Takes the list of ChangedField objects and reformats each into the new change event dictionary.
        Not all ChangedField objects will be retained, as some are pure overlaps with ProblemHistory objects.
        Includes special logic to correlate matching keyword additions and removals for the snapshots.

        :meta private:
        """
        processed_change_history = []
        paired_event_count = 0
        paired_event_terms = ['addedRelation', 'removedRelation', 'keywordAdded', 'keywordRemoved']
        for changed_field_object in change_history:
            # Count the events related to adding/removing keyword and problem relationships (see below)
            if any(term in changed_field_object['action'].keys() for term in paired_event_terms):
                paired_event_count += 1
            new_event = self._reformat_change_history_event(changed_field_object, include_data_changes)
            if new_event:
                processed_change_history.append(new_event)

        def _match_paired_change_events(add_action, remove_action, _processed_change_history, comparison_parameters):
            """
            This method is used to match the keyword/related_problem events for adding and removing (if removed)
            to make sure both have the full set of additional attributes for the combined_history feature. It iterates
            twice through the _processed_change_history objects, first creating an index of all changes for keyword and
            related problem additions/removals, then again to actually match the paired events using the index to look
            up the paired values, if available.

            :meta private:
            """
            change_event_data = {}
            for new_changed_field_object in _processed_change_history:
                for change in new_changed_field_object.changes:
                    if change._change_type in [add_action, remove_action]:
                        change_timestamp = new_changed_field_object.changed_at.strftime("%Y-%m-%dT%H:%M:%S%z")
                        key = '&'.join([str(change.change_details[parameter]) for parameter in comparison_parameters])
                        key += '&' + change._change_type
                        if key not in change_event_data:
                            change_event_data[key] = {}
                        if change_timestamp not in change_event_data[key]:
                            change_event_data[key][change_timestamp] = {}
                        change_event_data[key][change_timestamp] = change.change_details

            for new_changed_field_object in _processed_change_history:
                for change in new_changed_field_object.changes:
                    if change._change_type in [add_action, remove_action]:
                        change_timestamp = new_changed_field_object.changed_at.strftime("%Y-%m-%dT%H:%M:%S%z")
                        key = '&'.join([str(change.change_details[parameter]) for parameter in comparison_parameters])
                        if change._change_type == add_action:
                            key += '&' + remove_action
                            if key in change_event_data:
                                sorted_timestamps = sorted(change_event_data[key].keys())
                                for timestamp in sorted_timestamps:
                                    if timestamp > change_timestamp:
                                        next_change_details = change_event_data[key][timestamp]
                                        change.change_details['removed_at'] = next_change_details['removed_at']
                                        change.change_details['removed_by'] = next_change_details['removed_by']
                                        break
                        elif change._change_type == remove_action:
                            key += '&' + add_action
                            if key in change_event_data:
                                sorted_timestamps = sorted(change_event_data[key].keys())
                                for i in range(len(sorted_timestamps) - 1, -1, -1):
                                    if sorted_timestamps[i] < change_timestamp:
                                        prev_change_details = change_event_data[key][sorted_timestamps[i]]
                                        change.change_details['addedAt'] = prev_change_details['addedAt']
                                        change.change_details['addedBy'] = prev_change_details['addedBy']
                                        break

        _match_paired_change_events('keywordAdded', 'keywordRemoved', processed_change_history, ['keyword_name'])
        _match_paired_change_events('addedRelation', 'removedRelation', processed_change_history, ['type', 'related_radar_id'])

        return processed_change_history

    def _reformat_change_history_event(self, changed_field_object, include_data_changes=False):
        """
        Processes a single ChangedField object into the new change event dictionary.
        Not all changed attributes will be retained, as some are also listed in 'matching' ChangedField objects.
        Skipped attributes will be listed in change_history_attribute_denylist.

        :meta private:
        """
        new_change_event = {}
        changed_attributes = []

        change_history_attribute_denylist = [
            'assignee', 'category', 'component', 'event', 'fixOrdering', 'milestone', 'priority', 'state', 'tentpole', 'data'
        ]
        change_history_related_problem_attributes = [
            'addedRelation', 'removedRelation', 'relationTypeChange'
        ]

        if include_data_changes:
            change_history_attribute_denylist.remove('data')

        def _process_related_problem_change(attribute, change):
            """
            Takes the part of the ChangedField object's 'action' dictionary when the change is for
            relating/unrelating other problems, and builds a dict for the Relationship class.

            :meta private:
            """
            _changes = []

            related_problem_relationship_type_map = {
                'related to' : Relationship.TYPE_RELATED_TO,
                'original of' : Relationship.TYPE_ORIGINAL_OF,
                'duplicate of' : Relationship.TYPE_DUPLICATE_OF,
                'clone of' : Relationship.TYPE_CLONE_OF,
                'cloned to' : Relationship.TYPE_CLONED_TO,
                'blocked by' : Relationship.TYPE_BLOCKED_BY,
                'blocking' : Relationship.TYPE_BLOCKING,
                'parent of' : Relationship.TYPE_PARENT_OF,
                'subtask of' : Relationship.TYPE_SUBTASK_OF,
                'cause of' : Relationship.TYPE_CAUSE_OF,
                'caused by' : Relationship.TYPE_CAUSED_BY
            }

            def _build_addedRelation_dict(type, related_radar_id):
                return {
                    'addedRelation' : {
                        'type' : type,
                        'related_radar_id' : related_radar_id,
                        'addedBy' : changed_field_object['addedBy'],
                        'addedAt' : changed_field_object['addedAt'],
                        'removed_by' : None,
                        'removed_at' : None
                    }
                }

            def _build_removedRelation_dict(type, related_radar_id):
                return {
                    'removedRelation' : {
                        'type' : type,
                        'related_radar_id' : related_radar_id,
                        'addedAt' : None,
                        'addedBy' : None,
                        'removed_by' : changed_field_object['addedBy'],
                        'removed_at' : changed_field_object['addedAt']
                    }
                }

            RELATIONSHIP_CHANGE_REGEX = r'this problem is (?:now |no longer )?(\S* ?\S{2}).*rdar://(?:problem/)?(\d+)(?: \(was (.*)\))?'
            new_relationship_type_string, radar_id, previous_relationship_type_string = re.findall(RELATIONSHIP_CHANGE_REGEX, change)[0]
            assert new_relationship_type_string in related_problem_relationship_type_map, '"{}" not found in known relationship types. (Radar ID: {}, related Radar ID: {})'.format(new_relationship_type_string, self.radar.id, radar_id)

            if attribute == 'relationTypeChange':
                _changes.append(_build_addedRelation_dict(related_problem_relationship_type_map[new_relationship_type_string], int(radar_id)))
                _changes.append(_build_removedRelation_dict(related_problem_relationship_type_map[previous_relationship_type_string], int(radar_id)))
            elif attribute == 'addedRelation':
                _changes.append(_build_addedRelation_dict(related_problem_relationship_type_map[new_relationship_type_string], int(radar_id)))
            elif attribute == 'removedRelation':
                _changes.append(_build_removedRelation_dict(related_problem_relationship_type_map[new_relationship_type_string], int(radar_id)))

            return _changes

        changes = changed_field_object['action']
        for attribute, change in changes.items():
            if attribute in change_history_attribute_denylist:
                continue
            elif attribute in change_history_related_problem_attributes:
                relationship_changes = _process_related_problem_change(attribute, change)
                changed_attributes.extend(relationship_changes)
            elif attribute == 'keywordAdded':
                changed_attributes.append({
                    attribute : {
                        'keyword_name' : change,
                        'addedBy' : changed_field_object['addedBy'],
                        'addedAt' : changed_field_object['addedAt'],
                        'removed_by' : None,
                        'removed_at' : None
                    }
                })
            elif attribute == 'keywordRemoved':
                changed_attributes.append({
                    attribute : {
                        'keyword_name' : change,
                        'addedAt' : None,
                        'addedBy' : None,
                        'removed_by' : changed_field_object['addedBy'],
                        'removed_at' : changed_field_object['addedAt']
                    }
                })
            else:
                changed_attributes.append({ attribute : change })

        if changed_attributes:
            new_change_event = {
                'changed_at' : changed_field_object['addedAt'],
                'changed_by' : changed_field_object['addedBy'],
                'changes' : changed_attributes
            }
            return RadarHistoryModificationEvent(new_change_event)
        else:
            return

    def _build_combined_history(self, problem_history, change_history, radar, additional_snapshot_attributes, skip_diagnosis_history, skip_snapshots):
        """
        Takes the reformatted problem_history and change_history lists and combines them.
        Creates a snapshot for every change event, backfilling for the initial title, reproducible,
        and classification values as well as back-referencing previous assignee and component values.

        :meta private:
        """
        combined_history = []
        raw_combined_history = []
        raw_combined_history.extend(problem_history + change_history)
        sorted_raw_combined_history = sorted(raw_combined_history, key=lambda k: k.changed_at)

        # Due to rdar://92610324, we have to make sure the first RadarHistoryModificationEvent in the sorted list is actually
        # the true initial mod event (where Assignee is changed from None to <person> and Component from None to <component>). If
        # the first event isn't the creation event, find it and arbitrarily make it the oldest event, 1sec older than first_event.
        def _find_creation_event_index(combined_history):
            for index, modification_event in enumerate(combined_history):
                if modification_event.did_attribute_change('assignee') and modification_event.did_attribute_change('component'):
                    if modification_event.change_for_attribute('assignee').old_value is None and modification_event.change_for_attribute('assignee').old_value is None:
                        return index
            raise Exception("Unable to find the creation event in the history for rdar://{}".format(radar.id))

        creation_event_index = _find_creation_event_index(sorted_raw_combined_history)
        if creation_event_index > 0:
            logger.warning("The oldest RadarHistoryModificationEvent for rdar://{} is not the creation event. Rolling back the true creation event's changedAt timestamp arbitrarily to accommodate.".format(radar.id))
            sorted_raw_combined_history[creation_event_index].changed_at = sorted_raw_combined_history[0].changed_at - datetime.timedelta(seconds=1)
            sorted_raw_combined_history = sorted(sorted_raw_combined_history, key=lambda k: k.changed_at)

        # Combine the change events that have the same timestamp.
        index = 0
        for modification_event in sorted_raw_combined_history:
            previous_event = sorted_raw_combined_history[index-1] if index > 0 else None
            if previous_event and (modification_event.changed_at == previous_event.changed_at) and (modification_event.changed_by == previous_event.changed_by):
                combined_history[-1].changes.extend(modification_event.changes)
            else:
                combined_history.append(modification_event)
            index += 1

        if skip_snapshots:
            return combined_history

        def _find_attribute_for_backfill(attribute, combined_history_without_snapshots, radar):
            """
            Looks for the initial value of an attribute based on whenever it changed, to be sent back to the
            initial modification_event's snapshot. This applies to Title, Classification, Reproducible, and Originator.
            If the attribute never changed, the current value must be the same as the initial value.

            :meta private:
            """
            for modification_event in combined_history_without_snapshots:
                for change in modification_event.changes:
                    if change._change_type == attribute:
                        return change.old_value
            return getattr(radar, attribute)

        # Build the initial snapshot.
        initial_createdAt = datetime.datetime.strftime(radar.createdAt, '%Y-%m-%dT%H:%M:%S%z')
        initial_snapshot_values = {
            'assignee' : None,
            'category_name' : None,
            'component' : None,
            'createdAt' : initial_createdAt,
            'event_name' : None,
            'fixOrder' : 6,
            'id' : radar.id,
            'lastModifiedAt' : initial_createdAt,
            'milestone' : None,
            'priority' : 5,
            'state' : 'Analyze',
            'tentpole_name' : None
        }
        if not skip_diagnosis_history:
            initial_snapshot_values['assigneeLastModifiedAt'] = None
            initial_snapshot_values['classification'] = _find_attribute_for_backfill('classification', combined_history, radar)
            initial_snapshot_values['configurationSummary'] = None
            initial_snapshot_values['duplicateOfProblemID'] = None
            initial_snapshot_values['history_keywords'] = []
            initial_snapshot_values['isReadByAssignee'] = False
            initial_snapshot_values['originator'] = _find_attribute_for_backfill('originator', combined_history, radar)
            initial_snapshot_values['related_problems'] = []
            initial_snapshot_values['reproducible'] = _find_attribute_for_backfill('reproducible', combined_history, radar)
            initial_snapshot_values['resolution'] = 'Unresolved'
            initial_snapshot_values['substate'] = 'Screen'
            initial_snapshot_values['title'] = _find_attribute_for_backfill('title', combined_history, radar)
            if len(additional_snapshot_attributes) > 0:
                for addl_attribute in additional_snapshot_attributes:
                    initial_snapshot_values[addl_attribute] = None
        initial_snapshot = RadarHistorySnapshot(initial_snapshot_values)

        # Update the snapshot for every modification_event.
        for index, modification_event in enumerate(combined_history):
            was_modified_by_assignee = False
            previous_event = combined_history[index-1] if index > 0 else None
            new_snapshot = initial_snapshot._copy() if index == 0 else previous_event.radar_history_snapshot._copy()
            for change in modification_event.changes:
                change.apply_to_radar_history_snapshot(new_snapshot, radar)

                # Also fetch the previous assignee and component dicts to fill in their 'from' values.
                if change.change_type() == 'old-new':
                    if change.property_name() == 'assignee':
                        was_modified_by_assignee = True
                        if isinstance(change.old_value, RadarHistoryValuePlaceholderPreviousAssignee):
                            change.old_value = previous_event.radar_history_snapshot.assignee
                    elif change.property_name() == 'component':
                        if isinstance(change.old_value, RadarHistoryValuePlaceholderPreviousComponent):
                            change.old_value = previous_event.radar_history_snapshot.component

                    # Special handling for changing a Radar's Resolution to/from 'Duplicate':
                    # 1. The DiagHistory prints "Duplicate of rdar://problem/########" instead of just 'Duplicate'.
                    # 2. There is no modification event for 'duplicateOfProblemID' in any history API so do it manually.
                    if change.property_name() == 'resolution':
                        if change.new_value is not None and 'Duplicate' in change.new_value:
                            try:
                                original_radar_id = re.match(r'.*Duplicate of rdar://problem/(\d+)', change.new_value)[1]
                                new_snapshot.duplicateOfProblemID = original_radar_id
                            except:
                                pass
                            new_snapshot.resolution = 'Duplicate'
                            change.new_value = 'Duplicate'
                        if change.old_value is not None and 'Duplicate' in change.old_value:
                            change.old_value = 'Duplicate'
                            if not 'Duplicate' in change.new_value:
                                new_snapshot.duplicateOfProblemID = None

            # There is no modification event for 'assigneeLastModifiedAt' in any history API so do it manually.
            if (modification_event.changed_by == new_snapshot.assignee):
                was_modified_by_assignee = True
            if was_modified_by_assignee and not skip_diagnosis_history:
                new_snapshot.assigneeLastModifiedAt = modification_event.changed_at
            new_snapshot.lastModifiedAt = modification_event.changed_at
            modification_event.radar_history_snapshot = new_snapshot

        return combined_history


class RadarHistoryModificationEvent(DictionaryBasedModel):
    """
    This class represents a set of modifications made to a Radar at a particular point in time. The changed
    attributes come from either the Problem History or the Diagnosis History (ChangedField) objects of the Radar
    in question. For context, see :py:meth:`~radarclient.model.Radar.combined_history`.

    :param datetime.datetime changed_at: the time at which the modifications were made
    :param Person changed_by: the user responsible for the modifications
    :param list changes: a list of dictionaries, each one a :py:class:`RadarHistoryChange` (or one of its subclasses) which represents a single modified attribute or related action.
    :param RadarHistorySnapshot radar_history_snapshot: a historical snapshot of the Radar at the time the modifications were made (`including` the as-modified attributes)

    For most attributes that can only ever hold single values, the corresponding dictionary in ``changes`` will be a :py:class:`RadarHistoryChangeOldNew`
    and include the name of the changed attribute as its key, with a nested dictionary containing ``from`` and ``to``
    key-value pairs. Notable attributes excluded from this include ``configuration``, for which the API only returns
    "Changes made" (but not the contents), and all the non-``assignee`` roles.

    For changed attributes that can hold multiple values (ie. keywords and related problems), the corresponding
    dictionaries in ``changes`` include the 'action' as its key (``keywordAdded``, ``keywordRemoved``, ``addedRelation``, or
    ``removedRelation``) with a nested dictionary referencing the :py:class:`RadarHistoryKeywordAssociation` or
    :py:class:`RadarHistoryRelationship` that was added or removed.

    There are custom "change classes" defined for many groups of (or individual) attributes. For more information,
    start with :py:class:`RadarHistoryChange`.

    """
    DEFAULT_PROPERTIES = [
        'changed_at',
        'changed_by',
        'changes',
        'radar_history_snapshot'
    ]

    @cached_class_property
    def property_names(cls):
        return super(RadarHistoryModificationEvent, RadarHistoryModificationEvent).property_names + \
               RadarHistoryModificationEvent.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarHistoryModificationEvent, cls).property_value_converter_map)
        map.update({
            'changed_at': ISO8601UTCDateValueConverter,
            'changed_by': PersonValueConverter,
            'changes': RadarHistoryChangeListValueConverter,
        })
        return map

    def change_for_attribute(self, attribute):
        """
        Returns the first :py:class:`RadarHistoryChange` matching the specific ``attribute`` provided for a given
        :py:class:`RadarHistoryModificationEvent`, or `None` if that attribute didn't change in this modification.

        For changes that could have multiple entries in the same modification event, such as keywords or related problems,
        use :py:meth:`~radarclient.model.RadarHistoryModificationEvent.changes_for_attributes` instead.
        """
        for _change in self.changes:
            if _change.property_name() == attribute:
                return _change
        return None

    def changes_for_attributes(self, attributes=None):
        """
        Returns a :py:class:`list` of `all` the :py:class:`RadarHistoryChange` objects matching any the values in ``attributes`` for a given
        :py:class:`RadarHistoryModificationEvent`, or an empty list if those attributes didn't change in that modification event.
        """
        attributes = attributes or []
        _changes = []
        for _change in self.changes:
            if _change.property_name() in attributes:
                _changes.append(_change)
        return _changes

    def did_attribute_change(self, attribute):
        """
        A convenience wrapper for :py:meth:`~radarclient.model.RadarHistoryModificationEvent.change_for_attribute`.

        Returns a boolean, `True` if the provided `attribute` changed in this specific :py:class:`RadarHistoryModificationEvent`.
        """
        if self.change_for_attribute(attribute):
            return True
        return False

    def __unicode__(self, include_changes=True):
        if include_changes:
            return u'<RadarHistoryModificationEvent at {} for changes made by {}>\n    {}'.format(
                self.changed_at,
                self.changed_by,
                '\n    '.join([item.__unicode__() for item in self.changes])
            )
        else:
            return u'<RadarHistoryModificationEvent at {} for changes made by {}>'.format(self.changed_at, self.changed_by)


class RadarHistorySnapshot(DictionaryBasedModel):
    """
    Represents a historical snapshot of a Radar at a single point in time. A separate snapshot is generated
    for each :py:class:`RadarHistoryModificationEvent` in the :py:meth:`~radarclient.model.Radar.combined_history` for a :py:class:`Radar`.

    Several attributes that are normally represented by custom classes in standard :py:class:`Radar`
    objects are only represented by their value strings from Radar's history APIs:

    - ``category_name`` instead of :py:class:`Category`
    - ``event_name`` instead of :py:class:`Event`
    - ``tentpole_name`` instead of :py:class:`Tentpole`
    - ``history_keywords`` instead of ``keywords``, a :py:class:`list` of :py:class:`RadarHistoryKeywordAssociation` objects instead of :py:class:`KeywordAssociation` objects. Each contains additional historical properties, but only the string value of ``keyword_name`` is available, and not the component or id.
    - ``related_problems`` is a :py:class:`list` of :py:class:`RadarHistoryRelationship` objects instead of :py:class:`Relationship` objects. Each contains additional historical properties but swaps the actual radar instances for ids.

    By default, the snapshots will include 23 of the most commonly-used attributes: ``assignee``, ``assigneeLastModifiedAt``,
    ``category_name``, ``classification``, ``component``, ``configurationSummary``, ``createdAt``, ``duplicateOfProblemID``,
    ``event_name``, ``fixOrder``, ``history_keywords``, ``id``, ``isReadByAssignee``, ``lastModifiedAt``, ``milestone``,
    ``priority``, ``related_problems``, ``reproducible``, ``resolution``, ``state``, ``substate``, ``tentpole_name``, and ``title``.
    With ``skip_diagnosis_history=True`` this is limited to only 11 attributes (see above in :py:meth:`~radarclient.model.Radar.combined_history`).

    .. warning::
        Some attributes have different names in the Diagnosis history API responses than their equivalent attribute name in the response
        from the ``/problems/<problem_id>`` API (aka the 'live' or current value). For example, ``configurationSummary`` is referred to as
        ``configSummary`` in the history APIs, and because it is one of the default attributes included in the snapshots, a special change
        class is provided to map that. Other additional attributes that don't match will be referenced by the nomenclature provided by the
        history APIs unless new custom change classes are added. (rdar://80634225)

    Additional attributes/actions (``change_type`` values) can be persisted in snapshots by including them in the ``additional_snapshot_attributes``
    argument of the call to ``radar.combined_history.items()``. They will be added to all snapshots from the first entry onward. This feature
    cannot be used in conjunction with ``skip_diagnosis_history=True``.

    Example::

        radar = radar_client.radar_for_id(1234)
        # include some additional attributes in the snapshots
        for modification_event in radar.combined_history(additional_snapshot_attributes=['workaround', 'succinctSummaryRootCause', 'percentageOfEffortComplete', 'isVerifiedByTester']):
            print(modification_event)
            print(modification_event.radar_history_snapshot)

    """
    DEFAULT_PROPERTIES = [
        'assignee',
        'category_name',
        'component',
        'createdAt',
        'event_name',
        'fixOrder',
        'id',
        'lastModifiedAt',
        'milestone',
        'priority',
        'state',
        'tentpole_name',
    ]

    @cached_class_property
    def property_names(cls):
        return super(RadarHistorySnapshot, RadarHistorySnapshot).property_names + \
               RadarHistorySnapshot.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarHistorySnapshot, cls).property_value_converter_map)
        map.update({
            'assignee': PersonValueConverter,
            'assigneeLastModifiedAt': ISO8601UTCDateValueConverter,
            'component': ComponentValueConverter,
            'fixOrder' : SimpleIntegerValueConverter,
            'history_keywords' : RadarHistoryKeywordAssociationListValueConverter,
            'id': SimpleIntegerValueConverter,
            'milestone': MilestoneAsRadarPropertyValueConverter,
            'priority': SimpleIntegerValueConverter,
        })
        return map

    def __unicode__(self):
        snapshot_output = ''
        indent_width = 0
        for k in sorted(self.__dict__.keys()):
            if k != 'dictionary_representation_data':
                if len(k) > indent_width:
                    indent_width = len(k)
        for k, v in sorted(self.__dict__.items()):
            if k != 'dictionary_representation_data':
                if not isinstance(v, list):
                    snapshot_output += '\n    {} | {}'.format(k.ljust(indent_width), v)
                else:
                    snapshot_output += '\n    {} |'.format(k.ljust(indent_width))
                    for index, item in enumerate(v):
                        snapshot_output += '\n    {} | {}'.format(' '*indent_width, item) if index > 0 else ' {}'.format(item)

        return u'<RadarHistorySnapshot from {} for <rdar://problem/{}>>{}'.format(self.lastModifiedAt, self.id, snapshot_output)

    def _copy(self):
        """
        Make a mostly deep copy of this snapshot.
        Related problems are shallow copied to avoid excess memory usage. rdar://134949347

        :meta private:
        """
        if hasattr(self, "related_problems"):
            copy1 = copy(self)
            copy1.related_problems = []
            copy2 = deepcopy(copy1)
            copy2.related_problems = copy(self.related_problems)
            return copy2
        return deepcopy(self)


class RadarHistoryRelationship(DictionaryBasedModel):
    """
    Represents a relationship to another Radar in the past, as part of a :py:class:`RadarHistorySnapshot`.

    :param str type: the relationship type, see below
    :param Radar radar_id: the source radar's id
    :param int related_radar_id: the related radar's id
    :param Person addedBy: the user that added the relationship
    :param datetime.datetime addedAt: the time the relationship was added
    :param Person removed_by: the user that removed the relationship `(if applicable)`
    :param datetime.datetime removed_at: the time the relationship was removed `(if applicable)`

    This class differs from :py:class:`Relationship` in that both the radar & related radar objects are not included; only their ids.
    Also, the times and DRI of both the related radar's addition and removal are added for reference. The actual values for ``addedBy``,
    ``addedAt``, ``removed_by``, and ``removed_at`` are extrapolated from the :py:class:`RadarHistoryModificationEvent` instances that
    contain the ``changes`` referencing the addition (and removal, when applicable) of the related radar.

    .. note::
        The use of both camelCase parameter names (``addedBy``, ``addedAt``) and conventional python underscore/snake_case names
        (``removed_by``, ``removed_at``) is intentional. Properties named in camelCase come directly from the Radar API and are
        intentionally unaltered.

    For a list of available values for the ``type`` property, see :py:class:`Relationship`.

    """
    DEFAULT_PROPERTIES = [
        'type',
        'radar_id',
        'related_radar_id',
        'addedBy',
        'addedAt',
        'removed_by',
        'removed_at'
    ]

    @cached_class_property
    def property_names(cls):
        return super(RadarHistoryRelationship, RadarHistoryRelationship).property_names + \
               RadarHistoryRelationship.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarHistoryRelationship, cls).property_value_converter_map)
        map.update({
            'addedBy': PersonValueConverter,
            'removed_by' : PersonValueConverter,
            'removed_at' : ISO8601UTCDateValueConverter,
            'radar_id': SimpleIntegerValueConverter,
            'related_radar_id' : SimpleIntegerValueConverter
        })
        return map

    def __init__(self, change_details, radar):
        super(RadarHistoryRelationship, self).__init__(change_details)
        self.radar_id = radar.id

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        if self.removed_by and self.removed_at:
            return u'<RadarHistoryRelationship {} -{}-> {}, added by {} on {}, removed by {} on {}>'.format(
                self.radar_id,
                self.type,
                self.related_radar_id,
                self.addedBy,
                self.addedAt,
                self.removed_by,
                self.removed_at
            )
        else:
            return u'<RadarHistoryRelationship {} -{}-> {}, added by {} on {}>'.format(
                self.radar_id,
                self.type,
                self.related_radar_id,
                self.addedBy,
                self.addedAt
            )

    def __eq__(self, other):
        match = self.related_radar_id == other.related_radar_id
        match = match and self.type == other.type
        return match

    # todo: validate this comparison mechanism?
    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(self.radar_id) ^ hash(self.type) ^ hash(self.related_radar_id)


class RadarHistoryKeywordAssociation(DictionaryBasedModel):
    """
    An object that captures the historical record of an association of a keyword to a Radar, as part of a :py:class:`RadarHistorySnapshot`.

    :param str keyword_name: the ``name`` value of the keyword as-added
    :param Person addedBy: the user that added the keyword
    :param datetime.datetime addedAt: the time at which the keyword was added
    :param Person removed_by: the user that removed the keyword `(if applicable)`
    :param datetime.datetime removed_at: the time at which the keyword was removed `(if applicable)`

    This class differs from :py:class:`KeywordAssociation` primarily in that only the name of the keyword is retained for
    historical purposes instead of the full ``Keyword`` object. Also, the times and DRI of both the keyword's addition and removal
    are included together for reference. The actual values for ``addedBy``, ``addedAt``, ``removed_by``, and ``removed_at`` are
    extrapolated from the :py:class:`RadarHistoryModificationEvent` instances that contain the ``changes``
    referencing the addition (and removal, when applicable) of the keyword.

    .. note::
        The use of both camelCase parameter names (``addedBy``, ``addedAt``) and conventional python underscore/snake_case names
        (``removed_by``, ``removed_at``) is intentional. Properties named in camelCase come directly from the Radar API and are
        intentionally unaltered.

    """

    DEFAULT_PROPERTIES = [
        'keyword_name',
        'addedBy',
        'addedAt',
        'removed_by',
        'removed_at'
    ]

    def __eq__(self, other):
        return self.keyword_name == other.keyword_name

    def __ne__(self, other):
        return not self.keyword_name == other.keyword_name

    @cached_class_property
    def property_names(cls):
        return super(RadarHistoryKeywordAssociation, RadarHistoryKeywordAssociation).property_names + \
               RadarHistoryKeywordAssociation.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarHistoryKeywordAssociation, cls).property_value_converter_map)
        map.update({
            'addedBy': PersonValueConverter,
            'removed_by' : PersonValueConverter,
            'removed_at' : ISO8601UTCDateValueConverter
        })
        return map

    def __unicode__(self):
        if self.removed_by and self.removed_at:
            return u'<RadarHistoryKeywordAssociation for "{}", added by {} on {}, removed by {} on {}>'.format(
                self.keyword_name,
                self.addedBy,
                self.addedAt,
                self.removed_by,
                self.removed_at
            )
        else:
            return u'<RadarHistoryKeywordAssociation for "{}", added by {} on {}>'.format(
                self.keyword_name,
                self.addedBy,
                self.addedAt
            )


class RadarHistoryKeywordAssociationValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, keyword_association_data):
        return RadarHistoryKeywordAssociation(keyword_association_data)

    @classmethod
    def encode_radar_value(cls, keyword_association, *args):
        raise Exception('Encoding of keyword associations is not supported')


class RadarHistoryKeywordAssociationListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return RadarHistoryKeywordAssociationValueConverter


class RadarHistoryValuePlaceholder(object):

    pass


class RadarHistoryValuePlaceholderPreviousAssignee(RadarHistoryValuePlaceholder):

    pass


class RadarHistoryValuePlaceholderPreviousComponent(RadarHistoryValuePlaceholder):

    pass


class RadarHistoryChangeListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return RadarHistoryChangeValueConverter


class RadarHistoryChangeValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, value):
        decoded_value = RadarHistoryChange.change_for_raw_data(value)
        if decoded_value:
            return decoded_value
        raise Exception('Unable to decode history change: {}'.format(value))


class RadarHistoryChangeSimpleStringValueConverter(AbstractValueConverter):
    """
    This converter is used by the :py:class:`Radar` class' `self.combined_history` functionality for attributes that
    sometimes replace `None` with an empty string, such as `substate`, `configurationSummary`,  resolvedBy`, and the
    non-assignee roles.

    :meta private:
    """
    @classmethod
    def decode_radar_value(cls, value):
        if value == '':
            return None
        return value

    @classmethod
    def encode_radar_value(cls, value, *args):
        if not value:
            return ''
        return value


class RadarHistoryChange(object):
    """
    Each :py:class:`RadarHistoryModificationEvent` includes the ``changes`` property that is a list of changed attributes represented by
    custom "change classes". This is the base change class for all subclasses that handle modifications to various groups of (or
    individual) Radar attributes.

    :param str change_type(): For changes to the most-common attributes, this will be ``old-new``. For the rest, it will return the same as ``property_name()``.
    :param str property_name(): The name of the attribute/field that was changed (such as ``title`` or ``assignee``) or associated action (such as ``keywordAdded`` or ``removedRelation``).
    :param varies changed_value(): The updated value of the attribute/field, or the object added/removed (such as with keywords or related problems), or the string representing the `result` of the change.

    For info on the ``old-new`` changes, see :py:class:`RadarHistoryChangeOldNew`.

    Why all the various change subclasses? The goal was to be able to provide custom services/functionality for those change events in
    shared functions. So far there are three shared functions:

    - ``apply_to_radar_history_snapshot(self, snapshot, radar)``: For any custom behavior when adding/removing the related changes to/from the current radar_history_snapshot.
    - ``initialize_from_change_type_and_details(self)``: To add custom properties to the specific subclass, for ease of reference elsewhere in code.
    - ``__unicode__()``: Defines how the contents of this change will output for a ``print()`` statement in code. Useful primarily for demonstration and debugging. Any subclasses that don't define their own method will fall back on the standard output defined here.

    """
    @classmethod
    def change_for_raw_data(cls, raw_data):
        assert isinstance(raw_data, dict) and len(raw_data) == 1
        change_type = list(raw_data.keys())[0]
        change_details = raw_data[change_type]

        known_change_classes = []
        def register_handler_class(change_class):
            if not 'Abstract' in change_class.__name__ and change_class.__name__ != 'RadarHistoryChange':
                known_change_classes.append(change_class)
            for subclass in change_class.__subclasses__():
                register_handler_class(subclass)
        register_handler_class(cls)

        for change_class in known_change_classes:
            if change_class.can_parse_data(change_type, change_details):
                return change_class(change_type, change_details)
        logger.warning('No explicit RadarHistoryChange subclass designated for change_type: {}'.format(change_type))
        return RadarHistoryChangeGeneric(change_type, change_details)

    def __init__(self, change_type, change_details):
        self._change_type = change_type
        self.change_details = change_details
        self.initialize_from_change_type_and_details()

    def initialize_from_change_type_and_details(self):
        raise NotImplementedError()

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        if hasattr(snapshot, self.property_name()):
            setattr(snapshot, self.property_name(), self.new_value)

    def change_type(self):
        return self._change_type

    def property_name(self):
        return self._change_type

    def changed_value(self):
        return self.change_details

    @classmethod
    def can_parse_data(cls, data):
        raise NotImplementedError()

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        if self._change_type in ['keywordAdded', 'keywordRemoved']:
            change_summary = 'Keyword name "{}"'.format(self.keyword_name)
        elif self._change_type in ['keyAdded', 'keyModified', 'keyRemoved']:
            change_summary = 'KeyValuePair name "{}"'.format(self.key_name)
        elif self._change_type in ['addedRelation', 'removedRelation']:
            change_summary = "type '{}', related_radar_id {}".format(self.change_details['type'], self.change_details['related_radar_id'])
        else:
            change_summary = self.change_details
        return u"<RadarHistoryChange for '{}': {}>".format(self.property_name(), change_summary)


class RadarHistoryChangeOldNew(RadarHistoryChange):
    """
    Many common attribute changes are listed in the Diagnosis History (ChangedField) API's responses with dictionaries
    for both 'from' (old) and 'to' (new) values.

    This class is used for changes with ``change_type()`` values of ``old-new``, and will have these extra parameters in addition to the
    standard parameters in :py:class:`RadarHistoryChange`:

    :param varies old_value: The previous (or 'from') value.
    :param varies new_value: The new/current (or 'to') value. For these changes, it will be the same as ``changed_value()``.

    """
    def initialize_from_change_type_and_details(self):
        value_converter_class = self.value_converter_class()
        value_converter = lambda x: x
        if value_converter_class:
            value_converter = value_converter_class.decode_radar_value

        from_value = self.change_details['from']
        to_value = self.change_details['to']

        self.old_value = from_value
        self.new_value = to_value

        try:
            if isinstance(from_value, RadarHistoryValuePlaceholder):
                self.old_value = from_value
            else:
                self.old_value = value_converter(from_value)
            self.new_value = value_converter(to_value)
        except:
            logger.warning('Unable to decode change type "{}" with value converter "{}" for data: {}'.format(self.property_name(), value_converter_class, self.change_details))

    def change_type(self):
        return 'old-new'

    def changed_value(self):
        return self.new_value

    def value_converter_class(self):
        custom_converter_mappings = {
            'component' : ComponentValueConverter,
            'originator': RadarHistoryChangeSimpleStringValueConverter,
            'resolvedBy': RadarHistoryChangeSimpleStringValueConverter,
            'dri': RadarHistoryChangeSimpleStringValueConverter,
            'epm': RadarHistoryChangeSimpleStringValueConverter,
            'targetCompletionCurrent': RadarHistoryChangeSimpleStringValueConverter,
            'targetStartDate': RadarHistoryChangeSimpleStringValueConverter
        }

        if not self.property_name() in custom_converter_mappings:
            return Radar.property_value_converter_map.get(self.property_name(), RadarHistoryChangeSimpleStringValueConverter)
        else:
            return custom_converter_mappings[self.property_name()]

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        # Each of the following needs to be defined in its own subclass.
        non_matching_attribute_names = [
            'configSummary'
        ]
        if not change_type in non_matching_attribute_names:
            return 'from' in change_detail_data and 'to' in change_detail_data and len(change_detail_data) == 2

    def __unicode__(self):
        return u"<RadarHistoryChange for '{}' from: {} to: {}>".format(self._change_type, self.old_value, self.new_value)


class RadarHistoryChangeRole(RadarHistoryChangeOldNew):
    """
    This change class is for the non-assignee roles, for which the history APIs only return
    full-name string values in the 'from' (old) and 'to' (new) values.

    """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in [
            'dri',
            'epm',
            'originator',
            'resolvedBy'
        ]


class RadarHistoryChangeConfigurationSummary(RadarHistoryChangeOldNew):
    """ :meta private: """

    def property_name(self):
        return 'configurationSummary'

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'configSummary'


class RadarHistoryChangeAddedRelation(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.related_radar_id = self.change_details['related_radar_id']
        self.relationship_type = self.change_details['type']

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        snapshot.related_problems.append(RadarHistoryRelationship(self.change_details, radar))

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'addedRelation'


class RadarHistoryChangeRemovedRelation(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.related_radar_id = self.change_details['related_radar_id']
        self.relationship_type = self.change_details['type']

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        # todo: mutation of collection during enumeration - does this work?
        for history_related_problem in snapshot.related_problems:
            if history_related_problem.related_radar_id == self.related_radar_id and history_related_problem.type == self.relationship_type:
                snapshot.related_problems.remove(history_related_problem)

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'removedRelation'


class RadarHistoryChangeKeywordAdded(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.keyword_name = self.change_details['keyword_name']

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        snapshot.history_keywords.append(RadarHistoryKeywordAssociation(self.change_details))

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'keywordAdded'


class RadarHistoryChangeKeywordRemoved(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.keyword_name = self.change_details['keyword_name']

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        # todo: mutation of collection during enumeration - does this work?
        for history_keyword_assoc in snapshot.history_keywords:
            if history_keyword_assoc.keyword_name == self.keyword_name:
                snapshot.history_keywords.remove(history_keyword_assoc)

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'keywordRemoved'


class RadarHistoryChangeInformalData(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.data = self.change_details

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'data'

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        pass


class RadarHistoryChangeIsReadByAssignee(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.is_read = self.change_details == 'checked'

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        snapshot.isReadByAssignee = self.is_read

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'isReadByAssignee'


class RadarHistoryChangeCheckbox(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.checkbox = self._change_type
        self.is_checked = self.change_details == 'checked'

    def apply_to_radar_history_snapshot(self, snapshot, radar):
        if hasattr(snapshot, self.property_name()):
            setattr(snapshot, self.property_name(), self.change_details)

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_detail_data in ['checked', 'unchecked']


class RadarHistoryChangeImpact(RadarHistoryChangeCheckbox):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in [
            '3rdPartyContent',
            'approved',
            'confidentialContent',
            'hasOpenSource',
            'hasPatentReviewImpact',
            'hI',
            'importOrExport',
            'isRegressionRequired',
            'isVerifiedByTester',
            'loc',
            'newAPI',
            'newSPI',
            'umbrella'
        ]


class RadarHistoryChangeAbstractMultiValueAttribute(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.new_value = self.change_details

    # todo: implement support for dynamic list-based attributes
    def apply_to_radar_history_snapshot(self, snapshot, radar):
        pass


class RadarHistoryChangePicture(RadarHistoryChangeAbstractMultiValueAttribute):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in ['pictureAdded', 'pictureRemoved']


class RadarHistoryChangeProblemSecurity(RadarHistoryChangeAbstractMultiValueAttribute):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in ['problemSecurityAdded', 'problemSecurityRemoved']


class RadarHistoryChangeTargetMilestones(RadarHistoryChangeAbstractMultiValueAttribute):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in ['targetMilestonesPlaceholderAdded', 'targetMilestonesAdded', 'targetMilestonesRemoved', 'targetMilestonesPlaceholderCloned']


class RadarHistoryChangeAbstractModifyTextField(RadarHistoryChange):
    """
    This change class is used for single-value text fields that can be freely-edited in Radar.
    Typically, changes are only denoted in the history APIs with "Changes made".

    """

    def initialize_from_change_type_and_details(self):
        self.new_value = self.change_details


class RadarHistoryChangeModifyWorkaround(RadarHistoryChangeAbstractModifyTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'workaround'      # "Changes made"


class RadarHistoryChangeModifyReleaseNotes(RadarHistoryChangeAbstractModifyTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'releaseNotes'    # "Changes made"


class RadarHistoryChangeModifySourceChanges(RadarHistoryChangeAbstractModifyTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'sourceChanges'   # "Changes made"


class RadarHistoryChangeConfiguration(RadarHistoryChangeAbstractModifyTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'configuration'   # "Changes made"


class RadarHistoryChangeSuccinctSummaryRootCause(RadarHistoryChangeAbstractModifyTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in [
            'succinctSummaryRootCause', # "Changes made"
            'failedModuleAdded',        # "New information added to failed module."
            'detailOfFailureAdded',     # "New information added to failure detail."
            'actionTaken'               # "Changes made"
        ]


class RadarHistoryChangeAbstractAddToMultiValuedTextField(RadarHistoryChange):
    """
    A change class for text-field attributes in Radar that can hold multiple values. Their changes
    are often denoted only by 'New Information added' in the history APIs.

    """

    def initialize_from_change_type_and_details(self):
        self.new_value = self.change_details


class RadarHistoryChangeAddRemoveExternalSystem(RadarHistoryChangeAbstractAddToMultiValuedTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in ['externalSystemsAdded', 'externalSystemsRemoved']


class RadarHistoryChangeAddToProblemDiagnosis(RadarHistoryChangeAbstractAddToMultiValuedTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'problemDiagnosis'


class RadarHistoryChangeAddToProblemDescription(RadarHistoryChangeAbstractAddToMultiValuedTextField):
    """ :meta private: """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type == 'problemDescription'


class RadarHistoryAddRemoveExternalID(RadarHistoryChangeAbstractAddToMultiValuedTextField):
    """
    These don't match any known field[s] in the Radar 8 UI or any documented API call.

    :meta private:
    """

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in ['externalIDAdded', 'externalIDRemoved']


class RadarHistoryChangeKeyValuePair(RadarHistoryChange):
    """ :meta private: """

    def initialize_from_change_type_and_details(self):
        self.key_name = self.change_details

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return change_type in ['keyAdded', 'keyModified', 'keyRemoved']


class RadarHistoryChangeGeneric(RadarHistoryChange):
    """
    A catch-all change class that will be the default for any attribute (change_type) that isn't defined
    in its own change class. This prevents the code from crashing whenever an unknown (or new) attribute
    is changed.

    This class should be the last/lowest change class in the codebase.

    :meta private:
    """
    def initialize_from_change_type_and_details(self):
        self.new_value = self.change_details

    @classmethod
    def can_parse_data(cls, change_type, change_detail_data):
        return False


class RadarBoardPersonValueConverter(AbstractValueConverter):
    """
    This converts from the person dictionaries as returned by the Boards API.

    :meta private:
    """

    @classmethod
    def decode_radar_value(cls, person_data):
        if person_data is None:
            return None
        # Boards API returns `id` instead of `dsid` in some instances
        # This replaces `id` with `dsid` and assigns the value before creating the Person object if 'id' is used instead of 'dsid'
        if person_data.get("id") is not None:
            person_data["dsid"] = person_data["id"]
            del person_data["id"]
        return Person(person_data)

    @classmethod
    def encode_radar_value(cls, person, *args):
        if person is not None:
            if person.dsid is not None:
                return int(person.dsid)
        return None


class RadarBoardAccessListMemberConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, member_data):
        if member_data is None:
            return None
        return RadarBoardAccessListMember(member_data)

    @classmethod
    def encode_radar_value(cls, person, *args):
        if person is not None:
            if person.dsid is not None:
                return int(person.dsid)
        return None


class RadarBoardComponentStringToComponentObjectConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, component_string):
        if component_string is None:
            return None
        # Boards API Returns the component as a String with a | (e.g Radar | New Bugs)
        component_string = component_string.split("|")
        data = {"name": component_string[0].strip(), "version": component_string[1].strip()}
        return Component(dictionary_representation=data)


class RadarBoardAccessListValueConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return RadarBoardAccessListMemberConverter


class RadarBoardStateColumnListConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return RadarBoardStateColumnConverter


class RadarBoardStateColumn(DictionaryBasedModel):
    """
    Represents a :py:class:`RadarBoard` State Column.

    For more information, please reference the `State Column Documentation`_
    """
    DEFAULT_PROPERTIES = ["title", "maxState", "id"]

    def __init__(self, state_column):
        super(RadarBoardStateColumn, self).__init__(state_column)


class RadarBoardAccessListMember(DictionaryBasedModel):
    """
    Represents an access list member for a :py:class:`RadarBoard`

    You should not need to instantiate objects of this class yourself.

    For more information, please reference the `Access List Documentation`_

    This object contains a :py:class:`Person` attribute and a :py:class:`list` of roles

    Example::

        person = member.person
        dsid = person.dsid
        firstName = person.firstName
        roles = member.roles

    For convenience, you can also see the role for the AccessListMember using the following attributes:

        member.is_board_admin
        member.is_team_member
        member.is_product_owner
        member.is_scrum_leader

    Some API methods require different levels of access.
    In general a ``board-admin`` has no limitation whereas a ``team-member`` is heavily restricted.
    """
    DEFAULT_PROPERTIES = ["person", "roles"]
    BOARD_ADMIN = "board-admin"
    TEAM_MEMBER = "team-member"
    PRODUCT_OWNER = "product-owner"
    SCRUM_LEADER = "scrum-leader"

    def __init__(self, member_data):
        super(RadarBoardAccessListMember, self).__init__(member_data)
        self.is_board_admin = RadarBoardAccessListMember.BOARD_ADMIN in self.roles
        self.is_team_member = RadarBoardAccessListMember.TEAM_MEMBER in self.roles
        self.is_product_owner = RadarBoardAccessListMember.PRODUCT_OWNER in self.roles
        self.is_scrum_leader = RadarBoardAccessListMember.SCRUM_LEADER in self.roles

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarBoardAccessListMember, cls).property_value_converter_map)
        map.update({
            "person": RadarBoardPersonValueConverter
        })
        return map


class RadarBoard(DictionaryBasedModel):
    """
    Represents a Radar Board.

    You should not need to instantiate objects of this class yourself.

    You can get :py:class:`RadarBoard` instances with :py:meth:`~radarclient.client.RadarClient.board_for_id` or :py:meth:`~radarclient.client.RadarClient.available_boards`

    Most Radar Web API properties are directly mapped to properties on instances of this class.
    """
    DEFAULT_PROPERTIES = [
        "accessList",
        "dateCreated",
        "defaultComponentId",
        "defaultComponent",
        "description",
        "id",
        "objectVersion",
        "state",
        "stateColumns",
        "title",
    ]
    BASE_URL = "boards"
    URL_COMPONENTS_FOR_GET_BY_ID = (BASE_URL,)

    def __init__(self, board_data, client):
        self.client = client
        super(RadarBoard, self).__init__(board_data)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarBoard, cls).property_value_converter_map)
        map.update({
            "dateCreated": ISO8601UTCDateValueConverter,
            "defaultComponent": RadarBoardComponentValueConverter,
            "accessList": RadarBoardAccessListValueConverter,
            "stateColumns": RadarBoardStateColumnListConverter
        })
        return map

    @property
    def board_admins(self):
        """
        All people with the ``board-admin`` role

        For more information, please reference the `Access List Documentation`_

        :rtype: list[RadarBoardAccessListMember]
        """
        return [person for person in self.accessList if person.is_board_admin]

    @property
    def _board_admin_dsid_list(self):
        """
        Provides a list of DSIDs for people with ``board-admin`` status

        :meta private:

        :rtype: list[int]
        """
        return [member.person.dsid for member in self.board_admins]

    @property
    def current_user_is_board_admin(self):
        """
        If the currently logged in user is an Admin for the Radar Board

        Some Boards API require ``Board Admin`` status

        :rtype: bool
        """
        return self.client.current_user().dsid in self._board_admin_dsid_list

    @property
    def team_members(self):
        """
        All people with the ``team-member`` role

        For more information, please reference the `Access List Documentation`_

        :rtype: list[RadarBoardAccessListMember]
        """
        return [person for person in self.accessList if person.is_team_member]

    @property
    def product_owners(self):
        """
        All people with the ``product-owner`` role

        For more information, please reference the `Access List Documentation`_

        :rtype: list[RadarBoardAccessListMember]
        """
        return [person for person in self.accessList if person.is_product_owner]

    @property
    def scrum_leaders(self):
        """
        All people with ``scrum-leader`` role

        For more information, please reference the `Access List Documentation`_

        :rtype: list[RadarBoardAccessListMember]
        """
        return [person for person in self.accessList if person.is_scrum_leader]

    def sprints(self, include_closed=False):
        """
        All :py:class:`RadarBoardSprint` objects for the :py:class:`RadarBoard`

        :param bool include_closed: [Optional] Whether or not to include closed sprints in the response. Defaults to ``False``
        :rtype: list[RadarBoardSprint]
        """
        sprints = self.client.sprints_for_board_id(board_id=self.id)
        if include_closed:
            return sprints
        return [sprint for sprint in sprints if sprint.state != "closed"]

    def active_sprint(self):
        """
        The Active :py:class:`RadarBoardSprint` for the :py:class:`RadarBoard` or None if undefined

        :rtype: RadarBoardSprint or None
        """
        sprints = self.client.sprints_for_board_id(board_id=self.id)
        active_sprint = [sprint for sprint in sprints if sprint.state == "active"]
        if active_sprint:
            assert len(active_sprint) == 1, "There can be only one active Sprint per Board!"
            return active_sprint[0]
        return None

    def epics(self):
        """
        Fetches all :py:class:`RadarBoardEpic` objects for the :py:class:`RadarBoard`

        :rtype: list[RadarBoardEpic]
        """
        return self.client.epics_for_board_id(self.id)

    def jobs(self):
        """
        Fetches all :py:class:`RadarBoardJob` objects for the :py:class:`RadarBoard`

        The endpoint for this method is restricted, you may need to request access to the ``Get Jobs`` API

        :rtype: list[RadarBoardJob]
        """
        return self.client.jobs_for_board_id(self.id)

    def backlog_stories(self):
        """
        Fetches all :py:class:`RadarBoardStory` objects in the Backlog of the :py:class:`RadarBoard`

        :rtype: list[RadarBoardStory]
        """
        status, stories = self.client.build_and_send_request(
            url_components=(RadarBoard.BASE_URL, self.id, "backlog", RadarBoardStory.BASE_URL))
        return [RadarBoardStory(story, self.client) for story in stories]

    def unprioritized_backlog(self):
        """
        All :py:class:`RadarBoardStory` objects in the Backlog of the :py:class:`RadarBoard` with ``backlogSection`` value of ``UNPRIORITIZED``

        :rtype: list[RadarBoardStory]
        """
        return [story for story in self.backlog_stories() if story.backlogSection == "UNPRIORITIZED"]

    def prioritized_backlog(self):
        """
        All :py:class:`RadarBoardStory` objects for in the Backlog of the :py:class:`RadarBoard` with ``backlogSection`` value of ``PRIORITIZED``

        :rtype: list[RadarBoardStory]
        """
        return [story for story in self.backlog_stories() if story.backlogSection == "PRIORITIZED"]

    def archive(self):
        """
        Archive the :py:class:`RadarBoard`

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {"objectVersion": self.objectVersion, "state": "archived"}
        status, board = self.client.build_and_send_json_request(url_components=("boards", self.id), request_data=data)
        return response_code_is_success(status)

    def create_sprint(self, start_date, end_date, title):
        """
        Create a :py:class:`RadarBoardSprint` on the :py:class:`RadarBoard`

        For more information, please reference the `Create Sprint Documentation`_

        :param str start_date: The Start date for the Sprint in ISO8601 format
        :param str end_date: The End date for the Sprint in ISO8601 format
        :param str title: The Title for the Sprint

        Example ``startDate`` Formatting::

            2023-01-20T23:59:59.000Z

        :rtype: RadarBoardSprint
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "startDate": start_date,
            "endDate": end_date,
            "title": title,
            }
        status, sprint = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.id, RadarBoardSprint.BASE_URL),
            request_data=data, method="POST")
        return RadarBoardSprint(sprint, self.client)

    def create_backlog_story(self, title, story_points=None, business_value=None):
        """
        Create a :py:class:`RadarBoardStory` on the :py:class:`RadarBoard` backlog

        For more information, please reference the `Create Backlog Story Documentation`_

        To add an `existing` Radar as a Story use :py:meth:`RadarBoard.add_story_for_radar_id`

        :param str title: The title of the :py:class:`RadarBoardStory`
        :param int story_points: [Optional] The story points to assign
        :param int business_value: [Optional] The business value to assign
        :rtype: RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = [
            {
                "title": title,
                "storyPoints": story_points,
                "businessValue": business_value
            }
        ]
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.id, "backlog", RadarBoardStory.BASE_URL),
            request_data=data)
        return RadarBoardStory(story[0], self.client)

    def move_story_ids_to_prioritized_backlog(self, story_ids):
        """
        Move a list of story IDs to the PRIORITIZED backlog section

        :param list story_ids: A list of story IDs to move to the PRIORITIZED backlog
        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "ids": story_ids,
        }
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.id, RadarBoardStory.BASE_URL, "moveStories"),
            request_data=data, method="POST")
        return response_code_is_success(status)

    def create_epic(self, title):
        """
        Create a :py:class:`RadarBoardEpic` on the :py:class:`RadarBoard`

        For more information, please reference the `Create Epic Documentation`_

        To add an `existing` Radar as an epic use :py:meth:`RadarBoard.add_epic_for_radar_id`

        :param str title: The title of the :py:class:`RadarBoardEpic`
        :rtype: RadarBoardEpic
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
                "title": title
        }
        status, epic = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.id, RadarBoardEpic.BASE_URL),
            request_data=data)
        return RadarBoardEpic(epic, self.client)

    def add_story_for_radar_id(self, radar_id, return_story_object=False):
        """
        Import a single :py:class:`Radar` object to the Board as a :py:class:`RadarBoardStory`

        The endpoints for this method are restricted, you may need to request access to the ``Create Jobs`` and ``Get Jobs`` API

        :param int radar_id: The ID for the Radar to import
        :param bool return_story_object: If a :py:class:`RadarBoardStory` should be returned instead of a :py:class:`RadarBoardJob`
        :rtype: RadarBoardJob or RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        # Default behaviour
        if not return_story_object:
            data = {
                "problemIds": [radar_id],
                "type": "STORY_IMPORT"
            }
            return self.create_radar_board_job(data)

        # Opt-in behaviour
        radar = self.client.radar_for_id(radar_id)
        return radar.add_to_radar_board_as_story(board_id=self.id, return_story_object=True)

    def add_stories_for_radar_ids(self, radar_ids):
        """
        Import multiple :py:class:`Radar` objects to the :py:class:`RadarBoard` as a :py:class:`RadarBoardStory`

        The endpoint for this method is restricted, you may need to request access to the ``Create Jobs`` API

        :param list(int) radar_ids: List of Radar IDs to import
        :rtype: RadarBoardJob
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "problemIds": radar_ids,
            "type": "STORY_IMPORT"
        }
        return self.create_radar_board_job(data)

    def add_epic_for_radar_id(self, radar_id, return_epic_object=False):
        """
        Import a single :py:class:`Radar` object to the Board as a :py:class:`RadarBoardEpic`

        The endpoints for this method are restricted, you may need to request access to the ``Create Jobs`` and ``Get Jobs`` API

        :param int radar_id: The ID for the Radar to import
        :param bool return_epic_object: If a :py:class:`RadarBoardEpic` should be returned instead of a :py:class:`RadarBoardJob`
        :rtype: RadarBoardJob or RadarBoardEpic
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        # Default behaviour
        if not return_epic_object:
            data = {
                "problemIds": [radar_id],
                "type": "EPIC_IMPORT"
            }
            return self.create_radar_board_job(data)

        # Opt-in behaviour
        radar = self.client.radar_for_id(radar_id)
        return radar.add_to_radar_board_as_epic(board_id=self.id, return_epic_object=True)

    def add_epics_for_radar_ids(self, radar_ids):
        """
        Import multiple :py:class:`Radar` objects to the :py:class:`RadarBoard` as a :py:class:`RadarBoardEpic`

        The endpoint for this method is restricted, you may need to request access to the ``Create Jobs`` API

        :param list(int) radar_ids: List of Radar IDs to import
        :rtype: RadarBoardJob
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "problemIds": radar_ids,
            "type": "EPIC_IMPORT"
        }
        return self.create_radar_board_job(data)

    def create_radar_board_job(self, job_data):
        """
        Create a :py:class:`RadarBoardJob` to import Radars as Stories or Epics.

        :param dict job_data: The data to create the Job with

        The endpoint for this method is restricted, you may need to request access to the ``Create Jobs`` API

        For convenience, it is recommended to use the following methods:
            - :py:meth:`RadarBoard.add_story_for_radar_id`
            - :py:meth:`RadarBoard.add_stories_for_radar_ids`
            - :py:meth:`RadarBoard.add_epic_for_radar_id`
            - :py:meth:`RadarBoard.add_epics_for_radar_ids`

        :rtype: RadarBoardJob
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, job = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.id, RadarBoardJob.BASE_URL),
            request_data=job_data,
            method="POST")
        return RadarBoardJob(job, self.client)

    def commit_changes(self):
        """
        Commits queued changes to the Radar database.

        Only supports updating the ``title`` and ``description`` attributes.

        For more information, please reference the `Update Board API Documentation`_

        Example::

            board.title = "New Title"
            board.description = "My new description"
            board.commit_changes()

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "title": self.title,
            "description": self.description,
            "objectVersion": self.objectVersion,
        }
        status, board = self.client.build_and_send_json_request(
            url_components=("boards", self.id),
            request_data=data)
        return response_code_is_success(status)


class RadarBoardSprint(DictionaryBasedModel):
    """
    Represents a Sprint belonging to a :py:class:`RadarBoard`.

    You should not need to instantiate objects of this class yourself.

    You can get :py:class:`RadarBoardSprint` instances with :py:meth:`~radarclient.client.RadarClient.sprints_for_board_id`, :py:meth:`RadarBoard.sprints()` or :py:meth:`RadarBoard.active_sprint()`

    Most Radar Web API properties are directly mapped to properties on instances of this class.
    """
    DEFAULT_PROPERTIES = [
        "boardId",
        "endDate",
        "hasEvents",
        "id",
        "objectVersion",
        "startDate",
        "state",
        "summary",
        "title",
    ]
    BASE_URL = "sprints"

    def __init__(self, sprint_data, client):
        self.client = client
        super(RadarBoardSprint, self).__init__(sprint_data)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarBoardSprint, cls).property_value_converter_map)
        map.update({
            "startDate": ISO8601UTCDateValueConverter,
            "endDate": ISO8601UTCDateValueConverter,
        })
        return map

    def stories(self):
        """
        All :py:class:`RadarBoardStory` objects for the :py:class:`RadarBoardSprint`

        :rtype: list[RadarBoardStory]
        """
        status, stories = self.client.build_and_send_request(
            url_components=("boards", self.boardId, "sprints", self.id, "stories"))
        return [RadarBoardStory(story, self.client) for story in stories]

    def open_stories(self):
        """
        All :py:class:`RadarBoardStory` objects for the :py:class:`RadarBoardSprint` not in ``verify`` or ``closed`` state.

        :rtype: list[RadarBoardStory]
        """
        return [story for story in self.stories() if story.state not in ["closed", "verify"]]

    def closed_stories(self):
        """
        All :py:class:`RadarBoardStory` objects for the :py:class:`RadarBoardSprint` in ``closed`` state.

        :rtype: list[RadarBoardStory]
        """
        return [story for story in self.stories() if story.state == "closed"]

    def verify_stories(self):
        """
        All :py:class:`RadarBoardStory` objects for the :py:class:`RadarBoardSprint` in ``verify`` state.

        :rtype: list[RadarBoardStory]
        """
        return [story for story in self.stories() if story.state == "verify"]

    def delete(self):
        """
        Delete the :py:class:`RadarBoardSprint`

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, _ = self.client.build_and_send_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardSprint.BASE_URL, self.id),
            method="DELETE")
        return response_code_is_success(status)

    def start(self):
        """
        Start the :py:class:`RadarBoardSprint`

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        if self.state == "active":
            raise ValueError("Cannot start a Sprint that is already active")
        if self.state == "closed":
            raise ValueError("Cannot start a Sprint that is closed")
        data = {
            "state": "active",
            "objectVersion": "{}".format(self.objectVersion),
        }
        status, sprint = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardSprint.BASE_URL, self.id),
            request_data=data,
            method="POST")
        return response_code_is_success(status)

    def close(self, follow_on_sprint=None):
        """
        Close the :py:class:`RadarBoardSprint`

        :param follow_on_sprint: The :py:class:`RadarBoardSprint` object to move stories to. If ```None```, remaining stories will be moved to the backlog

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "state": "closed",
            "objectVersion": "{}".format(self.objectVersion),
        }
        if follow_on_sprint is not None:
            data["followOnSprintId"] = follow_on_sprint.id
        if self.state == "closed":
            raise ValueError("Cannot Close a Sprint which is already closed")
        status, sprint = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardSprint.BASE_URL, self.id),
            request_data=data,
            method="POST")
        return response_code_is_success(status)

    def events(self):
        """
        All :py:class`RadarBoardSprintEvent` objects for the :py:class:`RadarBoardSprint`

        :rtype: list[RadarBoardSprintEvent]
        """
        status, events = self.client.build_and_send_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardSprint.BASE_URL, self.id, RadarBoardSprintEvent.BASE_URL)
        )
        return [RadarBoardSprintEvent(event, self.client) for event  in events]

    def create_story(self, title, story_points=None, business_value=None):
        """
        Create a :py:class:`RadarBoardStory` in the :py:class:`RadarBoardSprint`

        To add an `existing` Radar as a Story use :py:meth:`RadarBoard.add_story_for_radar_id`

        :param str title: The title of the :py:class:`RadarBoardStory`
        :param int story_points: [Optional] The story points to assign
        :param int business_value: [Optional] The business value to assign
        :rtype: RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = [{"title": title,"storyPoints": story_points,"businessValue": business_value}]
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardSprint.BASE_URL, self.id, RadarBoardStory.BASE_URL),
            request_data=data)
        return RadarBoardStory(story[0], self.client)

    def add_story_for_radar_id(self, radar_id):
        """
        Import a :py:class:`Radar` object to the :py:class:`RadarBoardSprint` as a :py:class:`RadarBoardStory`

        :param str radar_id: The id of the :py:class:`Radar`
        :returns: A :py:class:`RadarBoardStory` object
        :rtype: RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, response = self.client.build_and_send_json_request(url_components=(
            RadarBoard.BASE_URL,
            self.boardId,
            RadarBoardSprint.BASE_URL,
            self.id,
            RadarBoardStory.BASE_URL),
            request_data=[{"problemId": radar_id}])

        # Radar API can Return a list of Stories - in this case we requested and will only return one
        return RadarBoardStory(response[0], client=self.client)

    def commit_changes(self):
        """
        Commits queued changes to the Radar database.

        For more information, please reference the `Update Sprint API Documentation`_

        Only supports updating the ``summary`` and ``title`` attributes.

        Example::

            sprint.title = "New Title"
            sprint.description = "My new description"
            sprint.commit_changes()

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "state": self.state,
            "summary": self.summary,
            "title": self.title,
            "objectVersion": self.objectVersion,
        }
        status, sprint = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardSprint.BASE_URL, self.id),
            method="POST",
            request_data=data)
        return response_code_is_success(status)


class RadarBoardEpic(DictionaryBasedModel):
    """
    Represents an Epic belonging to a :py:class:`RadarBoard`.

    You should not need to instantiate objects of this class yourself. You can get :py:class:`RadarBoardEpic` instances with
    :py:meth:`~radarclient.client.RadarClient.epics_for_board_id` or :py:meth:`RadarBoard.epics()`

    Most Radar Web API properties are directly mapped to properties on instances of this class.
    """
    DEFAULT_PROPERTIES = [
        "boardId",
        "businessValue",
        "color",
        "id",
        "objectVersion",
        "problemId",
        "rank",
        "storyPoints",
        "title",
    ]
    BASE_URL = "epics"

    def __init__(self, epic_data, client):
        self.client = client
        super(RadarBoardEpic, self).__init__(epic_data)

    def radar(self, additional_fields=None, error_callback=None, verbose=False, fetch_person_info_from_ds=False):
        """
        The :py:class:`Radar` object for the Epic

        Please reference the :py:class:`Radar` documentation for additional arguments

        :rtype: Radar
        """
        return self.client.radar_for_id(
            self.problemId,
            additional_fields=additional_fields,
            error_callback=error_callback,
            verbose=verbose,
            fetch_person_info_from_ds=fetch_person_info_from_ds)

    def delete(self):
        """
        Delete the :py:class:`RadarBoardEpic`

        For more information, please reference the `Delete Epic API Documentation`_

        This does not delete the underlying :py:class:`Radar`

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        status, _ = self.client.build_and_send_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardEpic.BASE_URL, self.id),
            method="DELETE")
        return response_code_is_success(status)

    def create_story(self, title, story_points=None, business_value=None):
        """
        Create a new :py:class:`RadarBoardStory` related to the :py:class:`RadarBoardEpic`

        For more information, please reference the `Create Epic Story Documentation`_

        :param str title: The title of the :py:class:`RadarBoardStory`
        :param int story_points: [Optional] The story points to assign
        :param int business_value: [Optional] The business value to assign
        :rtype: RadarBoardStory
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = [{"title": title, "storyPoints": story_points, "businessValue": business_value}]
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, "epics", self.id, RadarBoardStory.BASE_URL),
            request_data=data)
        return RadarBoardStory(story[0], self.client)

    def relate_existing_stories(self, stories):
        """
        Relate a list of :py:class:`RadarBoardStory` to the :py:class:`RadarBoardEpic`

        An existing Radar must be added as a :py:class:`RadarBoardStory` before it can be related to a :py:class:`RadarBoardEpic`
        using :py:meth:`RadarBoard.add_story_for_radar_id` or :py:meth:`RadarBoard.add_stories_for_radar_ids`

        To create a new :py:class:`RadarBoardStory` related to a :py:class:`RadarBoardEpic` use :py:meth:`RadarBoardEpic.create_story`

        :param list stories: A list of :py:class:`RadarBoardStory` objects
        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {"objectVersion": self.objectVersion, "relatedItems": [story.id for story in stories]}
        status, epic = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardEpic.BASE_URL, self.id),
            request_data=data, method="POST")
        return response_code_is_success(status)

    def commit_changes(self):
        """
        Commits queued changes to the Radar database.

        Only supports updating the ``title``, ``color``, ``businessValue`` and ``storyPoints`` attributes.

        To update additional attributes, modify the underlying Radar using :py:meth:`RadarBoardEpic.radar()`

        For more information, please reference the `Update Epic API Documentation`_

        Example::

            epic.storyPoints = 1
            epic.title = "new title"
            epic.commit_changes()

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "objectVersion": self.objectVersion,
            "title": self.title,
            "color": self.color,
            "businessValue": self.businessValue,
            "storyPoints": self.storyPoints,
        }
        status, epic = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardEpic.BASE_URL, self.id),
            request_data=data)
        return response_code_is_success(status)


class RadarBoardStory(DictionaryBasedModel):
    """
    Represents a Radar Board Story.

    For more information, please reference the `Story API Documentation`_

    You should not need to instantiate objects of this class yourself.

    You can get existing :py:class:`RadarBoardStory` objects with the following methods:

        Stories in the ``backlog`` of a :py:class:`RadarBoard`
            - :py:meth:`RadarBoard.backlog_stories()`
            - :py:meth:`RadarBoard.unprioritized_backlog()`
            - :py:meth:`RadarBoard.prioritized_backlog()`

        Stories in a :py:class:`RadarBoardSprint`
            - :py:meth:`RadarBoardSprint.stories()`
            - :py:meth:`RadarBoardSprint.open_stories()`
            - :py:meth:`RadarBoardSprint.closed_stories()`
            - :py:meth:`RadarBoardSprint.verify_stories()`

    You can create new :py:class:`RadarBoardStory` objects with the following methods:

        - :py:meth:`RadarBoardEpic.create_story()`
        - :py:meth:`RadarBoardSprint.create_story()`
        - :py:meth:`RadarBoard.create_backlog_story()`

    You can also add existing Radars as :py:class:`RadarBoardStory` objects with the following methods:

        - :py:meth:`RadarBoard.add_story_for_radar_id`
        - :py:meth:`RadarBoard.add_stories_for_radar_ids`

    Most Radar Web API properties are directly mapped to properties on instances of this class.
    """
    DEFAULT_PROPERTIES = [
        "assignee",
        "backlogRank",
        "backlogSection",
        "businessValue",
        "classification",
        "componentName",
        "event",
        "id",
        "keywords",
        "milestone",
        "priority",
        "problemId",
        "resolvedBy",
        "sprintId",
        "state",
        "stateColumnId",
        "storyPoints",
        "title",
        "epics",
    ]
    BASE_URL = "stories"

    def __init__(self, story_data, client):
        self.client = client
        super(RadarBoardStory, self).__init__(story_data)

        # For Stories returned in Sprint events, epics are not returned
        if self.dictionary_representation_data.get("epics") is not None:
            self.epics = RadarBoardEpic.parse_webservice_data(self.epics, self.client)
        else:
            self.epics = None

        # For Tasks returned in Sprint events, epics are not returned
        if self.dictionary_representation_data.get("tasks") is not None:
            self.tasks = [RadarBoardStoryTask(subtask_data=task, related_radar_id=self.id, client=self.client) for task in self.tasks]
        else:
            self.tasks = None

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarBoardStory, cls).property_value_converter_map)
        map.update({
            "createdDate": ISO8601UTCDateValueConverter,
            "assignee": RadarBoardPersonValueConverter,
            "resolvedBy": RadarBoardPersonValueConverter,
            "keywords": KeywordListValueConverter,
            "componentName": RadarBoardComponentStringToComponentObjectConverter
        })
        return map

    def radar(self, additional_fields=None, error_callback=None, verbose=False, fetch_person_info_from_ds=False):
        """
        The :py:class:`Radar` object for the Story

        Please reference the :py:class:`Radar` documentation for additional arguments

        :rtype: Radar
        """
        return self.client.radar_for_id(
            self.problemId,
            additional_fields=additional_fields,
            error_callback=error_callback,
            verbose=verbose,
            fetch_person_info_from_ds=fetch_person_info_from_ds)

    def component(self):
        """
        Convenience wrapper to get the :py:class:`Component` for the :py:class:`RadarBoardStory`

        :rtype: Component
        """
        return self.client.component_for_name_and_version(name=self.componentName.name, version=self.componentName.version)

    def add_to_sprint(self, sprint):
        """
        Add the :py:class:`RadarBoardStory` to a :py:class:`RadarBoardSprint`

        :param sprint: The :py:class:`RadarBoardSprint` object to add the Story to

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "sprintId": sprint.id,
            "ids": [self.id],
        }
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, sprint.boardId, RadarBoardStory.BASE_URL, "moveStories"),
            request_data=data, method="POST")
        return response_code_is_success(status)

    def relate_to_epic(self, epic):
        """
        Relate the :py:class:`RadarBoardStory` to a :py:class:`RadarBoardEpic`

        :param epic: The :py:class:`RadarBoardEpic` object to relate the Story to

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {"objectVersion": epic.objectVersion,"relatedItems": [self.id]}
        status, epic = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardEpic.BASE_URL, epic.id),
            request_data=data, method="POST")
        return response_code_is_success(status)

    def add_to_prioritized_backlog(self, backlog_rank=5):
        """
        Add the :py:class:`RadarBoardStory` to the `PRIORITIZED` backlog section

        :param int backlog_rank: The backlog rank for the :py:class:`RadarBoardStory`. Defaults to `5`

        Supports moving a :py:class:`RadarBoardStory` from a :py:class:`RadarBoardSprint` or the `UNPRIORITIZED` backlog to the `PRIORITIZED` backlog

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "ids": [self.id],
            "backlogRank": backlog_rank
        }
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardStory.BASE_URL, "moveStories"),
            request_data=data, method="POST")
        return response_code_is_success(status)

    def delete(self):
        """
        Delete the :py:class:`RadarBoardStory`

        For more information, please reference the `Delete Board Story API Documentation`_

        This does not delete the underlying :py:class:`Radar`

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {"ids": [self.id]}
        status, _ = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardStory.BASE_URL),
            method="DELETE",
            request_data=data)
        return response_code_is_success(status)

    def state_column(self):
        """
        Get the :py:class:'RadarBoardStateColumn` object for the :py:class:`RadarBoardStory`

        For more information, please reference the `State Column Documentation`_

        :rtype: RadarBoardStateColumn
        """
        board = self.client.board_for_id(self.boardId)
        columns = [state_column for state_column in board.stateColumns if state_column.id == self.stateColumnId]
        assert len(columns) == 1, "There can only be one matching StateColumn"
        return columns[0]

    def commit_changes(self):
        """
        Commits queued changes to the Radar database.

        For more information, please reference the `Update Story API Documentation`_

        Only supports updating the ``businessValue`` and ``storyPoints`` attributes.

        To update additional attributes, modify the underlying Radar using :py:meth:`RadarBoardStory.radar()`

        Example::

            story.storyPoints = 1
            story.title = "new title"
            story.commit_changes()

        :rtype: bool
        :raises: :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`
        """
        data = {
            "objectVersion": self.objectVersion,
            "businessValue": self.businessValue,
            "storyPoints": self.storyPoints,
        }
        status, story = self.client.build_and_send_json_request(
            url_components=(RadarBoard.BASE_URL, self.boardId, RadarBoardStory.BASE_URL, self.id),
            request_data=data)
        return response_code_is_success(status)

    def events(self):
        """
        Represents all :py:class:`RadarBoardSprintEvent` objects related to the :py:class:`RadarBoardStory` in a :py:class:`RadarBoardSprint`

        This method returns :py:class:`RadarBoardSprintEvent` objects related to the :py:class:`RadarBoardStory`

        Each :py:class:`RadarBoardSprintEvent` has a ``type`` value (str) corresponding to one of the following:

            ``story_added`` when the :py:class:`RadarBoardStory` was created
            ``story_removed`` when the :py:class:`RadarBoardStory` was removed
            ``story_complete`` when the :py:class:`RadarBoardStory` was marked as complete
            ``storyPoints_changed`` when the :py:class:`RadarBoardStory` `storyPoints` value was changed
            ``businessValue_changed`` when the :py:class:`RadarBoardStory` `businessValue` was changed

        Stories not in a Sprint (e.g. in the backlog) will return `None`

        :rtype: list[RadarBoardSprintEvent]
        """

        # If a Sprint is in the backlog it will not have any Sprint History
        if self.sprintId is not None:
            sprint_events = self.client.sprint_for_id(board_id=self.boardId, sprint_id=self.sprintId).events()
            return [event for event in sprint_events if event.entityType == "story" and event.item.problemId == self.problemId]
        return None


class RadarBoardJob(DictionaryBasedModel):
    """
    Represents a Radar Board Job.

    For more information, please reference the `Boards API Documentation`_

    You should not need to instantiate objects of this class yourself. You can get :py:class:`RadarBoardJob` instances with
    :py:meth:`RadarBoard.jobs`.

    Most Radar Web API properties are directly mapped to properties on instances of this class.
    """
    DEFAULT_PROPERTIES = [
        "jobId",
        "status",
        "type",
        "createdBy",
        "successStoryCount",
        "failureStoryCount",
        "totalStoryCount",
        "successEpicCount",
        "failureEpicCount",
        "totalEpicCount"
        "sprintId"
    ]
    BASE_URL = "jobs"

    def __init__(self, job_data, client):
        self.client = client
        super(RadarBoardJob, self).__init__(job_data)

    def is_completed(self):
        """
        Helper method to determine if the job status is `COMPLETED`

        :rtype: bool
        """
        return self.status == "COMPLETED"

    def is_submitted(self):
        """
        Helper method to determine if the job status is `SUBMITTED`

        :rtype: bool
        """
        return self.status == "SUBMITTED"

    def is_failed(self):
        """
        Helper method to determine if the job status is `FAILED`

        :rtype: bool
        """
        return self.status == "FAILED"

    def is_cancelled(self):
        """
        Helper method to determine if the job status is `CANCELLED`

        :rtype: bool
        """
        return self.status == "CANCELLED"

    def is_started(self):
        """
        Helper method to determine if the job status is `STARTED`

        :rtype: bool
        """
        return self.status == "STARTED"

    def has_failures(self):
        """
        Helper method to determine if the job has any failures

        :rtype: bool
        """
        assert self.type in ["STORY_IMPORT", "EPIC_IMPORT"]

        # Only check if the job state is 'COMPLETE' to avoid AttributeError
        if self.is_completed():
            # If there are any failures, the failureStoryCount / failureEpicCount will not be 0
            if self.type == "STORY_IMPORT":
                return self.failureStoryCount != 0
            elif self.type == "EPIC_IMPORT":
                return self.failureEpicCount != 0
        return True

    def is_successful(self):
        """
        Helper method if the job is completed and successful

        Will return False if the state is `FAILED`, `SUBMITTED`, `CANCELLED` or `STARTED`

        :rtype: bool
        """
        assert self.type in ["STORY_IMPORT", "EPIC_IMPORT"]

        # Return early if the job failed, was cancelled is still started or submitted
        if self.is_failed():
            logger.error("Job failed")
            return False
        elif self.is_cancelled():
            logger.error("Job cancelled")
            return False
        elif self.is_started():
            logger.error("Job has not yet completed - state 'STARTED'")
            return False
        elif self.is_submitted():
            logger.error("Job has not yet completed - state 'SUBMITTED'")
            return False

        # If the job is complete
        if self.is_completed():
            if self.type == "STORY_IMPORT":
                return self.successStoryCount == self.totalStoryCount
            elif self.type == "EPIC_IMPORT":
                return self.successEpicCount == self.totalEpicCount
        else:
            return False


class RadarBoardSprintEvent(DictionaryBasedModel):
     """
     Represents a Radar Board Sprint event

     For more information, please reference the `Radar Boards Event Documentation`_

     You should not need to instantiate objects of this class yourself. You can get :py:class:`RadarBoardSprintEvent` instances with
         :py:meth:`RadarBoardSprint.events`.

     Most Radar Web API properties are directly mapped to properties on instances of this class.
     """
     DEFAULT_PROPERTIES = [
             "entityId",
             "entityType",
             "id",
             "item",
             "pointsCompleted",
             "pointsRemaining",
             "problemId",
             "storyPointsChange",
             "type",
             "value"
             "createdBy",
             "dateCreated"
             "problemId",
             "problemTitle"
     ]
     BASE_URL = "events"

     def __init__(self, event_data, client):
        self.client = client
        super(RadarBoardSprintEvent, self).__init__(event_data)
        if self.entityType == "story":
            self.item = RadarBoardStory(self.item, client)

     @cached_class_property
     def property_value_converter_map(cls):
        return {
            "dateCreated": ISO8601UTCDateValueConverter,
            "createdBy": RadarBoardPersonValueConverter,
            }


class RadarBoardStoryTask(DictionaryBasedModel):
    """
    Represents a Subtask for a RadarBoardStory

    Subtasks are similar to Stories but do not have Story Points or Business Value attributes

    You should not need to instantiate objects of this class yourself. You can get :py:class:`RadarBoardStoryTask` instances with
    :py:meth:`RadarBoardStory.tasks`.
    """
    DEFAULT_PROPERTIES = [
        "id",
        "milestone",
        "objectVersion",
        "priority",
        "problemId",
        "resolvedBy",
        "sprintId",
        "state",
        "title"
    ]

    def __init__(self, subtask_data, related_radar_id, client):
        self.client = client
        super(RadarBoardStoryTask, self).__init__(subtask_data)
        self._related_radar_id = related_radar_id

    @cached_class_property
    def property_value_converter_map(cls):
        return {
            "assignee": RadarBoardPersonValueConverter,
            "resolvedBy": RadarBoardPersonValueConverter,
            "keywords": KeywordListValueConverter,
            "componentName": RadarBoardComponentStringToComponentObjectConverter
        }

    def related_story(self):
        """
        The :py:class:`RadarBoardStory` object for the Task

        :rtype: RadarBoardStory
        """
        return self.client.story_for_id(story_id=self._related_radar_id, board_id=self.boardId)

    def radar(self, additional_fields=None, error_callback=None, verbose=False, fetch_person_info_from_ds=False):
        """
        The :py:class:`Radar` object for the Story

        Please reference the :py:class:`Radar` documentation for additional arguments

        :rtype: Radar
        """
        return self.client.radar_for_id(
            self.problemId,
            additional_fields=additional_fields,
            error_callback=error_callback,
            verbose=verbose,
            fetch_person_info_from_ds=fetch_person_info_from_ds)


class RadarAPIEndpoint(DictionaryBasedModel):
    """
    Represents a Radar API endpoint summarized by the response to
    :py:meth:`~radarclient.client.RadarClient.api_endpoints` or as part of a
    :py:class:`RadarAPIEndpointAccessCheck` in response to
    :py:meth:`~radarclient.client.RadarClient.api_endpoint_access_for_names`.

    RadarAPIEndpoint objects always have the following properties:

    - id, :py:class:`int`
    - name, :py:class:`str` referencing the 'short' name of the endpoint
    - httpMethod, :py:class:`str`, from ``GET``, ``PUT``, ``POST``, or ``DELETE``
    - type, :py:class:`str`, usually ``PUBLIC`` or ``RESTRICTED``
    - family, :py:class:`str`
    - documentationUrl, :py:class:`str`, the link to the location of the endpoint's documentation online
    - uriList, :py:class:`list`, the list of example syntax strings found in the documentation

    RadarAPIEndpoint objects can also have the following property, depending on the context:

    - ratelimit, which has ``base``, ``mid``, and ``max`` properties of its own, mapping to :py:class:`int` values \
    that correspond to transactions/second limits enforced by the API.

    Example::

        endpoints = radar_client.api_endpoints()
        for endpoint in endpoints:
            print(endpoint)

    """
    identifier_attrs = ('id', 'name')
    DEFAULT_PROPERTIES = [
        'id',
        'name',
        'httpMethod',
        'type',
        'family',
        'documentationUrl',
        'uriList'
    ]

    def __init__(self, endpoint_data):
        # The user-friendly URIs are included behind different keys depending on the source of the response data.
        if 'displayUriList' in endpoint_data:
            uri_pattern_data = endpoint_data['displayUriList']
            del endpoint_data['displayUriList']
        else:
            uri_pattern_data = endpoint_data['uriPattern']
        del endpoint_data['uriPattern']
        super(RadarAPIEndpoint, self).__init__(endpoint_data)
        self.uriList = [uri for uri in uri_pattern_data.split(',')]

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarAPIEndpoint, cls).property_value_converter_map)
        map.update({
            "ratelimit": DotNotationDictionaryValueConverter,
            "terms": DotNotationDictionaryValueConverter
        })
        return map

    def __unicode__(self):
        return u'<RadarAPIEndpoint {} "{}" ({}) from {}>'.format(self.id, self.name, self.type, self.family)


class RadarAPIEndpointPermission(DictionaryBasedModel):
    """
    Represents a Radar API endpoint's permissions, as part of the :py:class:`RadarAPIEndpointAccessCheck` object from
    the response to :py:meth:`~radarclient.client.RadarClient.api_endpoint_access_for_names`.

    RadarAPIEndpointPermission objects have the following properties:

    - endpoint, :py:class:`RadarAPIEndpoint`
    - permission, :py:class:`str`, from ``ALLOW``, ``DENY``, or ``NOT_REQUESTED``
    - reason, :py:class:`str`, the reason for a ``DENY`` status on a requested endpoint (if any)

    """
    DEFAULT_PROPERTIES = [
        'endpoint',
        'permission',
        'reason'
    ]

    def __init__(self, endpoint_permission_data):
        super(RadarAPIEndpointPermission, self).__init__(endpoint_permission_data)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarAPIEndpointPermission, cls).property_value_converter_map)
        map.update({
            "endpoint": RadarAPIEndpointValueConverter
        })
        return map

    def __unicode__(self):
        repr = u'<RadarAPIEndpointPermission "{}" for {}'.format(self.permission, self.endpoint)
        if self.permission == 'DENY' and self.reason is not None:
            repr += u' with reason "{}"'.format(self.reason)
        repr += u'>'
        return repr


class RadarAPIEndpointAccessCheck(DictionaryBasedModel):
    """
    Represents the entire response to :py:meth:`~radarclient.client.RadarClient.api_endpoint_access_for_names` and
    :py:meth:`~radarclient.client.RadarClient.api_endpoint_access_for_ids`.

    RadarAPIEndpointAccessCheck objects have the following properties:

    - message, :py:class:`str`, the full response message embedded in the response
    - url, :py:class:`str`, linking to the Radar Portal page for requesting endpoint access, typically designed to \
    pre-select the missing endpoints automatically
    - permissions, the :py:class:`list` of :py:class:`RadarAPIEndpointPermission` objects referencing the endpoints \
    in question

    Example::

        endpoint_names = [
            'AddProblemKeyword', 'FindComponent', 'FindComponentBundle', 'FindComponentBundleGroups',
            'FindKeywords', 'FindPeople', 'FindProblems', 'GetComponent', 'GetComponentBundle',
            'GetComponentBundleGroup', 'GetComponentTree', 'GetCurrentUserDetails', 'GetKeywordById',
            'ListProblemKeywords', 'RemoveProblemKeyword', 'UpdateProblem'
        ]
        endpoint_access = radar_client.api_endpoint_access_for_names(endpoint_names)
        print(endpoint_access)

        # The output when all are already approved:
        <RadarAPIEndpointAccessCheck with 16 endpoints, no approval request necessary>

        # The output when some are needed for requesting approval:
        <RadarAPIEndpointAccessCheck with 16 endpoints, request approval via https://radar.apple.com/portal/10152472/874ed3f9-ad12-4270-bdef-3f632c9e749a>

    """
    DEFAULT_PROPERTIES = [
        'message',
        'url',
        'permissions'
    ]

    def __init__(self, endpoint_access_data):
        super(RadarAPIEndpointAccessCheck, self).__init__(endpoint_access_data)

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(RadarAPIEndpointAccessCheck, cls).property_value_converter_map)
        map.update({
            "permissions": RadarAPIEndpointPermissionListConverter
        })
        return map

    def __unicode__(self):
        repr = u'<RadarAPIEndpointAccessCheck with {} endpoints, '.format(len(self.permissions))
        if self.url is not None:
            repr += u'request approval via {}>'.format(self.url)
        else:
            repr += u'no approval request necessary>'
        return repr


class RadarAPIEndpointValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        return RadarAPIEndpoint(item_data) if item_data else None


class RadarAPIEndpointPermissionValueConverter(AbstractValueConverter):

    @classmethod
    def decode_radar_value(cls, item_data):
        permission_str = item_data['permission']['permission']
        reason_str = item_data['permission']['reason']
        item_data['permission'] = permission_str
        item_data['reason'] = reason_str
        return RadarAPIEndpointPermission(item_data) if item_data else None


class RadarAPIEndpointPermissionListConverter(ListValueConverter):

    @classmethod
    def list_item_value_converter_class(cls):
        return RadarAPIEndpointPermissionValueConverter


class KeyValuePair(DictionaryBasedModel):
    """
    Represents a single Key-Value Pair, as specified in the `Key-Value API Documentation`_. They are part of an
    instance of the :py:class:`KeyValueStore` class and should not be instantiated directly.

    KeyValuePair objects have the following properties:

    - name, :py:class:`str` that is the typically referred to as the `key` and can also be referenced by ``key`` and \
        ``key_name``
    - value, :py:class:`str`, has a limit of 4000 bytes (characters)
    - valueType, :py:class:`str` -- this is hard-coded; the only supported ``valueType`` is ``String``
    - createdAt, :py:class:`str` (ISO8601 timestamp)
    - createdBy, :py:class:`Person`
    - lastModifiedAt, :py:class:`str` (ISO8601 timestamp)
    - lastModifiedBy, :py:class:`Person`

    .. note::
        The ``name`` (key) of a KeyValuePair cannot be changed after creation. It must be deleted and re-created with
        the desired ``name``.

    See the :py:class:`KeyValueStore` class for more information and example code.
    """
    DEFAULT_PROPERTIES = [
        'name',
        'value',
        'valueType',
        'createdAt',
        'createdBy',
        'lastModifiedAt',
        'lastModifiedBy'
    ]
    PROPERTY_KEYNAME_MAP = {
        'key': 'name',
        'key_name': 'name',
    }

    def __init__(self, kv_store, source, dictionary_representation=None, key=None, value=None, *extra_constructor_args):
        dictionary_representation = dictionary_representation or {}
        self.name = dictionary_representation.get('name', key)
        self.value = dictionary_representation.get('value', value)
        self.valueType = dictionary_representation.get('valueType', 'String')  # Only supported valueType is "String"
        self.kv_store = kv_store
        self.source = source
        if dictionary_representation:
            super(KeyValuePair, self).__init__(dictionary_representation, *extra_constructor_args)
            return

        super(KeyValuePair, self).__init__({'name': key, 'value': value, 'valueType': self.valueType},
                                           *extra_constructor_args)

    @cached_class_property
    def property_names(cls):
        return super(KeyValuePair, KeyValuePair).property_names \
            + KeyValuePair.DEFAULT_PROPERTIES

    @cached_class_property
    def property_value_converter_map(cls):
        map = dict(super(KeyValuePair, cls).property_value_converter_map)
        map.update({
            'createdBy': PersonValueConverter,
            'lastModifiedBy': PersonValueConverter,
        })
        return map

    @cached_class_property
    def keyname_map(cls):
        map = dict(super(KeyValuePair, cls).keyname_map)
        map.update(KeyValuePair.PROPERTY_KEYNAME_MAP)
        return map

    def update(self, new_value=None):
        """
        Updates the ``value`` of the KeyValuePair. Equivalent to :py:meth:`KeyValueStore.update_value_for_key`. **The
        update will be committed to the Radar infrastructure immediately**.

        :param str new_value: The text to be set as the updated ``value`` that will replace the existing.

        """
        self.kv_store.update_value_for_key(self.name, new_value)

    def delete(self):
        """
        Deletes the KeyValuePair from the :py:class:`KeyValueStore`. Equivalent to
        :py:meth:`KeyValueStore.delete_key_value_pair_for_key`. **The deletion will be committed to the Radar
        infrastructure immediately.**
        """
        self.kv_store.delete_key_value_pair_for_key(self.name)

    def __unicode__(self):
        return u'<KeyValuePair "{}" from {}>'.format(self.name, self.source)


class KeyValueStore(object):
    """
    Contains the loaded :py:class:`KeyValuePair` objects that are associated with :py:class:`Radar`,
    :py:class:`Component`, :py:class:`AccessGroup`, :py:class:`WorkGroup`, :py:class:`TestSuite`, :py:class:`TestCase`,
    :py:class:`ScheduledTest`, and :py:class:`ScheduledTestCase` objects. See more information in the
    `Key-Value API Documentation`_.

    Typically, the :py:class:`KeyValuePair` objects must be loaded into the KeyValueStore before they can be referenced,
    by calling :py:meth:`~KeyValueStore.load_pairs_for_keys`. However, calling :py:meth:`~KeyValueStore.value_for_key`,
    :py:meth:`~KeyValueStore.key_value_pair_for_key`, or :py:meth:`~KeyValueStore.key_value_pairs_for_keys()` will
    automatically load the applicable key-value pairs from the API as-needed.

    Specifically for :py:class:`Radar` objects, the **full** set of key-value pairs can be `preloaded` by including
    ``additional_fields=['keyValues']`` in the parameters for the retrieval method.

    .. note::
        All changes to a KeyValueStore and its KeyValuePairs are committed to the Radar infrastructure **immediately**.

    For more information, see these additional methods:

    - :py:class:`Radar.key_values` and :py:meth:`~radarclient.client.RadarClient.key_values_for_radar_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_component_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_access_group_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_work_group_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_test_suite_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_test_case_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_scheduled_test_id`
    - :py:meth:`~radarclient.client.RadarClient.key_values_for_scheduled_test_case_id`

    Example::

            # 1. Accessing a specific key-value pair by key/name (preloading not necessary):
            radar_kvs = radar_client.key_values_for_radar_id(123456789)
            test_dri = radar_kvs.value_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri)

            # 2a. Preloading all available key-value pairs:
            radar = radar_client.radar_for_id(123456789, additional_fields=['keyValues'])
            for key_name in radar.key_values.loaded_keys():
                print(key_name)

            # 2b. Loading specific key-value pairs:
            group_kvs = radar_client.key_values_for_work_group_id(123456)
            group_kvs.load_pairs_for_keys(['swe.amt.audio_qa.lab_dri', 'swe.amt.audio_qa.slack_channel'])

            # 3. Adding a new key-value pair:
            component_kvs = radar_client.key_values_for_component_id(123456)
            component_kvs.add_key_value_pair(
                key_name='swe.amt.audio_qa.assigned_lab',
                value='DA14.02W AQA Automation Lab'
            )

            # 4a. Updating the value of an existing key-value pair:
            radar = radar_client.radar_for_id(123456789)
            radar.key_values.update_value_for_key(
                key_name='swe.amt.audio_qa.test_config',
                new_value='D34/21A210c'
            )

            # 4b. Updating the value of an existing key-value pair via its KeyValuePair object:
            radar = radar_client.radar_for_id(123456789)
            test_dri_kv_pair = radar.key_values.key_value_pair_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri_kv_pair.addedBy)
            test_dri_kv_pair.update('John Q. Tester')

            # 5a. Deleting a key-value pair:
            radar = radar_client.radar_for_id(123456789)
            radar.key_values.delete_key_value_pair_for_key('swe.amt.audio_qa.test_dri')

            # 5b. Deleting the value of an existing key-value pair via its KeyValuePair object:
            radar = radar_client.radar_for_id(123456789)
            test_dri_kv_pair = radar.key_values.key_value_pair_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri_kv_pair.addedBy)
            test_dri_kv_pair.delete()

    """
    def __init__(self, client, source, key_value_data=None):
        self.client = client
        self.source = source
        self.base_url_parts = self.source.webservice_url_components_for_key_values()
        self._loaded_pairs = dict()
        if key_value_data:
            self._apply_loaded_key_value_pair_data(self.source, key_value_data)

    def _webservice_url_components_with_key_name(self, key_name):
        components = [component for component in self.base_url_parts if component is not None]
        components.append(key_name)
        return tuple(components)

    def _send_key_value_request(self, url_components, success_code, method, request_data=None):
        url = self.client.webservice_url_for_path_components(*url_components)
        if request_data:
            request_json = json.dumps(request_data)
            request = self.client.request_for_json_url(url, json_string=request_json, method=method)
        else:
            request = self.client.request_for_url(url, method=method)
        try:
            status, response = self.client.send_request(request)
            if status == success_code:
                return response
            elif status == 404:
                # 404 errors specifically don't raise an UnsuccessfulResponseException
                message = 'Non-{} response code 404: {}'.format(success_code, response['message'])
                raise KeyValuePairNotFoundException(status, response['title'], message)
            else:
                server_message = response.get('message', response) if isinstance(response, dict) else response
                raise Exception('Unexpected Key-Value success status code! ({}): {}'.format(status, server_message))
        except UnsuccessfulResponseException as exc_ure:
            err_status = exc_ure.code
            err_reason = exc_ure.reason
            err_message = 'Non-{} response code {}: {}'.format(success_code, err_status, exc_ure.message)
            if err_status == 409:
                raise KeyValuePairAlreadyExistsException(err_status, err_reason, err_message)
            else:
                raise exc_ure
        except Exception as exc:
            raise Exception('Unknown Key-Value Request failure: {}'.format(exc))

    def _apply_loaded_key_value_pair_data(self, source, key_value_data_list):
        for key_value_pair_data in key_value_data_list:
            key_value_pair = KeyValuePair(self, source, key_value_pair_data)
            self._loaded_pairs[key_value_pair.name] = key_value_pair

    def _load_key_value_pair_data(self, key_name):
        url_components = self._webservice_url_components_with_key_name(key_name)
        response = self._send_key_value_request(url_components, success_code=200, method='GET')
        return response

    def _load_all_key_value_pair_data(self):
        url_components = tuple(self.base_url_parts)
        response = self._send_key_value_request(url_components, success_code=200, method='GET')
        self._apply_loaded_key_value_pair_data(self.source, response)

    def load_pairs_for_keys(self, key_names=None):
        """
        Loads the applicable :py:class:`KeyValuePair` objects with ``name`` properties matching the provided
        ``key_names`` into the KeyValueStore. If no ``key_names`` are provided, it will load **all** the available
        key-value pairs from the Radar API.

        :param list key_names: Typically referred to as the `key` of a key-value pair, and are the ``name`` properties
            of the applicable :py:class:`KeyValuePair` objects.
        :return: ``None``
        """
        if not key_names:
            self._load_all_key_value_pair_data()
        else:
            if isinstance(key_names, compat.string_types):
                key_names = [key_names]
            for key_name in key_names:
                key_value_pair_data = self._load_key_value_pair_data(key_name)
                self._apply_loaded_key_value_pair_data(self.source, [key_value_pair_data])

    def reset(self, key_name=None):
        """
        Unloads the applicable KeyValuePair from the local KeyValueStore, if loaded. If ``key_name`` is blank, it will
        unload **all** of them. It does **not** delete key-value pairs from the Radar infrastructure.

        :meta private:
        """
        if key_name:
            if key_name in self.loaded_keys():
                del self._loaded_pairs[key_name]
        else:
            del self._loaded_pairs
            self._loaded_pairs = dict()

    def value_for_key(self, key_name):
        """
        Returns the ``value`` for a key-value pair with ``name`` matching the provided ``key_name``. If not loaded, the
        applicable :py:class:`KeyValuePair` will be loaded into the local KeyValueStore first.

        :param str key_name: Typically referred to as the `key` of a key-value pair, and is the ``name`` property of the
            applicable :py:class:`KeyValuePair` object.
        :rtype: str

        Example::

            # 1. From a Radar object:
            radar = radar_client.radar_for_id(123456789)
            test_dri = radar.key_values.value_for_key('swe.amt.audio_qa.test_dri')
            print(test_dri)

            # 2. From a Component object:
            component_key_values = radar_client.key_values_for_component_id(123456)
            test_results_url = component_key_values.value_for_key('swe.amt.audio_qa.test_results_url')
            url.open(test_results_url)

        """
        loaded_key_value_pair = self.key_value_pair_for_key(key_name)
        return loaded_key_value_pair.value

    def key_value_pair_for_key(self, key_name):
        """
        Returns the complete :py:class:`KeyValuePair` with ``name`` matching the provided ``key_name``. If not loaded,
        the applicable :py:class:`KeyValuePair` will be loaded into the local KeyValueStore first. This is useful if
        the additional properties ``createdAt``, ``createdBy``, ``lastModifiedAt``, or ``lastModifiedBy`` are needed.

        :param str key_name: Typically referred to as the `key` of a key-value pair, and is the ``name`` property of the
            applicable :py:class:`KeyValuePair` object.
        :rtype: KeyValuePair
        """
        key_value_pairs = self.key_value_pairs_for_keys([key_name])
        return key_value_pairs[0]

    def key_value_pairs_for_keys(self, key_names):
        """
        Returns all the :py:class:`KeyValuePair` with ``name`` properties matching the provided ``key_names``. If not
        loaded, the applicable :py:class:`KeyValuePair` objects will be loaded into the local KeyValueStore first. This
        is useful if the additional properties ``createdAt``, ``createdBy``, ``lastModifiedAt``, or ``lastModifiedBy``
        are needed.

        :param list key_names: Typically referred to as the `key` of a key-value pair, and are the ``name`` properties
            of the applicable :py:class:`KeyValuePair` objects.
        :rtype: list[KeyValuePair]
        """
        key_value_pairs = []
        for key_name in key_names:
            loaded_key_value_pair = self._loaded_pairs.get(key_name)
            if not loaded_key_value_pair:
                self.load_pairs_for_keys([key_name])
                loaded_key_value_pair = self._loaded_pairs.get(key_name)
            key_value_pairs.append(loaded_key_value_pair)
        return key_value_pairs

    def loaded_keys(self):
        """
        Returns all the ``name`` properties of the `loaded` :py:class:`KeyValuePair` objects, without their values. It
        will not cause any key-value pairs to be loaded from the Radar API by itself.

        :rtype: list[str]
        """
        return list(self._loaded_pairs.keys())

    def loaded_values(self):
        """
        Returns all the ``value`` properties of the `loaded` :py:class:`KeyValuePair` objects, without their ``name``
        keys. It will not cause any key-value pairs to be loaded from the Radar API by itself.

        :rtype: list[str]
        """
        return [pair.value for pair in self._loaded_pairs.values()]

    def loaded_pairs(self):
        """
        Returns all the `loaded` :py:class:`KeyValuePair` objects. It will not cause any key-value pairs to be loaded
        from the Radar API by itself.

        :rtype: list[KeyValuePair]
        """
        return list(self._loaded_pairs.values())

    def add_key_value_pair(self, key_name, value):
        """
        Adds a new key-value pair to the KeyValueStore. **NOTE:** The resulting key-value pair is **not** added to
        the `local` KeyValueStore instance as a :py:class:`KeyValuePair` automatically, and must be loaded separately
        if needed. **The addition will be committed to the Radar infrastructure immediately.**

        .. warning::
            The Radar infrastructure limits the KeyValueStore to a maximum of **200** key-value pairs per Radar,
            Component, Group, etc. In addition, each ``value`` is limited to a maximum of **4000** bytes (characters).

        :param str key_name: Typically referred to as the `key` of a key-value pair, and will end up as the ``name``
            property of the resulting :py:class:`KeyValuePair`. **NOTE:** This string cannot be changed after creation,
            and is limited to alphanumeric characters, ``-``, ``_``, ``.``, and ``:``.
        :param str value: The text string to be the initial `value` for the key-value pair. It is limited to a maximum
            of **4000** bytes.
        :return: ``None``

        """
        key_value_pair_data = {'name': key_name, 'value': str(value), 'valueType': 'String'}
        url_components = tuple(self.base_url_parts)
        self._send_key_value_request(url_components, success_code=201, method='POST',
                                                request_data=key_value_pair_data)

    def update_value_for_key(self, key_name, new_value):
        """
        Updates the ``value`` of an existing key-value pair. Will reload the applicable :py:class:`KeyValuePair` if it
        is already loaded into the KeyValueStore. **The update will be committed to the Radar infrastructure
        immediately.**

        :param str key_name: Typically referred to as the `key` of a key-value pair, and is the ``name`` property of the
            applicable :py:class:`KeyValuePair` object.
        :param str value: The text string to be the updated `value` for the key-value pair. It is limited to a maximum
            of **4000** bytes.
        :return: ``None``

        """
        key_value_pair_data = {'value': str(new_value), 'valueType': 'String'}
        url_components = self._webservice_url_components_with_key_name(key_name)
        self._send_key_value_request(url_components, success_code=200, method='PUT',
                                                request_data=key_value_pair_data)
        if key_name in self.loaded_keys():
            self.reset(key_name)
            self.load_pairs_for_keys([key_name])

    def delete_key_value_pair_for_key(self, key_name):
        """
        Deletes the :py:class:`KeyValuePair` matching the provided ``key_name`` from the KeyValueStore. **The deletion
        will be committed to the Radar infrastructure immediately.**

        :param str key_name: Typically referred to as the `key` of a key-value pair, and is the ``name`` property of the
            applicable :py:class:`KeyValuePair` object.
        :return: ``None``

        """
        url_components = self._webservice_url_components_with_key_name(key_name)
        self._send_key_value_request(url_components, success_code=204, method='DELETE')
        if key_name in self.loaded_keys():
            self.reset(key_name)

    @compat.repr_from_unicode
    def __repr__(self):
        pass

    def __unicode__(self):
        loaded_count = len(self._loaded_pairs)
        suffix = '' if loaded_count == 1 else 's'
        return u'<KeyValueStore with {} loaded KeyValuePair object{}, for {}>'.format(loaded_count, suffix, self.source)


class KeyValueStoreForTestSuiteCase(KeyValueStore):
    """
    This KeyValueStore subclass is used specifically for a Test Case within a Test Suite.

    :meta private:
    """
    def __init__(self, client, test_case, test_suite):
        super(KeyValueStoreForTestSuiteCase, self).__init__(client, test_case)
        self.source_suite = test_suite
        self.base_url_parts = TestSuite.BASE_URL_COMPONENTS_FOR_KEY_VALUES + (
            test_suite.suiteId, 'cases',
            test_case.caseId, 'key-values'
        )

    def __unicode__(self):
        loaded_count = len(self._loaded_pairs)
        suffix = '' if loaded_count == 1 else 's'
        return u'<KeyValueStore with {} loaded KeyValuePair object{}, for {} in {}>'.format(loaded_count, suffix,
                                                                                            self.source,
                                                                                            self.source_suite)
