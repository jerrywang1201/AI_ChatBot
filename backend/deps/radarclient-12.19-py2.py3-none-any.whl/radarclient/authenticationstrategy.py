from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import base64
import hashlib
import hmac
import json
import logging
import os
import platform
import struct
import subprocess
import time
import re
import datetime
import warnings
from base64 import urlsafe_b64decode, urlsafe_b64encode
from hashlib import sha1
from os import urandom

from .compat import urllib_parse_qs as parse_qs
from .compat import urllib_urlparse as urlparse
from .compat import urllib_urlencode as urlencode
from .exceptions import AuthenticationError
from .directory import AppleDirectoryQuery
from .environment import RadarEnvironment
from . import gssauthenticator
from . import compat
from . import http_request_utilities
import ssl


logger = logging.getLogger(__name__)


class RadarAccessToken(object):

    def __init__(self, token, user_name, token_expiration_datetime, dsid=None):
        if not token:
            raise ValueError('Missing mandatory token parameter')
        self.token = token
        self.user_name = user_name
        self.dsid = dsid
        self.expiration_datetime = token_expiration_datetime

    @classmethod
    def token_for_signon_response_payload(cls, signon_response_payload):
        token_expiration_seconds, = re.findall(r'^(\d+) Seconds', signon_response_payload['tokenExpiresIn'])
        token_expiration_time = int(token_expiration_seconds) - 10  # Safety margin
        expiration_date = datetime.datetime.now() + datetime.timedelta(seconds=token_expiration_time)
        return cls(signon_response_payload['accessToken'], signon_response_payload['user']['appleConnectName'], expiration_date, signon_response_payload['user']['id'])

    # Returns a tuple (token_is_valid, expiration_datetime, time_remaining_seconds)
    def expiration_status_information(self):
        is_valid = True
        seconds_remaining = None
        expiration_date = self.expiration_datetime
        if expiration_date:
            seconds_remaining = (expiration_date - datetime.datetime.now()).total_seconds()
            is_valid = seconds_remaining > 0
        return is_valid, expiration_date, seconds_remaining


class ClientSystemIdentifier(object):
    """
    This class captures information about your application. You should
    provide a meaningful name and update the version number whenever you
    update your application code.

    :param str name: Your application's name
    :param str version: Your application's version number as a string

    This information is sent along in the HTTP ``User-Agent`` header::

        User-Agent: MyRadarSyncApp/1.0 python-radarclient/1.29 urllib2/2.7 Python/2.7.5 OSX/10.9

    This helps to identify requests from your application in case of
    problems, for example if your application overloads the web API servers
    with requests due to a programming error.

    If you don't provide the ClientSystemIdentifier instance it's not a fatal error,
    but you will get a warning message.

    See :py:class:`RadarClient` for a usage example.

    """

    def __init__(self, name, version, _unit_test_override_name_checks=False):
        version = str(version)
        if not _unit_test_override_name_checks:
            assert name != 'MyApp', 'Please pick a real client system identifier name for your software, "MyApp" is just a documentation placeholder'
            assert 'script' not in name.lower(), 'Please avoid client system identifier names containing the string "script". The Radar API server implementation has a bug that rejects such names (see radar:39020667).'
            assert re.match(r'^[a-zA-Z0-9][a-zA-Z0-9._-]+$', name), \
                'Invalid system identifier name (letters, numbers, ., _, and - are allowed) and first ' \
                'character must be alphanumeric'
            assert re.match(r'^\d[a-zA-Z0-9._-]*$', version), 'Invalid system identifier version (letters, numbers, ., _, and - are allowed, and a leading digit is required)'
        self.name = name
        self.version = version

    def user_agent_string(self):
        return '{}/{}'.format(self.name, self.version)


class AuthenticationStrategy(object):
    """
    An abstract base class for authentication strategy implementations. Authentication
    strategies implement a particular Radar web API authentication method.

    :param RadarEnvironment radar_environment: Optional RadarEnvironment instance, in case you need to target a different environment than production.
    :param int request_timeout: Optional request timeout duration in seconds. Defaults to 300 seconds

    See :py:class:`RadarClient` for a usage example.

    """

    cached_ca_cert_bundle_data = None
    ca_cert_bundle_package_resource_subpath = 'ssl/apple-20250203.pem'

    def __init__(self, radar_environment=None, request_timeout=None):
        if not radar_environment:
            radar_environment = RadarEnvironment.default_environment()
        self.radar_environment = radar_environment
        self.cached_radar_access_token = None
        self.should_use_radar_access_token = True
        self.client_system_identifier_accessor = lambda : None

        if not request_timeout:
            request_timeout = 300
        logger.debug('Using request timeout of {}s'.format(request_timeout))
        self.request_timeout = request_timeout

    def __getstate__(self):
        return {
            'radar_environment': self.radar_environment,
            'cached_radar_access_token': self.cached_radar_access_token,
            'should_use_radar_access_token': self.should_use_radar_access_token,
            'request_timeout': self.request_timeout,
        }

    def __setstate__(self, state):
        self.__dict__.update(state)

    def authenticated_request(self, url, data=None, method=None):
        request = self.raw_request(url, data, method)
        if self.should_use_radar_access_token:
            token_value = self.radar_access_token().token
            assert(token_value)
            request.add_header('Radar-Authentication', token_value)
        else:
            self.configure_request_for_native_authentication(request)
        return request

    def raw_request(self, url, data=None, method=None):
        return http_request_utilities.AuthenticatedRequestUrllib2(self, url, data, method)

    def radar_access_token(self):
        token = self.cached_radar_access_token
        if token:
            is_valid, expiration_datetime, seconds_remaining = token.expiration_status_information()
            if is_valid:
                logger.debug('Radar authentication token cache hit [{}/0x{:x}/0x{:x}] expires {} ({}s remaining)'.format(os.getpid(), id(self), id(token), expiration_datetime, seconds_remaining))
            else:
                logger.debug('Radar authentication token expired [{}/0x{:x}/0x{:x}] expired {} ({}s ago)'.format(os.getpid(), id(self), id(token), expiration_datetime, abs(seconds_remaining)))
                token = None
        else:
            logger.debug('Radar authentication token cache miss [{}/0x{:x}]'.format(os.getpid(), id(self)))

        if not token:
            token = self.acquire_radar_access_token()
            self.cached_radar_access_token = token
            _, expiration_datetime, seconds_remaining = token.expiration_status_information()
            logger.debug('Radar authentication token acquired [{}/0x{:x}/0x{:x}] expiration date {} ({}s remaining)'.format(os.getpid(), id(self), id(token), expiration_datetime, seconds_remaining))

        return token

    def acquire_radar_access_token(self):
        url = self.radar_environment.configuration_value('webservice_url') + '/signon'
        request = self.raw_request(url)
        http_request_utilities.configure_request_for_json(request)
        http_request_utilities.configure_request_user_agent_string_with_client_system_identifier(request, self.client_system_identifier_accessor(), authentication_strategy=self)
        self.configure_request_for_native_authentication(request)
        response = request.send()
        auth_data_or_error_string = response.data()
        if not isinstance(auth_data_or_error_string, dict):
            status = response.status()
            error_cls = http_request_utilities.exception_class_for_unsuccessful_http_response_code(status)
            raise error_cls(status, response.status_reason(), 'Non-200 response code {} or non-dictionary response body while getting API token: {}'.format(status, auth_data_or_error_string))
        token = RadarAccessToken.token_for_signon_response_payload(auth_data_or_error_string)
        return token

    def ensure_valid_authentication_credentials(self):
        if self.should_use_radar_access_token:
            return self.radar_access_token() is not None
        return True

    def ca_cert_bundle_data(self):
        if not self.cached_ca_cert_bundle_data:
            self.cached_ca_cert_bundle_data = compat.package_resource_bytes(self.ca_cert_bundle_package_resource_subpath).decode('utf-8')
            assert(len(self.cached_ca_cert_bundle_data) > 0)
        return self.cached_ca_cert_bundle_data

    def did_receive_response(self, response):
        headers_to_log = [
            'X-B3-TraceId',
            'Content-Length'
        ]

        header_summary = ', '.join(['{}={}'.format(key, response.header(key)) for key in headers_to_log])
        logger.log(logging.DEBUG, 'Received response for {} {}: status {}, duration {:.3f}s, {}'.format(response.request.effective_method_for_logging(), response.request.url(), response.status(), response.duration(), header_summary))

    def configure_request_for_native_authentication(self, request):
        pass

    def username(self):
        return None

    @staticmethod
    def open_urllib_request_without_following_redirections(request, ca_cert_bundle_data, timeout=None):
        class NoRedirectionProcessor(compat.urllib_HTTPErrorProcessor):

            def http_response(self, request, response):
                return response

            https_response = http_response

        cookie_jar = compat.cookie_CookieJar()
        non_redirecting_opener = compat.urllib_build_opener(compat.urllib_HTTPSHandler(context=http_request_utilities.ssl_context(ca_cert_bundle_data)), NoRedirectionProcessor, compat.urllib_HTTPCookieProcessor(cookie_jar))
        return non_redirecting_opener.open(request, timeout=timeout), cookie_jar


class AuthenticationStrategyOIDC(AuthenticationStrategy):
    """
    .. deprecated:: 12.18
        AuthenticationStrategyOIDC has been deprecated and split up into more specialized authentication strategies.
        Users relying on this strategy for AppleConnect authentication should enable PKCE on their OAuth 2.0 client
        and migrate to :py:class:`AuthenticationStrategyAppleConnect`. Users of this strategy that are passing in
        access_token should migrate to :py:class:`AuthenticationStrategyOAuthAccessToken`.

    A Radar Web API authentication strategy that uses the access token generated by IdMS OpenID Connect (OIDC)
    to authenticate to Radar.

    Currently Radar supports the Corporate OIDC Authorization Grant Code Flow that involves the client application and
    identity provider. The access token must be a Radar resource-specific token.

    You can either supply the Radar OIDC access_token directly or a
    client_id/client_secret combination that will perform a grant code authorization with the AppleConnect CLI
    and a token request to the IdMS OAuth endpoint.

    .. note:: Appleconnect CLI version must be 6.1 or higher and caller must be in a macOS environment. Currently the CLI is not available for use in non-macOS environments.

    With the client_id/client_secret combination, this requires that the current macOS
    user session is signed in to AppleConnect/kerberos. Please read :py:class:`AuthenticationStrategySPNego` for
    more details on setting up for authentication with a macOS user session.
    Using AppleConnect with kerberos will be an automated, non-interactive operation.

    :param str access_token: The OIDC access token.
    :param str client_id: The OIDC client ID of the IdMS app.
    :param str client_secret: The OIDC client secret of the IdMS app.

    You can also directly provide the access_token value if you already have it from somewhere
    else, for example in an AppleConnect-based web application. The implementation will
    not attempt to re-fetch it in this case and you will need to handle failures from expired
    JWT access_tokens yourself. For web services, an OIDC auth proxy can handle the token expirations and re-authenticate.
    You can also use a custom session handler to store the access_token per session and re-issue a new token once it is
    expired to pass the token into this auth strategy.

    .. note:: There is currently some overlap between this authentication strategy and the :py:class:`AuthenticationStrategyAppleConnect<radarclient.authenticationstrategy.AuthenticationStrategyAppleConnect>` one for the local system use case that calls out to the AppleConnect command line utility. We plan to remove that part from this authentication strategy in the future and focus this one on other OIDC use cases, especially for server environments.

    :py:class:`RadarEnvironments<RadarEnvironment>` supported: ``production`` and ``uat-alt``
    """
    def __init__(self, access_token=None, client_id=None, client_secret=None, **kwargs):
        warnings.warn('AuthenticationStrategyOIDC is deprecated. Migrate to an alternate strategy like AuthenticationStrategyAppleConnect or AuthenticationStrategyOAuthAccessToken.', DeprecationWarning, stacklevel=2)
        super(AuthenticationStrategyOIDC, self).__init__(**kwargs)
        self.client_id = client_id
        self.client_secret = client_secret
        if access_token:
            self.access_token = access_token
            self.should_check_expiration = False
        else:
            if not (client_id and client_secret):
                raise Exception('You must either provide values for "access_token" or for "client_id/client_secret"')
            self.should_check_expiration = True
            self._authenticate()

    def serialized_attributes(self):
        return ['client_id', 'client_secret', 'access_token', 'token_timestamp', 'should_check_expiration']

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state['super_state'] = super(AuthenticationStrategyOIDC, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyOIDC, self).__setstate__(state['super_state'])
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key, None))

    def token_age(self):
        return datetime.datetime.now() - self.token_timestamp

    def is_token_expired(self):
        return self.token_age().total_seconds() > self.token_max_age_seconds

    def _authenticate(self):
        realm = self.radar_environment.configuration_value('kerberos_realm')
        resource = self.radar_environment.configuration_value('webservice_url')

        # AppleConnect version 6.1 no longer requires the app ID '-I' parameter.
        # App ID is not required to auth with OIDC once you supply a client_id.
        cmd = ['appleconnect', 'getToken', '--realm', realm, '-t', 'oauth', '-C', self.client_id,
               '--oauth-grant-type', 'code', '-u', resource]
        logger.debug('appleconnect oauth grant token command: {}'.format(cmd))
        try:
            apc_output = subprocess.check_output(cmd, timeout=20)
        except subprocess.CalledProcessError as e:
            raise Exception('Command failed, please ensure AppleConnect version is 6.1 or higher, error: {}'.format(e))
        except subprocess.TimeoutExpired as e:
            raise Exception('Timeout occurred, please ensure you are logged in to the '
                            'correct AppleConnect environment (prod/uat) for command: {}, error: {}'.format(cmd, e))
        code_output = [line.decode('utf-8') for line in apc_output.splitlines()]
        grant_code = [line[len('oauth-grant-code: '):] for line in code_output if 'oauth-grant-code: ' in line][0]

        logger.debug('Calling IdMS token endpoint with grant code: {}'.format(grant_code))
        token_response = self._get_token_from_idms(grant_code)

        self.access_token = token_response['access_token']
        self.token_max_age_seconds = token_response['expires_in']

        logger.debug('self.access_token: {}'.format(self.access_token))
        logger.debug('self.token_max_age_seconds: {}'.format(self.token_max_age_seconds))
        self.token_timestamp = datetime.datetime.now()

    def _get_token_from_idms(self, grant_code):
        data = {
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'grant_type': 'authorization_code',
            'code': grant_code
        }

        try:
            params = json.dumps(data).encode('utf-8')
            token_url = self.radar_environment.configuration_value('idms_oauth_token_api_url')
            logger.debug('Making token request to IdMS endpoint: "{}" with params: {}'.format(token_url, params))
            token_request = compat.urllib_Request(url=token_url,
                                                  data=params,
                                                  headers={'accept': 'application/json',
                                                           'Content-Type': 'application/json'})
            response = http_request_utilities.urlopen(url_or_request=token_request, cadata=self.ca_cert_bundle_data())
            token_response = json.loads(response.read().decode('utf-8'))
            return token_response
        except compat.urllib_HTTPError as e:
            raise e

    def configure_request_for_native_authentication(self, request):
        if self.should_check_expiration and self.is_token_expired():
            logger.info(u'Authentication Radar OIDC access token age > max age {}s, re-authenticating...'.format(self.token_max_age_seconds))
            self._authenticate()
        request.add_header('X-Apple-OIDC-Access-Token', self.access_token)


class AuthenticationStrategyWebCookie(AuthenticationStrategy):
    """
    .. deprecated:: 12.18
        Use :py:class:`AuthenticationStrategySystemAccountOAuth` or :py:class:`AuthenticationStrategyNarrative` instead.

    A Radar Web API authentication strategy that uses the web cookie authentication method.

    .. note:: It is recommended that you use the SPNego authentication strategy instead whenever possible.

    You can either supply a username/password combination or the cookie value directly.

    If you supply the username/password, the implementation will fetch the cookie value,
    and it will re-fetch it automatically if it is about to expire.

    Alternatively you can directly provide the cookie value if you already have it from somewhere
    else, for example in an AppleConnect-based web application. The implementation will
    not attempt to re-fetch it in this case and you will need to handle failures from expired
    cookies yourself.

    .. note::
      There have been reports that the cookie_value method does not work in the UAT environments.
      It does work in the production environment.

    :param str appleconnect_username: The AppleConnect username
    :param str appleconnect_password: The AppleConnect password
    :param str cookie_value: The cookie value, for situations where you already have it

    See :py:class:`AuthenticationStrategy` for additional constructor parameters.

    See :py:class:`RadarClient` for a usage example.

    If you are running this on the Apple Kube platform, you have to ensure that your
    pods can access the iDMS servers in the "Apple Internal" named network.
    You can check this with https://caniconnect.aci.apple.com. You will probably have to grant
    a network entitlement for your pods/app/namespace, something like::

        /opt/brew/bin/ent request <pod-id>.<namespace>.kube --network-out='Apple Internal'

    """

    def __init__(self, appleconnect_username=None, appleconnect_password=None, cookie_value=None, **kwargs):
        warnings.warn('AuthenticationStrategyWebCookie is deprecated and will stop working on September 30, 2025. Migrate to an OAuth based authentication strategy like AuthenticationStrategySystemAccountOAuth.', DeprecationWarning, stacklevel=2)
        super(AuthenticationStrategyWebCookie, self).__init__(**kwargs)
        self.setup_for_credentials(appleconnect_username, appleconnect_password, cookie_value)

    def setup_for_credentials(self, appleconnect_username, appleconnect_password, cookie_value):
        self.appleconnect_username = appleconnect_username
        self.appleconnect_password = appleconnect_password
        if cookie_value:
            self.cookie_value = cookie_value
            self.should_check_expiration = False
        else:
            if not (appleconnect_username and appleconnect_password):
                raise Exception('You must either provide values for "appleconnect_username/appleconnect_password" or for "cookie_value"')
            self.should_check_expiration = True
            self._authenticate()

    def serialized_attributes(self):
        return 'appleconnect_username appleconnect_password cookie_value cookie_timestamp should_check_expiration'.split()

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state['super_state'] = super(AuthenticationStrategyWebCookie, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyWebCookie, self).__setstate__(state['super_state'])
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key, None))

    def username(self):
        return self.appleconnect_username

    def cookie_age(self):
        return datetime.datetime.now() - self.cookie_timestamp

    def is_cookie_expired(self):
        return self.cookie_age().seconds > self.radar_environment.configuration_value('cookie_max_age_seconds')

    def _authenticate(self):
        env = self.radar_environment
        url = '{}?appIdKey={}'.format(env.configuration_value('authweb_login_url'), env.configuration_value('appid_key'))
        try:
            data = b''.join(http_request_utilities.urlopen(url, self.ca_cert_bundle_data(), timeout=self.request_timeout).readlines())
            data = data.decode('utf-8')
        except compat.urllib_URLError as e:
            raise Exception('Unable to connect to authentication web server (using URL "{}"), is the VPN connection required but not active? error: {}'.format(url, e))

        matches = re.findall(r'(<form[^>]+action="(.*?)"[^>]*>)', data)
        if not matches:
            raise Exception('Unable to find session ID in authentication web page "{}"'.format(url))

        relative_url = None
        for element, action in matches:
            if 'command' in element:
                relative_url = action
        if not relative_url:
            raise Exception('Unable to find form action in page "{}"'.format(url))

        url = env.configuration_value('authweb_login_url_2') + '/' + relative_url
        parameters = 'appIdKey={}&appleId={}&accountPassword={}'.format(env.configuration_value('appid_key'), compat.urllib_url_quote(self.appleconnect_username), compat.urllib_url_quote(self.appleconnect_password))
        request = compat.urllib_Request(url, parameters.encode('utf-8'))

        response, cookie_jar = self.open_urllib_request_without_following_redirections(request, self.ca_cert_bundle_data(), self.request_timeout)

        cookies = {cookie.name: cookie for cookie in cookie_jar}
        cookie_env = env.configuration_value('web_cookie_environment')
        logger.debug('Web cookie auth url: {}, key: {}, cookies: {}'.format(url, cookie_env, cookies))
        if cookie_env not in cookies:
            response_data = response.read().decode('utf-8')
            logger.debug('Unable to authenticate. URL: {}, Response data: "{}", headers: {}'.format(url, response_data, response.headers))

            error_reason_span_classes = ['dserror', 'dsheading', 'dstext']
            for span_class in error_reason_span_classes:
                if span_class in response_data:
                    reason = re.findall(r'<span\s+class="{}">(.+?)</span>'.format(span_class), response_data)
                    if reason:
                        reason = reason[0].strip()
                        raise Exception('Unable to authenticate using the WebCookie strategy: {}'.format(reason))

            if "Touch your YubiKey to continue" in response_data:
                    raise Exception('Unable to authenticate using the WebCookie strategy, this account is configured to use a YubiKey, which is not supported for WebCookie.')

            raise Exception('Unable to authenticate using the WebCookie strategy, cookie "{}" not found in response from "{}". Response data: "{}", headers: {}'.format(cookie_env, url, response_data, response.headers))

        self.cookie_value = cookies[cookie_env].value
        self.cookie_timestamp = datetime.datetime.now()

    def configure_request_for_native_authentication(self, request):
        if self.should_check_expiration and self.is_cookie_expired():
            logger.info(u'Authentication web cookie age > max age {}s, re-authenticating...'.format(self.radar_environment.configuration_value('cookie_max_age_seconds')))
            self._authenticate()
        request.add_header('Cookie', self.cookie_value)


class AuthenticationStrategyCachedRadarAccessToken(AuthenticationStrategy):
    """
    A Radar Web API authentication strategy that uses a cached radar access token.

    .. note:: It is recommended that you use the SPNego authentication strategy instead whenever possible.

    You can directly provide access tokens to this strategy if you've already retrieved one independently
    of radarclient. The token value is expected to be retrieved via Radar's /signon HTTP call in most
    cases. This implementation will not attempt to refresh the token and you will need to handle
    failures from expired tokens yourself.

    This strategy is specifically useful when working with iTriage, where only an access token is exposed
    as an environment variable on the system.

    :param str token_value: The access token value

    See :py:class:`AuthenticationStrategy` for additional constructor parameters.

    See :py:class:`RadarClient` for a usage example.

    """
    def __init__(self, token_value, **kwargs):
        super(AuthenticationStrategyCachedRadarAccessToken, self).__init__(**kwargs)
        self.token_value = token_value

    def acquire_radar_access_token(self):
        return RadarAccessToken(self.token_value, user_name=None, token_expiration_datetime=None)


class AuthenticationStrategyAppToApp(AuthenticationStrategy):
    """
    This authentication strategy implements the App to App (A3) authentication method as supported by RWS.

    Prerequisites for the use of this strategy:

    1. Your application must be registered with IdMS.
    2. Your application must be white-listed with RWS to use App-To-App. Refer to `Onboarding A3 with Radar`_ on the Radar API website for details.
    3. The system account or user DSID must be on-boarded with RWS.

    AuthenticationStrategyAppToApp doesn't need a system account's user name and password.
    It allows server side applications to use an already authenticated user's DSID to interact with RWS.
    It removes the need to maintain a System Account to perform Radar interactions.

    :param str application_id: application id provided by IdMS team
    :param str application_password: application password provided by IdMS team
    :param str radar_app_to_app_context: radar app-to-app context string provided by RWS team
    :param str person_dsid: User's DsID registered with RWS team

    .. _`Onboarding A3 with Radar`: https://radar.apple.com/support/articles/5e740d9706dd8e004f366054/onboarding-a3-with-radar

    Example::

        auth_strategy = AuthenticationStrategyAppToApp(application_id=os.getenv('APP_ID'),
                                                       application_password=os.getenv('APP_PASS'),
                                                       radar_app_to_app_context=os.getenv('APP_CONTEXT'),
                                                       person_dsid='user_dsid')

        client = radarclient.RadarClient(auth_strategy,
                                         radarclient.ClientSystemIdentifier('python-radarclient-unittest', radarclient.__version__))

    """
    def __init__(self,
                 application_id=None,
                 application_password=None,
                 radar_app_to_app_context=None,
                 person_dsid=None,
                 **kwargs):
        super(AuthenticationStrategyAppToApp, self).__init__(**kwargs)
        self._radar_rws_app_id = 21

        self._application_id = application_id
        self._application_password = application_password
        self._radar_app_to_app_context = radar_app_to_app_context

        self._person_dsid = person_dsid

        self._validate_parameters()

        # all parameters are provided!
        self._user_and_token_details = {
            'idms_app_to_app_token': None
        }

    def serialized_attributes(self):
        return '_radar_rws_app_id _application_id _application_password _radar_app_to_app_context _person_dsid _user_and_token_details'.split()

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state['super_state'] = super(AuthenticationStrategyAppToApp, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyAppToApp, self).__setstate__(state['super_state'])
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key, None))

    def configure_request_for_native_authentication(self, request):
        # get current session, retrieve the accessToken and add the header to RWS calls
        # its possible, by the time this is called, we may not have active user token or session
        # as server side may have called, end_session and then trying to call configure_request_for_native_authentication
        # handle that properly
        self._authenticate(request=request)

    def setup_user_session(self):
        try:
            self._get_app_to_app_token_from_idms()
        except Exception as e:
            raise e

        return True

    def end_session(self):
        """
        Ends the user session by sending an invalidation request to the server and clearing the locally cached token information.
        """
        self._end_rws_session()

        self._person_dsid = None
        self._user_and_token_details = { 'idms_app_to_app_token': None }
        return True

    def username(self):
        return self.radar_access_token().user_name

    def _authenticate(self, request):
        """
        Handle authentication considering UAT or PROD environments
        """
        self.setup_user_session()

        request.add_header(name='X-Apple-Client-App-ID', value=self._application_id)
        request.add_header(name='X-Apple-IDMS-A3-Token', value=self._user_and_token_details['idms_app_to_app_token'])
        request.add_header(name='X-Apple-User-ID', value=self._person_dsid)

    def _get_app_to_app_token_from_idms(self):
        """
        Talk to iDMS and get the app to app token for user session
        :raises: Exception if iDMS fails to provide app to app token
        """
        generate_token_payload = {
            'appId': compat.unicode_string_type(self._application_id),
            'appPassword': self._application_password,
            'context': self._radar_app_to_app_context,
            'otherApp': self._radar_rws_app_id,
            'prsId': self._person_dsid
        }

        try:
            params = json.dumps(generate_token_payload).encode('utf-8')
            token_request = compat.urllib_Request(url=self._get_token_generate_url(),
                                        data=params,
                                        headers={'content-type': 'application/json'})
            response = http_request_utilities.urlopen(url_or_request=token_request, cadata=self.ca_cert_bundle_data())
            token_response = json.loads(response.read().decode('utf-8'))
            self._user_and_token_details['idms_app_to_app_token'] = token_response['token']
        except compat.urllib_HTTPError as e:
            raise e

    def _validate_parameters(self):
        """
        Validate mandatory parameters, raise exception if any of those are missing

        :raises: Exception
        """
        invalid_parameters = []
        if not self._application_id:
            invalid_parameters.append('application_id')
        if not self._application_password:
            invalid_parameters.append('application_password')
        if not self._radar_app_to_app_context:
            invalid_parameters.append('radar_app_to_app_context')
        if not self._person_dsid:
            invalid_parameters.append('person_dsid')

        if invalid_parameters:
            raise Exception('AuthenticationStrategyAppToApp: You must provide values for {}'.format(', '.join(invalid_parameters)))

    def _get_token_generate_url(self):
        return self.radar_environment.configuration_value('idms_app_to_app_generate_token_api_url')

    def _get_rws_user_signoff_url(self):
        return self.radar_environment.configuration_value('rws_user_signoff_api_url')

    def _end_rws_session(self):
        # POST /signoff
        # Radar-Authentication: user's accessToken

        sign_off_request = compat.urllib_Request(url=self._get_rws_user_signoff_url(),
                                    headers={'Radar-Authentication': self.radar_access_token().token})
        sign_off_request.get_method = lambda: "POST"
        http_request_utilities.urlopen(url_or_request=sign_off_request, cadata=self.ca_cert_bundle_data())


class AuthenticationStrategyOAuthAccessToken(AuthenticationStrategy):
    """
    A Radar Web API authentication strategy that uses IdMS OAuth 2.0 access
    tokens generated elsewhere to authenticate to Radar.

    This strategy passes the access token directly to the signon endpoint, with
    no further information required.

    The access_token parameter should be a raw access token string that was
    obtained elsewhere (for example, during authentication to a web app). If the
    access token cannot be provided statically, users should subclass this class
    and override the ``generate_oauth_access_token`` method to obtain and return
    an access token. See the subclasses included with this package for examples.

    Valid access tokens have an audience of https://radar-webservices.apple.com,
    and are most commonly obtained by an IdMS OAuth 2.0 / OIDC client using the
    `Token Exchange Flow`_, which exchanges the access token obtained during OIDC
    authentication for a resource-specific access token. Clients must have
    delegated authorization for Radar in order to perform the token exchange.

    :py:class:`RadarEnvironments<radarclient.client.RadarEnvironment>` supported: ``production`` and ``uat-alt``

    .. _`Token Exchange Flow`: https://idmsac.corp.apple.com/IdMS-Corp-Docs/oauth2/docs/overview/oauth2-token-exchange.html#oauth20-token-exchange-flow

    :param str | Callable access_token: An IdMS OAuth 2.0 access token for the
        Radar resource server, or a callable which will generate OAuth 2.0
        access tokens for the Radar resource server.
    """

    def __init__(self, access_token, **kwargs):
        # type: (str, **Any) -> None
        super(AuthenticationStrategyOAuthAccessToken, self).__init__(**kwargs)
        self.should_use_radar_access_token = True
        self.access_token = access_token

    def generate_oauth_access_token(self):
        return self.access_token

    def serialized_attributes(self):
        return ["access_token"]

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state["super_state"] = super(AuthenticationStrategyOAuthAccessToken, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyOAuthAccessToken, self).__setstate__(state.pop("super_state", {}))
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key))


    def configure_request_for_native_authentication(self, request):
        # type: (http_request_utilities.AuthenticatedRequestUrllib2) -> None
        request.add_header("X-Apple-OIDC-Access-Token", self.generate_oauth_access_token())

    def _token_request(self, **params):
        # type: (**str) -> str
        """Perform a token request with the OAuth token endpoint, returning the access_token from the response."""
        request = self.raw_request(
            url=self.radar_environment.configuration_value("idms_oauth_token_api_url"),
            data=json.dumps(params).encode(),
            method="POST",
        )
        request.add_header("Content-Type", "application/json")
        response = request.send(check_response_code=False)
        if not response.is_success():
            raise AuthenticationError("Unexpected response status from OAuth access token request ({})".format(response.data()))
        token_response = response.data()
        return token_response["access_token"]  # type: ignore


class AuthenticationStrategyAppleConnect(AuthenticationStrategyOAuthAccessToken):
    """
    A Radar Web API authentication strategy that uses tokens generated by the
    appleconnect(1) command line utility to authenticate to Radar.

    This strategy only works on macOS, with AppleConnect 6.1 (or later)
    installed, in order to generate tokens.

    If provided, the client_id is used to generate an OAuth access token using
    PKCE, and should result in an authenticated session for the user which uses
    the profile associated with the IdMS App, if configured in the Radar Portal.

    In order to use a custom client_id, the IdMS app must be configured as an
    OAuth 2.0 Client, with PKCE enabled, and have onboarded with Radar as a
    delegated resource. Refer to `OIDC Onboarding with Radar Web Services`_ in
    the Radar docs for more information.

    All parameters are optional. If none are provided, this will use the default
    Radar client ID, and the currently logged-in AppleConnect user.

    :param str client_id: OAuth Client ID to use for authentication. The client
        must be onboarded with RWS.
    :param str account: Account name to authenticate as.
    :param str interactivity_type: Level of interactivity for AppleConnect auth,
        passed to appleconnect CLI.
    :param str use_identity: Identity type to authenticate as, passed to
        appleconnect CLI.

    .. _`OIDC Onboarding with Radar Web Services`: https://radar.apple.com/support/articles/6552acb3a0de25003a93b291/oidc-onboarding-with-radar-web-services#existing-idms-application-users

    :py:class:`RadarEnvironments<radarclient.client.RadarEnvironment>` supported: ``production`` and ``uat-alt``

    Example::

        auth_strategy = AuthenticationStrategyAppleConnect(
            # Use custom client ID for Radar profile
            client_id="qtfuzmnaeupzauxxtb3kfksz3uv3mw",
            # Authenticate as system account using Narrative delegation
            account="magitek_system",
            interactivity_type="none",
            use_identity="delegated",
        )
    """

    MIN_APPLECONNECT_VERSION = (6, 1)
    APPLECONNECT_BINARY_PATH = "/usr/local/bin/appleconnect"

    def __init__(
        self,
        client_id=None,  # type: Optional[str]
        account="",  # type: str
        keytab="",  # type: str
        interactivity_type="gui",  # type: Literal["cli", "gui", "none"]
        use_identity=None,  # type: Optional[Literal["yubikey", "touchId", "delegated"]]
        **kwargs
    ):
        if platform.system() != "Darwin":
            raise AuthenticationError("{} is only available for Darwin platforms with appleconnect(1)".format(self.__class__.__name__))
        if not self.available():
            raise AuthenticationError("{} requires appleconnect(1) version {} or later".format(self.__class__.__name__, '.'.join(map(str, self.MIN_APPLECONNECT_VERSION))))
        super(AuthenticationStrategyAppleConnect, self).__init__(access_token="", **kwargs)
        self.client_id = client_id or self.radar_environment.configuration_value("oauth_client_id")
        self.account = account
        self.keytab = keytab
        self.interactivity_type = interactivity_type
        self.use_identity = use_identity

    def serialized_attributes(self):
        return ["client_id", "account", "keytab", "interactivity_type", "use_identity"]

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state["super_state"] = super(AuthenticationStrategyAppleConnect, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyAppleConnect, self).__setstate__(state.pop("super_state", {}))
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key))

    def generate_oauth_access_token(self):
        # type: () -> str
        cmd = [
            self.APPLECONNECT_BINARY_PATH,
            "getToken",
            "--token-type=oauth",
            "--oauth-grant-type=pkce",
            "--oauth-client-ID={}".format(self.client_id),
            "--interactivity-type={}".format(self.interactivity_type),
            "--oauth-resource={}".format(self.radar_environment.configuration_value("oauth_resource")),
        ]
        if self.radar_environment.configuration_value("kerberos_realm") == "APPLECONNECT-UAT.APPLE.COM":
            cmd.append("--environment=uat")
        if self.account:
            cmd.append("--account={}".format(self.account))
        if self.keytab:
            cmd.append("--keytab={}".format(self.keytab))
        if self.use_identity:
            cmd.append("--use-identity={}".format(self.use_identity))

        logger.debug("Running AppleConnect CLI: {}".format(" ".join(cmd)))

        output = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        if isinstance(output, bytes):
            output = output.decode("utf-8")
        parsed = {}
        for line in output.splitlines():
            key, _, val = line.partition(": ")
            parsed[key] = val

        # Workaround for accounts which cannot sign into a client
        rws_client_id = self.radar_environment.configuration_value("oauth_client_id")
        if "Your account does not have permission to access this application" in parsed.get("Error", "") and self.client_id != (rws_client_id):
            logger.warning("appleconnect Error: %s", parsed.get("Error"))
            logger.error("Problem signing in with client ID (%s); retrying with RWS client ID", self.client_id)
            self.client_id = rws_client_id
            return self.generate_oauth_access_token()
        token = parsed.get("oauth-access-token")
        if not (token):
            raise Exception("appleconnect CLI did not return an access token; output:\n{}".format(parsed))
        return token

    @classmethod
    def available(cls):
        # type: () -> bool
        try:
            output = subprocess.check_output([cls.APPLECONNECT_BINARY_PATH, "version"])
            if isinstance(output, bytes):
                output = output.decode("utf-8")
            version, _, _ = output.strip().split()[0].partition("b")  # In case of a beta version installed, strip the beta suffix.
            return tuple(map(int, version.split("."))) >= cls.MIN_APPLECONNECT_VERSION
        except EnvironmentError:
            return False


class AuthenticationStrategyOAuthRefreshToken(AuthenticationStrategyOAuthAccessToken):
    """
    A Radar Web API authentication strategy that uses IdMS OAuth 2.0 refresh
    tokens to authenticate to Radar.

    This strategy exchanges a refresh token for access tokens, using the given
    OAuth Client credentials. After the exchange, the access token is passed to
    the signon endpoint for authentication.

    The refresh_token parameter can be a raw refresh token string that was
    obtained elsewhere (for example, during authentication to a web app), or can
    be a callable which will return a valid refresh token for the OAuth client.

    The refresh token must have been issued using the same OAuth client
    credentials provided. The OAuth client must have delegated access to Radar
    approved for the configured IdMS environment.

    :py:class:`RadarEnvironments<radarclient.client.RadarEnvironment>` supported: ``production`` and ``uat-alt``

    :param str | Callable refresh_token: An IdMS OAuth 2.0 refresh token for the
        given OAuth client, or a callable which will generate refresh tokens for
        the client.
    :param str oauth_client_id: An IdMS OAuth 2.0 Client ID
    :param str oauth_client_secret: The Client Secret for the given OAuth 2.0
        Client.
    """

    def __init__(self, refresh_token, oauth_client_id, oauth_client_secret, **kwargs):
        # type: (str | Callable[[], str], str, str, **Any) -> None
        self._refresh_token = refresh_token
        self._oauth_client_id = oauth_client_id
        self._oauth_client_secret = oauth_client_secret
        super(AuthenticationStrategyOAuthRefreshToken, self).__init__(access_token="", **kwargs)

    def serialized_attributes(self):
        return ["_refresh_token", "_oauth_client_id", "_oauth_client_secret"]

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state["super_state"] = super(AuthenticationStrategyOAuthRefreshToken, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyOAuthRefreshToken, self).__setstate__(state.pop("super_state", {}))
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key))

    def generate_oauth_access_token(self):
        # type: () -> str
        """Exchange refresh token for RWS access token"""
        refresh_token = self._refresh_token() if callable(self._refresh_token) else self._refresh_token
        # 1. Exchange refresh token for IdMS access token for the given client
        client_access_token = self._token_request(
            client_id=self._oauth_client_id,
            client_secret=self._oauth_client_secret,
            grant_type="refresh_token",
            refresh_token=refresh_token,
        )
        # If token is already for Radar resource server, return it
        if self._parse_audience(client_access_token) == self.radar_environment.configuration_value("webservice_url"):
            return client_access_token

        # 2. Exchange the IdMS access token for a radar-webservices resource access token
        rws_access_token = self._token_request(
            client_id=self._oauth_client_id,
            client_secret=self._oauth_client_secret,
            grant_type="urn:ietf:params:oauth:grant-type:token-exchange",
            resource=self.radar_environment.configuration_value("webservice_url"),  # type: ignore
            requested_token_type="urn:ietf:params:oauth:token-type:access_token",
            subject_token_type="urn:ietf:params:oauth:token-type:access_token",
            subject_token=client_access_token,
        )
        return rws_access_token

    def _parse_audience(self, token):
        # type: (str) -> str
        """Parse the audience from a JWT"""
        payload = token.split(".")[1]
        # Add padding to make the payload a multiple of 4 characters
        payload += "=" * (4 - len(payload) % 4)
        return json.loads(urlsafe_b64decode(payload.encode()))["aud"]


class _OTPGenerator:
    """A standards-compliant one-time password generator.

    Generates HOTP codes compliant with [RFC 4226][1] and TOTP codes compliant
    with [RFC 6238][2].

    Args:
        secret: A base32-encoded shared secret

    [1]: https://datatracker.ietf.org/doc/html/rfc4226
    [2]: https://datatracker.ietf.org/doc/html/rfc6238
    """

    NUM_DIGITS = 6
    TOTP_INTERVAL = 30

    def __init__(self, secret):
        # type: (str) -> None
        self._decoded_secret = base64.b32decode(secret, casefold=True)

    def hotp(self, counter):
        # type: (int) -> str
        """Returns the HOTP code for the given counter value"""
        # Get digest
        msg = struct.pack(">Q", counter)
        digest = hmac.new(self._decoded_secret, msg, sha1).digest()
        # Dynamic truncation
        first_byte = ord(digest[-1]) if isinstance(digest, str) else digest[-1]
        offset = first_byte & 0x0F
        (sbits,) = struct.unpack_from(">L", digest, offset)
        code = (sbits & 0x7FFFFFFF) % 10**_OTPGenerator.NUM_DIGITS
        # Return code as a 0-padded string of digits
        return "{:0{num_digits}}".format(code, num_digits=_OTPGenerator.NUM_DIGITS)

    def totp(self):
        # type: () -> str
        """Returns the current TOTP code using the system time"""
        return self.hotp(int(time.time()) // _OTPGenerator.TOTP_INTERVAL)


def _code_verifier_challenge_pkce():
    # type: () -> tuple[str, str]
    """
    Generates a code verifier and its corresponding code challenge for use
    with PKCE flows.
    """
    code_verifier = urlsafe_b64encode(urandom(32)).rstrip(b"=").decode()
    code_challenge = urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest()).rstrip(b"=").decode()
    return code_verifier, code_challenge


class AuthenticationStrategySystemAccountOAuth(AuthenticationStrategyOAuthAccessToken):
    """
    A Radar Web API authentication strategy that uses the IdMS "REST-based
    Authentication for System Accounts".

    You must supply the AppleConnect username, password, and a TOTP config to
    authenticate. This only works with System Accounts.

    If provided, the client_id is used to generate an OAuth access token using
    PKCE, and should result in an authenticated session for the user which uses
    the profile associated with the IdMS App, if configured in the Radar Portal.

    :param str appleconnect_username: The system account username
    :param str appleconnect_password: The system account password
    :param str totp_secret: The TOTP secret for the system account
    :param str totp_deviceid: The device ID for the given TOTP secret
    :param str client_id: OAuth Client ID to use for authentication. The client
        must be onboarded with RWS and have PKCE enabled.

    See :py:class:`AuthenticationStrategy` for additional constructor parameters.
    """

    # Map of environments (kerberos realms) to REST API URLs
    _IDMS_2SV_URL = {
        "APPLECONNECT.APPLE.COM": "https://idms-int-rsvc.corp.apple.com/service/authservice/authenticate",
        "APPLECONNECT-UAT.APPLE.COM": "https://idms-int-rsvc-uat.corp.apple.com/service/authservice/authenticate",
    }
    _AUTH_CODE_URL = {
        "APPLECONNECT.APPLE.COM": "https://idmsac.apple.com/IDMSWebAuth/appleauth/auth/oauth2/v2/authorizationcode",
        "APPLECONNECT-UAT.APPLE.COM": "https://idmsac-uat.corp.apple.com/IDMSWebAuth/appleauth/auth/oauth2/v2/authorizationcode",
    }

    def __init__(
        self,
        appleconnect_username,  # type: str
        appleconnect_password,  # type: str
        totp_secret,  # type: str
        totp_deviceid,  # type: int
        client_id="",  # type: str
        **kwargs
    ):
        # type: (...) -> None
        super(AuthenticationStrategySystemAccountOAuth, self).__init__(access_token="", **kwargs)
        self.appleconnect_username = appleconnect_username
        self.appleconnect_password = appleconnect_password
        self.totp_deviceid = totp_deviceid
        self.totp_generator = _OTPGenerator(totp_secret)
        self.client_id = client_id or str(self.radar_environment.configuration_value("oauth_client_id"))
        self.app_id_key = str(self.radar_environment.configuration_value("appid_key"))

    def serialized_attributes(self):
        return ["appleconnect_username", "appleconnect_password", "totp_deviceid", "totp_generator", "client_id", "app_id_key"]

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state["super_state"] = super(AuthenticationStrategySystemAccountOAuth, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategySystemAccountOAuth, self).__setstate__(state.pop("super_state", {}))
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key))

    def generate_oauth_access_token(self):
        # type: () -> str
        """Generates an access token via PKCE by way of CorpJWT -> Authorization Code -> Access Token"""
        # Generate a code_verifier and challenge for PKCE
        code_verifier, code_challenge = _code_verifier_challenge_pkce()
        corp_jwt = self._generate_corp_jwt(code_challenge)
        auth_code = self._generate_auth_code(corp_jwt, code_challenge)
        return self._token_request(
            client_id=self.client_id,
            grant_type="authorization_code",
            code_verifier=code_verifier,
            code=auth_code,
        )

    def _generate_corp_jwt(self, code_challenge):
        # type: (str) -> str
        """Generate a CorpJWT using the system account credentials via the IdMS REST API"""
        idms_2sv_url = self._IDMS_2SV_URL.get(self.radar_environment.configuration_value("kerberos_realm"))  # type: ignore
        request = self.raw_request(
            url=idms_2sv_url,
            data=json.dumps(
                {
                    "secondFactor": {"secCode": self.totp_generator.totp(), "deviceId": self.totp_deviceid},
                    "dsRequest": {
                        "appCredentials": {
                            "appIdKey": self.app_id_key,
                        }
                    },
                    "account": {"accountName": self.appleconnect_username, "password": self.appleconnect_password},
                    "generateJwt": True,
                    "corpOAuthAuthorizeReqInfo": {
                        "clientId": self.client_id,
                        "responseType": "code",
                        "resource": self.radar_environment.configuration_value("oauth_resource"),
                        "codeChallenge": code_challenge,
                        "codeChallengeMethod": "S256",
                    },
                }
            ).encode(),
            method="POST",
        )
        request.add_header("Content-Type", "application/json")
        request.add_header("appIdKey", self.app_id_key)
        response = request.send(check_response_code=False)
        if not response.is_success():
            raise AuthenticationError("Unexpected response status when generating CorpJWT ({})".format(response.status()), response.data())
        response_data = response.data()  # type: dict
        corp_jwt = response_data.get("corpJwt")
        if corp_jwt:
            return corp_jwt
        for exception in response_data.get("dsresponse", {}).get("allExceptions", []):
            raise AuthenticationError("Problem getting CorpJWT from IdMS: {} ({})".format(exception["errorMessage"], exception["errorCode"]))
        logger.error("invalid corp_jwt response data: %s", response_data)
        raise AuthenticationError("Unexpected response from IdMS for system account authentication: no CorpJWT in response")

    def _generate_auth_code(self, corp_jwt, code_challenge):
        # type: (str, str) -> str
        """Generate an OIDC authorization code grant from the given CorpJWT using the IdMS API"""
        auth_code_url = self._AUTH_CODE_URL.get(self.radar_environment.configuration_value("kerberos_realm"))  # type: ignore
        query_params = {
            "client_id": self.client_id,
            "response_type": "code",
            "resource": self.radar_environment.configuration_value("oauth_resource"),
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        request = compat.urllib_Request(
            url="{}?{}".format(auth_code_url, urlencode(query_params)),
            headers={
                "X-Apple-Corp-Auth-Jwt": corp_jwt,
                "Accept": "application/json",
            },
        )

        response, _ = self.open_urllib_request_without_following_redirections(request, self.ca_cert_bundle_data(), self.request_timeout)
        location_header_value = response.headers.get("Location", None)
        logger.debug("AuthenticationStrategySystemAccount._generate_auth_code: Location: {}".format(location_header_value))
        if response.getcode() != 302:
            errmsg = "Unexpected response status when generating auth code ({})".format(response.status)
            try:
                body = json.loads(response.read().decode())
            except Exception:
                body = None
            logger.error("%s; body=%s", errmsg, body)
            raise AuthenticationError(errmsg, body)
        location_url = urlparse(location_header_value)
        location_params = parse_qs(location_url.query)
        return location_params.get("code", []).pop()

AuthenticationStrategySystemAccount = AuthenticationStrategySystemAccountOAuth
"""
Alias for :py:class:`AuthenticationStrategySystemAccountOAuth`
"""

class AuthenticationStrategyNarrative(AuthenticationStrategyOAuthAccessToken):
    """
    A Radar Web API authentication strategy that uses a Narrative Actor Identity
    to authenticate to Radar.

    This strategy is intended to authenticate system accounts on Linux systems
    that support Narrative, e.g. kube.

    Prerequisites:

    1. You must be using a system account.
    2. You must connect from a system that supports Narrative and which has
        Narrative Actor Identity certificates installed.
    3. The system account must be configured in AppleConnect with an actor
        identity policy for the system you're connecting from.

    For more information:

    - https://idmsac.corp.apple.com/IdMS-Corp-Docs/oauth2/docs/tutorials/system_account_authentication.html
    - https://kube.apple.com/docs/narrative-identities/

    :param str cert_dir: Directory path containing Narrative Actor Identity in
        certificate file "chain.pem" and key file "private.pem"
    :param str client_id: Optional OAuth Client ID to use for authentication.
        The client must be onboarded with RWS and have PKCE enabled.
    :param str cert_file_name: Name to use for the Narrative cert file
        ("chain.pem" by default). Will be joined with 'cert_dir' for the full
        path to the cert file.
    :param str key_file_name: Name to use for the Narrative private key file
        ("private.pem" by default). Will be joined with 'cert_dir' for the full
        path to the key file.

    Example::

        auth_strategy = AuthenticationStrategyNarrative(cert_dir="/narrative/kube-actor")
    """

    def __init__(self, cert_dir, client_id="", cert_file_name="chain.pem", key_file_name="private.pem", **kwargs):
        # type: (str, str, str, str, **Any) -> None
        super(AuthenticationStrategyNarrative, self).__init__(access_token="", **kwargs)
        self.cert_file = os.path.join(cert_dir, cert_file_name)
        self.key_file = os.path.join(cert_dir, key_file_name)
        self.client_id = client_id or str(self.radar_environment.configuration_value("oauth_client_id"))

    def serialized_attributes(self):
        return ["cert_file", "key_file", "client_id"]

    def __getstate__(self):
        state = {k: getattr(self, k, None) for k in self.serialized_attributes()}
        state["super_state"] = super(AuthenticationStrategyNarrative, self).__getstate__()
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategyNarrative, self).__setstate__(state.pop("super_state", {}))
        for key in self.serialized_attributes():
            setattr(self, key, state.get(key))

    def generate_oauth_access_token(self):
        # type: () -> str
        """Generates an access token via PKCE by way of Narrative -> Authorization Code -> Access Token"""
        # Generate a code_verifier and challenge for PKCE
        code_verifier, code_challenge = _code_verifier_challenge_pkce()
        auth_code = self._generate_auth_code(code_challenge)
        return self._token_request(
            client_id=self.client_id,
            grant_type="authorization_code",
            code_verifier=code_verifier,
            code=auth_code,
        )

    def _generate_auth_code(self, code_challenge):
        # type: (str) -> str
        url = self.radar_environment.configuration_value("idms_mtls_actor_authorize_endpoint")
        body = {
            "client_id": self.client_id,
            "response_type": "code",
            "resource": self.radar_environment.configuration_value("oauth_resource"),
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        logger.debug("Getting grant code: url=%r, cert_file=%r, key_file=%r, body=%r", url, self.cert_file, self.key_file, body)
        req = compat.urllib_Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        req.method = "POST"
        context = ssl.create_default_context(cadata=self.ca_cert_bundle_data())
        context.load_cert_chain(self.cert_file, self.key_file)
        res = compat.urlopen(req, timeout=5, context=context)
        obj = json.loads(res.read().decode())
        if "code" not in obj:
            raise AuthenticationError("AuthenticationStrategyNarrative: grant code not found in response: {!r}".format(obj))
        return str(obj["code"])


class AuthenticationStrategySPNego(AuthenticationStrategy):
    """
    .. deprecated:: 12.18
        Use :py:class:`AuthenticationStrategyAppleConnect` instead.

    A Radar Web API authentication strategy that uses the SPNego/Kerberos authentication method.
    It depends on the GSS API implementation provided by macOS in
    /System/Library/Frameworks/GSS.framework. It has also been tested on Linux
    with libgss.

    This requires that the current macOS user session is signed in to AppleConnect/kerberos.

    :param str username: An optional AppleConnect username in case multiple accounts are signed in.

    See :py:class:`AuthenticationStrategy` for constructor parameters.

    See :py:class:`RadarClient` for a usage example.

    .. rubric:: Kerberos authentication for automated systems

    If you would like to set up a system for automated, non-interactive operation
    you can use a Kerberos keytab file together with this authentication method.

    .. rubric:: Kerberos authentication for automated systems - macOS Setup

    1.) Create a keytab file::

        ktutil --keytab=<appleconnect_username>.keytab add -p <appleconnect_username>@APPLECONNECT.APPLE.COM -e aes256-cts-hmac-sha1-96 -V 9

    Make sure this file is protected with the proper UNIX file system permissions.

    This part is a one-time operation, although you might have to repeat it after 90 days when the password expires.

    2.) Set up your automated process, e.g. with cron, and make it so that the system
    authenticates using the keytab file before running your code::

        kinit -k -t <keytab file> <appleconnect_username>@APPLECONNECT.APPLE.COM

    You can run this separately before your main script, for example in a driver shell script,
    or directly from within your radarclient-based Python script.

    .. rubric:: Kerberos authentication for automated systems - Linux Setup

    For Linux, the steps are as follows::

        $ uname -a
        Linux ubuntu 3.13.0-32-generic #57-Ubuntu SMP Tue Jul 15 03:51:08 UTC 2014 x86_64 x86_64 x86_64 GNU/Linux

        $ apt-get update -y
        $ sudo apt-get install krb5-user krb5-config

        $ sudo vi /etc/krb5.conf
        -> under realms, add (taken from ~/Library/Preferences/edu.mit.Kerberos on macOS):

            APPLECONNECT.APPLE.COM = {
                kdc = wdg1.apple.com:4160
                kdc = wdg1-alt.apple.com:4160
            }

        $ ktutil
        ktutil:  addent -password -p <appleconnect_username>@APPLECONNECT.APPLE.COM -k 9 -e aes256-cts-hmac-sha1-96
        Password for <appleconnect_username>@APPLECONNECT.APPLE.COM:
        ktutil:  wkt <appleconnect_username>.keytab
        ktutil:  quit

        $ kinit -k -t <appleconnect_username>.keytab <appleconnect_username>@APPLECONNECT.APPLE.COM

        $ klist
        Ticket cache: FILE:/tmp/krb5cc_1000
        Default principal: <appleconnect_username>@APPLECONNECT.APPLE.COM

        Valid starting       Expires              Service principal
        11/19/2014 13:46:25  11/19/2014 15:46:25  krbtgt/APPLECONNECT.APPLE.COM@APPLECONNECT.APPLE.COM
            renew until 11/19/2014 23:46:25

    It has been verified on Oracle Linux with the same steps except with yum instead of apt-get::

        yum -y install krb5-workstation krb5-libs krb5-auth-dialog

    After the klist output looks good, you can test if the authentication works for rardarclient with::

        radartool --spnego find-person --email your_email@apple.com
        <Person 1234 Firstname Lastname>

    If you see the error message "kinit: Invalid UID in persistent keyring name while getting default ccache"
    then you might have to comment out this line in /etc/krb5.conf::

        default_ccache_name = KEYRING:persistent:%{uid}

    .. note:: There are different Kerberos packages available on Linux, one of them is not supported, you'll probably recognize it by a failure involving ``kinit -l``.

    .. note:: You can use an alternate Kerberos library,  Heimdal (https://github.com/heimdal/heimdal). That lets you create an authentication session without a keytab file. You can look at `examples/heimdal-docker`_ for an example Dockerfile that uses the SDP Base Images Python base image and Heimdal.

    .. note:: A full recommended /etc/krb5.conf file is attached to this Radar: rdar://74206115 (Need a standard location for krb5.conf file)

    .. _`examples/heimdal-docker`: https://github.pie.apple.com/liyanage/radarclient-python/tree/main/examples/heimdal-docker

    .. rubric:: Running on Apple Kube

    If you are running this on the Apple Kube platform, you have to ensure that your
    pods can access the Kerberos servers in the "Apple Datacenters" named network.
    You can check this with https://caniconnect.aci.apple.com. You will probably have
    to grant a network entitlement for your pods/app/namespace, something like::

        /opt/brew/bin/ent request <pod-id>.<namespace>.kube --network-out='Apple Datacenters'

    """

    def __new__(cls, **kwargs):
        if AuthenticationStrategyAppleConnect.available():
            warnings.warn('AuthenticationStrategySPNego is deprecated and will stop working in 2026. The current instantiation for AuthenticationStrategySPNego has been redirected to AuthenticationStrategyAppleConnect automatically. Please change your code to explicitly use AuthenticationStrategyAppleConnect.', DeprecationWarning, stacklevel=2)
            if 'username' in kwargs:
                kwargs['account'] = kwargs['username']
                del kwargs['username']
            return AuthenticationStrategyAppleConnect(**kwargs)
        warnings.warn('AuthenticationStrategySPNego is deprecated and will stop working in 2026. Please migrate to an OAuth based authentication strategy.', DeprecationWarning, stacklevel=2)
        return super().__new__(cls)

    def __init__(self, **kwargs):
#        warnings.warn('AuthenticationStrategySPNego is deprecated and will stop working in 2026. Migrate to an OAuth based authentication strategy like AuthenticationStrategyAppleConnect.', DeprecationWarning, stacklevel=2)
        username = None
        if 'username' in kwargs:
            username = kwargs.get('username', None)
            del kwargs['username']
        super(AuthenticationStrategySPNego, self).__init__(**kwargs)
        self.setup_authenticator_for_username(username)

    def setup_authenticator_for_username(self, username, allow_username_mismatch=False):
        logged_in_account = None
        accounts = AppleDirectoryQuery.logged_in_appleconnect_accounts(radar_environment=self.radar_environment)
        for account in accounts:
            if username and account.username != username:
                if allow_username_mismatch:
                    logger.warning(u'Setting up authentication strategy with username {} instead of {}'.format(account.username, username))
                else:
                    continue
            logged_in_account = account
            break

        if not logged_in_account:
            if username:
                message = 'No AppleConnect session established for username "{}", please log in'.format(username)
            else:
                message = 'No AppleConnect session established, please log in'
            raise Exception(message)

        if logged_in_account.expired:
            raise Exception('AppleConnect session for {} expired, please log in'.format(logged_in_account.full_username))

        logger.debug('setup_authenticator_for_username using account {}'.format(logged_in_account))

        self.gss_authenticator = gssauthenticator.GSSAuthenticator(logged_in_account.username, self.radar_environment.configuration_value('kerberos_realm'))

    def __getstate__(self):
        state = {
            'super_state': super(AuthenticationStrategySPNego, self).__getstate__(),
            'username': self.username(),
        }
        return state

    def __setstate__(self, state):
        super(AuthenticationStrategySPNego, self).__setstate__(state['super_state'])
        self.setup_authenticator_for_username(state['username'], allow_username_mismatch=True)

    def username(self):
        return self.gss_authenticator.username

    def configure_request_for_native_authentication(self, request):
        self.gss_authenticator.attach_token_to_request(request)

    @classmethod
    def available(cls):
        return gssauthenticator.GSSAuthenticator.gss_is_available()


__all__ = [
    "AuthenticationStrategyAppleConnect",
    "AuthenticationStrategyNarrative",
    "AuthenticationStrategyOAuthAccessToken",
    "AuthenticationStrategyOAuthRefreshToken",
    "AuthenticationStrategySystemAccountOAuth",
    "AuthenticationStrategySPNego",
    "AuthenticationStrategySystemAccount",
    "AuthenticationStrategyAppToApp",
    "AuthenticationStrategyCachedRadarAccessToken",
    "AuthenticationStrategyWebCookie",
    "AuthenticationStrategyOIDC",
    "AuthenticationStrategy",
    "ClientSystemIdentifier",
    "RadarAccessToken",
]
