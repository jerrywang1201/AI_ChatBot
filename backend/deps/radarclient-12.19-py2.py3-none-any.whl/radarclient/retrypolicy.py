#!/usr/bin/env python

import re
from random import randrange


class RetryPolicy(object):
    """
    Builds a policy for automatic retries of requests sent to the Radar API that fail with transient or unexpected
    errors. The policy is a series of :py:class:`RetryScheme` objects that match specific request parameters and
    determine the behavior for re-sending each request.

    :param list scheme_design: [optional] A list of :py:class:`dict` objects, each of which prescribes the retry
        behavior for a combination of the HTTP method, API endpoint, and HTTP status code. Leave this blank to use
        the DEFAULT_SCHEME_DESIGN automatically (see below).
    :param int max_send_attempts: [optional] The maximum number of attempts for any particular send request. Cannot be
        exceeded by any individual RetryScheme. Defaults to 5, and cannot exceed 10.
    :param float fixed_delay: [optional] Override the default 1-second delay for RetrySchemes that will use a fixed
        delay before retries.
    :param callable logging_callback: [optional] Callback function to use for logging when the retry policy is
        applied. The four required arguments map to the ``request``, the specific ``exception`` (usually but not always
        an instance of :py:class:`~radarclient.exceptions.UnsuccessfulResponseException`), the Retry ``scheme``
        matching the request, and the intended ``delay`` (in seconds).
    :param bool retry_transient_networking_errors: [optional] ``True`` will also retry after transient networking
        errors in the intermediate python layers, up to ``max_send_attempts`` times. Defaults to ``True``.

    The RetryPolicy behavior will attempt to retry any send request failures that result in an
    :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` that match any of the designed RetrySchemes by
    pausing for either a fixed amount of time, or utilizing an exponential backoff, or even retry without `any` delay,
    up to the prescribed number of times (``max_send_attempts``). For multithreaded implementations, the retry behavior
    is per-thread.

    If ``retry_transient_networking_errors`` is ``True``, the RetryPolicy will also attempt to catch networking errors
    in the intermediate python layers (``ConnectionError`` from ``builtins``, ``socket``, ``urllib``, ``ssl``,
    ``http.client``, etc.) and retry them, without delay, up to ``max_send_attempts`` times. These kinds of errors are
    typically indicative of problems between the local host and the Radar API, and usually temporary.

    If/when the maximum number of attempts are tried without success, the library will return an instance of
    :py:class:`~radarclient.exceptions.MaximumSendAttemptsExceededException` or
    :py:class:`~radarclient.exceptions.NetworkErrorMaximumAttemptsExceededException` (for transient networking errors),
    depending on which kind of failure was encountered for the final attempt.

    Users can opt in to the RetryPolicy class and behavior by configuring it on their
    :py:class:`~radarclient.client.RadarClient` instance.

    A set of pre-configured retry schemes is provided by default, but you can use your own if desired.

    To see the available/pre-built :py:class:`RetryScheme` objects for a RadarClient object:

    Example::

        radar_client = RadarClient(
            authentication_strategy,
            system_identifier,
            retry_policy=radarclient.RetryPolicy()
        )
        for scheme in radar_client.retry_policy.schemes:
            print(scheme)

    A retry scheme design for the ``schemes`` :py:class:`list` is built like this:

    Example::

        retry_policy_design = [
            {
                'methods': [
                    'GET'
                ],
                'endpoints': [
                    'problems'
                ],
                'status_codes': [
                    429
                ],
                'delay_type': RetryPolicy.DELAY_TYPE_EXPONENTIAL_BACKOFF,
                'max_send_attempts': 5
            }
        ]
        radar_client = RadarClient(
            authentication_strategy,
            system_identifier,
            retry_policy=radarclient.RetryPolicy(scheme_design=retry_policy_design)
        )

    .. note::
        Leave the ``endpoints`` list empty to match `all` endpoints in combination with the provided ``methods``
        and ``status_codes``.

    A retry policy can optionally specify a logging callback that is invoked when the policy is applied:

    Example::

        def retry_callback(request, exception, scheme, delay):
            print(f'Radar API returned {exception.code}. Retrying {request.method} {request.url()} after {scheme.delay_type} {delay}')

        radar_client = RadarClient(
            authentication_strategy,
            system_identifier,
            retry_policy=radarclient.RetryPolicy(logging_callback=retry_callback)
        )

    """
    DELAY_TYPE_EXPONENTIAL_BACKOFF = 'exponential backoff delay'
    DELAY_TYPE_FIXED = 'fixed delay'
    DELAY_TYPE_NONE = 'no delay'
    # This regex specifically allows certain "xxxx/find" endpoints in addition to the normal single-phrase endpoints
    ENDPOINT_REGEX = r'.*apple.com/((?:problems|keywords|groups|people|components|component-bundles|component-bundle-groups|scheduled-tests|test-suites|query|label-sets)/find$|[\w-]+(?=/?.*$))'
    ABSOLUTE_MAX_ATTEMPTS = 10

    DEFAULT_SCHEME_DESIGN = [
        {
            'methods': [
                'GET'
            ],
            'endpoints': [],
            'status_codes': [
                429     # Too Many Attempts
            ],
            'delay_type': DELAY_TYPE_EXPONENTIAL_BACKOFF,
            'max_send_attempts': 5
        },
        {
            'methods': [
                'GET'
            ],
            'endpoints': [],
            'status_codes': [
                401,    # Unauthorized
                500,    # Internal Server Error
                502,    # Bad Gateway
                503,    # Service Unavailable
                504     # Gateway Timeout
            ],
            'delay_type': DELAY_TYPE_FIXED,
            'max_send_attempts': 3
        },
        {
            'methods': [
                'POST'
            ],
            'endpoints': [
                'component-bundle-groups/find',
                'component-bundles/find',
                'components/find',
                'groups/find',
                'keywords/find',
                'label-sets/find',
                'people/find',
                'problems/find',
                'query/find',
                'scheduled-tests/find',
                'test-suites/find',
                'tests',
                'jobs'
            ],
            'status_codes': [
                429     # Too Many Attempts
            ],
            'delay_type': DELAY_TYPE_EXPONENTIAL_BACKOFF,
            'max_send_attempts': 5
        },
        {
            'methods': [
                'POST'
            ],
            'endpoints': [
                'component-bundle-groups/find',
                'component-bundles/find',
                'components/find',
                'groups/find',
                'keywords/find',
                'people/find',
                'problems/find',
                'scheduled-tests/find',
                'test-suites/find',
                'tests'
            ],
            'status_codes': [
                401,    # Unauthorized
                500,    # Internal Server Error
                502,    # Bad Gateway
                503,    # Service Unavailable
                504     # Gateway Timeout
            ],
            'delay_type': DELAY_TYPE_FIXED,
            'max_send_attempts': 3
        },
        {
            'methods': [
                'PUT'
            ],
            'endpoints': [
                'reorder',
                'tests'
            ],
            'status_codes': [
                429     # Too Many Attempts
            ],
            'delay_type': DELAY_TYPE_EXPONENTIAL_BACKOFF,
            'max_send_attempts': 5
        },
        {
            'methods': [
                'GET'
            ],
            'endpoints': [
                'jobs'
            ],
            'status_codes': [
                403
            ],
            'delay_type': DELAY_TYPE_FIXED,
            'max_send_attempts': 5
        }
    ]

    def __init__(self, scheme_design=None, max_send_attempts=5, fixed_delay=1.0, logging_callback=None,
                 retry_transient_networking_errors=True):
        all_schemes = scheme_design or RetryPolicy.DEFAULT_SCHEME_DESIGN
        assert all_schemes
        # Ensure that the max_send_attempts will always fall between 1-10
        self.max_send_attempts = min(max(1, max_send_attempts), RetryPolicy.ABSOLUTE_MAX_ATTEMPTS)
        self.schemes = self._build_retry_schemes(all_schemes)
        self.fixed_delay = fixed_delay
        self.logging_callback = logging_callback
        self.retry_transient_networking_errors = retry_transient_networking_errors

    def _build_retry_schemes(self, all_schemes):
        retry_schemes = {}
        for scheme in all_schemes:
            delay_type = scheme['delay_type']
            max_send_attempts = min(scheme['max_send_attempts'], self.max_send_attempts)
            for method in scheme['methods']:
                endpoints = scheme.get('endpoints') or ['*']
                for endpoint in endpoints:
                    for status_code in scheme['status_codes']:
                        key = (method, endpoint, status_code)
                        retry_schemes[key] = RetryScheme(method, endpoint, status_code, delay_type, max_send_attempts)
        return retry_schemes

    def _strip_endpoint(self, full_url):
        return re.match(self.ENDPOINT_REGEX, full_url).group(1)

    def _get_retry_scheme(self, method, endpoint, status_code):
        key = (method, endpoint, status_code)
        scheme = self.schemes.get(key)
        if not scheme:
            scheme = self.schemes.get((method, '*', status_code), RetryScheme())
        return scheme

    def _get_delay(self, delay_type, attempt_count):
        # time.sleep() takes a float for the number of seconds
        if delay_type == RetryPolicy.DELAY_TYPE_EXPONENTIAL_BACKOFF:
            # pseudo-exponential backoff with a randomized base interval
            return (randrange(350, 600) / 1000.0) * 2 ** attempt_count
        elif delay_type == RetryPolicy.DELAY_TYPE_FIXED:
            return self.fixed_delay
        elif delay_type is None or delay_type == RetryPolicy.DELAY_TYPE_NONE:
            return 0.0

    def __repr__(self):
        repr = u'<RetryPolicy with {} RetryScheme instances, max_send_attempts={}'.format(
            len(self.schemes),
            self.max_send_attempts
        )
        if self.retry_transient_networking_errors:
            repr += ", and retries for transient networking errors"
        return u'{}>'.format(repr)


class RetryScheme(object):
    """
    A scheme for prescribing the automatic retry behavior for
    :py:class:`~radarclient.exceptions.UnsuccessfulResponseException` failures matching a specific combination of
    HTTP method, Radar API endpoint, and HTTP status (error) code received in the response.

    :param str method: The HTTP method, ie. ``GET``, ``POST``, ``PUT``, etc.
    :param str endpoint: The Radar API endpoint, ie. ``problems``, ``components``, ``query``, etc. A ``*`` indicates it
        will match any endpoint.
    :param int status_code: The HTTP response status (error) code, ie. 401, 404, 429, 500, etc.
    :param str delay_type: The delay behavior to use for each retry attempt. See more below.
    :param int max_send_attempts: The maximum number of times to attempt the send request.

    The available **delay_type** options are:

    - ``RetryPolicy.DELAY_TYPE_EXPONENTIAL_BACKOFF``, an exponential backoff with a random base delay interval between \
    350-600ms
    - ``RetryPolicy.DELAY_TYPE_FIXED``, a fixed delay interval (specified when setting up the RetryPolicy class, \
    defaults to 1.0 sec)
    - ``RetryPolicy.DELAY_TYPE_NONE``

    See more info at :py:class:`RetryPolicy`.
    """

    def __init__(self, method=None, endpoint=None, status_code=None, delay_type=None, max_send_attempts=1):
        self.method = method
        self.endpoint = endpoint
        self.status_code = status_code
        self.delay_type = delay_type
        self.max_send_attempts = max_send_attempts

    def __eq__(self, other):
        if type(self) == type(other) and vars(self) == vars(other):
            return True
        return False

    def __repr__(self):
        return u'<RetryScheme for {} /{} & error {}, up to {} attempts>'.format(
            self.method,
            self.endpoint,
            self.status_code,
            self.max_send_attempts
        )
