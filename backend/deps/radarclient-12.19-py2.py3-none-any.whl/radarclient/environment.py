#!/usr/bin/env python

# autopep8 -i --ignore E501 githelper.py

from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

import json
import os

from .utilities import logger


class RadarEnvironment(object):
    """
    Provides configuration values for different Radar environments (production or UAT/Test).

    You supply instances of this class to the AuthenticationStrategy constructors.

    Example::

        environment_identifier = 'production'
        environment = RadarEnvironment(environment_identifier)
        strategy = AuthenticationStrategyAppleConnect(radar_environment=environment)
        client = RadarClient(strategy, ClientSystemIdentifier('MyApp', '1.0'))

    """

    required_keys = ['webservice_url', 'appid_key', 'authweb_login_url', 'authweb_login_url_2', 'web_cookie_environment', 'kerberos_realm']
    cached_default_environment = None

    well_known_configurations = {
        'production': {
            'webservice_url': 'https://radar-webservices.apple.com',
#            'webservice_url': 'https://radar-webservices-alt.apple.com',
            'appid_key': '77e2a60d4bdfa6b7311c854a56505800be3c24e3a27a670098ff61b69fc5214b',
            'authweb_login_url': 'https://idmsac.corp.apple.com/IDMSWebAuth/classicLogin',
            'authweb_login_url_2': 'https://idmsac.corp.apple.com/IDMSWebAuth',
            'web_cookie_environment': 'acack',
            'kerberos_realm': 'APPLECONNECT.APPLE.COM',
            'idms_app_to_app_generate_token_api_url': 'https://idmsac.corp.apple.com/auth/apptoapp/token/generate',
            'rws_user_signoff_api_url': 'https://radar-webservices.apple.com/signoff',
            'idms_oauth_token_api_url': 'https://idmsac.apple.com/auth/oauth2/token',
            'idms_mtls_actor_authorize_endpoint': 'https://idmsac-api.apple.com/service/actor/authorize',
            'oauth_client_id': '41rih2rtlg4zyax6eztzug6ftnhkun',
            'oauth_resource': 'https://radar-webservices.apple.com',
        },
        'production-non-vpn': {
            'webservice_url': 'https://radar-webservices.apple.com',
            'appid_key': '77e2a60d4bdfa6b7311c854a56505800be3c24e3a27a670098ff61b69fc5214b',
            'authweb_login_url': 'https://idmsac.apple.com/IDMSWebAuth/classicLogin',
            'authweb_login_url_2': 'https://idmsac.apple.com/IDMSWebAuth',
            'web_cookie_environment': 'acack',
            'kerberos_realm': 'APPLECONNECT.APPLE.COM',
            'idms_app_to_app_generate_token_api_url': 'https://idmsac.apple.com/auth/apptoapp/token/generate',
            'rws_user_signoff_api_url': 'https://radar-webservices.apple.com/signoff',
            'idms_oauth_token_api_url': 'https://idmsac.apple.com/auth/oauth2/token'
        },
        'uat': {
            'webservice_url': 'https://rws-sandbox.apple.com',
            'appid_key': '941af45c281a33ec74940b902831099457a002573da79a8faf7f58b9ed0a2f70',
            'authweb_login_url': 'https://idmsac-uat.corp.apple.com/IDMSWebAuth/classicLogin',
            'authweb_login_url_2': 'https://idmsac-uat.corp.apple.com/IDMSWebAuth',
            'web_cookie_environment': 'acack-uat',
            'kerberos_realm': 'APPLECONNECT-UAT.APPLE.COM',
            'idms_app_to_app_generate_token_api_url': 'https://idmsac-uat.corp.apple.com/auth/apptoapp/token/generate',
            'rws_user_signoff_api_url': 'https://rws-sandbox.apple.com/signoff',
            'idms_oauth_token_api_url': 'https://idmsac-uat.corp.apple.com/auth/oauth2/token'
        },
        'uat-alt': {
            'webservice_url': 'https://rdr-rws-test2.corp.apple.com',
            'appid_key': '941af45c281a33ec74940b902831099457a002573da79a8faf7f58b9ed0a2f70',
            'authweb_login_url': 'https://idmsac-uat.corp.apple.com/IDMSWebAuth/classicLogin',
            'authweb_login_url_2': 'https://idmsac-uat.corp.apple.com/IDMSWebAuth',
            'web_cookie_environment': 'acack-uat',
            'kerberos_realm': 'APPLECONNECT-UAT.APPLE.COM',
            'idms_app_to_app_generate_token_api_url': 'https://idmsac-uat.corp.apple.com/auth/apptoapp/token/generate',
            'idms_mtls_actor_authorize_endpoint': 'https://idmsac-uat-api.apple.com/service/actor/authorize',
            'rws_user_signoff_api_url': 'https://rdr-rws-test2.corp.apple.com/signoff',
            'idms_oauth_token_api_url': 'https://idmsac-uat.corp.apple.com/auth/oauth2/token',
            'oauth_client_id': 'hcjqu4f34vpvyxbbh1k26u1yqa1hdp',
            'oauth_resource': 'https://rdr-rws-test2.corp.apple.com',
        },
    }

    defaults = {
        'cookie_max_age_seconds': 600
    }

    def __init__(self, identifier_or_path):
        if identifier_or_path in self.well_known_configurations:
            self.configuration = self.well_known_configurations[identifier_or_path]
        elif os.path.exists(identifier_or_path):
            self.configuration = self.environment_configuration_from_json_file(identifier_or_path)
        else:
            raise Exception(u'Invalid environment identifier "{}", neither a well-known environment identifier nor a path that exists'.format(identifier_or_path))
        self.identifier = identifier_or_path

    def configuration_value(self, key):
        if key not in self.configuration and key not in self.defaults:
            raise Exception(u'Invalid configuration key "{}" (config identifier {})'.format(key, self.identifier))
        return self.configuration.get(key, self.defaults.get(key, None))

    @classmethod
    def environment_configuration_from_json_file(cls, path):
        with open(path, 'r') as f:
            configuration = json.load(f)
        missing_keys = set(cls.required_keys) - set(configuration.keys())
        if missing_keys:
            raise Exception(u'Invalid configuration in JSON file "{}", missing keys: {}'.format(path, ', '.join(missing_keys)))
        return configuration

    @classmethod
    def default_environment(cls):
        if not cls.cached_default_environment:
            key = 'RADARCLIENT_ENVIRONMENT_OVERRIDE_CONFIG_PATH'
            if key in os.environ:
                override_config_path = os.environ[key]
                logger.warning('Overriding default environment with values from configuration file {} (from environment variable {})'.format(override_config_path, key))
                cls.cached_default_environment = cls(override_config_path)
            else:
                cls.cached_default_environment = cls('production')
        return cls.cached_default_environment

__all__ = [
    "RadarEnvironment"
]