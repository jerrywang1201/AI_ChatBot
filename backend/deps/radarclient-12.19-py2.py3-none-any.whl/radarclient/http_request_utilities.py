"""
HTTP request related utilities, mostly shared between authenticationstrategy.py and client.py
"""
from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import
from sys import path_importer_cache

import json
import logging
import os
import ssl
import datetime
import platform
from .version import __version__ as library_version
from . import compat
from .exceptions import (
    ObjectNotFoundException, RadarAccessDeniedResponseException, UnsuccessfulResponseException,
)

logger = logging.getLogger('radarclient')
logger.addHandler(logging.NullHandler())

def exception_class_for_unsuccessful_http_response_code(status):
    if status == compat.http_FORBIDDEN:
        error_cls = RadarAccessDeniedResponseException
    elif status == compat.http_NOT_FOUND:
        error_cls = ObjectNotFoundException
    else:
        error_cls = UnsuccessfulResponseException

    return error_cls

def configure_request_user_agent_string_with_client_system_identifier(request, client_system_identifier=None, authentication_strategy=None):
    osx_version = platform.mac_ver()[0]
    os_version = 'OSX/{}'.format(osx_version) if osx_version else '{}/{}'.format(platform.system(), platform.release())
    user_agent_string = 'python-radarclient/{} ({}) {} Python/{} {}'.format(library_version, type(authentication_strategy).__name__, request.http_client_version_info(), platform.python_version(), os_version)
    if client_system_identifier:
        user_agent_string = client_system_identifier.user_agent_string() + ' ' + user_agent_string
    request.add_header('User-Agent', user_agent_string)

class AuthenticatedRequest(object):

    def __init__(self, authentication_strategy, url, data=None, method=None):
        self.authentication_strategy = authentication_strategy
        self._url = str(url)
        self.data = data
        self.method = str(method) if method else method
        self.is_file_download_request = False
        self.creation_timestamp = datetime.datetime.now()

    def url(self):
        return self._url

    def get_host(self):
        return compat.urllib_urlparse(self.url()).netloc

    def get_path(self):
        return compat.urllib_urlparse(self.url()).path

    def add_header(self, name, value):
        pass

    def _unittest_support_get_header(self, name):
        pass

    def http_client_version_info(self):
        pass

    def send(self):
        pass

    def effective_method_for_logging(self):
        if self.method:
            return self.method
        elif self.data:
            return 'POST'
        else:
            return 'GET'


class AuthenticatedResponse(object):

    def __init__(self, request):
        self.request = request
        self.response_data = None
        self.creation_timestamp = datetime.datetime.now()

    def header(self, name):
        pass

    def data(self):
        if self.response_data is None:
            data_file = self.file()
            if data_file is not None:
                self.response_data = data_file.read()
        return self.response_data

    def file(self):
        return None

    def status(self):
        pass

    def status_reason(self):
        return '(unknown error)'

    def is_success(self):
        return response_code_is_success(self.status())

    def duration(self):
        return (self.creation_timestamp - self.request.creation_timestamp).total_seconds()

    def check_response_code(self):
        status = self.status()
        is_put_or_post = self.request.method in ('PUT', 'POST')
        if not is_put_or_post and status in [compat.http_NOT_FOUND]:
            return
        if not self.is_success():
            extra_errors_info = ''
            message = self.status_reason()
            if self.header('Content-Type').startswith('application/json'):
                data = self.data()
                if data:
                    if isinstance(data, list) and len(data) > 0:
                        message = data[0].get('message', message)
                    elif isinstance(data, dict):
                        if 'messages' in data and isinstance(data['messages'], list):
                            message = '\n'.join(data['messages'])
                        elif 'message' in data:
                            message = data.get('message')
                        if 'errors' in data:
                            extra_errors_info = ' Errors: {}'.format(pprint.pformat(data['errors']))
            error_cls = exception_class_for_unsuccessful_http_response_code(status)
            raise error_cls(
                self.status(), message, 'Non-2xx/success response code {} for request path "{}": {}{}'.format(self.status(), self.request.get_path(), message, extra_errors_info))


class AuthenticatedResponseUrllib2(AuthenticatedResponse):

    def __init__(self, request, urllib_response, check_response_code=True):
        super(AuthenticatedResponseUrllib2, self).__init__(request)
        self.urllib_response = urllib_response

        self.response_data = None
        # Last and added to guard against <rdar://problem/66387707> /test-suites/reorder-case
        # endpoint sends invalid JSON response: "Success"
        if self.header('Content-Length') != "0" and not \
                request.is_file_download_request and not \
                compat.selector_for_request(self.request.request) == '/test-suites/reorder-case':
            if self.header('Content-Type').startswith('application/json'):
                response_raw_data = self.urllib_response.read()
                if len(response_raw_data) > 0:
                    self.response_data = self.decode_json_data(response_raw_data)

        if check_response_code:
            self.check_response_code()

        self.request.authentication_strategy.did_receive_response(self)

    def decode_json_data(self, json_data):
        try:
            response_data = compat.json_loads(json_data)
            return response_data
        except json.JSONDecodeError as e:
            raise Exception('Received invalid response that could not be decoded as JSON:\n{}'.format(json_data))
        except ValueError as e:
            if 'Invalid control character' in str(e):
                json_data = re.sub(r'([\x00-\x1f]+)', lambda x: '<invalid character ' + hex(ord(x.group(1))) + '>', json_data)
                raise Exception('Received invalid JSON response containing control characters. They are highlighted in the following dump as "<invalid character 0x??>":\n{}'.format(json_data))
            else:
                raise

    def file(self):
        return self.urllib_response

    def status(self):
        return self.urllib_response.getcode()

    def status_reason(self):
        if hasattr(self.urllib_response, 'reason'):
            return self.urllib_response.reason

    def header(self, name):
        return self.urllib_response.info().get(name, '')


class AuthenticatedRequestUrllib2(AuthenticatedRequest):

    proxy = os.environ.get('HTTPS_PROXY', None)
    if proxy:
        proxy_handler = compat.urllib_ProxyHandler({'https': proxy})
        opener = compat.urllib_build_opener(proxy_handler)
        compat.urllib_install_opener(opener)

    def __init__(self, authentication_strategy, url, data=None, method=None):
        # For Python 2, ensure the URL and method are in bytes, not unicode strings,
        # otherwise sending binary data will fail (see https://stackoverflow.com/questions/7993175/)
        url = str(url)
        if method:
            method = str(method)
        elif data:
            method = 'POST'
        else:
            method = 'GET'
        self.method = method

        super(AuthenticatedRequestUrllib2, self).__init__(authentication_strategy, url, data, method)
        self.request = compat.urllib_Request(url, data)
        self.request.get_method = lambda: method

    def add_header(self, name, value):
        # For Python 2, ensure request headers are all bytes, not unicode strings,
        # otherwise sending binary data will fail (see https://stackoverflow.com/questions/7993175/)
        self.request.add_header(str(name), str(value))

    def _unittest_support_get_header(self, name):
        return dict(self.request.header_items())[name]

    def http_client_version_info(self):
        return 'urllib/{}'.format(compat.urllib_version)

    def send(self, check_response_code=True):
        try:
            data = self.authentication_strategy.ca_cert_bundle_data()
            response = urlopen(self.request, data, timeout=self.authentication_strategy.request_timeout)
        except compat.urllib_HTTPError as e:
            response = e
        return AuthenticatedResponseUrllib2(self, response, check_response_code=check_response_code)


cached_ssl_context = None
def ssl_context(cadata):
    global cached_ssl_context
    if (not cached_ssl_context) and cadata:
        cached_ssl_context = ssl.create_default_context()
        cached_ssl_context.load_default_certs()
        cached_ssl_context.load_verify_locations(cadata=cadata)
        key = 'RADARCLIENT_ALLOW_INSECURE_TLS_CONNECTIONS'
        if os.environ.get(key, False):
            logger.warning('Disabling TLS certificate validation because {} environment variable is set'.format(key))
            cached_ssl_context.check_hostname = False
            cached_ssl_context.verify_mode = ssl.CERT_NONE
    return cached_ssl_context


def urlopen(url_or_request, cadata, timeout=None):
    return compat.urlopen(url_or_request, timeout=timeout, context=ssl_context(cadata))

def configure_request_for_json(request):
    request.add_header('Content-Type', 'application/json;charset=UTF-8')
    request.add_header('Accept', 'application/json;charset=UTF-8')

def response_code_is_success(code):
    """
    Check if a returned HTTP status code is a success

    :param int code: HTTP status code

    :return: ``True`` if success, ``False`` otherwise
    """
    return 200 <= int(code) < 300
