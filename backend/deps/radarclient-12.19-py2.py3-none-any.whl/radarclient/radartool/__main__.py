from . import radartool
import radarclient

system_identifier = radarclient.ClientSystemIdentifier('radartool', radarclient.__version__)
radartool.RadarToolCommandLineDriver.run(client_system_identifier=system_identifier, inherit_default_commands=True)
