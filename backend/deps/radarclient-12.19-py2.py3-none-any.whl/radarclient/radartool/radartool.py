#!/usr/bin/env python

"""

"""
from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import
import shutil

import radarclient
from radarclient import compat
import sys
import os
import abc
import argparse
import subprocess
import re
import csv
import contextlib
import email.mime.text
import email.header
import smtplib
import plistlib
import textwrap
import signal
import logging
import collections
import functools
import json
import threading
import warnings
import getpass
import shlex
import errno
import hashlib
import code
import readline # importing this triggers editing support in the InteractiveConsole used by the "interact" subcommand
import datetime
import copy
import time
from radarclient import http_request_utilities

try:
    from pathlib import Path
except:
    pass

warnings.simplefilter('always', DeprecationWarning)

try:
    email.Charset.add_charset('utf-8', email.Charset.QP, email.Charset.QP, 'utf-8')
except:
    pass

def send_mail(from_email, to_email, subject, body):
    msg = email.mime.text.MIMEText(body, 'html', 'UTF-8')
    msg['Subject'] = email.header.Header(subject, 'UTF-8')
    msg['From'] = email.header.Header(compat.unicode_string_type(from_email), 'UTF-8')
    msg['To'] = email.header.Header(compat.unicode_string_type(to_email), 'UTF-8')

    s = smtplib.SMTP('relay.apple.com')
    s.sendmail(from_email, re.split(r',\s*', to_email), msg.as_string())
    s.quit()


# TODO: remove when WebCookie is no longer available
class KeychainPassword(object):

    @classmethod
    def find_generic_username_and_password(cls, username=None, label=None):
        cmd = ['security', 'find-generic-password', '-g']
        if label:
            cmd.extend(['-l', label])
        if username:
            cmd.extend(['-a', username])
        return cls.run_security_command(cmd)

    @classmethod
    def run_security_command(cls, cmd):
        try:
            security_output = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        except:
            return None

        result = re.findall(r'password: (?:0x([A-Z0-9]+)\s+)?"(.*?)"$.*"acct"<blob>="(.*?)"$', security_output, re.DOTALL | re.MULTILINE)
        if not result:
            return None

        (hexpassword, password, username), = result
        if hexpassword:
            password = hexpassword.decode('hex').decode('utf-8')

        return username, password


class AbstractSubcommand(object):
    """
    A base class for custom subcommand plug-in classes.

    You can, but don't have to, derive from this class for
    your custom subcommand extension classes. It also documents
    the interface you are expected to implement in your class
    and it provides some convenience methods.

    :param argparse.Namespace arguments: The command-line options passed to your subcommand
                                         in the form of a namespace instance as returned by
                                         :py:meth:`argparse.ArgumentParser.parse_args`.

    """

    def __init__(self, arguments, radar_client):
        self.args = arguments
        self.radar_client = radar_client

        if sys.stdout.isatty():
            self.setup_terminal_resize_monitoring()

    def setup_terminal_resize_monitoring(self):
        self.update_terminal_column_count()
        if compat.PY2:
            # Under Python 2, the signal handler calls can cause url loading operations to fail
            return

        def terminal_resize_handler(signum, frame):
            self.update_terminal_column_count()

        signal.signal(signal.SIGWINCH, terminal_resize_handler)

    def update_terminal_column_count(self):
        if compat.PY2:
            self.terminal_column_count = 80
            return        
        self.terminal_column_count = shutil.get_terminal_size(fallback=(80, 24)).columns

    def default_progress_reporting_callback(self):
        def progress_callback(progress, loaded_count, total_count):
            if not loaded_count:
                print('Loading Radars...', file=sys.stderr)
            else:
                print('Loaded {} of {}, {:.0%} complete'.format(loaded_count, total_count, progress), file=sys.stderr)
        return progress_callback

    @classmethod
    def configure_argument_parser(cls, parser):
        """
        If you override this in your subclass, you can configure additional command line arguments
        for your subcommand's arguments parser.

        :param argparse.ArgumentParser parser: The argument parser that you can configure.

        """
        pass

    @classmethod
    def find_people_from_ids(cls, radar_list):
        """
        Returns two dictionaries - one with people and another with radar objects per person.

        (1) key - dsid. value - person object.
        (2) key - dsid. value - list of radar objects

        """

        people = {}
        radars_for_person = {}

        for radar in radar_list:
            dsid = radar.assignee.dsid
            people[dsid] = radar.assignee
            if dsid not in radars_for_person:
                radars_for_person[dsid] = [radar]
            else:
                radars_for_person[dsid].append(radar)

        return people, radars_for_person

    @classmethod
    def subcommand_name(cls):
        return '-'.join([i.lower() for i in re.findall(r'([A-Z][a-z]+)', re.sub(r'^Subcommand', '', cls.__name__))])

    @classmethod
    def radar_list_url(cls, radar_list):

        if not radar_list:
            return ""

        # for list of radar objects
        if type(radar_list[0]) == radarclient.model.Radar:
            id_accessor = lambda x: str(x.id)

        # for list of radar ids
        else:
            id_accessor = lambda x: str(x)

        radars = [id_accessor(x) for x in radar_list]

        return "rdar://problem/" + '&'.join(radars)

    @classmethod
    def prompt_for_confirmation(cls, message):
        if input('\n{} Enter "y" to confirm, anything else to cancel: '.format(message)).lower() == 'y':
            return True
        print('Canceling', file=sys.stderr)
        return False

    @classmethod
    def requires_python_3(cls):
        return False


Event = collections.namedtuple('Event', 'id, type, payload')


class EventSourceGenerator(object):

    def __init__(self, event_publisher):
        self.event_publisher = event_publisher
        self.running = True
        self.queue = collections.deque()
        self.queue_condition = threading.Condition()
        self.event_publisher.add_event_subscriber(self)

    def handle_event(self, event):
        self.queue_condition.acquire()
        self.queue.appendleft(event)
        self.queue_condition.notify()
        self.queue_condition.release()

    def __iter__(self):
        return self

    def __next__(self):
        if not self.running:
            raise StopIteration

        data = ''
        self.queue_condition.acquire()
        if len(self.queue):
            event = self.queue.pop()
            data = 'event: {}\ndata: {}\n\n'.format(event.type, json.dumps(event.payload))
        else:
            self.queue_condition.wait(5)
            if not len(self.queue):
                data = 'event: heartbeat\ndata: heartbeat\n\n'
        self.queue_condition.release()
        return data

    def close(self):
        self.running = False
        self.event_publisher.remove_event_subscriber(self)


class ANSIColor(object):

    red = '1'
    green = '2'
    yellow = '3'
    blue = '4'

    @classmethod
    @contextlib.contextmanager
    def terminal_color(cls, stdout_color=None, stderr_color=red):

        if stdout_color:
            sys.stdout.write(cls.start_sequence(stdout_color))
        if stderr_color:
            sys.stderr.write(cls.start_sequence(stderr_color))

        try:
            yield
        except:
            cls.clear()
            raise

        cls.clear()

    @classmethod
    def clear(cls):
        for stream in [sys.stdout, sys.stderr]:
            stream.write(cls.clear_sequence())

    @classmethod
    def start_sequence(cls, color=red):
        return "\x1b[3{0}m".format(color)

    @classmethod
    def clear_sequence(cls):
        return "\x1b[m"

    @classmethod
    def wrap(cls, value, color=red):
        return u'{}{}{}'.format(cls.start_sequence(color), value, cls.clear_sequence())


class SubcommandFindPerson(AbstractSubcommand):
    """Find Radar users"""

    def __call__(self):
        mapping = {i: radarclient.model.CamelCase.encode(i) for i in 'first_name last_name email dsid'.split()}
        find_args = {k: v for k, v in list({v: getattr(self.args, k) for k, v in list(mapping.items())}.items()) if v}
        find_args['includeExternal'] = self.args.include_external
        people = self.radar_client.find_people(**find_args)
        for person in people:
            print(person)

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('--first_name', help='The first name to search for')
        parser.add_argument('--last_name', help='The last name to search for')
        parser.add_argument('--email', help='The e-mail address to search for')
        parser.add_argument('--dsid', help='The DSID to search for')
        parser.add_argument('--include-external', action='store_true', help='Include external accounts (default is to return only Apple-internal accounts)')


class SubcommandInteract(AbstractSubcommand):
    """Drop into an interactive Python session with a prepared Radar client instance"""

    def __call__(self):
#        locals().update({'radarclient': radarclient, 'client': self.radar_client, 'radar_client': self.radar_client})
        console_locals = locals()
        console_locals.update({'radarclient': radarclient, 'client': self.radar_client, 'radar_client': self.radar_client})
        console = code.InteractiveConsole(locals=console_locals)
        console.push('import readline')
        console.push('import rlcompleter')
        console.push('readline.parse_and_bind("bind \'\t\' rl_complete")')
        console.interact(banner='Starting interactive Python console. A RadarClient instance is available as "client" and "radar_client"')


class SubcommandNotebook(AbstractSubcommand):
    """Launch a Jupyter notebook with a prepared Radar client instance"""

    def __call__(self):

        if not self.ensure_jupyter_installed():
            return 1

        if self.args.path:
            print(self.conda_path())
            return 0

        self.copy_current_radarclient_module_to_isolated_site_dir()

        subprocess_env = self.sanitized_subprocess_environment()

        if self.args.conda:
            conda_tool_path = self.conda_path() / 'bin/conda'
            cmd = [conda_tool_path.as_posix()] + self.args.extra_args
            print('Running "conda" utility with: "{}"'.format(' '.join(cmd)))
            subprocess.run(cmd, env=subprocess_env)
            return 0

        if self.args.jupyter:
            jupyter_path = self.jupyter_path()
            cmd = [jupyter_path.as_posix()] + self.args.extra_args
            print('Running "jupyter" utility with: "{}"'.format(' '.join(cmd)))
            subprocess.run(cmd, env=subprocess_env)
            return 0

        if self.args.update:
            cmd = self.conda_update_cmd()
            print('Updating conda with "{}"'.format(' '.join(cmd)))
            subprocess.run(cmd, env=subprocess_env)
            return 0

        notebook_parent_path = Path('~/Documents/radartool-notebook').expanduser()
        if self.args.extra_args:
            notebook_filename = Path(self.args.extra_args[0])
            if notebook_filename.suffix != '.ipynb':
                print('Notebook filename "{}" does not have the "ipynb" extension.'.format(notebook_filename), file=sys.stderr)
                return 1
            print(notebook_filename.as_posix())
            if '/' in notebook_filename.as_posix():
                notebook_parent_path = notebook_filename.parent
                notebook_filename = Path(notebook_filename.name)
        else:
            notebook_filename = Path('RadarClient.ipynb')

        notebook_parent_path = notebook_parent_path.resolve()
        notebook_parent_path.mkdir(parents=True, exist_ok=True)
        notebook_path = notebook_parent_path / notebook_filename
        if not notebook_path.exists():
            self.write_notebook_template_to_path(notebook_path)

        if self.args.vsc:
            cmd = ['code', os.fspath(notebook_path)]
            subprocess.check_call(cmd)
            return 0

        port = 8887

        cmd = [self.jupyter_path().as_posix(), 'lab', '--port', str(port), '--notebook-dir', notebook_parent_path.as_posix(), notebook_path.as_posix()]
        print('Running Jupyter Notebook with {}'.format(' '.join(cmd)))
        if self.args.verbose:
            print('Environment variables: %@', ' '.join(['='.join(item) for item in subprocess_env.items()]))
        result = subprocess.run(cmd, env=subprocess_env)
        if result.returncode:
            print('Unable to run jupyter notebook', file=sys.stderr)
            return 1

        return 0

    def radarclient_isolated_site_dir_path(self):
        return self.conda_path() / 'radarclient_isolated_copy_site_packages'

    def copy_current_radarclient_module_to_isolated_site_dir(self):
        # We want to make the specific version of radarclient from which the user
        # ran radartool available to the miniconda environment. We don't want to pick
        # up any other modules from that Python installation, so we copy over just
        # radarclient.
        time_start = datetime.datetime.now()
        radarclient_site_packages_path = self.radarclient_isolated_site_dir_path()
        if radarclient_site_packages_path.exists():
            shutil.rmtree(radarclient_site_packages_path)
        radarclient_site_packages_path.mkdir(exist_ok=True, parents=True)
        radarclient_site_packages_copy_path = radarclient_site_packages_path / 'radarclient'
        shutil.copytree(radarclient.__path__[0], radarclient_site_packages_copy_path, symlinks=True, ignore=shutil.ignore_patterns('radartool', '__pycache__', '*.pyc'))
        elapsed = (datetime.datetime.now() - time_start).total_seconds()
        if self.args.verbose:
            print('Copied radarclient from {} to {} in {}s'.format(radarclient.__path__[0], radarclient_site_packages_copy_path, elapsed))

    def sanitized_subprocess_environment(self):
        env = copy.copy(os.environ)
        if '__PYVENV_LAUNCHER__' in env:
            del env['__PYVENV_LAUNCHER__']
        if 'PYTHONPATH' not in env:
            env['PYTHONPATH'] = self.radarclient_isolated_site_dir_path().as_posix()
        return env

    def ensure_jupyter_installed(self):
        if not self.ensure_miniconda_installed():
            return False

        jupyter_path = self.jupyter_path()
        if jupyter_path.exists():
            return True

        conda_install_path = self.conda_path()
        print('Installing Jupyter Notebook into {}'.format(conda_install_path))
        conda_path = conda_install_path / 'bin/conda'
        packages_to_install = ['notebook', 'matplotlib', 'pandas', 'jupyterlab']
        cmd = [conda_path, 'install', '--yes', '--quiet', '-c', 'conda-forge'] + packages_to_install
        result = subprocess.run(cmd, env=self.sanitized_subprocess_environment())
        if result.returncode:
            print('Unable to install jupyter notebook, env = {}'.format(os.environ), file=sys.stderr)
            return False

        assert jupyter_path.exists()
        return True

    def jupyter_path(self):
        conda_install_path = self.conda_path()
        return conda_install_path / 'bin/jupyter'

    def current_arch(self):
        return subprocess.check_output(['arch'], universal_newlines=True).strip()

    def ensure_miniconda_installed(self):
        conda_install_path = self.conda_path()
        logging.debug('Verifying miniconda installation at {}'.format(conda_install_path))

        if conda_install_path.exists():
            logging.debug('Miniconda exists at {}'.format(conda_install_path))
            return True

        current_arch = self.current_arch()

        try:
            print('Would you like to perform the one-time installation of radartool\'s Jupyter environment now? It will be installed for architecture {} into:\n\n    {}\n\n(You can get this path again later with the --path option)\n'.format(current_arch, conda_install_path.as_posix()))
            prompt_input = input('Hit return to continue, Ctrl-C to cancel')
        except KeyboardInterrupt:
            print('\nCancelling radartool Jupyter Notebook installation', file=sys.stderr)
            return False

        # Installer base URL: https://repo.anaconda.com/miniconda/
        # Current "latest" versions and their hashes: https://docs.anaconda.com/free/miniconda/index.html#latest-miniconda-installer-links

        if current_arch == 'arm64':
            download_path = self.download_miniconda(
                # miniconda_installer_filename='Miniconda3-py38_4.10.1-MacOSX-arm64.sh',
                # miniconda_installer_expected_hash='4ce4047065f32e991edddbb63b3c7108e7f4534cfc1efafc332454a414deab58'
                # miniconda_installer_filename='Miniconda3-py39_4.12.0-MacOSX-arm64.sh',
                # miniconda_installer_expected_hash='4bd112168cc33f8a4a60d3ef7e72b52a85972d588cd065be803eb21d73b625ef'
                miniconda_installer_filename='Miniconda3-py312_24.1.2-0-MacOSX-arm64.sh',
                miniconda_installer_expected_hash='1c277b1ec046fd1b628390994e3fa3dbac0e364f44cd98b915daaa67a326c66a'
            )
        else:
            download_path = self.download_miniconda(
                # miniconda_installer_filename='Miniconda3-py38_4.8.3-MacOSX-x86_64.sh',
                # miniconda_installer_expected_hash='9b9a353fadab6aa82ac0337c367c23ef842f97868dcbb2ff25ec3aa463afc871'
                # miniconda_installer_filename='Miniconda3-py39_4.11.0-MacOSX-x86_64.sh',
                # miniconda_installer_expected_hash='7717253055e7c09339cd3d0815a0b1986b9138dcfcb8ec33b9733df32dd40eaa'
                # miniconda_installer_filename='Miniconda3-py38_4.12.0-MacOSX-x86_64.sh',
                # miniconda_installer_expected_hash='f930f5b1c85e509ebbf9f28e13c697a082581f21472dc5360c41905d10802c7b'
                miniconda_installer_filename='Miniconda3-py312_24.1.2-0-MacOSX-x86_64.sh',
                miniconda_installer_expected_hash='bc45a2ceea9341579532847cc9f29a9769d60f12e306bba7f0de6ad5acdd73e9'
            )

        if not download_path:
            return False

        cmd = ['sh', download_path.as_posix(), '-b', '-p', conda_install_path.as_posix()]
        print('Installing miniconda for architecture {} with "{}"'.format(current_arch, ' '.join(cmd)))
        result = subprocess.run(cmd)
        if result.returncode:
            print('Unable to install miniconda', file=sys.stderr)
            return False

        cmd = self.conda_update_cmd()
        print('Updating conda with "{}"'.format(' '.join(cmd)))
        subprocess.run(cmd, env=self.sanitized_subprocess_environment())

        return True

    def conda_update_cmd(self):
        conda_tool_path = self.conda_path() / 'bin/conda'
        return [conda_tool_path.as_posix(), 'update', '--all', '--yes']

    @classmethod
    def download_miniconda(cls, miniconda_installer_filename, miniconda_installer_expected_hash):
        miniconda_installer_url = 'https://repo.anaconda.com/miniconda/' + miniconda_installer_filename

        tmp_path = Path(os.environ['TMPDIR']).resolve()
        download_path = tmp_path / miniconda_installer_filename

        print('Downloading miniconda installer from {} to {}'.format(miniconda_installer_url, download_path))
        cmd = ['curl', '-o', download_path, miniconda_installer_url]
        result = subprocess.run(cmd)
        if result.returncode:
            print('Unable to download miniconda installer', file=sys.stderr)
            return None

        print('Verifying checksum of downloaded installer package {}'.format(download_path))
        file_hash = cls.hash_for_path(download_path)
        if file_hash != miniconda_installer_expected_hash:
            print('Miniconda installer hash mismatch: effective {}, expected {}'.format(file_hash, miniconda_installer_expected_hash), file=sys.stderr)
            return None

        return download_path

    @staticmethod
    def hash_for_path(path):
        m = hashlib.sha256()
        with open(path, 'rb') as f:
            while True:
                data = f.read(5 * 1024 * 1024)
                if data:
                    m.update(data)
                else:
                    break
        return m.hexdigest()

    def conda_path(self):
        cmd = ['getconf', 'DARWIN_USER_CACHE_DIR']
        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode == 0
        cache_dir_path = Path(result.stdout.strip())
        return cache_dir_path / 'radartool-jupyter-conda-{}'.format(self.current_arch())

    @staticmethod
    def write_notebook_template_to_path(path):
        if path.exists():
            return

        path.write_text(r"""            {
            "cells": [
            {
            "cell_type": "code",
            "execution_count": 7,
            "metadata": {},
            "outputs": [],
            "source": [
                "import radarclient\n",
                "\n",
                "system_identifier = radarclient.ClientSystemIdentifier('JupyterNotebookPythonRadarClient', '1.0')\n",
                "client = radar_client = radarclient.RadarClient(radarclient.AuthenticationStrategyAppleConnect(), system_identifier)"
            ]
            },
            {
            "cell_type": "code",
            "execution_count": null,
            "metadata": {},
            "outputs": [],
            "source": []
            }
            ],
            "metadata": {
            "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3"
            },
            "language_info": {
            "codemirror_mode": {
                "name": "ipython",
                "version": 3
            },
            "file_extension": ".py",
            "mimetype": "text/x-python",
            "name": "python",
            "nbconvert_exporter": "python",
            "pygments_lexer": "ipython3",
            "version": "3.8.3"
            }
            },
            "nbformat": 4,
            "nbformat_minor": 4
            }"""
        )

    @classmethod
    def requires_python_3(cls):
        return True

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('--path', action='store_true', help='Print the conda environment path instead of starting the notebook')
        parser.add_argument('--update', action='store_true', help='Run conda update instead of starting the notebook')
        parser.add_argument('--conda', action='store_true', help='Run the "conda" utility in the conda environment instead of starting the notebook. All remaining arguments are passed to the utility. Note that the first extra argument must be one its subcommand names, not an option starting with a dash.')
        parser.add_argument('--vsc', action='store_true', help='Open the notebook in Visual Studio Code instead of in the browser.')
        parser.add_argument('--jupyter', action='store_true', help='Run the "jupyter" utility in the conda environment instead of starting the notebook. All remaining arguments are passed to the utility. Note that the first extra argument must be one its subcommand names, not an option starting with a dash.')
        parser.add_argument('extra_args', nargs=argparse.REMAINDER, help='When you use no other options and just launch the notebook, this optional argument lets you pass the filename of the notebook to open. If you use the --conda option, then the arguments passed here are passed on to the "conda" utility.')


class SubcommandGetWebCookie(AbstractSubcommand):
    """Fetch and print a web cookie authentication token"""

    def __call__(self):
        authentication_strategy = self.radar_client.authentication_strategy
        if not isinstance(authentication_strategy, radarclient.client.AuthenticationStrategyWebCookie):
            print('You must use the web cookie authentication strategy for this subcommand. Try the --username option.', file=sys.stderr)
            return

        print(authentication_strategy.cookie_value)


def left_truncate_string_to_available_width_with_offset(string, available_width):
    if available_width < len(string):
        string = '...' + string[len(string) - available_width:]
    return string


def transfer_delegate_for_command(_subcommand, _label):

    should_print_progress = not _subcommand.args.no_progress

    # This is wrapped in a helper function because I could not figure out how to resolve the
    # circular imports caused by the superclass declaration when the class is at the toplevel
    class RadarToolEnclosureTransferDelegate(radarclient.model.RadarEnclosureTransferDelegate):

        def __init__(self, command, label):
            super(RadarToolEnclosureTransferDelegate, self).__init__()
            self.command = command
            self.label = label

        def policy_for_duplicate_upload(self, enclosure):
            if self.command.args.ignore_duplicates:
                if self.command.args.verbose:
                    print('Ignoring duplicate enclosure error for {}'.format(enclosure), file=sys.stderr)
                return self.DUPLICATE_POLICY_IGNORE
            else:
                return super(RadarToolEnclosureTransferDelegate, self).policy_for_duplicate_upload(enclosure)

        def did_start_transfer(self, enclosure):
            pass
#             if should_print_progress
#                 self.progress(0, None, self.label)

        def update_transfer_progress(self, enclosure, bytes_read, bytes_total):
            if should_print_progress:
                self.progress(bytes_read, bytes_total, self.label)

        def did_end_transfer(self, enclosure, status):
            if should_print_progress:
                print('\r')

        @staticmethod
        def progress(bytes_read, bytes_total, status=''):
            indeterminate = bytes_total is None
            formatted_read = '{:>6.2f}MB'.format(bytes_read / (1024 * 1024))

            if indeterminate:
                compat.write_unicode_string_to_file(sys.stdout, u'{} | {}\r'.format(formatted_read, status))
            else:
                bar_len = 40
                bar_and_bytes_len = bar_len + 18
                available_status_len = (_subcommand.terminal_column_count - 1) - bar_and_bytes_len
                status = left_truncate_string_to_available_width_with_offset(status, available_status_len)
                if bytes_total:
                    filled_len = int(round(bytes_read / float(bytes_total) * bar_len))
                    percent = '{:.1f}%'.format(round(100.0 * bytes_read / float(bytes_total), 1))
                else:
                    filled_len = bar_len
                    percent = '{:.1f}%'.format(100)
                label_len = len(percent)
                bar = '=' * filled_len + '-' * (bar_len - filled_len)
                label_start = (bar_len - label_len) // 2
                bar = bar[0:label_start] + percent + bar[label_start + label_len:]
                compat.write_unicode_string_to_file(sys.stdout, u'\033[2K[{}] {} {}\r'.format(bar, formatted_read, status))
            sys.stdout.flush()

    return RadarToolEnclosureTransferDelegate(_subcommand, _label)


class RadarFindingSubcommand(AbstractSubcommand):

    def __call__(self):
        if self.args.shared_report or self.args.query:
            if self.args.shared_report:
                print('The --shared-report option is deprecated, please switch to --query', file=sys.stderr)
                self.args.query = self.args.shared_report
            radars = self.execute_query()
        else:
            find_args = self.parse_find_args()
            if not find_args:
                raise Exception('No find criteria given')
            if self.args.verbose:
                print('Query: {}'.format(json.dumps(find_args)), file=sys.stderr)

            progress_callback = None if self.args.quiet else self.default_progress_reporting_callback()
            if self.should_find_count_only():
                count = self.radar_client.find_radar_count(find_args)
                self.process_radar_count(count)
                return
            else:
                radars = self.radar_client.find_radars(find_args, batch_size=self.args.batch_size, progress_callback=progress_callback, additional_fields=self.additional_radar_fields(), limit=self.args.limit)

        self.process_radars(radars)

    def should_find_count_only(self):
        return False

    def additional_radar_ids_from_options(self):
        return []

    def process_radars(self, radars):
        raise NotImplementedError()

    def process_radar_count(self, radar_count):
        raise NotImplementedError()

    def execute_query(self):
        all_radars = []
        needs_by_id_request = not self.additional_radar_fields_supported_by_radars_for_query()
        for report_id in self.args.query:
            if needs_by_id_request:
                radar_ids = self.radar_client.radar_ids_for_query(report_id, limit=self.args.limit)
                radars = self.radar_client.radars_for_ids(radar_ids, additional_fields=self.additional_radar_fields())
            else:
                radars = self.radar_client.radars_for_query(report_id, self.additional_radar_fields(), limit=self.args.limit)
            all_radars.extend(radars)
        return all_radars

    def additional_radar_fields(self):
        return []

    def additional_radar_fields_supported_by_radars_for_query(self):
        return True

    def parse_find_args(self):
        find_args = {}

        if self.args.raw_query_json:
            try:
                find_args = json.loads(self.args.raw_query_json)
            except ValueError as e:
                print('Unable to parse JSON: {}'.format(e), file=sys.stderr)
                sys.exit(1)
            return find_args

        def make_component_queries(component_args, include_subs=False):
            components = []
            for name, version in component_args:
                if name.startswith('like:'):
                    name = {'like': name[5:]}
                if version.startswith('like:'):
                    version = {'like': version[5:]}
                components.append({'name': name, 'version': version, 'includeSubcomponents': include_subs})
            return components

        components = []
        if self.args.component:
            components.extend(make_component_queries(self.args.component))

        if self.args.component_tree:
            components.extend(make_component_queries(self.args.component_tree, include_subs=True))

        if len(components) == 1:
            find_args['component'] = components[0]
        elif len(components) > 1:
            find_args['component'] = {'any': components}

        if self.args.component_bundle:
            bundles = []
            for bundle_name in self.args.component_bundle:
                bundles.append({'name': bundle_name})
            if len(bundles) == 1:
                find_args['componentBundle'] = bundles[0]
            elif len(components) > 1:
                find_args['componentBundle'] = {'any': bundles}

        def person_value_transform(value):
            if value == 'me':
                my_person_id = self.radar_client.current_user().dsid
                return my_person_id
            elif "@" in value:
                return self.radar_client.find_people(False, email=value)[0].dsid
            else:
                return int(value)

        if self.args.assignee:
            find_args['assignee'] = self.parse_operators(self.args.assignee, 'eq neq any none', value_transform=person_value_transform)
        elif self.args.assignee_directs:
            find_args['assignee'] = {"directReportOf": self.parse_operators(self.args.assignee_directs, 'eq neq any none', value_transform=person_value_transform)}
        elif self.args.assignee_org:
            find_args['assignee'] = {"organizationOf": self.parse_operators(self.args.assignee_org, 'eq neq any none', value_transform=person_value_transform)}

        if self.args.originator:
            find_args['originator'] = self.parse_operators(self.args.originator, 'eq neq any none', value_transform=person_value_transform)
        elif self.args.originator_directs:
            find_args['originator'] = {"directReportOf": self.parse_operators(self.args.originator_directs, 'eq neq any none', value_transform=person_value_transform)}
        elif self.args.originator_org:
            find_args['originator'] = {"organizationOf": self.parse_operators(self.args.originator_org, 'eq neq any none', value_transform=person_value_transform)}

        if self.args.state:
            find_args['state'] = self.parse_operators(self.args.state, valid_values='Analyze Integrate Build Verify Closed'.split())

        if self.args.substate:
            find_args['substate'] = self.parse_operators(self.args.substate, valid_values='Screen Investigate Fix Review Prepare Nominate'.split())

        if self.args.keyword:
            find_args['keyword'] = []
            for keyword in self.args.keyword.split(','):
                if re.match(r'\d+$', keyword):
                    keyword = int(keyword)
                find_args['keyword'].append(keyword)
        elif self.args.keyword_contains:
            find_args['keyword'] = {
                'like': '%{}%'.format(self.args.keyword_contains)
            }

        self.parse_id_args(find_args)

        if self.args.last_modified_at:
            for value in self.args.last_modified_at:
                self.set_or_combine_operator_value('lastModifiedAt', value, find_args)

        if self.args.created_at:
            for value in self.args.created_at:
                self.set_or_combine_operator_value('createdAt', value, find_args)

        if self.args.order_by:
            order_by = [{'field': field, 'order': order} for field, order in self.args.order_by]
            find_args['orderBy'] = order_by

        return find_args

    def parse_id_args(self, find_args):
        if self.args.clipboard:
            print('--clipboard is deprecated, please switch to --ids-from-clipboard', file=sys.stderr)
            setattr(self.args, 'ids_from_clipboard', self.args.clipboard)

        ids = []
        if self.args.id:
            ids = self.radar_ids_from_text(self.args.id, '--id option value')

        if self.args.ids_from_clipboard:
            ids = self.radar_ids_from_text(subprocess.check_output(['pbpaste']), 'clipboard contents')

        if self.args.ids_from_stdin:
            ids = self.radar_ids_from_text(sys.stdin.read(), 'stdin contents')

        additional_radar_ids_from_options = self.additional_radar_ids_from_options()
        if additional_radar_ids_from_options:
            ids.extend(additional_radar_ids_from_options)

        if not ids:
            return

        ids = [int(i) for i in ids]

        if 'id' not in find_args:
            find_args['id'] = {'any': ids}
        else:
            find_args['id']['any'].extend(ids)

    @staticmethod
    def radar_ids_from_text(text, source_label):
        ids = radarclient.RadarClient.extract_radar_ids_from_text(text)
        if not ids:
            print('No Radar IDs found in {}'.format(source_label), file=sys.stderr)
            sys.exit(1)

        return ids

    @staticmethod
    def update_find_args_with_ids_from_text(find_args, text, source_label):
        ids = radarclient.RadarClient.extract_radar_ids_from_text(text)
        if not ids:
            print('No Radar IDs found in {}'.format(source_label), file=sys.stderr)
            sys.exit(1)

        if 'id' not in find_args:
            find_args['id'] = {'any': ids}
        else:
            find_args['id']['any'].extend(ids)

    def set_or_combine_operator_value(self, property_name, raw_value, find_args):
        value = self.parse_operators(raw_value)
        if property_name in find_args:
            existing_value = find_args[property_name]
            if isinstance(value, dict) and isinstance(existing_value, dict) and not (value.keys() == existing_value.keys()):
                existing_value.update(value)
            else:
                raise Exception('Multiple incompatible values for {}: {}/{}'.format(property_name, value, existing_value))
        else:
            find_args[property_name] = value

    def parse_operators(self, value, valid_operators=None, valid_values=None, value_transform=lambda x: x):
        if not valid_operators:
            valid_operators = 'eq neq gt gte lt lte any none'

        valid_operators = valid_operators.split()
        regex = r'^(?:({}):)?(.+)'.format('|'.join(valid_operators))
        match = re.findall(regex, value)[0]
        operator, value = match

        if operator in ['any', 'none']:
            values = re.split(r'\s*,\s*', value)
            self.validate_value_with_choices(values, valid_values)
            return {operator: list(map(value_transform, values))}

        self.validate_value_with_choices(value, valid_values)
        value = value_transform(value)
        return {operator: value} if operator else value

    def validate_value_with_choices(self, value, valid_values):
        if not valid_values:
            return

        if isinstance(value, list):
            invalid_values = set(value) - set(valid_values)
            if not invalid_values:
                return
            raise Exception('Invalid values: {}'.format(', '.join(invalid_values)))

        if value not in valid_values:
            raise Exception('Invalid value: {}'.format(value))

    @classmethod
    def configure_argument_parser_radar_find_options(cls, parser):

        def integer_argument_range_checker(min, max):
            def checker(string):
                value = int(string)
                if value >= min and value <= max:
                    return value
                raise argparse.ArgumentTypeError('value must be between {} and {}, inclusive'.format(min, max))
            return checker

        query_options_group = parser.add_argument_group('Query options')
        query_options_group.add_argument('--id', help='Find by Radar ID. The tool will try to find one or more Radar numbers in whatever string you pass, for example out of a multi-problem Radar URL.')
        query_options_group.add_argument('--ids-from-stdin', action='store_true', help='Find by Radar IDs contained in the text piped into stdin')
        query_options_group.add_argument('--ids-from-clipboard', action='store_true', help='Find by Radar IDs contained in the text of the current clipboard contents')
        query_options_group.add_argument('--clipboard', action='store_true', help='Deprecated. Please switch to --ids-from-clipboard')
        query_options_group.add_argument('--state', help='Find by state')
        query_options_group.add_argument('--substate', help='Find by substate')
        query_options_group.add_argument('--last-modified-at', action='append', help='Find by last modified date')
        query_options_group.add_argument('--created-at', action='append', help='Find by creation date')
        query_options_group.add_argument('--component', nargs=2, action='append', help='Find Radars in the given component. Takes two arguments, the component name and version. Can be passed multiple times.')
        query_options_group.add_argument('--component-bundle', action='append', help='Find Radars in the given component bundle. Takes one argument, the component bundle name. Can be passed multiple times.')
        query_options_group.add_argument('--component-tree', nargs=2, action='append', help='Find Radars in the given component and its subcomponents. Takes two arguments, the component name and version. Can be passed multiple times.')
        query_options_group.add_argument('--shared-report', action='append', type=int, help='Deprecated, please use --query instead')
        query_options_group.add_argument('--query', action='append', type=int, help='Find Radars by executing a query. Takes one argument, the numeric query ID. Can be passed multiple times. If you use this option, all other find criteria options are ignored.')

        group = query_options_group.add_mutually_exclusive_group()
        group.add_argument('--originator', help='Find by originator DSID or e-mail address')
        group.add_argument('--originator-directs', help='Find by originator\'s manager\'s DSID or e-mail address')
        group.add_argument('--originator-org', help='Find by originator org\'s manager\'s DSID or e-mail address')
        group.add_argument('--assignee', help='Find by assignee DSID or e-mail address')
        group.add_argument('--assignee-directs', help='Find by assignee\'s manager\'s DSID or e-mail address')
        group.add_argument('--assignee-org', help='Find by assignee org\'s manager\'s DSID or e-mail address')

        group = query_options_group.add_mutually_exclusive_group()
        group.add_argument('--keyword', help='Find by one or more keywords (strings or IDs). Separate multiple keywords with commas, no spaces. Radars with all keywords will be returned.')
        group.add_argument('--keyword-contains', help='Find by keyword substring')

        raw_query_option_group = parser.add_argument_group('Raw Queries')
        raw_query_option_group.add_argument('--raw-query-json', help='Find Radars by passing a raw query JSON string as documented at https://radar.apple.com/developer/api/documentation/latest/problem-apis#find-problems. When you use this option, radartool ignores all other query options listed in the previous section.')

        operational_options_group = parser.add_argument_group('Operational Options')
        operational_options_group.add_argument('--limit', type=int, help='Limit to a given number of results')
        operational_options_group.add_argument('--batch-size', type=integer_argument_range_checker(1, radarclient.RadarClient.max_radar_batch_size), default=int(os.environ.get('RADARTOOL_BATCH_SIZE', '10')), help='Query batch size')

        output_options_group = parser.add_argument_group('Output/Display Options')
        output_options_group.add_argument('--order-by', nargs=2, action='append', metavar=('FIELD', 'ORDER'), help='Server-side ordering of results (as opposed to client-side sorting). Takes two arguments, the field name and "ascending" or "descending". Can be passed up to three times.')
        output_options_group.add_argument('--quiet', '-q', action='store_true', default=False, help='Do not print progress output')


class EnclosureDownloadSubcommand(RadarFindingSubcommand):

    __metaclass__ = abc.ABCMeta

    @staticmethod
    @abc.abstractmethod
    def enclosure_collection_for_radar(radar):
        raise NotImplementedError()

    @staticmethod
    @abc.abstractmethod
    def label():
        raise NotImplementedError()

    def additional_radar_ids_from_options(self):
        radar_ids_to_analyze = []
        for text in self.args.radar_id:
            radar_ids = radarclient.RadarClient.extract_radar_ids_from_text(text)
            radar_ids_to_analyze.extend(radar_ids)
        return radar_ids_to_analyze

    def additional_radar_fields(self):
        return ['attachments', 'pictures']

    def additional_radar_fields_supported_by_radars_for_query(self):
        return False

    def process_radars(self, radars_to_analyze):
        logging.debug('Downloading enclosures for radars: {}'.format(radars_to_analyze))
        for radar in radars_to_analyze:
            if hasattr(self.args, 'archive') and self.args.archive:
                self.download_attachments_archive(radar)
            else:
                self.download_enclosures(radar)

    def download_enclosures(self, radar):
        enclosures = list(self.enclosure_collection_for_radar(radar).items())
        if not enclosures:
            print('Radar {} does not have any {}s'.format(radar.id, self.label()), file=sys.stderr)
            return

        if self.args.downloads:
            output_dir_name = os.path.expanduser(radarclient.RadarGUI.attachment_download_cache_parent_directory_path())
            output_dir_name += '/{}'.format(radar.id)
        elif self.args.downloads_folder:
            output_dir_name = os.path.expanduser(radarclient.RadarGUI.attachment_save_to_downloads_folder_path())
        elif self.args.download_directory_path:
            output_dir_name = self.args.download_directory_path.replace('{radar_id}', str(radar.id))
            if not os.path.exists(output_dir_name):
                os.makedirs(output_dir_name)
        else:
            output_dir_name = '{}-{}s'.format(radar.id, self.label())


        class AncestorDirectoryMtimeUpdater(object):

            def __init__(self, prefix):
                self.ancestor_directory_mtimes = {}
                self.prefix = prefix

            def record_time_for_ancestors_of_path(self, path, modTime):
                ancestor_relative_path = os.path.dirname(path)
                while ancestor_relative_path:
                    if ancestor_relative_path not in self.ancestor_directory_mtimes or modTime > self.ancestor_directory_mtimes[ancestor_relative_path]:
                        self.ancestor_directory_mtimes[ancestor_relative_path] = modTime
                    ancestor_relative_path = os.path.dirname(ancestor_relative_path)

            def apply_mtime_updates(self):
                for ancestor_relative_path, modTime in self.ancestor_directory_mtimes.items():
                    ancestor_output_dir_path = os.path.join(self.prefix, ancestor_relative_path)
                    logging.debug('setting mtime {} for file ancestor direcotry {}'.format(modTime, ancestor_output_dir_path))
                    os.utime(ancestor_output_dir_path, (modTime, modTime))


        ancestor_directory_mtime_updater = AncestorDirectoryMtimeUpdater(output_dir_name)
        for enclosure in enclosures:
            if not self.should_download_enclosure_with_filename(enclosure.fileName):
                continue

            if not os.path.exists(output_dir_name):
                os.makedirs(output_dir_name)

            output_path = os.path.join(output_dir_name, enclosure.fileName)
            output_basedir = os.path.dirname(output_path)
            if not os.path.exists(output_basedir):
                os.makedirs(output_basedir)

            enclosure.transfer_delegate = transfer_delegate_for_command(self, output_path)

            try:
                existing_size = 0
                if os.path.exists(output_path):
                    existing_size = os.stat(output_path).st_size
                    if existing_size == enclosure.fileSize:
                        if not self.args.no_progress:
                            skip_message = u'Skipping already fully downloaded file:     '
                            output_path = left_truncate_string_to_available_width_with_offset(output_path, (self.terminal_column_count - 1) - len(skip_message) - 8)
                            compat.print_unicode_string(u'{} {}'.format(skip_message, output_path))
                        continue
                    elif os.path.isdir(output_path):
                        output_path = self.replacement_path_for_path_with_file_vs_directory_conflict(output_path)
                logging.debug('Attempting to write-open output path "{}" for {} named "{}" in output basedir "{}"'.format(output_path, self.label(), enclosure.fileName, output_basedir))

                try:
                    f = open(output_path, 'wb')
                except IOError as e:
                    if e.errno != errno.ENOTDIR:
                        raise
                    directory_path = os.path.dirname(output_path)
                    renamed_path = self.replacement_path_for_path_with_file_vs_directory_conflict(directory_path)
                    os.rename(directory_path, renamed_path)
                    os.mkdir(directory_path)
                    f = open(output_path, 'wb')
                try:
                    enclosure.write_to_file(f, continue_at=existing_size)
                except radarclient.UnsuccessfulResponseException as ure:
                    if ure.code == 400:
                        print('Radar {}: Attachment unavailable from server: {}'.format(radar.id, enclosure.fileName), file=sys.stderr)
                    else:
                        raise
                finally:
                    f.close()

                mod_or_create_date = enclosure.addedAt
                if hasattr(enclosure, 'lastModifiedAt'):
                    mod_or_create_date = enclosure.lastModifiedAt
                timetuple_localtime = mod_or_create_date.astimezone(radarclient.LocalTimeZone()).timetuple()
                modTime = time.mktime(timetuple_localtime)
                logging.debug('lastModifiedAt: {}, as local: {}, timetuple: {}, modTime: {}'.format(mod_or_create_date, mod_or_create_date.astimezone(radarclient.LocalTimeZone()), timetuple_localtime, modTime))
                os.utime(output_path, (modTime, modTime))
                ancestor_directory_mtime_updater.record_time_for_ancestors_of_path(enclosure.fileName, modTime)

            except KeyboardInterrupt as e:
                if not self.args.no_progress:
                    print('\n')
                raise e

        ancestor_directory_mtime_updater.apply_mtime_updates()

    @staticmethod
    def replacement_path_for_path_with_file_vs_directory_conflict(output_path):
        path, extension = os.path.splitext(output_path)
        return path + '.renamed_because_directory_with_same_name_exists' + extension

    def should_download_enclosure_with_filename(self, filename):
        if self.args.filter_rules:
            for rule in self.args.filter_rules:
                accept = bool(rule.accept(filename))
                logging.debug('filename: {}, rule: {}, accept: {}, exclude: {}'.format(filename, rule.regex.pattern, accept, rule.exclude))
                if accept:
                    return not rule.exclude
        return True

    def download_attachments_archive(self, radar):
        archive_enclosure = radar.attachment_archive_download_enclosure()
        archive_enclosure.transfer_delegate = transfer_delegate_for_command(self, archive_enclosure.fileName)
        with open(archive_enclosure.fileName, 'wb') as f:
            archive_enclosure.write_to_file(f)

    @classmethod
    def configure_argument_parser(cls, parser):
        cls.configure_argument_parser_radar_find_options(parser)
        parser.add_argument('radar_id', nargs='*', help='The ID(s) of the Radar whose {}s should be downloaded. Space separated ids or radar links.'.format(cls.label()))
        download_dir_option_group = parser.add_mutually_exclusive_group()
        download_dir_option_group.add_argument('--downloads', action='store_true', help='Download into the location that the Radar 8 GUI app uses when double-clicking on an attachment.')
        download_dir_option_group.add_argument('--downloads-folder', action='store_true', help='Download into the location that the Radar 8 GUI app uses when using the "Save to Downloads Folder" menu command')
        download_dir_option_group.add_argument('--download-directory-path', help='Download into the given directory. Occurrences of the token "{radar_id}" in the path will be replaced with the radar ID.')
        parser.add_argument('--no-progress', action='store_true', default=not sys.stdout.isatty(), help='Do not print a progress bar. This is set automatically if stdout is not a TTY.')

        class FilterRule(object):

            def __init__(self, regex, exclude):
                self.regex = re.compile(regex)
                self.exclude = exclude

            def accept(self, file_path):
                return self.regex.search(file_path)

        class FilterAppendAction(argparse.Action):

            def __init__(self, option_strings, dest, nargs=None, **kwargs):
                if nargs is not None:
                    raise ValueError("nargs not allowed")
                super(FilterAppendAction, self).__init__(option_strings, dest, **kwargs)

            def __call__(self, parser, namespace, values, option_string=None):
                # print('{} {} {}'.format(namespace, values, option_string))
                filter_rules = getattr(namespace, self.dest)
                if not filter_rules:
                    filter_rules = []
                    setattr(namespace, self.dest, filter_rules)
                filter_rules.append(FilterRule(values, 'exclude' in option_string))

        parser.add_argument('--include', action=FilterAppendAction, dest='filter_rules', help='Filter {} filenames using regular expressions. May be passed multiple times.'.format(cls.label()))
        parser.add_argument('--exclude', action=FilterAppendAction, dest='filter_rules', help='Filter {} filenames using regular expressions. May be passed multiple times.'.format(cls.label()))


class SubcommandDownloadAttachments(EnclosureDownloadSubcommand):
    """Download all attachments for a Radar"""

    @staticmethod
    def enclosure_collection_for_radar(radar):
        return radar.attachments

    @staticmethod
    def label():
        return 'attachment'

    @classmethod
    def configure_argument_parser(cls, parser):
        super(SubcommandDownloadAttachments, cls).configure_argument_parser(parser)
        parser.add_argument('--archive', action='store_true', help='Download all attachments as a .zip archive')


class SubcommandDownloadPictures(EnclosureDownloadSubcommand):
    """Download all pictures for a Radar"""

    @staticmethod
    def enclosure_collection_for_radar(radar):
        return radar.pictures

    @staticmethod
    def label():
        return 'picture'


class EnclosureUploadSubcommand(AbstractSubcommand):

    def __call__(self):
        radar_id = self.args.radar_id
        # We used to get a full radar instance by loading it by ID, but that fails
        # if the current user doesn't have access to the Radar. However, the server API
        # allows the originator to add more attachments even if the Radar is no longer
        # accessible. By not loading the Radar here and instead initializing it directly
        # with the ID and a dummy title we can support that use case.
        radar = radarclient.Radar({'id': radar_id, 'title': '(dummy title to satisfy constructor checks)'}, self.radar_client, ['id'])

        absolute_paths = []
        relative_paths = [compat.unicode_string_for_argument_string(path) for path in self.args.paths]
        for path in relative_paths:
            absolute_path = os.path.expanduser(path)
            if not os.path.exists(absolute_path):
                print('Path {} does not exist'.format(path), file=sys.stderr)
                return
            absolute_paths.append(absolute_path)

        for path in absolute_paths:
            self.add_enclosure(radar, path)

        try:
            radar.commit_changes()
        except KeyboardInterrupt as e:
            if not self.args.no_progress:
                print('\n')
            raise e

    def add_enclosure(self, radar, path):
        if not os.access(path, os.R_OK):
            raise IOError(errno.EACCES, os.strerror(errno.EACCES), path)
        enclosure = self.create_enclosure_for_radar(radar, os.path.basename(path))
        if self.args.overwrite_existing:
            enclosure.overwrite_existing_file = True
        enclosure.set_upload_file(open(path, 'rb'))

        enclosure.transfer_delegate = transfer_delegate_for_command(self, enclosure.fileName)
        collection = self.enclosure_collection_for_radar(radar)
        collection.add(enclosure)

    def create_enclosure_for_radar(self, radar, filename):
        raise NotImplementedError()

    def enclosure_collection_for_radar(self, radar):
        raise NotImplementedError()

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('--ignore-duplicates', action='store_true', help='The ID of the Radar to which an attachment should be added')
        parser.add_argument('--no-progress', action='store_true', default=not sys.stdout.isatty(), help='Do not print a progress bar. This is set automatically if stdout is not a TTY.')
        parser.add_argument('--overwrite-existing', action='store_true', help='Overwrite existing attachments with the same name')


class SubcommandUploadAttachment(EnclosureUploadSubcommand):
    """Upload an attachment to a Radar"""

    def create_enclosure_for_radar(self, radar, filename):
        return radar.new_attachment(filename)

    def enclosure_collection_for_radar(self, radar):
        return radar.attachments

    @classmethod
    def configure_argument_parser(cls, parser):
        super(SubcommandUploadAttachment, cls).configure_argument_parser(parser)
        parser.add_argument('radar_id', help='The ID of the Radar to which an attachment should be added')
        parser.add_argument('paths', nargs=argparse.REMAINDER, metavar='PATH', help='The path to the attachment file to be uploaded')


class SubcommandUploadPicture(EnclosureUploadSubcommand):
    """Upload a picture to a Radar"""

    def create_enclosure_for_radar(self, radar, filename):
        return radar.new_picture(filename)

    def enclosure_collection_for_radar(self, radar):
        return radar.pictures

    @classmethod
    def configure_argument_parser(cls, parser):
        super(SubcommandUploadPicture, cls).configure_argument_parser(parser)
        parser.add_argument('radar_id', help='The ID of the Radar to which a picture should be added')
        parser.add_argument('paths', nargs=argparse.REMAINDER, metavar='PATH', help='The path to the image file to be uploaded as picture')


class SubcommandRadarsForPersonId(AbstractSubcommand):
    """Find Radars assigned to a person identified by DSID or e-mail address"""

    def __call__(self):
        if "@" in self.args.dsid:
            find_args = {'assignee': self.radar_client.find_people(False, email=self.args.dsid)[0].dsid}
        else:
            find_args = {'assignee': int(self.args.dsid)}
        print(self.args)
        radars = self.radar_client.find_radars(find_args, progress_callback=self.default_progress_reporting_callback())
        for radar in radars:
            print(radar)

    @classmethod
    def configure_argument_parser(cls, parser):
        super(SubcommandRadarsForPersonId, cls).configure_argument_parser(parser)
        parser.add_argument('dsid', help='The assignee\'s DSID or e-mail address')


class SubcommandGitUpdate(AbstractSubcommand):
    """Updates Radars referenced in Git commit messages whose state is Analyze. Sets the Radar to Integrate/Software Changed and adds the Git commit hash to the diagnosis."""

    def __call__(self):
        if not self.check_valid_git_directory():
            return

        commits = self.git_commits()
        if not commits:
            return

        print('Checking for Radar IDs in {} commit(s):'.format(len(commits)))
        print('\n'.join([id[:10] for id in commits]))

        all_radar_ids = [id for data in list(commits.values()) for id in data['radar_ids']]
        radar_map = self.load_radars_for_ids(all_radar_ids)
        valid_radar_ids = set(radar_map.keys())
        current_branch = self.current_git_branch()

        radar_to_commit_map = collections.defaultdict(list)
        for commit_id, data in list(commits.items()):
            radar_ids = [x for x in data['radar_ids'] if x in valid_radar_ids]
            if not radar_ids:
                print('No Radar IDs found in commit message of {}'.format(commit_id), file=sys.stderr)
                continue

            for radar_id in radar_ids:
                if commit_id not in radar_to_commit_map[radar_id]:
                    radar_to_commit_map[radar_id].append(commit_id)

        if not radar_to_commit_map:
            return

        changed_radars = []
        for radar_id, commit_ids in list(radar_to_commit_map.items()):
            radar = radar_map[radar_id]
            commit_ids = [id[:10] for id in commit_ids]

            change_count = 0
            if radar.state == 'Analyze':
                if radar.milestone and radar.priority:
                    if not current_branch or current_branch == 'master':
                        print('{} radar:{} is in Analyze, changing to Integrate/Software Changed'.format('/'.join(commit_ids), radar.id))
                        radar.state = 'Integrate'
                        radar.resolution = 'Software Changed'
                        change_count += 1
                    elif radar.substate != 'Prepare':
                        print('{} radar:{} is in Analyze on non-master branch, changing substate to Prepare'.format('/'.join(commit_ids), radar.id))
                        radar.substate = 'Prepare'
                        radar.resolution = 'Software Changed'
                        change_count += 1
                else:
                    print('{} radar:{} is in Analyze but does not have milestone/priority set, unable to change state'.format('/'.join(commit_ids), radar.id), file=sys.stderr)
            else:
                print("{} radar:{} is not in Analyze, won't change state".format('/'.join(commit_ids), radar.id))

            diagnosis_items = radar.diagnosis.items(type='user')
            commit_ids_noted_in_diagnosis = [id for id in commit_ids for item in diagnosis_items if id in item.text]
            commit_ids_not_noted_in_diagnosis = [id for id in commit_ids if id not in commit_ids_noted_in_diagnosis]

            if commit_ids_not_noted_in_diagnosis:
                diagnosis_text = 'Fixed in {}'.format(', '.join(commit_ids_not_noted_in_diagnosis))
                if current_branch:
                    diagnosis_text += ' on {}'.format(current_branch)
                print('{} radar:{} Adding to diagnosis: "{}"'.format('/'.join(commit_ids), radar.id, diagnosis_text))
                entry = radarclient.model.DiagnosisEntry()
                entry.text = diagnosis_text
                radar.diagnosis.add(entry)
                change_count += 1
            else:
                print('{} radar:{} already has diagnosis entries referencing all commits, will not add another one'.format('/'.join(commit_ids), radar.id))

            if change_count:
                changed_radars.append(radar)

        if not changed_radars:
            return

        if not self.prompt_for_confirmation('Commit these changes?'):
            return

        for radar in changed_radars:
            print('Committing {}'.format(radar.id))
            radar.commit_changes()

    def check_valid_git_directory(self):
        try:
            git_root = subprocess.check_output(self.git_command(['rev-parse', '--show-toplevel']), stderr=subprocess.PIPE)  # noqa
        except:
            print("{} doesn't look like a git directory".format('That' if self.args.git_directory else 'This'))
            return False

        return True

    def current_git_branch(self):
        branch = None
        try:
            output = subprocess.check_output(self.git_command(['symbolic-ref', '-q', '--short', 'head']))
            branch = output.strip()
        except:
            pass
        return branch

    def git_command(self, args):
        cmd = ['git']
        if self.args.git_directory:
            cmd.extend(['-C', os.path.expanduser(self.args.git_directory)])
        cmd.extend(args)
        return cmd

    def git_commits(self):
        commits = collections.defaultdict(dict)

        if self.args.unpushed:
            output = subprocess.check_output(self.git_command(['rev-list', '@{u}..HEAD']), stderr=subprocess.PIPE)
            commit_ids = output.split()
            if not commit_ids:
                print('No unpushed commits found', file=sys.stderr)
                return None
        else:
            output = subprocess.check_output(self.git_command(['rev-list', '--no-walk'] + self.args.commits), stderr=subprocess.PIPE)
            commit_ids = output.split()

        for ref in commit_ids:
            try:
                output = subprocess.check_output(self.git_command(['show', '--no-patch', '--format=format:%H:%B', ref]), stderr=subprocess.PIPE)
            except:
                output = None
                pass

            if not output:
                print('Unknown reference "{}", skipping'.format(ref), file=sys.stderr)
                continue

            id, body = output.split(':', 1)

            radar_ids = radarclient.RadarClient.extract_radar_ids_from_text(body)
            if not radar_ids:
                print('No Radar IDs found in commit message of "{}", skipping'.format(ref), file=sys.stderr)
                continue

            commits[id]['radar_ids'] = radar_ids
        return commits

    def load_radars_for_ids(self, ids):
        return {str(radar.id): radar for radar in self.radar_client.radars_for_ids(ids)}

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('commits', nargs='*', default=['HEAD'], help='The git commits whose messages should be searched for Radar numbers. These arguments will be run through "git-rev-list --no-walk", see that man page for details. Defaults to HEAD.')
        parser.add_argument('-u', '--unpushed', action='store_true', help='Use the set of commits that are on HEAD but not yet pushed to the upstream branch.')
        parser.add_argument('-g', '--git-directory', help="Path to the Git working copy, this will be passed to git's -C option. Defaults to the current directory.")


class SubcommandFindRadars(RadarFindingSubcommand):
    """Find Radars matching search criteria"""

    def process_radars(self, radars):
        if self.args.sort:
            sort_properties = re.split(r'\s*,\s*', self.args.sort)

            def comparator(a, b):
                for property in sort_properties:
                    va = compat.unicode_string_type(getattr(a, property, None))
                    vb = compat.unicode_string_type(getattr(b, property, None))
                    order = (va > vb) - (va < vb)
                    if order:
                        return order
                return 0
            radars = sorted(radars, key=functools.cmp_to_key(comparator))
        if radars:
            formatted_output = self.format_radars(radars)
            # print(formatted_output)
            compat.print_unicode_string(formatted_output)

    def should_find_count_only(self):
        return self.args.count

    def process_radar_count(self, radar_count):
        print(radar_count)

    def format_radars(self, radars):
        if self.args.format == 'plist':
            return self.format_radars_plist(radars)
        elif self.args.format == 'json':
            return self.format_radars_json(radars)
        elif self.args.format == 'tab-separated':
            return self.format_radars_tab_separated(radars)
        elif self.args.url_list_group_by:
            return self.format_radars_url_list(radars)
        else:
            return self.format_radars_text(radars)

    def additional_radar_fields(self):
        return [i.split('.')[0] for i in self.properties()]

    def properties(self):
        properties = re.split(r'\s*,\s*', self.args.properties)
        if self.args.url_list_group_by:
            properties.append(self.args.url_list_group_by)
        return properties

    def format_radars_tab_separated(self, radars):
        result_string_file = compat.StringIO()
        csv_writer = csv.writer(result_string_file, 'excel-tab')

        properties = self.properties()
        if not self.args.no_header:
            csv_writer.writerow(properties)

        radar_data_list = self.radar_data(radars)
        for radar_data in radar_data_list:
            for property, value in list(radar_data.items()):
                if isinstance(value, list):
                    value = ','.join(value)
                else:
                    pass

                radar_data[property] = value  # rewrite value
            csv_writer.writerow([compat.file_output_representation_for_unicode_string(radar_data[key]) for key in properties])

        result_string = compat.unicode_string_for_stringio_value(result_string_file)
        result_string_file.close()
        return result_string

    def format_radars_text(self, radars):
        properties = self.properties()
        field_widths = {p: len(p) for p in properties}
        radar_data_list = self.radar_data(radars)
        for radar_data in radar_data_list:
            for property, value in list(radar_data.items()):
                if isinstance(value, list):
                    value = ','.join([compat.unicode_string_type(i) for i in value])
                else:
                    value = compat.unicode_string_type(value)
                radar_data[property] = value  # rewrite value
                field_widths[property] = max(field_widths[property], len(value))

        formatted_output = u''
        top_bottom_border = '+{}+'.format('+'.join(['-' * (field_widths[p] + 2) for p in properties]))
        formatted_output += top_bottom_border + '\n'
        formatted_output += u'|{}|'.format(u'|'.join([u' {} '.format(p + ' ' * (field_widths[p] - len(p))) for p in properties])) + '\n'
        formatted_output += top_bottom_border + '\n'
        for radar_data in radar_data_list:
            values = [(field_widths[p], compat.unicode_string_type(radar_data[p])) for p in properties]
            formatted_output += u'|{}|'.format(u'|'.join([u' {} '.format(v + ' ' * (width - len(v))) for width, v in values])) + '\n'
        formatted_output += top_bottom_border + '\n'

        return formatted_output

    def format_radars_plist(self, radars):
        return plistlib.writePlistToString(self.radar_data(radars))

    def format_radars_json(self, radars):
        return json.dumps(self.radar_data(radars), ensure_ascii=False, indent=1)

    def format_radars_url_list(self, radars):
        grouping_property_name = self.args.url_list_group_by
        groups = collections.defaultdict(list)
        for radar in radars:
            groups[getattr(radar, grouping_property_name)].append(radar)

        result = ''
        for grouping_item, radars in groups.items():
            header_value = self.url_list_group_header_for_property_value(grouping_property_name, grouping_item)
            result += '{}\n'.format(header_value)
            for radar in radars:
                result += 'rdar://{} ({})\n'.format(radar.id, radar.title)
            result += '\n'
        return result

    @staticmethod
    def url_list_group_header_for_property_value(grouping_property_name, value):
        if grouping_property_name == 'assignee':
            return '{} {}'.format(value.firstName, value.lastName)
        return value

    def radar_data(self, radars, none_value=''):
        properties = self.properties()
        data = []
        for radar in radars:
            data.append({})
            for key in properties:
                key_path = key.split('.')
                value = radar
                parent_value = None
                key_path_element = None
                while key_path:
                    key_path_element = key_path.pop(0)
                    parent_value = value
                    if isinstance(parent_value, dict):
                        value = parent_value[key_path_element]
                    else:
                        value = getattr(parent_value, key_path_element, '')
                    if callable(value):
                        value = value()
                if hasattr(parent_value, 'encode_user_friendly_property_value'):
                    value = parent_value.encode_user_friendly_property_value(key_path_element, value)
                if isinstance(value, list):
                    value = [compat.unicode_string_type(i) for i in value]
                elif value is None:
                    value = none_value
                elif key == 'id' and self.args.ids_as_urls:
                    value = 'rdar://problem/{}'.format(value)
                else:
                    value = compat.unicode_string_type(value)
                data[-1][key] = value
        return data

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.formatter_class = argparse.RawDescriptionHelpFormatter
        parser.description = """
            Find Radars by giving the search criteria as option arguments as documented below.

            Most options take an optional operator prefix, one of: eq ne lt lte gt gte none any.
            See the Radar web service documentation for details.

            Examples:

                radartool find-radars --properties id,lastModifiedAt,title --assignee 299156498 --state any:Analyze,Closed --last-modified-at gte:2014-01-09
                radartool find-radars --assignee 299156498 --keyword 'D2,2012 Macs'

        """.replace('            ', '')

        cls.configure_argument_parser_radar_find_options(parser)
        find_options_group = parser.add_argument_group('Options specific to the find-radars subcommand')

        format_options_group = find_options_group.add_mutually_exclusive_group()
        format_options_group.add_argument('--format', '-f', choices=['text', 'plist', 'json', 'tab-separated'], default=os.environ.get('RADARTOOL_FORMAT', 'text'), help='Optional output format choice, default is "text"')
        format_options_group.add_argument('--url-list-group-by', help='Format the output as a list of Radar URLs grouped by a property, e.g. assignee')

        find_options_group.add_argument('--ids-as-urls', action='store_true', help='Output Radar ID numbers as rdar URLs', default=bool(os.environ.get('RADARTOOL_IDS_AS_URLS', False)))
        find_options_group.add_argument('--no-header', action='store_true', help='For tab-separated output, suppress header row', default=bool(os.environ.get('RADARTOOL_NO_HEADER', False)))
        find_options_group.add_argument('--properties', '-p', default='id,title', help='Optional, comma-separated list of Radar properties to print')
        find_options_group.add_argument('--sort', help='Optional, comma-separated list of Radar properties to sort on')
        find_options_group.add_argument('--count', action='store_true', help='Print only the count of matched Radars')


class SubcommandChangeRadars(RadarFindingSubcommand):
    """Change Radars matching search criteria"""

    def process_radars(self, radars):
        self.change_radars(radars)

    def change_radars(self, radars):
        if not radars:
            return

        keyword_cache = {}

        def lookup_keyword(keyword_name_or_id):
            if keyword_name_or_id in keyword_cache:
                return keyword_cache[keyword_name_or_id]

            if re.match(r'^\d+$', keyword_name_or_id):
                keywords = self.radar_client.keywords_for_ids([int(keyword_name_or_id)])
            else:
                keywords = self.radar_client.keywords_for_name(keyword_name_or_id)

            if not keywords:
                raise Exception('No keyword found with name or ID "{}"'.format(keyword_name_or_id))
            if len(keywords) > 1:
                raise Exception('More than one keyword found with name "{}": {}. Please select by ID'.format(keyword_name_or_id, keywords))

            keyword_cache[keyword_name_or_id] = keywords[0]
            return keywords[0]

        for radar in radars:
            cmd = ['radartool', 'change-radars', '--id', str(radar.id)]

            if self.args.set_property:
                for property_change in self.args.set_property:
                    name, value = property_change
                    shell_cmd_value = value
                    if name == "assignee" and "@" in value:
                        # Perhaps assignee is e-mail address
                        value = str(self.radar_client.find_people(False, email=value)[0].dsid)
                    elif name == "category":
                        value = radarclient.model.Category({'name': value})
                    else:
                        shell_cmd_value = shlex.quote(value)
                        value = radar.decode_user_friendly_property_value(name, value)
                    cmd.extend(['-s', name, shell_cmd_value])
                    setattr(radar, name, value)

            if self.args.add_description:
                for description_entry_text in self.args.add_description:
                    cmd.extend(['-d', shlex.quote(description_entry_text)])
                    entry = radarclient.model.DescriptionEntry()
                    if description_entry_text == '-':
                        description_entry_text = sys.stdin.read()
                    entry.text = description_entry_text
                    radar.description.add(entry)

            if self.args.add_diagnosis:
                for diagnosis_entry_text in self.args.add_diagnosis:
                    cmd.extend(['-d', shlex.quote(diagnosis_entry_text)])
                    entry = radarclient.model.DiagnosisEntry()
                    if diagnosis_entry_text == '-':
                        diagnosis_entry_text = sys.stdin.read()
                    entry.text = diagnosis_entry_text
                    radar.diagnosis.add(entry)

            if self.args.add_keyword or self.args.remove_keyword:
                existing_keywords = radar.keywords()

                if self.args.add_keyword:
                    for keyword_name_or_id in self.args.add_keyword:
                        cmd.extend(['--add_keyword', shlex.quote(keyword_name_or_id)])
                        keyword = lookup_keyword(keyword_name_or_id)
                        if keyword not in existing_keywords:
                            radar.add_keyword(keyword)

                if self.args.remove_keyword:
                    for keyword_name_or_id in self.args.remove_keyword:
                        cmd.extend(['--remove_keyword', shlex.quote(keyword_name_or_id)])
                        keyword = lookup_keyword(keyword_name_or_id)
                        if keyword in existing_keywords:
                            radar.remove_keyword(keyword)

            cmd = ' '.join(cmd)
            print(cmd)
            if not (self.args.dry_run or self.args.confirm):
                radar.commit_changes()

        if self.args.dry_run:
            return

        if self.args.confirm and not self.prompt_for_confirmation('Commit these changes?'):
            return

        for radar in radars:
            radar.commit_changes()

    def additional_radar_fields(self):
        additional_fields = []
        if self.args.set_property:
            additional_fields.extend([name for name, _ in self.args.set_property])
        if additional_fields:
            return additional_fields
        return super(SubcommandChangeRadars, self).additional_radar_fields()

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.formatter_class = argparse.RawDescriptionHelpFormatter
        parser.description = """
            Change Radars by first finding them with the same options that the "find-radars"
            subcommand uses and then applying one or more changes.

            Examples:

                radartool change-radars --id 1234578,1234579 \
                --set_property state Integrate \
                --set_property resolution 'Software Changed' \
                --add_description 'Merged to master for integration in abcdef'

        """.replace('            ', '')

        cls.configure_argument_parser_radar_find_options(parser)
        change_options_group = parser.add_argument_group('Options specific to the change-radars subcommand')

        change_options_group.add_argument('--dry-run', '-n', action='store_true', help="Don't perform changes, just print what would be done")
        change_options_group.add_argument('--confirm', action='store_true', help="Show a confirmation prompt with the selected Radars before performing any modifications")
        change_options_group.add_argument('--set_property', '-s', nargs=2, action='append', metavar=('NAME', 'VALUE'), help='Set a Radar property to a given value. You can uses this option multiple times to set several properties.')
        change_options_group.add_argument('--add_description', action='append', metavar='MESSAGE', help='Append some text to the Radar description field. You can use this option multiple times to append multiple entries. You can use a single dash to indicate that the text should be read from stdin.')
        change_options_group.add_argument('--add_diagnosis', '-d', action='append', metavar='MESSAGE', help='Append some text to the Radar diagnosis field. You can use this option multiple times to append multiple entries. You can use a single dash to indicate that the text should be read from stdin.')
        change_options_group.add_argument('--add_keyword', action='append', metavar='KEYWORD', help='Add a keyword (by keyword ID or name). You can use this option multiple times to add multiple keywords.')
        change_options_group.add_argument('--remove_keyword', action='append', metavar='KEYWORD', help='Remove a keyword (by keyword ID or name). You can use this option multiple times to remove multiple keywords.')


class SubcommandCurrentUser(AbstractSubcommand):
    """Print the current username as returned by the Radar web API"""

    def __call__(self):
        print(self.radar_client.current_user())


class SubcommandCheckApiAccess(AbstractSubcommand):
    """Check if the current user has permissions for a given server-side API"""

    def __call__(self):
        requested_endpoints_info, unknown_items = self.requested_endpoints_info()
        if unknown_items:
            print('\033[0;31mUnable to find any API endpoints matching "{}"\033[0m'.format(', '.join(unknown_items)))
            if not requested_endpoints_info:
                return 1

        permissions_by_id = self.permissions_for_endpoint_ids([endpoint_info[0] for endpoint_info in requested_endpoints_info])

        print('Found the following API endpoints:')
        for identifier, name, method, uri_pattern in requested_endpoints_info:
            permission = permissions_by_id[identifier]
            status = permission['permission']['permission']
            ansi_color = 32 if status == 'ALLOW' else 31
            status = '\033[0;{}m{}\033[0m'.format(ansi_color, status)
            print('* {} ({}): {} {}: {}'.format(name, identifier, method, uri_pattern, status))

    def requested_endpoints_info(self):
        _, api_metadata = self.radar_client.build_and_send_json_request(('endpoints', 'compact'), None)

        unknown_items = []
        requested_endpoints_info = []
        for endpoint_name_or_query_path in self.args.endpoint_name_or_query_path:
            endpoint_name = None
            endpoint_uri_path = None

            match = re.match(r'^([A-Z]+[a-z0-9]+)+$', endpoint_name_or_query_path)
            if match:
                endpoint_name = match.group(0)
            else:
                endpoint_uri_path = endpoint_name_or_query_path

            current_item_endpoint_info = []

            for endpoint_family in api_metadata:
                for endpoint in endpoint_family['endpoints']:
                    name = endpoint['name']
                    identifier = endpoint['id']
                    method = endpoint['httpMethod']
                    uri_pattern = endpoint['uriPattern']

                    matching_endpoint_info = None

                    if endpoint_name:
                        if name == endpoint_name:
                            matching_endpoint_info = identifier, name, method, uri_pattern
                    elif endpoint_uri_path:
                        uri_method = None
                        endpoint_uri_path_for_match = copy.deepcopy(endpoint_uri_path)
                        uri_method_re = re.match(r'(GET|POST|PUT|DELETE)', endpoint_uri_path)
                        if uri_method_re:
                            uri_method = uri_method_re.group(0)
                            if method != uri_method:
                                continue
                            endpoint_uri_path_for_match = endpoint_uri_path_for_match.replace(uri_method + ' ', '')
                        uri_patterns = [uri for uri in uri_pattern.split(',')]
                        for pattern in uri_patterns:
                            uri_pattern_re = re.sub(r'\{[^}]+\}', r'[^/]+', pattern)
                            if re.match(uri_pattern_re + '$', endpoint_uri_path_for_match):
                                matching_endpoint_info = identifier, name, method, pattern

                    if matching_endpoint_info:
                        current_item_endpoint_info.append(matching_endpoint_info)

            if current_item_endpoint_info:
                requested_endpoints_info.extend(current_item_endpoint_info)
            else:
                unknown_items.append(endpoint_name_or_query_path)

        return requested_endpoints_info, unknown_items

    def permissions_for_endpoint_ids(self, endpoint_ids):
        my_dsid = self.radar_client.authentication_strategy.cached_radar_access_token.dsid
        query_data = {
            'endpointIds': endpoint_ids
        }
        _, access_data = self.radar_client.build_and_send_json_request(('entities', my_dsid, 'checkMyAccess'), query_data)
        permissions_by_id = {endpoint['endpoint']['id']: endpoint for endpoint in access_data['permissions']}
        return permissions_by_id

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('endpoint_name_or_query_path', nargs='+', help='The API endpoint(s) you want to check. You can either pass a URL path of the form "/query/2333724/execute" or an API endpoint name/label like "GetPreferenceByKeyspace". You can pass multiple values.')


class SubcommandRadarInfo(AbstractSubcommand):
    """Print a subset of the information for a given Radar ID"""

    def __call__(self):
        while True:
            self.radar_client.clear_radar_cache()
            self.args.repeat -= 1
            self.query_and_print()
            if not self.args.repeat > 0:
                break

    def query_and_print(self):
        radar = self.radar_client.radar_for_id(self.args.radar_id)
        radar_data = {
            'id': radar.id,
            'title': radar.title,
            'state': radar.state,
            'assignee': radar.assignee.email
        }
        if radar.substate:
            radar_data['substate'] = radar.substate

        output = ''
        if self.args.format == 'json':
            output = json.dumps(radar_data, indent=None)
        elif self.args.format == 'plist':
            output = plistlib.writePlistToString(radar_data)
        else:
            output = ''.join(['{}: {}\n'.format(k, v) for k, v in list(radar_data.items())])

        print(output)

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('radar_id', help='The Radar\'s ID')
        parser.add_argument('--format', '-f', choices=['text', 'json', 'plist'], default='text', help='Optional output format choice, default is "text"')
        parser.add_argument('--repeat', type=int, default=1, help='Optional repeat count, for testing purposes')


class SubcommandCloneRadar(AbstractSubcommand):
    """Clone a given Radar ID"""

    def __call__(self):
        comp = {'name': self.args.component, 'version': self.args.version}
        clone = self.radar_client.clone_radar(self.args.radar_id, self.args.reason, comp, self.args.current_originator)
        self.print_clone(clone)

    def print_clone(self, radar):
        radar_data = {
            'id': radar.id,
            'title': radar.title,
            'state': radar.state,
            'assignee': radar.assignee.email
        }
        if radar.substate:
            radar_data['substate'] = radar.substate

        output = ''
        if self.args.format == 'json':
            output = json.dumps(radar_data, indent=None)
        elif self.args.format == 'plist':
            output = plistlib.writePlistToString(radar_data)
        else:
            output = ''.join(['{}: {}\n'.format(k, v) for k, v in list(radar_data.items())])

        print(output)

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('radar_id', help='The ID of the original Radar')
        parser.add_argument('component', help='Target component')
        parser.add_argument('version', help='Target component version')
        parser.add_argument('reason', help='Description of the reason for cloning the Radar')
        parser.add_argument('--current_originator', '-o', type=bool, default=True, help='If true (the default), the current user will be set as the cloned Radar\'s originator. If false, the original Radar\'s originator is reused as the clone\'s originator.')
        parser.add_argument('--format', '-f', choices=['text', 'json', 'plist'], default='text', help='Optional output format choice, default is "text"')


class SubcommandCreateRadar(AbstractSubcommand):
    """Create a new Radar"""

    def __call__(self):
        new_radar_data = json.loads(self.args.raw_json)
        radar = self.radar_client.create_radar(new_radar_data)
        print(radar.id)

    @classmethod
    def configure_argument_parser(cls, parser):
        parser.add_argument('--raw-json', required=True, help='Create a Radar by passing a raw JSON document string as documented at https://radar.apple.com/developer/api/documentation/latest/problem-apis#create-problem. When you use this option, radartool ignores all other options listed in the previous section.')


class RadarToolCommandLineDriver(object):

    @classmethod
    def subcommand_map(cls, extension_namespaces=None, include_default_commands=False):
        if include_default_commands:
            namespaces = globals()
        else:
            namespaces = {}

        subcommand_map = {}
        if extension_namespaces:
            for ns in extension_namespaces:
                namespaces.update(ns)

        for k, v in list(namespaces.items()):
            if k.startswith('Subcommand') and callable(getattr(v, 'subcommand_name', None)):
                subcommand_map[v.subcommand_name()] = v

        return subcommand_map

    # TODO: remove when WebCookie is no longer available
    @classmethod
    def username_and_password(cls, args):
        username, password = args.username, args.password
        if username and password:
            return username, password
        elif username:
            password = getpass.getpass('AppleConnect Password:')
            return username, password

        result = KeychainPassword.find_generic_username_and_password(label='AppleConnect')
        if not (result):
            return None

        username, password = result
        return username, password

    @classmethod
    def resolve_subcommand_abbreviation(cls, subcommand_map):
        if len(sys.argv) < 2 or '--version' in [compat.unicode_string_for_argument_string(x) for x in sys.argv]:
            return True

        args = sys.argv[1:]

        subcommand = None
        index = 0
        while args and not subcommand:
            item = args.pop(0)
            index += 1
            if item in ['--username', '--password', '--spnego-username']:
                if args:
                    del(args[0])
                    index += 1
                continue
            if item in ['--spnego', '--version', '-v', '--verbose', '--python3', '-3']:
                continue
            subcommand = item

        if not subcommand:
            return False

        if subcommand in list(subcommand_map.keys()):
            return True

        # converts a string like 'abc' to a regex like '(a).*?(b).*?(c)'
        regex = re.compile('.*?'.join(['(' + char + ')' for char in subcommand]))
        subcommand_candidates = []
        for subcommand_name in list(subcommand_map.keys()):
            match = regex.match(subcommand_name)
            if not match:
                continue
            subcommand_candidates.append(cls.subcommand_candidate_for_abbreviation_match(subcommand_name, match))

        if not subcommand_candidates:
            return True

        if len(subcommand_candidates) == 1:
            print(subcommand_candidates[0].decorated_name, file=sys.stderr)
            sys.argv[index] = subcommand_candidates[0].name
            return True

        print('Ambiguous subcommand "{}": {}'.format(subcommand, ', '.join([i.decorated_name for i in subcommand_candidates])), file=sys.stderr)
        return False

    @classmethod
    def subcommand_candidate_for_abbreviation_match(cls, subcommand_name, match):
        SubcommandCandidate = collections.namedtuple('SubcommandCandidate', ['name', 'decorated_name'])
        decorated_name = ''
        span = None
        for i in range(1, match.lastindex + 1):
            span = match.span(i)
            preceding = subcommand_name[match.span(i - 1)[1]:span[0]] if span[0] else ''
            letter = subcommand_name[span[0]:span[1]]
            decorated_name += preceding + ANSIColor.wrap(letter, color=ANSIColor.green)
        trailing = subcommand_name[span[1]:]
        decorated_name += trailing
        return SubcommandCandidate(subcommand_name, decorated_name)

    @classmethod
    def authentication_strategy(cls, args):
        if args.uat:
            environment_identifier = 'uat'
        elif args.production_non_vpn:
            environment_identifier = 'production-non-vpn'
        else:
            environment_identifier = 'production'
        environment = radarclient.RadarEnvironment(environment_identifier)

        narrative_auth_strategy = cls.narrative_auth_strategy_from_args(args)
        if narrative_auth_strategy:
            return narrative_auth_strategy

        # TODO: remove when WebCookie is no longer available
        if args.username:
            # Explicitly asked for web cookie auth
            credentials = cls.username_and_password(args)
            if not credentials:
                return None
            username, password = credentials
            return radarclient.AuthenticationStrategyWebCookie(username, password, radar_environment=environment)

        accounts = radarclient.AppleDirectoryQuery.logged_in_appleconnect_accounts(radar_environment=environment)

        # TODO: remove when SPNego is no longer available
        spnego_available = radarclient.AuthenticationStrategySPNego.available()
        if args.spnego or args.spnego_username:
            # Explicitly asked for SPNego auth
            if not spnego_available:
                print("SPNego authentication requested but not available on this system", file=sys.stderr)
                return None
            if not accounts:
                print("SPNego authentication requested but there is no active AppleConnect session", file=sys.stderr)
                return None
            return cls.spnego_authentication_strategy(username=args.spnego_username, radar_environment=environment)

        appleconnect_available = radarclient.AuthenticationStrategyAppleConnect.available()
        if args.appleconnect or args.appleconnect_username:
            # Explicitly asked for AppleConnect auth
            if not appleconnect_available:
                print("AppleConnect authentication requested but not available on this system", file=sys.stderr)
                return None
            return cls.appleconnect_authentication_strategy(username=args.appleconnect_username, radar_environment=environment)

        if appleconnect_available:
            return cls.appleconnect_authentication_strategy(radar_environment=environment)

        # TODO: remove when WebCookie is no longer available
        credentials = cls.username_and_password(args)
        if credentials:
            username, password = credentials
            return radarclient.AuthenticationStrategyWebCookie(username, password, radar_environment=environment)

        print("*** Unable to get credentials to access Radar. Please use one of the authentication options to specify authentication parameters.", file=sys.stderr)
        if not appleconnect_available:
            print("Did not attempt SPNego authentication because it is not available on this system.", file=sys.stderr)

        return None

    @classmethod
    def narrative_auth_strategy_from_args(cls, args):
        if not args.narrative_actor_cert:
            return

        if not args.narrative_actor_key:
            print("--narrative-actor-cert also requires --narrative-actor-key", file=sys.stderr)
            sys.exit(1)
        
        cert_path = os.path.realpath(os.path.expanduser(args.narrative_actor_cert))
        key_path = os.path.realpath(os.path.expanduser(args.narrative_actor_key))

        return radarclient.AuthenticationStrategyNarrative(
            cert_dir='',
            cert_file_name=cert_path,
            key_file_name=key_path,
            client_id=args.narrative_client_id
        )

    # TODO: remove when SPNego is no longer available
    @classmethod
    def spnego_authentication_strategy(cls, username=None, radar_environment=None):
        return radarclient.AuthenticationStrategySPNego(username=username, radar_environment=radar_environment)

    @classmethod
    def appleconnect_authentication_strategy(cls, username='', radar_environment=None):
        return radarclient.AuthenticationStrategyAppleConnect(account=username, radar_environment=radar_environment)

    @staticmethod
    def print_version(should_exit=True):
        latest_version = '(unknown)'
        info_url = 'http://liyanage.apple.com/software/radarclient-python/index.html'
        try:
            response = http_request_utilities.urlopen(info_url, radarclient.AuthenticationStrategy().ca_cert_bundle_data())
            for line in response.read().splitlines():
                match = re.search(r'<title>.*radarclient ([\d\.]+) documentation</title>', line.decode('utf-8'))
                if not match:
                    continue
                latest_version = match.group(1)
                break
        except compat.urllib_URLError as e:
            print('Unable to get latest version from {}: {}'.format(info_url, e), file=sys.stderr)
        print('{}, latest version: {} (Python {}.{}.{} {})'.format(radarclient.__version__, latest_version, sys.version_info.major, sys.version_info.minor, sys.version_info.micro, sys.executable))
        if should_exit:
            sys.exit(0)

    @staticmethod
    def reexec_as_python3():
        if sys.version_info.major > 2:
            return
        returncode = -1
        try:
            returncode = subprocess.call(['python3', '-V'], stdout=subprocess.PIPE)
        except OSError:
            pass
        if returncode:
            print('Unable to find Python 3, which is required for the given options or subcommand', file=sys.stderr)
            sys.exit(1)
        exec_args = [arg for arg in [compat.unicode_string_for_argument_string(x) for x in sys.argv] if arg not in ['-3', '--python3']]
        cmd = ['python3'] + exec_args
        os.execvp('python3', cmd)

    @classmethod
    def run(cls, extension_namespaces=None, inherit_default_commands=False, client_system_identifier=None):
        should_reexec_as_python3 = ('--python3' in sys.argv or '-3' in sys.argv) and sys.version_info.major < 3
        if '--version' in sys.argv:
            cls.print_version(should_exit=not should_reexec_as_python3)

        if should_reexec_as_python3:
            cls.reexec_as_python3()

        subcommand_map = cls.subcommand_map(extension_namespaces=extension_namespaces, include_default_commands=inherit_default_commands)
        if not cls.resolve_subcommand_abbreviation(subcommand_map):
            sys.exit(1)
        description = textwrap.dedent("""\
            This utility provides a command line front end to some Radar operations.

            To use it, you'll have to authenticate to Radar with your AppleConnect credentials.
            There are four ways to do that:

            1.) By giving the --username and --password options
            2.) By giving just the --username option and letting the tool prompt you for the password
            3.) By having a Keychain entry named "AppleConnect" with your AppleConnect username and password
            4.) By being signed in to AppleConnect
            """)

        parser = argparse.ArgumentParser(description=description, formatter_class=argparse.RawDescriptionHelpFormatter)
        parser.add_argument('--version', action='store_true')
        parser.add_argument('--verbose', '-v', action='store_true', default=False, help='Print extra status and debugging output')
        parser.add_argument('--python3', '-3', action='store_true', default=False, help='Execute with Python 3')

        group = parser.add_mutually_exclusive_group()
        group.add_argument('--username', help='AppleConnect username')
        parser.add_argument('--password', help='AppleConnect password')
        group.add_argument('--spnego', action='store_true', help='Force SPNego authentication using the default Kerberos username')
        group.add_argument('--spnego-username', help='Force SPNego authentication using a specific Kerberos username')
        group.add_argument('--appleconnect', action='store_true', help='Force AppleConnect authentication using the currently logged in AppleConnect account')
        group.add_argument('--appleconnect-username', help='Force AppleConnect authentication using a specific username if multiple accounts are signed in')
        group.add_argument('--narrative-actor-cert', help='Use Narrative Actor Identity for authentication with this actor certificate path')
        parser.add_argument('--narrative-actor-key', help='Use Narrative Actor Identity for authentication with this private key path')
        parser.add_argument('--narrative-client-id', help='Optional OAuth Client ID to use for Narrative Actor Identity authentication')
        environment = parser.add_mutually_exclusive_group()
        environment.add_argument('--uat', action='store_true', help='Target the UAT environment instead of production')
        environment.add_argument('--production-non-vpn', dest='production_non_vpn', action='store_true', help='Target the non-VPN production environment')

        subparsers = parser.add_subparsers(title='Subcommands', dest='subcommand_name')
        for subcommand_name, subcommand_class in list(subcommand_map.items()):
            subparser = subparsers.add_parser(subcommand_name, help=subcommand_class.__doc__)
            subcommand_class.configure_argument_parser(subparser)

        args = parser.parse_args()
        subcommand_class = subcommand_map.get(args.subcommand_name)
        if not subcommand_class:
            # On Python 2 this is not reached because parse_args() already aborts
            # since subcommand_name is a mandatory argument. On Python 3, not
            # giving a subcommand name seems to make that method still return, with
            # args.subcommand_name set to None.
            parser.print_help()
            sys.exit(1)

        if subcommand_class.requires_python_3() and sys.version_info.major < 3:
            cls.reexec_as_python3()

        if args.verbose:
            logging.basicConfig(level=logging.DEBUG)
        else:
            logging.basicConfig()

        authentication_strategy = cls.authentication_strategy(args)
        if not authentication_strategy:
            print('Unable to determine authentication strategy', file=sys.stderr)
            sys.exit(1)

        client = radarclient.RadarClient(authentication_strategy, client_system_identifier=client_system_identifier, retry_policy=radarclient.RetryPolicy(), rate_limit_policy=radarclient.RateLimitPolicy())

        subcommand = subcommand_class(args, client)

        try:
            subcommand()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    system_identifier = radarclient.ClientSystemIdentifier(os.path.basename(sys.argv[0]), radarclient.__version__)
    RadarToolCommandLineDriver.run(client_system_identifier=system_identifier, inherit_default_commands=True)
