"""
This module is designed to help users build Radar Runner scripts that interact with the JSON RPC API as documented in
the `JSON RPC API Docs`_. The JSON RPC API and this module are both in **Beta**

.. note::
    This module only supports python3

**Best Practices for Writing Radar Runner Scripts with this Module**

**1. Log to a file at info level and have debug logging users can enable**

.. note::
    Logging at debug level may write sensitive information about radars to the log file and should be off by default

`Single Log File Example`::

    # Log anything you pass to logging and useful data from the module to the file

    import logging
    from pathlib import Path

    log_path = Path('~/Library/Logs/name_of_your_thing.log').expanduser()
    logging.basicConfig (
        filename=log_path,
        filemode='w',
        level=logging.INFO
    )


`Rotating Log File Example`::

    # Creates a new log file for each run of the script and stores 10 backups
    import logging
    from logging import handlers
    from pathlib import Path

    log_path = Path('~/Library/Logs/name_of_your_thing.log').expanduser()
    file_handler = handlers.RotatingFileHandler(log_path, backupCount=10)

    logging.basicConfig(
        level=logging.INFO,
        handlers=[file_handler]
    )

    file_handler.doRollover()

**2. Wrap the entire script in a try except block such as the below. This ensures you log needed exception information**

.. code-block:: python

    try:
        <your code here>
    except Exception ex:
        logging.exception(ex)
        raise ex

**3. Do not use the ``print`` method. It can cause problems  with radar reading from ``stdout``**
"""

from .exceptions import UnsuccessfulResponseException
from .authenticationstrategy import ClientSystemIdentifier
from .client import RadarClient, RetryPolicy, RateLimitPolicy, Relationship
from .model import Radar
from .utilities import logger
from typing import List
import sys
import pprint
import json
LOG = logger


def relationship_parser(radar_object, related_problems_data):
    LOG.debug('Using runner relationship parser')
    if related_problems_data is None:
        radar_object.loaded_relationships = None
    else:
        radar_object.loaded_relationships = []

        for relationship_info in related_problems_data:
            LOG.debug('\n{}'.format(pprint.pformat(relationship_info)))
            # The key for type seems to change depending on machine and possibly version of Radar. I can't investigate
            # now so this will support both
            relationship_type = relationship_info.get('type')
            if relationship_type is None:
                relationship_type = relationship_info['relationType']

            related_id = relationship_info.get('problem', {}).get('id')
            if related_id is None:
                related_id = relationship_info['problemID']
            relationship = Relationship(
                relationship_type,
                radar_object,
                related_radar_id=related_id
            )
            radar_object.loaded_relationships.append(relationship)


class RadarRunnerRPCException(UnsuccessfulResponseException):
    """
    Exception used when an error is returned from the JSON RPC API
    """
    def __init__(self, response_dict):
        error = response_dict['error']
        error_code = error['code']
        error_message = error['message']
        message = f'Request failed with code "{error_code}" and message "{error_message}"'
        super(RadarRunnerRPCException, self).__init__(error_code, error_message, message)


class RadarRunnerInvalidIDException(Exception):
    """
    Exception used when the response received from the JSON RPC API doesn't match the request ID
    """
    def __init__(self):
        super(RadarRunnerInvalidIDException, self).__init__('Response ID did not match expected')


class RadarRunnerRequest:
    """
    Base class representing a request to send to the JSON RPC API.
    """
    _valid_methods = {'findProblem', 'updateProblem', 'executeQuery', 'notify'}

    def __init__(self, json_rpc, method, request_id, request_data):
        """
        :param str json_rpc: JSON RPC version
        :param str method: Method to use for request
        :param int request_id: An int ID to use for the request
        :param dict request_data: The item that will be used as the value for the ``params`` key of the request
        """
        if method not in self._valid_methods:
            raise ValueError(f'{method} is not a valid JSONRPC method')
        self.json_rpc = json_rpc
        self.method = method
        self.request_data = request_data
        self.request_id = request_id
        self.response = None
        self.has_been_sent = False

    def _build_request_dict(self) -> dict:
        """
        Builds a request dictionary

        :return: dict for sending a request
        """
        return {
            'jsonrpc': self.json_rpc,
            'method': self.method,
            'params': self.request_data,
            'id': self.request_id
        }

    def send_request(self) -> None:
        """
        Builds the request and then sends the request out to the ``stdout``

        :return: None
        """
        LOG.info(f'Sending request with ID {self.request_id}')
        request = self._build_request_dict()
        LOG.debug(f'request = {pprint.pformat(request)}')
        sys.stdout.write(json.dumps(request))
        sys.stdout.write('\n')
        sys.stdout.flush()
        self.has_been_sent = True
        LOG.info(f'Sent request with ID {self.request_id}')

    def get_response(self) -> None:
        """
        Waits for the response to the request and saves it to ``self.response``

        :return: None
        """
        LOG.info(f'Getting response for request with ID {self.request_id}')
        self.response = json.loads(sys.stdin.readline())
        LOG.debug(f'response = {pprint.pformat(self.response)}')
        LOG.info(f'Got response for request with ID {self.request_id}')

    def process_response(self) -> None:
        """
        Processes a response. In this class just checks for errors but may have additional processing in child classes

        :return: None
        :raises: :py:class:`RadarRunnerInvalidIDException`, :py:class:`RadarRunnerRPCException`
        """
        LOG.info(f'Processing response for request with ID {self.request_id}')
        if self.response['id'] != self.request_id:
            # Don't raise if it is a parse error
            # rdar://99116942 (When Returning an Error from Runner, the Request ID is null)
            if self.response.get('error', {}).get('message') != 'Parse error':
                raise RadarRunnerInvalidIDException()
        if 'error' in self.response.keys():
            raise RadarRunnerRPCException(self.response)
        LOG.info(f'Done processing response for request with ID {self.request_id}')

    def send_and_wait_for_response(self) -> None:
        """
        Builds, sends, waits for, and then processes a JSON RPC API call

        :return: None
        :raises: :py:class:`RadarRunnerInvalidIDException`, :py:class:`RadarRunnerRPCException`
        """
        self.send_request()
        self.get_response()
        self.process_response()


class RadarRunnerRequestWithRadarReturn(RadarRunnerRequest):
    """
    JSON RPC request class that handles a list of returned radar data
    """
    def __init__(self, json_rpc, method, request_id, request_data, client):
        super().__init__(json_rpc, method, request_id, request_data)
        self.returned_radars = None
        self.client = client

    def process_response(self) -> None:
        """
        Checks for errors and converts all returned items in to :py:class:`~radarclient.model.Radar` objects which
        are saved at ``self.returned_radars``

        :return: None
        :raises: :py:class:`RadarRunnerInvalidIDException`, :py:class:`RadarRunnerRPCException`
        """
        super().process_response()
        self.returned_radars = []
        LOG.info('Processing returned radars')
        for radar in self.response['result']:
            LOG.debug(f'Processing {radar["id"]}')
            self.returned_radars.append(Radar(
                radar, self.client, [], relationship_parser=relationship_parser)
            )
        LOG.info('Done processing returned radars')


class RadarRunnerSession:
    """
    Used to track a Radar Runner session from start to finish. On creation, it reads in the passed in values from
    Radar via ``stdin`` and converts them to :py:class:`~radarclient.model.Radar` objects. Instantiating the session
    also creates a :py:class:`~radarclient.client.RadarClient` object with the attribute name ``client`` using the
    currently logged in AppleConnect session for authentication.
    """

    def __init__(self):
        input_dict = json.loads(sys.stdin.readline())
        self.method = input_dict['method']
        self.json_rpc = input_dict['jsonrpc']
        self._currentID = 1
        self.problems = None
        self.sys_id = ClientSystemIdentifier('RadarRunnerHelper', '1.0')
        self.client = RadarClient.radarclient_for_current_appleconnect_session(self.sys_id, retry_policy=RetryPolicy(), rate_limit_policy=RateLimitPolicy())

        LOG.info(f'method = "{self.method}"')
        if self.method == 'receiveProblemDetails':
            self.problems = []
            for problem in input_dict['params']['problems']:
                self.problems.append(
                    Radar(problem, self.client, problem.keys(), relationship_parser=relationship_parser)
                )

    def get_incremental_request_id(self) -> int:
        """
        Return the next int to use as a request ID

        :return: int to use as request ID
        """
        to_return = self._currentID
        self._currentID += 1
        return to_return

    def build_execute_query_request(self, query_id: int) -> RadarRunnerRequestWithRadarReturn:
        """
        Get a request that can be used against the `executeQuery` end point in the JSON RPC API

        :param int query_id: ID of the saved query to run

        :return: :py:class:`RadarRunnerRequestWithRadarReturn`

        Example::

            query_req = runner_session.build_execute_query_request(12345)
            query_req.send_and_wait_for_response()
            for radar in query_req.returned_radars:
                print(radar.title)

        """
        return RadarRunnerRequestWithRadarReturn(
            self.json_rpc,
            'executeQuery',
            self.get_incremental_request_id(),
            {'queryId': query_id},
            self.client
        )

    def build_get_problem_request_for_ids(self, radar_ids: List[int]) -> RadarRunnerRequestWithRadarReturn:
        """
        Builds a :py:class:`RadarRunnerRequestWithRadarReturn` for the ``findProblem`` endpoint of the JSON RPC API
        using a list of radar IDs

        :param list radar_ids: A list of int Radar IDs
        :return: :py:class:`RadarRunnerRequestWithRadarReturn`

        Example::

            query_req = runner_session.build_get_problem_request_for_ids([12345, 67890])
            query_req.send_and_wait_for_response()
            for radar in query_req.returned_radars:
                print(radar.title)

        """
        return RadarRunnerRequestWithRadarReturn(
            self.json_rpc,
            'findProblem',
            self.get_incremental_request_id(),
            {'problemId': radar_ids},
            self.client
        )

    def build_get_problem_request_for_id(self, radar_id: int) -> RadarRunnerRequestWithRadarReturn:
        """
        Builds a :py:class:`RadarRunnerRequestWithRadarReturn` for the ``findProblem`` endpoint of the JSON RPC API
        using a single radar ID

        :param list radar_id: A radar ID to get
        :return: :py:class:`RadarRunnerRequestWithRadarReturn`

        Example::

            query_req = runner_session.build_get_problem_request_for_id(12345)
            query_req.send_and_wait_for_response()
            for radar in query_req.returned_radars:
                print(radar.title)

        """
        return self.build_get_problem_request_for_ids([radar_id])

    def build_get_problem_request_for_radars(self, radars: List[Radar]) -> RadarRunnerRequestWithRadarReturn:
        """
        Builds a :py:class:`RadarRunnerRequestWithRadarReturn` for the ``findProblem`` endpoint of the JSON RPC API
        using a list of :py:class:`~radarclient.model.Radar` objects

        :param list radars: A list of :py:class:`~radarclient.model.Radar` objects to get
        :return: :py:class:`RadarRunnerRequestWithRadarReturn`

        Example::

            query_req = runner_session.build_get_problem_request_for_radars(list_of_radars)
            query_req.send_and_wait_for_response()
            for radar in query_req.returned_radars:
                print(radar.title)

        """
        return self.build_get_problem_request_for_ids([radar.id for radar in radars])

    def build_get_problem_request_for_radar(self, radar: Radar) -> RadarRunnerRequestWithRadarReturn:
        """
        Builds a :py:class:`RadarRunnerRequestWithRadarReturn` for the ``findProblem`` endpoint of the JSON RPC API
        using a :py:class:`~radarclient.model.Radar` object

        :param Radar radar: A :py:class:`~radarclient.model.Radar` object to get
        :return: :py:class:`RadarRunnerRequestWithRadarReturn`

        Example::

            query_req = runner_session.build_get_problem_request_for_radar(radar_object)
            query_req.send_and_wait_for_response()
            for radar in query_req.returned_radars:
                print(radar.title)

        """
        return self.build_get_problem_request_for_ids([radar.id])

    def build_problem_update_request(self, radar_id: int, request_dict: dict) -> RadarRunnerRequest:
        """
        Builds a :py:class:`RadarRunnerRequest` to update a radar via JSON RPC API.

        :param int radar_id: ID of the radar to be updated
        :param dict request_dict: A dictionary with values to be updated per the `JSON RPC API Docs`_.

        :return: :py:class:`RadarRunnerRequest`

        Example::

            update_dict = {'title': 'New title for radar'}
            update_req = runner_session.build_problem_update_request(12345, update_dict)
            update_req = send_and_wait_for_response()
            # If the update fails, a :py:class:`RadarRunnerRPCException` will be raised

        """
        base_dict = {'id': radar_id}
        base_dict.update(request_dict)
        return RadarRunnerRequest(
            self.json_rpc,
            'updateProblem',
            self.get_incremental_request_id(),
            {'problem': base_dict}
        )

    def build_notification_request(self, body: str, title: str = None, subtitle: str = None) -> RadarRunnerRequest:
        base_dict = {'body': body}
        if title is not None:
            base_dict['title'] = title
        if subtitle is not None:
            base_dict['subtitle'] = subtitle

        return RadarRunnerRequest(
            self.json_rpc,
            'notify',
            self.get_incremental_request_id(),
            base_dict
        )
