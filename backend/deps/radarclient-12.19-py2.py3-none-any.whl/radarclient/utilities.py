"""
Collection of utility functions that can be used to make life a bit easier
"""
from __future__ import print_function
from __future__ import division
from __future__ import unicode_literals
from __future__ import absolute_import
from sys import path_importer_cache

from radarclient import compat
import logging
from copy import copy, deepcopy
from math import ceil
from datetime import datetime, timedelta
from functools import total_ordering, reduce
from operator import getitem

logger = logging.getLogger('radarclient')
logger.addHandler(logging.NullHandler())

@total_ordering
class RadarProtocolVersion(object):

    # Special marker value that lets clients opt into in-development server-side features.
    pre_release_string = 'pre-release'
    v2_2_or_higher_string = '2.2-or-higher'
    current_default_string = '2.2'
    current_minimum_string = '2.2' # the current minimum version that the server implements even if the client asks for a lower one

    def __init__(self, version_string):
        if version_string == self.pre_release_string:
            self.is_pre_release = True
            return
        self.is_pre_release = False
        if version_string == self.v2_2_or_higher_string:
            version_string = self.current_default_string
        self.version_components = [int(x) for x in version_string.split('.')]

    def __lt__(self, other):
        if self.is_pre_release or other.is_pre_release:
            return other.is_pre_release and not self.is_pre_release

        for self_value, other_value in self.enumerate_version_components(self, other):
            if self_value > other_value:
                break
            if self_value < other_value:
                return True
        return False

    def __eq__(self, other):
        if self.is_pre_release or other.is_pre_release:
            return self.is_pre_release == other.is_pre_release

        for self_value, other_value in self.enumerate_version_components(self, other):
            if self_value != other_value:
                return False
        return True

    @staticmethod
    def enumerate_version_components(a, b):
        for i in range(max(len(a.version_components), len(b.version_components))):
            a_value_at_index_or_0 = (a.version_components[i:i + 1] or [0])[0]
            b_value_at_index_or_0 = (b.version_components[i:i + 1] or [0])[0]
            yield a_value_at_index_or_0, b_value_at_index_or_0

    def __str__(self):
        if self.is_pre_release:
            return self.pre_release_string
        return '.'.join([str(x) for x in self.version_components])

    def __repr__(self):
        return '<RadarProtocolVersion {}>'.format(str(self))

    @classmethod
    def from_string_or_instance(cls, string_or_protocol_version_instance):
        if isinstance(string_or_protocol_version_instance, cls):
            return string_or_protocol_version_instance
        return cls(string_or_protocol_version_instance)


class ChunkQueryDictGenerator(object):
    """
    Chunks up a query dictionary that would be used to find radars by the specified datetime value. The
    default ``chunking_key`` is ``createdAt``. The ``request_data`` query dict must contain a value for
    ``<chunking_key>['gt']`` or ``<chunking_key>['gte']``. Values can be either tz aware ``datetimes``
    or strings formatted for radar querying per the Date and Time info seen at `Radar Date and Time Format`_.
    This will also work with a len() call but the size is only an estimate.

    :param dict query_dict: query dictionary to chunk up
    :param float chunk_hours: size of each of the chunks in hours. Can be decimal if needed
    :param str chunking_value: key for datetime to chunk up the query with

    .. note::
        The ISO8601-formatted datetime strings in ``query_dict`` must be adjusted to the UTC timezone
        for use specifically with :py:meth:`~radarclient.client.RadarClient.find_radars_multithreaded`.

    If you are using the Find Problem query syntax documented in the v2.1 API:

    Examples::

        from radarclient import utilities, UTC

        request_data = {
            'state': 'Analyze',
            'createdAt': {
                'gte': '2020-01-01T00:00:00+0000',
                'lt': '2020-01-03T00:00:00+0000'
            }
        }

        # Chunk up the request in to multiple chunks with most chunks being 3 hours
        # Should get 16 query dictionaries back in this case
        request_chunks = utilities.ChunkQueryDictGenerator(request_data, 3)

        # The below will return the same as above
        request_data = {
            'state': 'Analyze',
            'createdAt': {
                'gte': '2020-01-01T00:00:00+0000',
                'lt': datetime(2020, 1, 3, 0, 0, 0, 0, tzinfo=UTC())
            }
        }

        request_gen = utilities.ChunkQueryDictGenerator(request_data, 3)

        # Chunk up the query from a Oct 11 2020 at midnight all the way to right now
        request_data = {
            'state': 'Analyze',
            'createdAt': {
                'gte': '2020-10-11T00:00:00+0000'
            }
        }
        request_gen = utilities.ChunkQueryDictGenerator(request_data, 3)

        # This example requires installing dateparser https://pypi.org/project/dateparser/
        # chunk up a query to get all radars in analyze created since yesterday at 3 pm PDT
        from dateparser import parse

        request_data = {
            'state': 'Analyze',
            'createdAt': {
                'gte': parse('yesterday 3 pm PDT'),
            }
        }
        request_gen = utilities.ChunkQueryDictGenerator(request_data, 1)
        print('Approximately {} query dictionaries will be created by request_gen'.format(len(request_gen))

        # with any of the above you can then use the query for find
        radars = []
        for request_data in request_gen:
            radars += radar_client.find_radars(request_data)

    If you are using the `updated` Find Problem query syntax in the v2.2+ API `(documentation still pending as
    of July 2021)`, ``ChunkQueryDictGenerator`` has been updated to support it. While users are still limited to
    a `single` attribute dictionary matching the ``chunking_key``, it can be at any depth in the query.

    Example::

        # This example uses the new Find Problem structure in API v2.2+ that puts attribute dictionaries
        # into an 'any' or 'all' list at the top level, and will break up the query into 7-day chunks.
        request_data = {
            "all": [
                {
                    "priority": {
                        "eq": 1
                    }
                },
                {
                    "any": [
                        {
                            "keyword": {
                                "eq": "Program Top Issue"
                            }
                        },
                        {
                            "keyword": {
                                "eq": "Seed Blocker"
                            }
                        }
                    ]
                },
                {
                    "originatedOrModifiedBy": {
                        "eq": {
                            "date": {
                                "gte": "2021-07-01T00:00:00-0000",
                                "lt": "2021-07-08T00:00:00-0000"
                            }
                        }
                    }
                }
            ]
        }
        request_gen = radarclient.utilities.ChunkQueryDictGenerator(request_data, 168, chunking_key='originatedOrModifiedBy')

    """

    @staticmethod
    def _convert_if_needed(to_convert):
        from . import ISO8601UTCDateValueConverter
        if isinstance(to_convert, compat.unicode_string_type):
            return ISO8601UTCDateValueConverter.decode_radar_value(to_convert)
        else:
            return to_convert

    def __init__(self, query_dict, chunk_hours, chunking_value='createdAt'):
        self.query_dict = query_dict
        self.chunk_hours = chunk_hours
        self.chunking_key = chunking_value

        def _get_path(json, target_key, path=None):
            to_return = False
            if path is None:
                path = []

            path_pairs = []
            if isinstance(json, list):
                path_pairs = [(_index, _item) for _index, _item in enumerate(json)]
            elif isinstance(json, dict):
                path_pairs = [(_key, _value) for _key, _value in json.items()]

            for location, value in path_pairs:
                path.append(location)
                if location == target_key or _get_path(value, target_key, path) is not False:
                    to_return = path
                    break
                path.pop(-1)

            return to_return

        chunking_key_path = _get_path(query_dict, self.chunking_key)
        if not chunking_key_path:
            raise KeyError('Unable to locate key "{}" in the query dictionary.'.format(self.chunking_key))
        chunking_value = reduce(getitem, chunking_key_path, query_dict)
        if not any(key_name in ['lt', 'lte', 'gt', 'gte'] for key_name in chunking_value.keys()):
            try:
                chunking_key_path.extend(_get_path(chunking_value, 'date'))
                chunking_value = reduce(getitem, chunking_key_path, query_dict)
            except TypeError:
                raise KeyError('Unable to locate the date parameters for the key "{}"'.format(self.chunking_key))

        if chunking_value.get('gte') is not None:
            self.gt_key = 'gte'
        elif chunking_value.get('gt') is not None:
            self.gt_key = 'gt'
        else:
            raise KeyError('Must have "{}" gte or gt a value in query'.format(self.chunking_key))
        self.start_date = self._convert_if_needed(chunking_value[self.gt_key])
        logger.debug('start_date = {}'.format(self.start_date.isoformat()))

        if chunking_value.get('lt') is not None:
            self.end_date = self._convert_if_needed(chunking_value['lt'])
            self.lt_key = 'lt'
        elif chunking_value.get('lte') is not None:
            self.end_date = self._convert_if_needed(chunking_value['lte'])
            self.lt_key = 'lte'
        else:
            self.end_date = datetime.now(self.start_date.tzinfo)
            self.lt_key = 'lt'
        logger.debug('end_date = {}'.format(self.end_date.isoformat()))

        self.size = int(ceil((self.end_date - self.start_date).total_seconds() / 60 / 60 / self.chunk_hours))

        self.generator = self._generate_chunk(chunking_key_path)

    def _generate_chunk(self, chunking_key_path):
        from . import ISO8601UTCDateValueConverter

        current_lt = self.end_date
        current_gt = self.end_date - timedelta(hours=self.chunk_hours)
        iter_count = 0
        while current_lt > self.start_date:
            iter_count += 1
            to_add = deepcopy(self.query_dict)
            if iter_count == 1:
                new_created = {self.lt_key: ISO8601UTCDateValueConverter.encode_radar_value(current_lt)}
            else:
                new_created = {'lt': ISO8601UTCDateValueConverter.encode_radar_value(current_lt)}

            if current_gt > self.start_date:
                new_created['gte'] = ISO8601UTCDateValueConverter.encode_radar_value(current_gt)
            else:
                new_created[self.gt_key] = ISO8601UTCDateValueConverter.encode_radar_value(self.start_date)

            reduce(getitem, chunking_key_path[:-1], to_add)[chunking_key_path[-1]] = new_created

            current_lt = current_lt - timedelta(hours=self.chunk_hours)
            current_gt = current_gt - timedelta(hours=self.chunk_hours)

            yield to_add

    def __len__(self):
        return self.size

    def __iter__(self):
        return self.generator

    def __next__(self):
        self.size -= 1
        return self.generator.next()


def response_code_is_success(code):
    """
    Check if a returned HTTP status code is a success

    :param int code: HTTP status code

    :return: ``True`` if success, ``False`` otherwise
    """
    return 200 <= int(code) < 300


def _convert_response_list_to_dict(response):
    """
    Some single-item response dictionaries are returned inside a list. This method accounts for that by
    returning the single response dictionary from the list.

    In v2.2 this also applies to some error responses (rdar://97676446).

    :meta private:
    """
    if isinstance(response, list) and len(response) == 1:
        return response[0]
    return response


def _strip_id_from_component_dict(_dict):
    """
    For APIs/endpoints that don't take a 'component' dictionary with the 'id' key-value pair, this removes it.

    :meta private:
    """
    if 'component' in _dict and 'id' in _dict['component']:
        del _dict['component']['id']
    return _dict


def _shared_multithreaded_thread_management(exception_queue, thread_set):
    """
    Shared logic for multithreaded thread management

    :param exception_queue: Queue of exceptions from a multithreaded method
    :param thread_set: Set of threads running for a multithreaded method
    """
    if exception_queue.full():
        raise exception_queue.get(timeout=1)

    # This to_remove use here avoids an error of the set changing size during iteration
    to_remove = set()
    for thread in thread_set:
        thread.join(timeout=.1)
        if not thread.is_alive():
            to_remove.add(thread)
    thread_set -= to_remove


def multithreaded_results_gen(result_queue, exception_queue, thread_set):
    """
    Generator function that will return results as they become available from a multithreaded process and
    will raise an exception if one is encountered in one of the threads.

    :param queue.Queue result_queue: queue of results
    :param queue.Queue exception_queue: queue with max size 1. If queue is full, exception in queue is raised
    :param set thread_set: set of thread objects to monitor for completion
    """
    local_thread_set = copy(thread_set)
    while len(local_thread_set) > 0 or not result_queue.empty() or exception_queue.full():
        _shared_multithreaded_thread_management(exception_queue, local_thread_set)

        try:
            yield result_queue.get(timeout=1)
        except compat.queue_module.Empty:
            pass


def wait_for_multithreaded_completion_helper(result_queue, exception_queue, thread_set, process_count, sentinel=None):
    """
    Waits for a multithreaded task to be complete and add sentinel values to the result queue

    :param queue.Queue result_queue: queue of results
    :param queue.Queue exception_queue: queue with max size 1. If queue is full, exception in queue is raised
    :param set thread_set: set of thread objects to monitor for completion
    :param int process_count: Number of multiprocess processes in use. This is the number of sentinel values that
        will be added to the queue
    :param sentinel: The value to add to the queue that indicates no more items will be added. Defaults to `None`
    """
    local_thread_set = copy(thread_set)
    while len(local_thread_set) > 0 or exception_queue.full():
        _shared_multithreaded_thread_management(exception_queue, local_thread_set)

    for _ in range(process_count):
        result_queue.put(sentinel)
