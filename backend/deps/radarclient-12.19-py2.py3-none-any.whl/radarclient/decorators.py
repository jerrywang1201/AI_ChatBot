"""
Store functions to be used as decorators here
"""

import functools
import warnings
import inspect
import os
from .exceptions import DeprecatedMethodException
from .compat import PY2

def deprecated(replacement, version):
    def decorator(f):
        @functools.wraps(replacement)
        def wrapper(*args, **kwds):
            warnings.warn('"{}" is deprecated, please use "{}" instead'.format(f.__name__, replacement.__name__), stacklevel=2)
            return replacement(*args, **kwds)
        wrapper.__doc__ = '.. deprecated:: {}\n\nUse :func:`{}` instead.'.format(version, replacement.__name__)
        return wrapper
    return decorator


def deprecated_in_place(replacement_name, version):
    """
    Decorator to utilize when there isn't a one to one replacement for the deprecated function

    :param str replacement_name: name of replacement function
    :param float version: version function was deprecated

    :rtype: function

    :meta private:
    """
    def decorator(f):
        def wrapper(*args, **kwargs):
            if 'RADARCLIENT_SUPPRESS_DEPRECATION_WARNINGS' not in os.environ:
                warnings.warn(
                    '"{}" is deprecated, please use "{}" instead'.format(f.__name__, replacement_name),
                    stacklevel=2
                )
            return f(*args, **kwargs)
        wrapper.__doc__ = '.. deprecated:: {} use :py:meth:`{}` instead\n'.format(version, replacement_name)
        return wrapper
    return decorator


def deprecated_and_removed(replacement_name, version):
    """
    Decorator to utilize when there isn't a 1:1 replacement for the deprecated function/method, and the original
    code is no longer functional at all. This raises a DeprecatedMethodException to the user with a custom message
    instead of wrapping the call to the replacement function/method.

    :param str replacement_name: name of replacement function
    :param float version: version function was deprecated

    :rtype: Exception

    :meta private:
    """
    def decorator(f):
        message = '"{}()" is deprecated as of {}, please use "{}()" instead'.format(f.__name__, version, replacement_name)
        def wrapper(*args, **kwargs):
            # *args and **kwargs aren't utilized here, but necessary throwaway arguments to make the decorator work
            raise DeprecatedMethodException(message)
        wrapper.__doc__ = '.. deprecated:: {} use :py:meth:`{}` instead\n'.format(version, replacement_name)
        return wrapper
    return decorator

# Backport of Python 3.8 cached_property, but for class methods
class cached_class_property(object):
    """
    Decorator to use on methods to both promote them to a class method (which takes a class
    object as its argument), as well as cache the result in the class' __dict__ so that subsequent
    accesses are fast. For more information, see https://docs.python.org/3/library/functools.html?highlight=decorators#functools.cached_property

    Use this class as a decorator like:

    @cached_class_property
    def foo(cls):
        ...

    On first access to Foo.foo, this property object will call foo(Foo) like a normal @classmethod, but then
    the result will be used to patch the class' __dict__ so that future lookups of "foo"
    return the cached data directly. @cached_property does this in the standard library at the
    instance level, but this decorator works at the class level for class methods.
        
    """
    def __init__(self, func):
        """
        Instantiate a property getter with the function to generate initial results
        as its first argument (i.e. the function that was wrapped by the decorator)
        """
        self.func = func
        self.attrname = func.__name__ if PY2 else None
        self.class_assigned_to = None
        self.__doc__ = func.__doc__

    def __set_name__(self, owner, name):
        """
        The assignment into the class' lookup table after instantiation is here.
        This is the class' __dict__ that needs to be patched on first invocation
        """
        self.attrname = name
        self.class_assigned_to = owner

    def __get__(self, instance, owner=None):
        # Since @cached_class_property is only used in a class definition,
        # the call to its getter will always have instance=None.
        # Call the original function to generate initial results now. If
        # this was called as Bar.foo (with Bar being a subclass of Foo),
        # owner will be Bar.
        val = self.func(owner)

        # Store back to the class dict that originally instantiated/assigned
        # this property so that future lookups return the result immediately. Before
        # Python 3.6, descriptors did not call __set_name__ when assigned as
        # a class method name, so hack around this be searching the mro chain
        # for the object that matches ourselves and patch us out of future lookups.
        if PY2:
            for scls in inspect.getmro(owner):
                if self.attrname in scls.__dict__ and scls.__dict__[self.attrname] == self:
                    setattr(scls, self.attrname, val)
                    break
        else:
            setattr(self.class_assigned_to, self.attrname, val)
        return val
